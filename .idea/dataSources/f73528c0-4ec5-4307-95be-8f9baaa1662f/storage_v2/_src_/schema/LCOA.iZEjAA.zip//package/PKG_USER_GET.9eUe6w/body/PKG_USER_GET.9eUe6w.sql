create package body pkg_user_get as
  function Get_Common_Data_List(ArrSql            in ARR_LONGSTR,
                                PageSize          in number,
                                PageIndex         in number,
                                OperationUserId   in varchar2,
                                OperationFunction in varchar2,
                                CUR_DATA          out sys_refcursor,
                                PagesCount        out number,
                                RowsCount         out number,
                                ErrMsg            out varchar2) return number as
    n_result  number(1) := 0; --0表示成功 非0表示失败
    v_sql     varchar2(32767);
    n_start   number(4);
    n_end     number(4);
    call_time date;
    SqlTxt    varchar2(32767);
  begin
    begin
      call_time := sysdate;
      for i in ArrSql.FIRST .. ArrSql.LAST loop
        SqlTxt := SqlTxt || ArrSql(i);
      end loop;
    end;
    begin
      if PageSize > 0 and PageIndex > 0 then
        n_start := PageSize * (PageIndex - 1) + 1;
        n_end   := PageSize * PageIndex;
        v_sql   := 'select t2.* from (select t1.*,rownum rn from (' ||
                   SqlTxt || ')t1 where rownum<=' || n_end ||
                   ') t2 where rn>=' || n_start;
      else
        v_sql := SqlTxt;
      end if;
      --打开游标，让游标指向结果集
      OPEN CUR_DATA FOR v_sql;

      --查询共有多少条记录
      v_sql := 'select count(*) from (' || SqlTxt || ')';
      execute immediate v_sql
        into RowsCount;

      --统计多少页记录
      if PageSize > 0 and PageIndex > 0 and RowsCount > 0 then
        if mod(RowsCount, PageSize) = 0 then
          PagesCount := RowsCount / PageSize;
        else
          PagesCount := RowsCount / PageSize + 1;
        end if;
      elsif RowsCount > 0 then
        PagesCount := 1;
      else
        PagesCount := 0;
      end if;
      n_result := 0;
    exception
      when others then
        ErrMsg   := 'Get_Common_Data_List: ' || SQLCODE || ',' || SQLERRM;
        n_result := 1;
    end;

    begin
      pkg_common.InsertOperationLog2(OperationUserId,
                                     '查询',
                                     OperationFunction,
                                     SqlTxt,
                                     call_time,
                                     sysdate,
                                     n_result);
    end;

    --正常返回
    if n_result = 0 then
      return 0;
    else
      RAISE_APPLICATION_ERROR(-20999, errmsg, false);
    end if;
  end;
  function Get_Leave_Info(DataId          in varchar2,
                          OperationUserId in varchar2,
                          CUR_INFO        out sys_refcursor,
                          CUR_FLOW        out sys_refcursor,
                          CUR_FILE        out sys_refcursor,
                          ErrMsg          out varchar2) return number as
  begin
    open CUR_INFO for
      select * from LCOA.OA_AFW_LEAVE_INFO t where t.c_leave_id = DataId;
    open CUR_FLOW for
      select *
        from LCOA.Oa_Afw_Workflow_Approval_Flow f
       where f.c_workflow_id = DataId
       order by f.n_approval_order;
    open CUR_FILE for
      select *
        from LCOA.OA_USER_UPLOAD_INFO l
       where l.c_forign_id = DataId
       order by l.d_upload_time;
    return 0;
  exception
    when others then
      ErrMsg := 'Get_Leave_Info: ' || SQLCODE || ',' || SQLERRM;
      RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
  end;
  function Get_Egress_Info(DataId          in varchar2,
                           OperationUserId in varchar2,
                           CUR_INFO        out sys_refcursor,
                           CUR_FLOW        out sys_refcursor,
                           CUR_FILE        out sys_refcursor,
                           ErrMsg          out varchar2) return number as
  begin
    open CUR_INFO for
      select * from LCOA.OA_AFW_EGRESS_INFO t where t.c_egress_id = DataId;
    open CUR_FLOW for
      select *
        from LCOA.Oa_Afw_Workflow_Approval_Flow f
       where f.c_workflow_id = DataId
       order by f.n_approval_order;
    open CUR_FILE for
      select *
        from LCOA.OA_USER_UPLOAD_INFO l
       where l.c_forign_id = DataId
       order by l.d_upload_time;
    return 0;
  exception
    when others then
      ErrMsg := 'Get_Egress_Info: ' || SQLCODE || ',' || SQLERRM;
      RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
  end;
  function Get_News_Info(DataId          in varchar2,
                         OperationUserId in varchar2,
                         CUR_INFO        out sys_refcursor,
                         CUR_NUMB        out sys_refcursor,
                         CUR_FLOW        out sys_refcursor,
                         CUR_FILE        out sys_refcursor,
                         CUR_FEED        out sys_refcursor,
                         ErrMsg          out varchar2) return number as
    approdate date;
  begin
    select t.d_input_time
      into approdate
      from LCOA.OA_MSG_PUBLISH_INFO t
     where t.c_news_id = DataId;
    open CUR_INFO for
      select T.*,
             ORG.V_ORGANIZATION_NAME,
             EMP.V_USER_TITLE,
             tus.v_headpic_aly
        from LCOA.OA_MSG_PUBLISH_INFO t
        LEFT JOIN LCBASE.T_ZIP_USER TUS
          ON T.C_INPUT_USER_ID = TUS.C_USER_ID
         and trunc(approdate) >= trunc(TUS.d_startdate)
         and trunc(approdate) < trunc(TUS.d_enddate)
        LEFT JOIN LCBASE.T_ZIP_ORGANIZATION ORG
          ON ORG.C_ORGANIZATION_ID = TUS.C_ORGANIZATION_ID
         and trunc(approdate) >= trunc(org.d_startdate)
         and trunc(approdate) < trunc(org.d_enddate)
        LEFT JOIN LCBASE.T_EMPLOYEES_INFO EMP
          ON EMP.C_USER_ID = T.C_INPUT_USER_ID
       where t.c_news_id = DataId;
    open CUR_NUMB for
      select r.*, org.v_organization_name, org.c_organization_id
        from LCOA.OA_MSG_PUBLISH_RANGE r, LCBASE.t_ZIP_Organization org
       where r.c_target_id = org.c_organization_id
         and r.c_news_id = DataId
         and trunc(approdate) >= trunc(org.d_startdate)
         and trunc(approdate) < trunc(org.d_enddate);
    open CUR_FLOW for
      select f.*, u.v_headpic_aly
        from LCOA.Oa_Afw_Workflow_Approval_Flow f
        left join lcbase.t_zip_user u
          on u.c_user_id = f.c_approval_user_id
         and trunc(approdate) >= trunc(u.d_startdate)
         and trunc(approdate) < trunc(u.d_enddate)
       where f.c_workflow_id = DataId;
    open CUR_FILE for
      select *
        from LCOA.OA_USER_UPLOAD_INFO l
       where l.c_forign_id = DataId
       order by l.d_upload_time;
    open CUR_FEED for
      select t.*, p.c_pic_addr, decode(i.c_input_user_id, null, 0, 1)
        from lcoa.oa_msg_feed_list t
        left join (select C_PIC_ADDR, c_user_id
                     from lcbase.t_user_pic
                    where N_PIC_TYPE = 0) p
          on p.c_user_id = t.c_feed_user_id
        left join (select c_input_user_id
                     from lcoa.oa_msg_publish_info a
                    where a.N_SIGNATURE_TYPE != 0
                      and C_NEWS_ID = DataId) i
          on i.c_input_user_id = t.c_feed_user_id
       where t.c_msg_id = DataId
       order by t.d_feed_time desc;
    return 0;
  exception
    when others then
      ErrMsg := 'Get_News_Info: ' || SQLCODE || ',' || SQLERRM;
      RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
  end;
  function Get_Expense_Info(DataId          in varchar2,
                            OperationUserId in varchar2,
                            CUR_INFO        out sys_refcursor,
                            CUR_ITEM        out sys_refcursor,
                            CUR_FLOW        out sys_refcursor,
                            CUR_FILE        out sys_refcursor,
                            ErrMsg          out varchar2) return number as
  begin
    open CUR_INFO for
      select *
        from LCOA.OA_EPS_EXPENSES_INFO t
       where t.c_expenses_id = DataId;
    open CUR_ITEM for
      select *
        from LCOA.OA_EPS_EXPENSES_ITEM i
       where i.c_expenses_id = DataId;
    open CUR_FLOW for
      select *
        from LCOA.Oa_Afw_Workflow_Approval_Flow f
       where f.c_workflow_id = DataId
       order by f.n_approval_order;
    open CUR_FILE for
      select *
        from LCOA.OA_USER_UPLOAD_INFO l
       where l.c_forign_id = DataId
       order by l.d_upload_time;
    return 0;
  exception
    when others then
      ErrMsg := 'Get_Expense_Info: ' || SQLCODE || ',' || SQLERRM;
      RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
  end;
end pkg_user_get;

/

