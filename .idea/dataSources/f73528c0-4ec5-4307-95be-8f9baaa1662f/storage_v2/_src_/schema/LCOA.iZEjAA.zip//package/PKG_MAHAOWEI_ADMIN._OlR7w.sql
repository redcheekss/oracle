create package pkg_mahaowei_admin is

  -- author  : edz
  -- created : 2020/5/9 17:46:17
  -- purpose : 

  function move_order(DataInfo        in varchar2,
                      OperationUserId IN VARCHAR2,
                      ErrMsg          out varchar2) return number;

  function get_organization_userlist(OperationUserId    IN VARCHAR2,
                                     UserOrOrganization in varchar2,
                                     OrganizationList   out sys_refcursor,
                                     UserInfoList       out sys_refcursor,
                                     ErrMsg             out varchar2)
    return number;

  function get_employees_list(OrganizationId  in varchar2,
                              status          in varchar2,
                              pageNum         in number,
                              PageSize        in number,
                              OperationUserId IN VARCHAR2,
                              DataList        out sys_refcursor,
                              owner           out varchar2,
                              BpName          out varchar2,
                              VpName          out varchar2,
                              totalPage       out number,
                              totalCount      out number,
                              ErrMsg          out varchar2) return number;

  function query_employeeinfo(OperationUserId IN VARCHAR2,
                              UserId          in varchar2,
                              bp              out number,
                              owner           out number,
                              vp              out number,
                              EmployeesInfo   out sys_refcursor,
                              UserInfo        out sys_refcursor,
                              UserpicList     out sys_refcursor,
                              ErrMsg          out varchar2) return number;
  function update_uorder(uorder   in number,
                         dorder   in number,
                         parentid in out varchar,
                         ErrMsg   out varchar2) return number;

  function update_dorder(uorder         in number,
                         OrganizationId in out varchar,
                         ErrMsg         out varchar2) return number;

  function count_order(OrganizationId in out varchar, ErrMsg out varchar2)
    return number;

  function insert_rest_days(DataInfo        in ARR_LONGSTR,
                            OperationUserId IN VARCHAR2,
                            ErrMsg          out varchar2) return number;

  function get_obvnames(nOrganizationId in varchar2,
                        owner           out VARCHAR2,
                        BpName          out VARCHAR2,
                        VpName          out VARCHAR2,
                        ErrMsg          out varchar2) return number;
  function count_organizationid(nOrganizationId in varchar2,
                                status          in VARCHAR2,
                                ErrMsg          out varchar2) return number;

  function RemoveOne_Schedule_Info(FlowId          in varchar2,
                                   OperationUserId in varchar2,
                                   ErrMsg          out varchar2)
    return number;

  procedure Create_Next_Approval_Todo(WorkflowId     in varchar2,
                                      TodoTitle      in varchar2,
                                      TodoSender_Cur out sys_refcursor);

  function get_email_content(OperationUserId IN VARCHAR2,
                             EmailList       out sys_refcursor,
                             ErrMsg          out varchar2) return number;

  procedure insert_email_info(WorkflowId     in varchar2,
                              ApprovalUserId in varchar2,
                              ContentFlag    in varchar2,
                              ErrMsg         out varchar2);

  function get_applyuser_nameandemail(WorkflowId   IN VARCHAR2,
                                      workflowtype in varchar2,
                                      applyuserid  out VARCHAR2,
                                      applyname    out varchar2,
                                      applyemail   out varchar2,
                                      ErrMsg       out varchar2)
    return number;

  procedure get_cancel_nameandemail(WorkflowId    IN VARCHAR2,
                                    approvalname  out varchar2,
                                    approvalemail out varchar2,
                                    ErrMsg        out varchar2);

end pkg_mahaowei_admin;
/

