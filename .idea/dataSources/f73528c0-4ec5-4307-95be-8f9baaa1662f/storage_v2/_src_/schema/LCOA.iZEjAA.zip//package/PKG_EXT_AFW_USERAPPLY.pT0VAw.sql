create package PKG_EXT_AFW_USERAPPLY is

  -- Author  : USER
  -- Created : 2020/4/12 16:43:10
  -- Purpose : TEMP

  -- Public type declarations
  --type <TypeName> is <Datatype>;

  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  --<VariableName> <Datatype>;
  -- Public function and procedure declarations
  --function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;

  --新增请假信息
  --传入参数：DataInfo以^分割的请假相关字段串
  --          ArrFile 附件列表
  --          OperationUserId 申请人Id
  --输出参数：DataId返回请假Id
  --          ErrMsg返回错误信息
  --返回值：0成功 非0表示执行失败 
  function Insert_Leave_Info(DataInfo        in varchar2,
                             ArrFile         in ARR_LONGSTR,
                             OperationUserId in varchar2,
                             DataId          out varchar2,
                             ErrMsg          out varchar2) return number;

  function Update_Schedule_Info(DataInfo        IN VARCHAR2,
                                ArrAttendee     in ARR_LONGSTR,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) return number;

end PKG_EXT_AFW_USERAPPLY;
/

