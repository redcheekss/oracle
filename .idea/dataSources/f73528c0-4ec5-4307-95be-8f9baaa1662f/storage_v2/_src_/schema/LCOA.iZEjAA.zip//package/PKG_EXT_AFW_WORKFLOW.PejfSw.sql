create package PKG_EXT_AFW_WORKFLOW is

  -- Author  : LIHUAWEI
  -- Created : 2020/4/20 16:16:23
  -- Purpose : 审批流统一对外接口

  function Approval_Target_Pass(WorkflowId      in varchar2,
                                WorkflowType    in number,
                                ApprovalUserId  in varchar2,
                                ApprovalRemark  in varchar2,
                                MsgSender_Cur   out sys_refcursor,
                                TodoSender_Cur  out sys_refcursor,
                                IsAll_MsgSender out number, --0是否，1是全部          
                                ErrMsg          out varchar2) return number;

  function Approval_Target_Reject(WorkflowId      in varchar2,
                                  WorkflowType    in number,
                                  ApprovalUserId  in varchar2,
                                  ApprovalRemark  in varchar2,
                                  MsgSender_Cur   out sys_refcursor,
                                  TodoSender_Cur  out sys_refcursor,
                                  IsAll_MsgSender out number, --0是否，1是全部          
                                  ErrMsg          out varchar2) return number;

  function Approval_Target_Cancel(WorkflowId      in varchar2,
                                  WorkflowType    in number,
                                  WorkflowUserId  in varchar2,
                                  ApprovalRemark  in varchar2,
                                  MsgSender_Cur   out sys_refcursor,
                                  TodoSender_Cur  out sys_refcursor,
                                  IsAll_MsgSender out number, --0是否，1是全部          
                                  ErrMsg          out varchar2) return number;

  function Approval_Target_Delay(WorkflowId      in varchar2,
                                 WorkflowType    in number,
                                 WorkflowUserId  in varchar2,
                                 ApprovalRemark  in varchar2,
                                 MsgSender_Cur   out sys_refcursor,
                                 TodoSender_Cur  out sys_refcursor,
                                 IsAll_MsgSender out number, --0是否，1是全部          
                                 ErrMsg          out varchar2) return number;

  function Approval_Target_Skip(WorkflowId      in varchar2,
                                WorkflowType    in number,
                                WorkflowUserId  in varchar2,
                                ApprovalRemark  in varchar2,
                                MsgSender_Cur   out sys_refcursor,
                                TodoSender_Cur  out sys_refcursor,
                                IsAll_MsgSender out number, --0是否，1是全部          
                                ErrMsg          out varchar2) return number;

  function Approval_Target_ResetSkip(WorkflowUserId in varchar2,
                                     ErrMsg         out varchar2)
    return number;

  function Get_Pre_Approval_Userlist(WorkflowUserId     in varchar2,
                                     WorkflowType       in number,
                                     WorkflowSubtype    in number,
                                     DStartTime         in varchar2,
                                     DEndTime           in varchar2,
                                     New_OrganizationId in varchar2,
                                     Days               out number,
                                     Hours              out number,
                                     CUR_DATA           out sys_refcursor,
                                     ErrMsg             out varchar2)
    return number;

end PKG_EXT_AFW_WORKFLOW;
/

