create package pkg_mahaowei_trans_info is
  function get_approval_list(recordvo        in varchar2,
                             pageNum         in number,
                             PageSize        in number,
                             getapprovallist out sys_refcursor,
                             totalPage       out number,
                             totalCount      out number,
                             errmsg          out varchar2) return number;

  function get_apply_list(recordvo     in varchar2,
                          pageNum      in number,
                          PageSize     in number,
                          getapplylist out sys_refcursor,
                          totalPage    out number,
                          totalCount   out number,
                          errmsg       out varchar2) return number;

  function add_leave_list(userid            in varchar2,
                          startdate         in varchar2,
                          enddate           in varchar2,
                          approvalapplytype in number,
                          errmsg            out varchar2) return number;

  function add_egress_list(userid            in varchar2,
                           startdate         in varchar2,
                           enddate           in varchar2,
                           approvalapplytype in number,
                           errmsg            out varchar2) return number;

  function add_news_list(userid            in varchar2,
                         startdate         in varchar2,
                         enddate           in varchar2,
                         approvalapplytype in number,
                         errmsg            out varchar2) return number;

  function add_adjustpost_list(userid            in varchar2,
                               startdate         in varchar2,
                               enddate           in varchar2,
                               approvalapplytype in number,
                               errmsg            out varchar2) return number;

  function add_promotion_list(userid            in varchar2,
                              startdate         in varchar2,
                              enddate           in varchar2,
                              approvalapplytype in number,
                              errmsg            out varchar2) return number;

  function get_user_todo(userId      in varchar2,
                         pageNum     in number,
                         PageSize    in number,
                         getUserTodo out sys_refcursor,
                         totalPage   out number,
                         totalCount  out number,
                         errmsg      out varchar2) return number;

  function add_usertodo_forward(userid in varchar2, errmsg out varchar2)
    return number;

  function add_usertodo_meetinfo(userid in varchar2, errmsg out varchar2)
    return number;

  function add_usertodo_promotion(userid in varchar2, errmsg out varchar2)
    return number;
end;
/

