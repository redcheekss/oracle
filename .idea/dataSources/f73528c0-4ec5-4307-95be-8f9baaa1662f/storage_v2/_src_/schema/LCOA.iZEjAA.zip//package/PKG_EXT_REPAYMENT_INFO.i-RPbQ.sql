create package pkg_ext_repayment_info is

  --1 新增立即还款
  --list<loanId,amount,picAddress>
  function add_installRepayment(data_value   IN ARR_LONGSTR,
                                data_images  in ARR_LONGSTR,
                                operation_id in char,
                                c_cursor     out sys_refcursor,
                                ErrMsg       OUT VARCHAR2) RETURN NUMBER;

  --2报销还款
  --list<loanId,amount：报销id，还款总金额>
  function add_installRepayment2(data_value   IN varchar2,
                                 operation_id in char,
                                 c_cursor     out sys_refcursor,
                                 ErrMsg       OUT VARCHAR2) RETURN NUMBER;

  --3 确认还款单详情
  function getRepaymentInfo(dataId                   in varchar2,
                            operationId              in char,
                            OaAfwRepaymentInfoEntity OUT SYS_REFCURSOR, --还款确认单详情
                            loanList                 OUT SYS_REFCURSOR, --借款单列表--包含图片
                            files                    OUT SYS_REFCURSOR, --还款单附件列表
                            ErrMsg                   OUT VARCHAR2)
    RETURN NUMBER;

  --4 个人-确认还款确认单
  function passRepayment(Repayment   IN ARR_LONGSTR,
	                       v_id        in char,
                         operationId in char,
                         c_cursor    out sys_refcursor,
                         ErrMsg      OUT VARCHAR2)
  
   RETURN NUMBER;
  --5报销-确认还款确认单
  function passRepayment2(Repayment   IN varchar2,
                          operationId in char,
                          ErrMsg      OUT VARCHAR2)
  
   RETURN NUMBER;
  --6 收款列表
  function get_Payment_list(data_value   in varchar2,
                            pageNum      in number,
                            PageSize     in number,
                            operationId  in char,
                            getapplylist out sys_refcursor,
                            totalPage    out number,
                            totalCount   out number,
                            errmsg       out varchar2) RETURN NUMBER;

  --重置 
  function ResetSkip(ApprovalUserId in varchar2, ErrMsg out varchar2)
    return number;

  --跳过
  function Target_Skip(repay_id     in varchar2,
                       operation_id in char,
                       ErrMsg       out varchar2) return number;

  function no_loanList(OperationUserId in varchar2,
                       loanList        OUT SYS_REFCURSOR,
                       loanFiles       OUT SYS_REFCURSOR,
                       ErrMsg          OUT VARCHAR2) RETURN NUMBER;
											 
	function  clear_content_info(V_CLAIM_FORMID in char, operation_id in char,ErrMsg out varchar2) 
	return number; 										 
											 

end pkg_ext_repayment_info;
/

