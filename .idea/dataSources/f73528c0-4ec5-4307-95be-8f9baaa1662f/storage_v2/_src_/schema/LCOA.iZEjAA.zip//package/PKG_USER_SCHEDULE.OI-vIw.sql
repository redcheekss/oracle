create package pkg_user_schedule as
  
  --检查发布人
  --传入参数：IssuerUserId发布人ID
  --传出参数：ErrMsg错误输出
  --返回值：0身份合法，非0身份非法
  function VerifyIssuerIdentity(IssuerUserId in varchar2,
                                ErrMsg       out varchar2) return number;

  function Insert_Leave_Info(DataInfo        in varchar2,
                             ArrFile         in ARR_LONGSTR,
                             OperationUserId in varchar2,
                             DataId          out varchar2,
                             ErrMsg          out varchar2) return number;

  function Update_Leave_Info(DataInfo        in varchar2,
                             OperationUserId in varchar2,
                             ErrMsg          out varchar2) return number;

  function Insert_Egress_Info(DataInfo        in varchar2,
                              ArrFile         in ARR_LONGSTR,
                              OperationUserId in varchar2,
                              DataId          out varchar2,
                              ErrMsg          out varchar2) return number;

  function Update_Egress_Info(DataInfo        in varchar2,
                              OperationUserId in varchar2,
                              ErrMsg          out varchar2) return number;

  function Insert_News_Info(DataInfo        in varchar2,
                            NewsContent     in clob,
                            ArrFile         in arr_longstr,
                            OrgRange        in arr_longstr,
                            OperationUserId in varchar2,
                            DataId          out varchar2,
                            ErrMsg          out varchar2) return number;

  function Update_News_Info(DataInfo        in varchar2,
                            NewsContent     in clob,
                            ArrFile         in arr_longstr,
                            OrgRange        in arr_longstr,
                            OperationUserId in varchar2,
                            DataId          out varchar2,
                            ErrMsg          out varchar2) return number;

  function Insert_Expense_Info(DataInfo        in varchar2,
                               OperationUserId in varchar2,
                               DataId          out varchar2,
                               ErrMsg          out varchar2) return number;

  function Update_Expense_Info(DataInfo        in varchar2,
                               OperationUserId in varchar2,
                               ErrMsg          out varchar2) return number;

  function Remove_News_Info(NewsId          IN VARCHAR2,
                            OperationUserId IN VARCHAR2,
                            ErrMsg          OUT VARCHAR2) return NUMBER;

  function Insert_Schedule_Info(DataInfo        in varchar2,
                                ArrAttendee     in ARR_LONGSTR,
                                OperationUserId in varchar2,
                                DataId          out varchar2,
                                ErrMsg          out varchar2) return number;

  function Update_Schedule_Info(DataInfo        IN VARCHAR2,
                                ArrAttendee     in ARR_LONGSTR,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) return NUMBER;

  function Remove_Schedule_Info(ScheduleId      IN VARCHAR2,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) return NUMBER;

  procedure Insert_User_Upload_File(DataId   varchar2,
                                    FileType number,
                                    ArrFile  ARR_LONGSTR);

  function RemoveOne_Schedule_Info(FlowId          in varchar2,
                                   OperationUserId in varchar2,
                                   ErrMsg          out varchar2)
    return number;

  function cancleEmailSend(schId in varchar2, ErrMsg out varchar2)
    return number;

  function sendEmail(ErrMsg out varchar2) return number;

end pkg_user_schedule;
/

