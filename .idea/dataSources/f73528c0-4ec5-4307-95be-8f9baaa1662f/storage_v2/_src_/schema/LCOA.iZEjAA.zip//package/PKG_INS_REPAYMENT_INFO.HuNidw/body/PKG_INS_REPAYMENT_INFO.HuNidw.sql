create package body pkg_ins_repayment_info is
  --1 查询到期还款
  function repaymentStatus(ErrMsg OUT VARCHAR2) RETURN NUMBER
  
   is
    type User_ids is record(
      C_USER_ID   lcoa.OA_AFW_LOAN_INFO.c_user_id%type, --申请人id
      FLOW_NUMBER lcoa.OA_AFW_LOAN_INFO.v_flow_number%type --借款单id
      );
  
    rows_count integer; --记录返回函数
    result_int integer; --返回结果
  
    C_AFW_LOAN sys_refcursor; --定义游标接收
    users      User_ids; --定义游标接收
  begin
    --查询到到期还款的用户
    SELECT count(*)
      INTO rows_count
      FROM LCOA.OA_AFW_LOAN_INFO
     WHERE N_PAYOFF_STATUS = 0;
    if rows_count > 0 then
      open C_AFW_LOAN for
        SELECT C_USER_ID, V_FLOW_NUMBER
          FROM LCOA.OA_AFW_LOAN_INFO
         WHERE N_PAYOFF_STATUS = 0
           and N_PAYOFF_STATUS = 5;
      fetch C_AFW_LOAN
        into users;
      while C_AFW_LOAN%found loop
        --给到期还款的用户发送消息
        result_int := add_todo_info(users.C_USER_ID,
                                    users.FLOW_NUMBER,
                                    ErrMsg);
        if result_int = -1 then
          return result_int;
        end if;
        fetch C_AFW_LOAN
          into users;
      end loop;
    end if;
    result_int := 0;
    return result_int;
  
  end repaymentStatus;

  --2 未还清借款列表
  function no_loanList(OperationUserId in varchar2,
                       loanList        OUT SYS_REFCURSOR,
                       loanFiles       OUT SYS_REFCURSOR,
                       ErrMsg          OUT VARCHAR2) RETURN NUMBER is
  begin
    open loanList for
      SELECT L.C_ID,
             L.V_FLOW_NUMBER,
             L.C_USER_ID,
             L.N_AMOUNT,
             L.V_CAUSE,
             L.N_LOAN_TYPE,
             L.D_PLAN_REPAYMENT_DATE,
             L.D_EXTENSION_DATE,
             L.N_EXTENSION_TIMES,
             L.N_REPAID_AMOUNT,
             L.N_STATUS,
             L.N_APPROVAL_STATUS,
             L.N_PAYOFF_STATUS,
             L.D_APPLY_TIME,
             L.C_PAYMENT_ID,
             L.N_PAYMENT_TYPE,
             L.C_USER_CORP_ID,
             L.n_Unconfirmed_Amount,
             L.d_Payoff_Time
        FROM LCOA.OA_AFW_LOAN_INFO L
       WHERE L.N_PAYOFF_STATUS = 0
         AND L.N_APPROVAL_STATUS = 5
         AND L.C_USER_ID = OperationUserId;
    open loanFiles for
      SELECT a.c_img_id,
             a.c_business_id,
             a.n_image_size,
             a.n_image_type,
             a.v_image_url,
             a.d_image_date,
             a.n_isdel_state,
             a.v_input_user_name,
             a.d_input_time,
             a.v_image_name,
             a.n_operation_type,
             a.c_input_user_id,
             a.v_hash_content,
             lr.c_loan_id
        FROM LCOA.OA_AFW_LOAN_INFO L
       inner join oa_afw_loan_repayment lr
          on lr.c_loan_id = l.c_id
       inner join lcoa.oa_afw_repayment_info r
          on lr.c_replayment_id = r.c_id
       inner join lcoa.t_lk_attachment a
          on lr.c_id = a.c_business_id
       WHERE L.N_PAYOFF_STATUS = 0
         AND L.N_APPROVAL_STATUS = 5
         AND L.C_USER_ID = OperationUserId;
  
    ErrMsg := '成功！';
    return 0;
  end no_loanList;

  --3 新增还款确认单
  --立即借款
  --list<loanId,amount,picAddress>
  function add_installRepayment(data_value   IN ARR_LONGSTR,
                                data_images  in ARR_LONGSTR,
                                operation_id in char,
                                c_cursor     out sys_refcursor,
                                ErrMsg       OUT VARCHAR2) RETURN NUMBER
  
   is
    v_date_value  PKG_COMMON.ARR_LONGSTR;
    v_data_images PKG_COMMON.ARR_LONGSTR;
    total         integer;
    loanId        char(32);
    V_FLOWNUMBER  char(32);
    result_int    integer;
    row_count     integer;
    user_id       char(32);
    user_name     varchar2(50);
    AMOUNT        number(10, 2) default 0.00;
    TodoTitle     varchar2(50);
    AMOUNT_total  number(10, 2) default 0.00;
    V_ID          char(32);
    V_ID_2        char(32);
    V_DAMOUNT     number(10, 2) default 0.00;
    v_id_3        char(32);
		vusername     varchar2(50);
		vemail        varchar2(50); 
		V_REPAIDAMOUNT number(10, 2) default 0.00;
		V_UNCONFIRMEDAMOUNT number(10, 2) default 0.00;
		V_REPLAYMENTAMOUNT  number(10, 2) default 0.00;
  begin
    V_FLOWNUMBER := pkg_common.GetFlowNumber('HK', 4); --生成还款单号
    V_ID         := lower(sys_guid());
    total        := data_value.count;
    --获取用户名
    SELECT V_USER_NAME
      into user_name
      FROM lcbase.T_ZIP_USER
     where C_USER_ID = operation_id
       AND D_ENDDATE > SYSDATE;
    --计算总金额
    for i in 1 .. total loop
      v_date_value := PKG_COMMON.Split(data_value(i), '^');
      --AMOUNT_total := AMOUNT_total + v_date_value(2);
 
      --判断借款是否存在
      select count(*)
        into row_count
        from lcoa.OA_AFW_LOAN_INFO
       where C_ID = v_date_value(1);
    
      --根据借款id 获取借款金额
      if row_count > 0 then
      
        select nvl(N_AMOUNT,0),nvl(N_REPAID_AMOUNT,0),nvl(N_UNCONFIRMED_AMOUNT,0)
          into V_DAMOUNT,V_REPAIDAMOUNT,V_UNCONFIRMEDAMOUNT
          from lcoa.OA_AFW_LOAN_INFO
         where C_ID = v_date_value(1);
        
			   --计算还款金额
				 V_REPLAYMENTAMOUNT:=(V_DAMOUNT-V_REPAIDAMOUNT-V_UNCONFIRMEDAMOUNT);
				  --还款总金额
				 AMOUNT_total := (AMOUNT_total + V_REPLAYMENTAMOUNT);
				 

        
      end if;
    end loop;
  
    -- 还款记录表
    INSERT INTO LCOA.OA_AFW_REPAYMENT_INFO
      (C_ID, --主键id
       V_FLOW_NUMBER, --还款单号
       C_USER_ID, --还款人
       N_REPLAYMENT_AMOUNT, --还款金额
       D_REPLAYMENT_TIME, --提交还款单的时间
       D_ARRIVAL_TIME, --入账时间(暂时没有用着，先保留)
       N_REPLAYMENT_TYPE, --还款类型(个人还款，报销还款)
       C_CLAIM_FORM_ID, --报销ID:个人还款时为空
       N_STATUS, --状态
       N_CONFIRM_STATUS, --确认状态:0待确认 1已确认
       D_APPLY_TIME, -- 申请时间
       D_UPDATE_TIME) --更新时间
    VALUES
      (V_ID, --主键id
       V_FLOWNUMBER, --还款单号
       operation_id, --用户id
       AMOUNT_total, --还款金额
       sysdate,
       '', --入账时间(确认还款时候需要更新时间为:当前确认时间。)
       1, --1 为个人
       '', --还款类型为个人时，为空
       0, --0 为正常，1 为作废，默认为0
       0, --确认状态0 为确认，1 为已确认（确认还款需要更新状态为1 ：已确认）
       SYSDATE,
       ''); --(更新时间确认时间：当前时间。)
  
    --处理借款单还款记录表
    for i in 1 .. total loop
				V_REPLAYMENTAMOUNT:=0.00;
				V_UNCONFIRMEDAMOUNT:=0.00;
				V_REPLAYMENTAMOUNT:=0.00;
				
        v_date_value := PKG_COMMON.Split(data_value(i), '^');
				--查询申请金额、还款金额、待确定金额
				select nvl(N_AMOUNT,0),nvl(N_REPAID_AMOUNT,0),nvl(N_UNCONFIRMED_AMOUNT,0)
				into V_DAMOUNT,V_REPAIDAMOUNT,V_UNCONFIRMEDAMOUNT
				from lcoa.OA_AFW_LOAN_INFO
			 where C_ID = v_date_value(1);
			  --还款金额
			  V_REPLAYMENTAMOUNT:=(V_DAMOUNT-V_REPAIDAMOUNT-V_UNCONFIRMEDAMOUNT);
					
			--借款单还款记录表
      V_ID_2 := lower(sys_guid());
      INSERT INTO LCOA.OA_AFW_LOAN_REPAYMENT
        (C_ID, --主键id
         C_REPLAYMENT_ID, --还款id
         C_LOAN_ID, --借款id
         N_REPLAYMENT_AMOUNT, --还款金额
         D_ARRIVAL_TIME) --入账时间
      VALUES
        (V_ID_2, V_ID, v_date_value(1),V_REPLAYMENTAMOUNT, '');


       --更新借款表 《待确认还款》 C_PAYMENT_CORP_ID
        update lcoa.OA_AFW_LOAN_INFO
           set N_UNCONFIRMED_AMOUNT =V_REPLAYMENTAMOUNT
        
         where C_ID = v_date_value(1); 

   
      -- 操作图片信息表
      --total := data_images.count;
      for i in 1 .. data_images.count loop
        v_data_images := PKG_COMMON.Split(trim(data_images(i)), '^');
      
        if v_data_images(1) <> v_date_value(1) then
          continue;
        end if;
        INSERT INTO LCOA.T_LK_ATTACHMENT
          (C_IMG_ID, --图片id
           C_BUSINESS_ID, --业务id
           N_IMAGE_SIZE, -- 图片大小
           N_IMAGE_TYPE, --图片类型
           V_IMAGE_URL, --上传图片路径
           D_IMAGE_DATE, --图片上传时间
           N_ISDEL_STATE, --是否删除标识
           V_INPUT_USER_NAME, --录入人
           D_INPUT_TIME, --录入时间
           V_IMAGE_NAME, --源文件
           N_OPERATION_TYPE, --操作类型
           C_INPUT_USER_ID, --录入用户id
           V_HASH_CONTENT) --文件hash 值
        VALUES
          (lower(sys_guid()),
           V_ID_2, --关系表主键id
           v_data_images(4), --图片大小
           v_data_images(5), --图片类型
           v_data_images(6), --图片上传url
           sysdate,
           0,
           user_name, --用户名字
           sysdate,
           '',
           5, -- 5.还款单附件
           operation_id, --录入id
           v_data_images(14));
      end loop;
    
      ---借款待归还提醒待办状态更新
      update lcoa.oa_tdo_todo_info info
         set info.n_status = 1
       where info.c_todo_data_id = v_date_value(1)
         and info.n_todo_type = 55;
    end loop;
  
    --发送待办
    TodoTitle := '【还款确认】'||user_name || '的还款待确认';
    insert into lcoa.OA_TDO_TODO_INFO
      (c_todo_id,
       c_todo_user_id,
       d_todo_time,
       n_todo_type,
       v_todo_title,
       d_input_time,
       n_status,
       d_done_time,
       c_todo_data_id)
    
      select lower(sys_guid()),
             r.c_user_id,
             sysdate,
             56,
             TodoTitle,
             sysdate,
             0,
             null,
             V_ID
        from oa_aut_user_role r
       where r.c_role_id =
             (select a.c_role_id
                from Oa_Aut_Role a, oa_afw_workflow_user_type b
               where trim(b.v_approval_user_id) = to_char(a.role_type)
                 and trim(b.v_approval_user_id) = '61');
  
  
  
   --发送邮件
     v_id_3:= lower(sys_guid());
          INSERT INTO
          LCOA.OA_MSG_EMAIL_INFO (C_ID,
          C_DATAID,
          N_OPERATION_TYPE,
          N_MESSAGE_TYPE,
          N_TYPE,
          V_FROM_NAME,
          V_FROM_ADDR,
          V_SUBJECT,
          V_CONTENT,
          N_DEL_STATUS,
          N_SEND_STATUS,
          D_SET_SEND_DATE,
          D_REAL_SEND_DATE,
          N_SEND_ONEBYONE,
          N_ALL_USER)
      VALUES(v_id_3,
          V_ID,
          6,
          1,
          1,
          null,
          null,
        '【还款确认】'||user_name||'的还款待确认',
          '您有一笔还款待确认，还款人【'||user_name||'】，请及时登录OA系统在【首页- 我的待办】中进行确认。',
          0,
          0,
          sysdate,
          null,
          0,
          1);
   
		 select 
					u.v_user_name ,u.v_email 
		 into vusername,vemail  
		 from 
					lcbase.t_zip_user u
		 left join 
					lcoa.oa_afw_repayment_info r
		 on u.c_user_id = r.c_user_id
		 where  u.d_enddate >sysdate and r.c_id  = v_id;
	   
    --邮件发送地址列表
    INSERT INTO LCOA.OA_MSG_RECIPIENT_ADDR
        (C_ID, V_RECIPIENT, V_SENDTOS_ADDR)
      VALUES
        (v_id_3, vusername, vemail);
        
    --commit; -- 测试用
    ErrMsg := '成功！';
    return 0;
  exception
    when others then
      dbms_output.put_line('新增还款确认单: ' || sqlcode || ',' || sqlerrm);
      rollback;
      return - 1;
  end add_installRepayment;

  --3.3报销还款
  --list<loanId,amount：报销id，还款总金额>
  function add_installRepayment2(data_value   IN varchar2,
                                 operation_id in char,
                                 c_cursor     out sys_refcursor,
                                 ErrMsg       OUT VARCHAR2) RETURN NUMBER
  
   is
    type R_OAAFWLOANINFO is record(
      C_USER_ID            lcoa.oa_afw_loan_info.c_user_id%type,
      C_ID                 lcoa.oa_afw_loan_info.c_id%type,
      V_FLOW_NUMBER        lcoa.oa_afw_loan_info.v_flow_number%type,
      N_AMOUNT             lcoa.oa_afw_loan_info.N_AMOUNT%type,
      N_REPAID_AMOUNT      lcoa.oa_afw_loan_info.N_REPAID_AMOUNT%type,
      N_UNCONFIRMED_AMOUNT lcoa.oa_afw_loan_info.N_UNCONFIRMED_AMOUNT%type);
    V_FLOWNUMBER char(32);
    -- to_date(DATAARR(6), 'yyyymmddhh24miss')
    total        integer;
    amount_total number(10, 2) default 0.00; --报销总金额
  
    V_LoanBalance number(10, 2) default 0.00; --借款本次偿还金额
  
    v_date_value PKG_COMMON.ARR_LONGSTR;
  
    V_OAAFWLOANINFO sys_refcursor;
  
    V_OUT_OAAFWLOANINFO R_OAAFWLOANINFO;
    V_ID                char(32);
    V_ID_2              char(32);
    v_amount_remaining  number;
    V_LoanBalanceReal   number;
		amount_total2 number(10, 2) default 0.00; 
  begin
    --获取总金额
    v_date_value := PKG_COMMON.Split(data_value, '^');
    amount_total := v_date_value(2); --报销还款总金额
	
    V_FLOWNUMBER := pkg_common.GetFlowNumber('HK', 4); --生成还款单号
    V_ID         := lower(sys_guid()); --生成还款id
  
    --插入还款记录表
    INSERT INTO LCOA.OA_AFW_REPAYMENT_INFO
      (C_ID, --主键id
       V_FLOW_NUMBER, --还款单号
       C_USER_ID, --还款人
       N_REPLAYMENT_AMOUNT, --还款金额
       D_REPLAYMENT_TIME, --提交还款单的时间
       D_ARRIVAL_TIME, --入账时间(暂时没有用着，先保留)
       N_REPLAYMENT_TYPE, --还款类型(个人还款，报销还款)
       C_CLAIM_FORM_ID, --报销ID:个人还款时为空
       N_STATUS, --状态
       N_CONFIRM_STATUS, --确认状态:0待确认 1已确认
       D_APPLY_TIME, -- 申请时间
       D_UPDATE_TIME) --更新时间
    VALUES
      (V_ID, --主键id
       V_FLOWNUMBER, --还款单号
       operation_id, --用户id
       amount_total, --报销还款总金额
       sysdate, --提交还款时间
       '', --入账时间                     （ 确认时候：更新为入账时间 ）
       2, --2为报销还款
       trim(v_date_value(1)), --传入报销id
       0, --状态:0正常 1删除（作废）
       0, --确认状态:0待确认 1已确认   （ 确认时候：更新为1已确认）
       SYSDATE, -- 申请时间
       ''); --更新时间  （ 确认时候：更新次时间）
  
    --根据报销id 查询用户借款信息 放入游标
    --(operation_id 传入用户，因此不需要做特殊处理
    v_amount_remaining := amount_total; --报销待还总金额
   
	
	--判断总金额
				 SELECT  
							to_NUMBER((  
							SELECT  
											SUM(N_AMOUNT)  
							FROM  
											LCOA.OA_AFW_LOAN_INFO oali  
							WHERE  
											oali.C_USER_ID = operation_id  
											AND N_LOAN_TYPE = 1  
											AND N_APPROVAL_STATUS = 5  
											AND N_PAYOFF_STATUS = 0) - (  
							SELECT  
											SUM(N_REPAID_AMOUNT)
							FROM  
											LCOA.OA_AFW_LOAN_INFO oali  
							WHERE  
											oali.C_USER_ID = operation_id  
											AND N_LOAN_TYPE = 1  
											AND N_APPROVAL_STATUS = 5  
											AND N_PAYOFF_STATUS = 0) - (  
							SELECT  
											decode(SUM(N_UNCONFIRMED_AMOUNT),NULL,0,SUM(N_UNCONFIRMED_AMOUNT))  
							FROM  
											LCOA.OA_AFW_LOAN_INFO oali  
							WHERE  
											oali.C_USER_ID = operation_id  
											AND N_LOAN_TYPE = 1  
											AND N_APPROVAL_STATUS = 5  
											AND N_PAYOFF_STATUS = 0  
											AND N_UNCONFIRMED_AMOUNT IS NOT NULL) ,'999999999999.00') into amount_total2  
			FROM   dual;
	 
	 if amount_total2 is null then
	         ErrMsg:='您还没有需要还款的备用金,请修改后再申请';
			     return -1; 
	 end if ;
	 /*SELECT 
         sum(nvl(L.N_AMOUNT,0)-nvl(L.N_REPAID_AMOUNT,0)-nvl(L.N_UNCONFIRMED_AMOUNT,0))into
				 amount_total2
        FROM lcoa.OA_AFW_LOAN_INFO L
       WHERE L.N_LOAN_TYPE = 1
         AND L.N_PAYOFF_STATUS = 0
         AND L.N_APPROVAL_STATUS=5
         and N_AMOUNT - nvl(N_REPAID_AMOUNT, 0) -
             nvl(N_UNCONFIRMED_AMOUNT, 0) > 0
         AND L.C_USER_ID = operation_id;*/

			if amount_total > amount_total2  then
			     ErrMsg:='您的还款金额大于实际可抵扣金额，请修改后再申请';
			     return -1; 												 
			end if ;
	
	 open V_OAAFWLOANINFO for
      SELECT L.C_USER_ID,
             L.C_ID, --借款id
             L.V_FLOW_NUMBER, --借款单号
             L.N_AMOUNT, --借款金额
             L.N_REPAID_AMOUNT, --已还金额
             L.N_UNCONFIRMED_AMOUNT -- 待确认还款金额
        FROM lcoa.OA_AFW_LOAN_INFO L
       WHERE L.N_LOAN_TYPE = 1
         AND L.N_PAYOFF_STATUS = 0
         AND L.N_APPROVAL_STATUS=5
         and N_AMOUNT - nvl(N_REPAID_AMOUNT, 0) -
             nvl(N_UNCONFIRMED_AMOUNT, 0) > 0
         AND L.C_USER_ID = operation_id
       order by L.D_APPLY_TIME;
    
  
    --遍历借款信息
    fetch V_OAAFWLOANINFO
      into V_OUT_OAAFWLOANINFO;
			
			
    while V_OAAFWLOANINFO%found loop
    
      --计算-每笔借款应还金额=本地订单的借款金额-已还金额-待确认还款金额
      V_LoanBalance := nvl(V_OUT_OAAFWLOANINFO.N_AMOUNT,0) -
                       nvl(V_OUT_OAAFWLOANINFO.N_REPAID_AMOUNT, 0) -
                       nvl(V_OUT_OAAFWLOANINFO.N_UNCONFIRMED_AMOUNT, 0);
    
      
			
			--报销待还总金额累次还款后-应还金额小于0
      if v_amount_remaining - V_LoanBalance < 0 then
        V_LoanBalance := v_amount_remaining;
      end if;
      v_amount_remaining := v_amount_remaining - V_LoanBalance; --剩余金额
    
      --更新待确认还款金额
      update lcoa.OA_AFW_LOAN_INFO L
         set L.N_UNCONFIRMED_AMOUNT =
             (nvl(V_OUT_OAAFWLOANINFO.N_UNCONFIRMED_AMOUNT, 0) +
             V_LoanBalance) -- 待确认还款金额
       where C_ID = V_OUT_OAAFWLOANINFO.C_ID;
    
      --操作还款记录关系表
      V_ID_2 := lower(sys_guid());
      INSERT INTO LCOA.OA_AFW_LOAN_REPAYMENT
        (C_ID, --主键id
         C_REPLAYMENT_ID, --还款id
         C_LOAN_ID, --借款id
         N_REPLAYMENT_AMOUNT, --还款金额
         D_ARRIVAL_TIME) --入账时间
      VALUES
        (V_ID_2, V_ID, V_OUT_OAAFWLOANINFO.C_ID, V_LoanBalance, '');
    
      ---借款待归还提醒待办状态更新
      update lcoa.oa_tdo_todo_info info
         set info.n_status = 1
       where info.c_todo_data_id = V_OUT_OAAFWLOANINFO.C_ID
         and info.n_todo_type = 55;
    
      if v_amount_remaining <= 0 then
        exit;
      end if;
      fetch V_OAAFWLOANINFO
        into V_OUT_OAAFWLOANINFO;
    end loop;
    -- commit; -- 测试用
    ErrMsg := '完成！';
    return 0;
  end add_installRepayment2;

  --4 确认还款单详情
  function getRepaymentInfo(dataId                   in varchar2,
                            operationId              in char,
                            OaAfwRepaymentInfoEntity OUT SYS_REFCURSOR,
                            --还款确认单详情
                            loanList OUT SYS_REFCURSOR,
                            --借款单列表--包含图片
                            files OUT SYS_REFCURSOR,
                            --还款单附件列表
                            ErrMsg OUT VARCHAR2) RETURN NUMBER is
    result_int integer default - 1;
  begin
    --操作还款确认单详情表
    open OaAfwRepaymentInfoEntity for
      select oa.c_id, --id
             oa.v_flow_number, --还款单号
             oa.c_user_id, --还款人id
             oa.N_REPLAYMENT_AMOUNT, --还款金额
             oa.d_replayment_time, -- 提交时间
             oa.d_arrival_time, --还款确认时间
             oa.N_REPLAYMENT_TYPE, --还款类型
             oa.c_claim_form_id, --报销id
             oa.n_status, --状态
             oa.n_confirm_status, --确认状态
             oa.d_apply_time, --申请时间
             oa.d_update_time, --更新时间
             o.v_organization_name, -- 部门
             e.V_USER_TITLE, --岗位
             t_user.v_user_name, --还款人
             t_user.v_pet_name, --名称
             t_user.v_headpic_aly --头像
        from lcoa.OA_AFW_REPAYMENT_INFO oa
        left join lcbase.t_zip_user t_user
          on oa.c_user_id = t_user.c_user_id
        left join lcbase.T_EMPLOYEES_INFO e
          on oa.c_user_id = e.c_user_id
        left join lcbase.t_zip_organization o
          on t_user.c_organization_id = o.c_organization_id
      
       where oa.C_ID = dataId
         and t_user.d_enddate > sysdate
         and o.d_enddate > sysdate;
  
    open loanList for
      SELECT L.C_ID,
             L.V_FLOW_NUMBER,
             L.C_USER_ID,
             L.N_AMOUNT,
             L.V_CAUSE,
             L.N_LOAN_TYPE,
             L.D_PLAN_REPAYMENT_DATE,
             L.D_EXTENSION_DATE,
             L.N_EXTENSION_TIMES,
             L.N_REPAID_AMOUNT,
             L.N_STATUS,
             L.N_APPROVAL_STATUS,
             L.N_PAYOFF_STATUS,
             L.D_APPLY_TIME,
             L.C_PAYMENT_ID,
             L.N_PAYMENT_TYPE,
             L.C_USER_CORP_ID,
             L.N_UNCONFIRMED_AMOUNT,
             L.d_Payoff_Time,
             kk.v_company            AS "V_USER_CORP_NAME",
             k.v_company             AS "V_PAYMENT_CORP_NAME",
             o.v_organization_name,
             L.C_PAYMENT_CORP_ID,
             e.v_User_Title,
             t_user.v_user_name,
             t_user.v_pet_name,
             t_user.v_headpic_aly,
             L.C_USER_CORP_ID,
             afw.n_replayment_amount as "rAmount"
        FROM lcoa.OA_AFW_LOAN_REPAYMENT AFW --借款对应记录表
        LEFT JOIN lcoa.OA_AFW_REPAYMENT_INFO oa --还款单信息表
          ON AFW.C_REPLAYMENT_ID = oa.c_id
        LEFT JOIN OA_AFW_LOAN_INFO L --借款记录表
          ON AFW.C_LOAN_ID = L.C_ID
        LEFT JOIN lcbase.t_zip_user t_user
          ON oa.c_user_id = t_user.c_user_id
        LEFT JOIN lcbase.T_EMPLOYEES_INFO e
          ON oa.c_user_id = e.c_user_id
        LEFT JOIN lcbase.t_zip_organization o
          ON t_user.c_organization_id = o.c_organization_id
        LEFT JOIN lcbase.T_LK_COMPANY_INFO k
          ON L.C_PAYMENT_CORP_ID = k.c_company_id
        LEFT JOIN lcbase.T_LK_COMPANY_INFO kk
          ON L.C_USER_CORP_ID = kk.c_company_id
       WHERE oa.C_ID = dataId
         AND t_user.D_ENDDATE > SYSDATE
         AND o.D_ENDDATE > SYSDATE;
  
    open files for
      SELECT a.c_img_id,
             a.c_business_id,
             a.n_image_size,
             a.n_image_type,
             a.v_image_url,
             a.d_image_date,
             a.n_isdel_state,
             a.v_input_user_name,
             a.d_input_time,
             a.v_image_name,
             a.n_operation_type,
             a.c_input_user_id,
             a.v_hash_content,
             r.c_loan_id
        FROM lcoa.T_LK_ATTACHMENT a
        LEFT JOIN lcoa.OA_AFW_LOAN_REPAYMENT r
          ON a.C_BUSINESS_ID = r.C_ID
       where r.C_REPLAYMENT_ID = dataId;
    result_int := 0;
    return result_int;
  
  exception
    when others then
      errmsg := '确认还款单详情: ' || sqlcode || ',' || sqlerrm;
      RAISE_APPLICATION_ERROR(sqlcode, errmsg, false);
    
  end getRepaymentInfo;

  --5 确认还款确认单
  /*
   参数
   list<借款单id，,时间:arrivalTime>
   逻辑：
     - 关系表中更新入账时间
     - 借款单中更新已还金额 是否还清
     - 确认收款后，申请人会收到一条还款成功的通知
     - 确认收款后，我的记录中该条数据的状态同步更新为“已还款”
   return 回款是否成。
  */

  function passRepayment(Repayment   IN ARR_LONGSTR,
                         v_id        in char,
                         operationId in char,
                         c_cursor    out sys_refcursor,
                         ErrMsg      OUT VARCHAR2)
  
   RETURN NUMBER is
    v_date_value            PKG_COMMON.ARR_LONGSTR;
    total                   integer;
    loand_id                char(32);
    total_REPLAYMENT_AMOUNT number(10, 2) default 0.00;
    V_REPLAYMENT_AMOUNT     number(10, 2);
    V_AMOUNT                number(10, 2);
    rows_count              integer;
    V_REPLAYMENT_ID         char(32);
    TodoTitle               varchar2(50);
    result_int              integer;
    V_USERID                char(32);
    LOAN_REPAYMENT          char(32);
    V_REPAIDAMOUNT          number(10, 2); --已还金额
    V_UNCONFIRMED_AMOUNT    number(10, 2); --待确认还款金额
    v_id_3                  char(32);
    vusername               varchar2(50);
    vemail                  varchar2(50);
  begin
    total := Repayment.count;
    for i in 1 .. total loop
      v_date_value := PKG_COMMON.Split(Repayment(i), '^');
      loand_id     := v_date_value(1);
    
      --根据还款id-查询还款数据是否存在
      select count(*)
        into rows_count
        from lcoa.OA_AFW_LOAN_REPAYMENT
       where C_LOAN_ID = loand_id and C_REPLAYMENT_ID =v_id;
      --获取还款金额
      if rows_count > 0 then
        select N_REPLAYMENT_AMOUNT
          into V_REPLAYMENT_AMOUNT --还款金额
          from lcoa.OA_AFW_LOAN_REPAYMENT
         where C_LOAN_ID = loand_id and C_REPLAYMENT_ID =v_id; 
      end if;
    
      --获取还款总金额-（消息用）
      total_REPLAYMENT_AMOUNT := (total_REPLAYMENT_AMOUNT +
                                 V_REPLAYMENT_AMOUNT);
      
      --获取借款金额
      select decode(N_AMOUNT, null, 0.00, N_AMOUNT), --申请金额
             decode(N_REPAID_AMOUNT, null, 0.00, N_REPAID_AMOUNT), --  还款金额
             decode(N_UNCONFIRMED_AMOUNT, null, 0.00, N_UNCONFIRMED_AMOUNT) --待确认还款金额
        into V_AMOUNT, V_REPAIDAMOUNT, V_UNCONFIRMED_AMOUNT
        from lcoa.OA_AFW_LOAN_INFO
       where C_ID = loand_id;
    
  
        --借款单还款记录表（关系表中更新入账时间)
        update lcoa.OA_AFW_LOAN_REPAYMENT
           set D_ARRIVAL_TIME = to_date(v_date_value(2),
                                        'yyyy-mm-dd HH24:mi:ss') --入账时间
         where C_LOAN_ID = loand_id 
         and 
               C_REPLAYMENT_ID=v_id; 
      
        --借款表更新还款金额
        --(上次累计还款金额+当前还款金额=总还款金额)更新还款金额
        V_REPAIDAMOUNT := (V_REPAIDAMOUNT + V_REPLAYMENT_AMOUNT);
       
       --更新借款信息表内容
       update lcoa.OA_AFW_LOAN_INFO
           set N_REPAID_AMOUNT      = V_REPAIDAMOUNT,
               N_PAYOFF_STATUS      = 1, --已还清（0未还清/1 为已经还清）
               D_PAYOFF_TIME        = to_date(v_date_value(2),
                                              'yyyy-mm-dd HH24:mi:ss'), --借款还清时间
               N_UNCONFIRMED_AMOUNT = 0 --待确认还款金额设置为0
         where C_ID = loand_id; --借款单id
     
      --将还在审批中的延期还款审批流废掉
      result_int:=  pkg_ins_delay_info.cutDelayApproval(loand_id,ErrMsg);
      if result_int<>0 then
        return -1;
      end if;
    end loop;
  
  
    ----还款记录表更新状态：N_CONFIRM_STATUS，D_ARRIVAL_TIME ，D_UPDATE_TIME
    --根据借款单获取还款id
    /*select C_REPLAYMENT_ID
      into V_REPLAYMENT_ID
      from lcoa.OA_AFW_LOAN_REPAYMENT
     where C_LOAN_ID = loand_id;
    */
    --更新还款单状态
    update LCOA.OA_AFW_REPAYMENT_INFO
       set N_CONFIRM_STATUS = 1, --确认状态:0待确认 1已确认
           D_ARRIVAL_TIME   = to_date(v_date_value(2),
                                      'yyyy-mm-dd HH24:mi:ss'), --入账时间
           D_UPDATE_TIME    = sysdate -- 更新时间 确认时间
     where c_id = v_id;
  
    ----用户发送消息
    --获取用户id(user_id),还款id（LOAN_REPAYMENT） 待发消息属性
    select C_USER_ID
      into V_USERID
      from lcoa.OA_AFW_LOAN_INFO
     where C_ID = loand_id;
    
    
    --删除待办 
    DELETE FROM lcoa.OA_TDO_TODO_INFO
     WHERE C_TODO_DATA_ID = v_id
       AND C_TODO_USER_ID IN
           (select c_user_id
              from oa_aut_user_role r
             where r.c_role_id =
                   (select a.c_role_id
                      from Oa_Aut_Role a, oa_afw_workflow_user_type b
                     where trim(b.v_approval_user_id) = to_char(a.role_type)
                       and trim(b.v_approval_user_id) = '61'));
  
    --返回还款用户id
    open c_cursor for
      select C_USER_ID from lcoa.OA_AFW_LOAN_INFO where C_ID = loand_id;
  
    -- 开始发发送消息
    result_int := add_OA_MSG_MESSAGE_info(V_USERID,
                                          --userid
                                          v_id,
                                          --（还款id)消息关联数据id
                                          total_REPLAYMENT_AMOUNT,
                                          '系统',
                                          --默认为系统
                                          --消息发送者2
                                          ErrMsg);                                         
     ---给用户发消息    
     v_id_3:= lower(sys_guid());
           INSERT
          INTO
          LCOA.OA_MSG_EMAIL_INFO (
          C_ID,
          C_DATAID,
          N_OPERATION_TYPE,
          N_MESSAGE_TYPE,
          N_TYPE,
          V_FROM_NAME,
          V_FROM_ADDR,
          V_SUBJECT,
          V_CONTENT,
          N_DEL_STATUS,
          N_SEND_STATUS,
          D_SET_SEND_DATE,
          D_REAL_SEND_DATE,
          N_SEND_ONEBYONE,
          N_ALL_USER)
      VALUES(
			    v_id_3,
          v_id,
          6,
          1,
          1,
          null,
          null,
        '【还款申请】您已成功归还'||total_REPLAYMENT_AMOUNT||'元借款',
          '您已成功归还'||total_REPLAYMENT_AMOUNT||'元借款，可登录OA系统查看',
          0,
          0,
          sysdate,
          null,
          1,
          1);
					
   --查询用户基础信息
   select u.v_user_name ,u.v_email into vusername,vemail  from lcbase.t_zip_user u
   left join lcoa.oa_afw_repayment_info r
   on u.c_user_id = r.c_user_id
   where  u.d_enddate >sysdate and r.c_id  = v_id;
	 
	 
    --邮件发送地址列表
    INSERT INTO LCOA.OA_MSG_RECIPIENT_ADDR
        (C_ID, V_RECIPIENT, V_SENDTOS_ADDR)
      VALUES
        (v_id_3, vusername, vemail);                                    

    if result_int <> 0 then
      ErrMsg := '消息发送异常！';
      return - 1;
    end if;
   
    -- commit; --测试使用！
    ErrMsg := '成功！';
    return 0;
  exception
    when others then
      dbms_output.put_line('个人还款确认异常: ' || sqlcode || ',' || sqlerrm);
      rollback;
      return - 1; 
  end passRepayment;
  

  

  --5 确认还款确认单(报销)
  /*
   参数list<报销id                                                                                                                                                                                                                       ,arrivalTime>
   逻辑：
     - 关系表中更新入账时间
     - 借款单中更新已还金额 是否还清
  
   return 回款是否成。 还款单号，
  */

  function passRepayment2(Repayment   IN varchar2,
                          operationId in char,
                          ErrMsg      OUT VARCHAR2)
  
   RETURN NUMBER is
   type R_OAAFWLOANINFO is record(
					C_USER_ID            lcoa.oa_afw_loan_info.c_user_id%type,
					C_REPLAYMENT_ID      lcoa.OA_AFW_LOAN_REPAYMENT.c_replayment_id%type,
					C_ID                 lcoa.oa_afw_loan_info.c_id%type,
					V_FLOW_NUMBER        lcoa.oa_afw_loan_info.v_flow_number%type,
					N_AMOUNT             lcoa.oa_afw_loan_info.N_AMOUNT%type,
					N_REPAID_AMOUNT      lcoa.oa_afw_loan_info.N_REPAID_AMOUNT%type,
					N_UNCONFIRMED_AMOUNT lcoa.oa_afw_loan_info.N_UNCONFIRMED_AMOUNT%type,
					N_REPLAYMENT_AMOUNT  lcoa.OA_AFW_LOAN_REPAYMENT.N_REPLAYMENT_AMOUNT%type);
			
    V_OAAFWLOANINFO         sys_refcursor;
    V_OUT_OAAFWLOANINFO     R_OAAFWLOANINFO;
    v_date_value            PKG_COMMON.ARR_LONGSTR;
    total                   integer;
    loand_id                char(32);
    total_REPLAYMENT_AMOUNT number(10, 2) default 0.00;
    V_REPLAYMENT_AMOUNT     number(10, 2) default 0.00;
    V_AMOUNT                number(10, 2) default 0.00;
    rows_count              integer;
    V_REPLAYMENT_ID         char(32);
    TodoTitle               varchar2(50);
    result_int              integer;
    V_USERID                char(32);
    LOAN_REPAYMENT          char(32);
    V_REPAIDAMOUNT          number(10, 2) default 0.00; --已还金额
    amount_total            number(10, 2) default 0.00;
    V_LoanBalance           number(10, 2) default 0.00;
    v_payoff_status         number;
    v_id_3                  char(32);
		vusername               varchar2(50);
		vemail                  varchar2(50);
  begin
  
    --获取报销id和时间
    v_date_value := PKG_COMMON.Split(Repayment, '^');
  
    --报销id 不能为空
    if v_date_value(1) is null then
      ErrMsg := '报销id_不能为空！';
      return - 1;
    end if;
    select x.n_replayment_amount into total_REPLAYMENT_AMOUNT
    from OA_AFW_REPAYMENT_INFO x where C_CLAIM_FORM_ID = trim(v_date_value(1));
    --更新报销还款记录信息
    update lcoa.OA_AFW_REPAYMENT_INFO R
       set R.D_ARRIVAL_TIME   = to_date(v_date_value(2), 'yyyymmddHH24miss'), --入账时间
           R.N_CONFIRM_STATUS = 1, --已确认
           R.D_UPDATE_TIME    = sysdate --更新时间
     where C_CLAIM_FORM_ID = trim(v_date_value(1));
  
    --根据用户id 查询用户借款信息
    open V_OAAFWLOANINFO for
      SELECT L.C_USER_ID, --用户id
             R.C_REPLAYMENT_ID, --还款id
             L.C_ID, --借款id
             L.V_FLOW_NUMBER, --借款单号
             L.N_AMOUNT, --借款金额
             L.N_REPAID_AMOUNT, --已还金额
             L.N_UNCONFIRMED_AMOUNT, -- 待确认还款金额
             R.N_REPLAYMENT_AMOUNT --本次还款金额
        FROM lcoa.OA_AFW_LOAN_INFO L
        JOIN LCOA.OA_AFW_LOAN_REPAYMENT R
          ON L.C_ID = R.C_LOAN_ID
        join OA_AFW_REPAYMENT_INFO ri
          on ri.c_id = r.c_replayment_id
       WHERE 
          ri.c_claim_form_id = trim(v_date_value(1)) 
       order by L.D_APPLY_TIME;
  
    fetch V_OAAFWLOANINFO
      into V_OUT_OAAFWLOANINFO;
		V_REPLAYMENT_ID:=	V_OUT_OAAFWLOANINFO.C_REPLAYMENT_ID;
    ------------------------------------------------------------------------------------
     v_payoff_status := 0; --是否还清状态！
    while V_OAAFWLOANINFO%found loop 
      --已还金额+本次还款金额 >= 借款金额  更新 v_payoff_status 为1

       if ( nvl(V_OUT_OAAFWLOANINFO.N_REPAID_AMOUNT,0) +
         nvl(V_OUT_OAAFWLOANINFO.N_REPLAYMENT_AMOUNT,0)) >=
         nvl(V_OUT_OAAFWLOANINFO.N_AMOUNT,0) then
          v_payoff_status := 1;
       else 
			    v_payoff_status := 0;
			end if;
    
		
      --更新借款单信息表
      update lcoa.OA_AFW_LOAN_INFO L
         set --更新已还款金额属性值=（之前还款金额+本次待确认还款金额）
             L.N_REPAID_AMOUNT = nvl(V_OUT_OAAFWLOANINFO.N_REPAID_AMOUNT, 0) +
                               nvl(V_OUT_OAAFWLOANINFO.N_REPLAYMENT_AMOUNT,
                                   0),
             --更新待确认还款金额=(待确认还款金额-本次待确认还款金额)
             L.N_UNCONFIRMED_AMOUNT = nvl(V_OUT_OAAFWLOANINFO.N_UNCONFIRMED_AMOUNT, 0) -
                                      nvl(V_OUT_OAAFWLOANINFO.N_REPLAYMENT_AMOUNT,
                                          0),
             L.n_payoff_status      = v_payoff_status, --更新借款单状态
             L.d_payoff_time        = decode(v_payoff_status,
                                             1,
                                             sysdate,
                                             null) --当还清状态为1时，更新时间，否则为null
       where C_ID = V_OUT_OAAFWLOANINFO.C_ID;
       
       
			 
      --更新还款关系记录表-入账时间
      update LCOA.OA_AFW_LOAN_REPAYMENT
         set D_ARRIVAL_TIME = to_date(v_date_value(2), 'yyyymmddHH24miss')
       where C_LOAN_ID = V_OUT_OAAFWLOANINFO.C_ID
         and C_REPLAYMENT_ID = V_OUT_OAAFWLOANINFO.C_REPLAYMENT_ID;
				 
				 
      fetch V_OAAFWLOANINFO
        into V_OUT_OAAFWLOANINFO;
        
      --将还在审批中的延期还款审批流废掉
      result_int:=  pkg_ins_delay_info.cutDelayApproval(V_OUT_OAAFWLOANINFO.C_ID,ErrMsg);
  
    end loop;
    
				 ---给用户发消息    
				 v_id_3:= lower(sys_guid());
         INSERT INTO
          LCOA.OA_MSG_EMAIL_INFO (
          C_ID,
          C_DATAID,
          N_OPERATION_TYPE,
          N_MESSAGE_TYPE,
          N_TYPE,
          V_FROM_NAME,
          V_FROM_ADDR,
          V_SUBJECT,
          V_CONTENT,
          N_DEL_STATUS,
          N_SEND_STATUS,
          D_SET_SEND_DATE,
          D_REAL_SEND_DATE,
          N_SEND_ONEBYONE,
          N_ALL_USER)
      VALUES(v_id_3,
          V_OUT_OAAFWLOANINFO.C_REPLAYMENT_ID,--还款id
          6,
          1,
          1,
          null,
          null,
        '【还款申请】您已成功归还'||total_REPLAYMENT_AMOUNT||'元借款',
          '您已成功归还'||total_REPLAYMENT_AMOUNT||'元借款，可登录OA系统查看',
          0,
          0,
          sysdate,
          null,
          1,
          1);
   
			 select 
						u.v_user_name ,u.v_email 
			 into vusername,vemail  
			 from 
						lcbase.t_zip_user u
			 left join 
						lcoa.oa_afw_repayment_info r
			 on u.c_user_id = r.c_user_id
			 where  u.d_enddate >sysdate and r.c_id  = V_REPLAYMENT_ID;
   
				--邮件发送地址列表
				INSERT INTO LCOA.OA_MSG_RECIPIENT_ADDR
						(C_ID, V_RECIPIENT, V_SENDTOS_ADDR)
					VALUES
						(v_id_3, vusername, vemail);
				
    --commit; --测试使用！
    ErrMsg := '成功！';
    return 0;
  end passRepayment2;

  --6 报销生成还款单
  function get_RepaymentBills(RepaymentBills OUT ARR_LONGSTR,
                              ErrMsg         OUT VARCHAR2)
  
   RETURN NUMBER is
  begin
    null;
  end get_RepaymentBills;

  --7 收款列表
  function get_Payment_list(data_value   in varchar2,
                            pageNum      in number,
                            PageSize     in number,
                            operationId  in char,
                            getapplylist out sys_refcursor,
                            totalPage    out number,
                            totalCount   out number,
                            errmsg       out varchar2)
  
   RETURN NUMBER is
    V_N_LOAN_TYPE      integer;
    V_N_CONFIRM_STATUS integer;
    V_TIME_START       varchar2(50);
    V_TIME_end         varchar2(50);
    v_sql              varchar2(1000);
    v_date_value       PKG_COMMON.ARR_LONGSTR;
    n_result           integer default - 1;
    V_USER_ID          char(32);
  
    v_time varchar2(50) default 'yyyy-mm-dd HH24:mi:ss';
  
  begin
  
    v_date_value := PKG_COMMON.Split(data_value, '^');
  
    V_N_LOAN_TYPE      := v_date_value(1);
    V_N_CONFIRM_STATUS := v_date_value(2);
    V_TIME_START       := v_date_value(3);
    V_TIME_end         := v_date_value(4);
    V_USER_ID          := v_date_value(5);
  
    v_sql := 'select
          R.c_id as "id",
          R.V_FLOW_NUMBER as "FLOWNUMBER",
           R.N_REPLAYMENT_TYPE as "REPAYMENTTYPE",--还款类型
           t_user.v_user_name as "username",--提交人名字
           R.N_REPLAYMENT_AMOUNT as "REPAYMENTAMOUNT",--还款总金额
           R.D_REPLAYMENT_TIME as "REPAYMENTTIME",     --提交还款单时间
          R.N_CONFIRM_STATUS as "CONFIRMSTATUS"       --状态
      from
             lcoa.OA_AFW_REPAYMENT_INFO R --还款记录表
      left join
           lcbase.t_zip_user t_user
      on
           R.C_USER_ID = t_user.c_user_id
      where  t_user.D_ENDDATE > sysdate';
  
    --拼接sql 返回数据
    --还款类型为空：默认为全部
    if V_N_LOAN_TYPE is not null then
      v_sql := v_sql || ' and R.N_REPLAYMENT_TYPE=''' || V_N_LOAN_TYPE || '''';
    end if;
  
    --判断已收款和未收款状态
    if V_N_CONFIRM_STATUS is not null then
      v_sql := v_sql || ' and R.N_CONFIRM_STATUS= ' || V_N_CONFIRM_STATUS;
    end if;
  
    --开始时间
    if V_TIME_START is not null then
      v_sql := v_sql || ' and R.D_REPLAYMENT_TIME> to_date(' || '''' ||
               V_TIME_START || '''' || ', ' || '''' || v_time || '''' || ') ';
    end if;
  
    --结束时间
    if V_TIME_end is not null then
      v_sql := v_sql || ' and R.D_REPLAYMENT_TIME< to_date(' || '''' ||
               V_TIME_end || '''' || ', ' || '''' || v_time || '''' || ') ';
    end if;
  
    dbms_output.put_line(v_sql ||
                         '----------------------------------------');
    --开始时间不能大于结束时间判断
    n_result := lcoa.pkg_common.GetPagingInfo(v_sql,
                                              PageSize,
                                              pageNum,
                                              getapplylist,
                                              totalCount,
                                              totalPage);
  
    if n_result = 0 then
      ErrMsg := '成功！';
      return n_result;
    end if;
  end get_Payment_list;

  --辅助存储过程

  --生成待办
  function add_todo_info(user_id     in char,
                         flow_number in char,
                         ErrMsg      OUT VARCHAR2) RETURN NUMBER is
  begin
    if user_id is not null and flow_number is not null then
      INSERT INTO LCOA.OA_TDO_TODO_INFO
        (C_TODO_ID,
         C_TODO_USER_ID,
         D_TODO_TIME,
         N_TODO_TYPE,
         V_TODO_TITLE,
         D_INPUT_TIME,
         N_STATUS,
         D_DONE_TIME,
         C_TODO_DATA_ID)
      VALUES
        (flow_number, user_id, sysdate, 15, '还款', sysdate, 0, '', '');
      ErrMsg := '生成待办-成功！';
      return 1;
    else
      return - 1;
    end if;
  end add_todo_info;

  --send message

  function add_OA_MSG_MESSAGE_info(user_id                 in char, --userid
                                   C_MSG_SRC               in char, --消息关联数据id
                                   total_REPLAYMENT_AMOUNT in number,
                                   send_author             in varchar2, --消息发送者
                                   ErrMsg                  OUT VARCHAR2)
    RETURN NUMBER
  
   is
    v_username varchar2(50);
  
  begin
  
    --插入用户消息表
    select u.v_user_name
      into v_username
      from lcbase.t_zip_user u
     where u.c_user_id = user_id
       and u.d_enddate > sysdate;
  
    INSERT INTO LCOA.OA_MSG_MESSAGE_INFO
      (C_MSG_ID, -- 数据ID
       N_MSG_TYPE, --消息类型(0:心情,1:公告,2:纪要,3:通知)
       N_ISTOP_FLAG, --是否置顶(0否1是)
       --D_ISTOP_TIME,                              --置顶时间
       V_MSG_TITLE, --消息标题
       D_MSG_TIME, --录入时间
       N_READ_FLAG, --是否已读(0否1是)
       C_MSG_USER_ID, --消息接收人ID
       C_MSG_SRC, --消息源的关联数据ID
       V_MSG_CONTENT, --消息内容
       V_MSG_SENDER, --消息发送者名称
       D_UPDATE_TIME --更新时间
       --N_ENABLE
       )
    VALUES
      (lower(sys_guid()),
       56,
       0,
       '【' || v_username || '】你已成功归还' || total_REPLAYMENT_AMOUNT || '元借款',
       sysdate,
       0,
       trim(user_id),
       trim(C_MSG_SRC), --消息关联数据id
       v_username || '的还款',
       send_author, --发送者名称
       sysdate);
    ErrMsg := '成功！';
    return 0;
  
  end add_OA_MSG_MESSAGE_info;

  ---测试函数的支持
  function add_test_afw_loan_info(data_values      in ARR_LONGSTR,
                                  out_v_c_id       out varchar2,
                                  out_V_FLOWNUMBER out varchar2,
                                  ErrMsg           OUT VARCHAR2)
    return number is
    v_date_value PKG_COMMON.ARR_LONGSTR;
    row_count    integer;
    V_FLOWNUMBER char(32);
    v_c_id       char(32);
    tempOut_c_id varchar2(2000);
  begin
  
    row_count := data_values.count;
    for i in 1 .. row_count loop
      v_date_value := PKG_COMMON.Split(data_values(i), '^');
      V_FLOWNUMBER := pkg_common.GetFlowNumber('JK', 4); --生成借款单号
      v_c_id       := lower(sys_guid());
      if i < row_count then
        tempOut_c_id := (tempOut_c_id || v_c_id || ',');
      else
        tempOut_c_id := (tempOut_c_id || v_c_id);
      end if;
      INSERT INTO LCOA.OA_AFW_LOAN_INFO
        (C_ID, --借款id
         V_FLOW_NUMBER, --借款单号
         C_USER_ID, --用户id
         N_AMOUNT, --借款金额
         V_CAUSE, --申请理由
         N_LOAN_TYPE, --借款类型（备用金、个人）
         D_PLAN_REPAYMENT_DATE, --申请借款时填写的还款日期
         D_EXTENSION_DATE, --延期还款日期（应该还款日期，插入时该日期等于D_PLAN_REPAYMENT_DATE）
         N_EXTENSION_TIMES, --延期次数
         N_REPAID_AMOUNT, --已还款金额
         N_STATUS, --状态 0为作废
         N_APPROVAL_STATUS, --模拟时，默认为5 审批完成。
         N_PAYOFF_STATUS, --0未还清 1已还清
         D_APPLY_TIME, --申请时间
         C_PAYMENT_ID, --对应支付记录表(oa_afw_payment_record)主键id
         N_PAYMENT_TYPE, --1线下支付（线下支付时，支付id为空） 2线上支付
         C_USER_CORP_ID, --所属主体
         C_PAYMENT_CORP_ID, --支付主体
         N_UNCONFIRMED_AMOUNT, --待确认还款金额
         D_PAYOFF_TIME --借款还清时间
         
         )
      VALUES
        (v_c_id,
         V_FLOWNUMBER,
         v_date_value(3), --贾晓新
         v_date_value(4),
         v_date_value(5),
         v_date_value(6),
         to_date(v_date_value(7), 'yyyymmddhh24miss'), --还款日期
         to_date(v_date_value(8), 'yyyymmddhh24miss'),
         v_date_value(9),
         v_date_value(10), --初次借款   已还款金额为0
         v_date_value(11),
         v_date_value(12),
         v_date_value(13),
         to_date(v_date_value(14), 'yyyymmddhh24miss'), --申请时间
         null,
         1,
         '0144429b172f4cd8a4112cdea01e7c3f',
         null,
         0, --初次借款，待确认金额为 0
         null);
    end loop;
    out_v_c_id       := tempOut_c_id;
    out_V_FLOWNUMBER := V_FLOWNUMBER;
    ErrMsg           := '成功！';
    --commit;
    return 0;
  exception
    when others then
      ErrMsg := 'test' || '新增借款款测试单: ' || sqlcode || ',' || sqlerrm;
      rollback;
      return - 1;
  end add_test_afw_loan_info;

  --重置
  function ResetSkip(ApprovalUserId in varchar2, ErrMsg out varchar2)
    return number is
  begin
    update lcoa.OA_AFW_REPAYMENT_INFO t
       set t.n_skip_flag = 0
     where t.n_confirm_status = 0
       and t.n_skip_flag = 1;
    --commit;
    return 0;
  exception
    when PKG_COMMON.EXP_CHECK then
      return pkg_common.g_errcode_afw_overlap;
    when others then
      ErrMsg := 'ResetSkip: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;

  --跳过
  function Target_Skip(repay_id     in varchar2,
                       operation_id in char,
                       ErrMsg       out varchar2) return number is
  begin
    update lcoa.OA_AFW_REPAYMENT_INFO t
       set t.n_skip_flag = 1
     where t.c_id = repay_id
          --and t.c_user_id = ApprovalUserId
       and t.n_confirm_status = 0;
  
    return 0;
  exception
    when PKG_COMMON.EXP_CHECK then
      return pkg_common.g_errcode_afw_overlap;
    when others then
      ErrMsg := 'Target_Skip: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;

 --撤回内容
  function  clear_content_info(V_CLAIM_FORMID in char, operation_id in char,ErrMsg out varchar2) 
  return number
  is 
     result_int integer default -1;
     type   R_OAAFWLOANINFO is record(
						C_USER_ID            lcoa.oa_afw_loan_info.c_user_id%type,
						C_REPLAYMENT_ID      lcoa.OA_AFW_LOAN_REPAYMENT.c_replayment_id%type,
						C_ID                 lcoa.oa_afw_loan_info.c_id%type,
						V_FLOW_NUMBER        lcoa.oa_afw_loan_info.v_flow_number%type,
						N_AMOUNT             lcoa.oa_afw_loan_info.N_AMOUNT%type,
						N_REPAID_AMOUNT      lcoa.oa_afw_loan_info.N_REPAID_AMOUNT%type, 
						N_UNCONFIRMED_AMOUNT lcoa.oa_afw_loan_info.N_UNCONFIRMED_AMOUNT%type,
						N_REPLAYMENT_AMOUNT  lcoa.OA_AFW_LOAN_REPAYMENT.N_REPLAYMENT_AMOUNT%type);
     
		   V_OAAFWLOANINFO         sys_refcursor;
     
     V_OUT_OAAFWLOANINFO     R_OAAFWLOANINFO;
  begin
     --报销id 不能为空
    if V_CLAIM_FORMID is null then
          ErrMsg := '报销id_不能为空！';
      return - 1;
    end if;
    --查询操作
    open V_OAAFWLOANINFO for
      SELECT L.C_USER_ID,     --用户id
             R.C_REPLAYMENT_ID, --还款id
             L.C_ID,             --借款id
             L.V_FLOW_NUMBER, --借款单号
             L.N_AMOUNT, --借款金额
             L.N_REPAID_AMOUNT, --已还金额
             L.N_UNCONFIRMED_AMOUNT, -- 待确认还款金额
             R.N_REPLAYMENT_AMOUNT --本次还款金额
        FROM lcoa.OA_AFW_LOAN_INFO L
        JOIN LCOA.OA_AFW_LOAN_REPAYMENT R
          ON L.C_ID = R.C_LOAN_ID
        join OA_AFW_REPAYMENT_INFO ri
          on (ri.c_id = r.c_replayment_id)
       WHERE 
          ri.c_claim_form_id = trim(V_CLAIM_FORMID);
         
       --遍历游标
       fetch V_OAAFWLOANINFO into V_OUT_OAAFWLOANINFO;
       while V_OAAFWLOANINFO%found loop
       --处理借款信息表
       update 
          lcoa.Oa_Afw_Loan_Info L
       set 
          L.N_UNCONFIRMED_AMOUNT =nvl(L.N_UNCONFIRMED_AMOUNT,0)-nvl(V_OUT_OAAFWLOANINFO.N_REPLAYMENT_AMOUNT,0)
       where
           L.C_ID = V_OUT_OAAFWLOANINFO.C_ID;
           
       --处理关系表内容  
        delete from lcoa.OA_AFW_LOAN_REPAYMENT where C_REPLAYMENT_ID = V_OUT_OAAFWLOANINFO.C_REPLAYMENT_ID;
         
       fetch V_OAAFWLOANINFO into V_OUT_OAAFWLOANINFO;
       end loop;
       
       --处理还款信息表
       update
			      lcoa.OA_AFW_REPAYMENT_INFO
			 set 
			      N_STATUS=1 --删除
			 where C_CLAIM_FORM_ID=V_CLAIM_FORMID;
			 
				ErrMsg:='成功！';
				result_int:=0;
				return result_int;
end;  
  
end pkg_ins_repayment_info;
/

