create package body PKG_EXT_SIGNATURE_INFO is
  function save_signature_info(DataInfo        in varchar2,
                               OperationUserId IN VARCHAR2,
                               UserId          OUT VARCHAR2,
                               ErrMsg          OUT VARCHAR2) return number is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
  begin
    time_start := systimestamp;
    begin
      n_optype := 2;
      n_result := lcoa.pkg_ins_signature_info.save_signature_info(DataInfo,
                                                                  UserId,
                                                                  ErrMsg);
    
    EXCEPTION
      WHEN OTHERS THEN
        --ErrMsg := pkg_common.g_errmsg_common;
        ErrMsg   := SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'save_loan_info',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
end;
/

