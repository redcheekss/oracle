create package PKG_INS_AFW_USERAPPLY is

  -- Author  : USER
  -- Created : 2020/4/12 16:43:10
  -- Purpose : TEMP

  -- Public type declarations
  --type <TypeName> is <Datatype>;

  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  --<VariableName> <Datatype>;
  -- Public function and procedure declarations
  --function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;

  --获取请假审批状态
  procedure GetLeaveAfwStatusById(WorkflowId in varchar2,
                                  AfwStatus  out number,
                                  OperType   in number := 0);
  --获取外出审批状态
  procedure GetEgressAfwStatusById(WorkflowId in varchar2,
                                   AfwStatus  out number,
                                   OperType   in number := 0);
  --获取公告审批状态
  procedure GetPublishAfwStatusById(WorkflowId in varchar2,
                                    AfwStatus  out number,
                                    OperType   in number := 0);
  --获取报销审批状态
  procedure GetExpensesAfwStatusById(WorkflowId in varchar2,
                                     AfwStatus  out number,
                                     OperType   in number := 0);
  --获取转正审批状态
  procedure GetPromotionAfwStatusById(WorkflowId in varchar2,
                                      AfwStatus  out number,
                                      OperType   in number := 0);
  --获取调岗审批状态                                      
  procedure GetAdjustpostAfwStatusById(WorkflowId in varchar2,
                                       AfwStatus  out number,
                                       OperType   in number := 0);
  --设置请假审批状态
  procedure SetLeaveAfwStatusById(WorkflowId in varchar2,
                                  AfwStatus  in number);
  --设置外出审批状态
  procedure SetEgressAfwStatusById(WorkflowId in varchar2,
                                   AfwStatus  in number);
  --设置公告审批状态
  procedure SetPublishAfwStatusById(WorkflowId in varchar2,
                                    AfwStatus  in number);
  --设置报销审批状态
  procedure SetExpensesAfwStatusById(WorkflowId in varchar2,
                                     AfwStatus  in number);
  --设置转正审批状态
  procedure SetPromotionAfwStatusById(WorkflowId in varchar2,
                                      AfwStatus  in number);
  --设置调岗审批状态
  procedure SetAdjustpostAfwStatusById(WorkflowId in varchar2,
                                       AfwStatus  in number);
  --组织消息内容
  procedure FormAfwResultMessage(ApprovalUserId in varchar2,
                                 AfwStatus      in number,
                                 ApprovalResult out varchar2);
  --组织请假待办消息标题
  procedure FormLeaveTodoTitleById(WorkflowId in varchar2,
                                   TodoTitle  out varchar2);
  --组织外出待办消息标题
  procedure FormEgressTodoTitleById(WorkflowId in varchar2,
                                    TodoTitle  out varchar2);
  --组织公告待办消息标题
  procedure FormPublishTodoTitleById(WorkflowId in varchar2,
                                     TodoTitle  out varchar2);
  --组织报销待办消息标题
  procedure FormExpensesTodoTitleById(WorkflowId in varchar2,
                                      TodoTitle  out varchar2);
  --组织转正待办消息标题
  procedure FormPromotionTodoTitleById(WorkflowId in varchar2,
                                       TodoTitle  out varchar2);
  --组织调岗待办消息标题
  --会签一次性生成，审批流中无需再发待办
  --procedure FormAdjustpostTodoTitleById(WorkflowId in varchar2,
  --                                       TodoTitle  out varchar2);
  --生成请假审批消息
  procedure CreateLeaveAfwMsgById(WorkflowId     in varchar2,
                                  ApprovalUserId in varchar2,
                                  AfwStatus      in number,
                                  MsgSender_Cur  out sys_refcursor);
  --生成外出审批消息
  procedure CreateEgressAfwMsgById(WorkflowId     in varchar2,
                                   ApprovalUserId in varchar2,
                                   AfwStatus      in number,
                                   MsgSender_Cur  out sys_refcursor);
  --生成公告审批消息
  procedure CreatePublishAfwMsgById(WorkflowId      in varchar2,
                                    ApprovalUserId  in varchar2,
                                    AfwStatus       in number,
                                    MsgRange        in number,
                                    MsgSender_Cur   out sys_refcursor,
                                    IsAll_MsgSender out number);
  --生成报销审批消息
  procedure CreateExpensesAfwMsgById(WorkflowId     in varchar2,
                                     ApprovalUserId in varchar2,
                                     AfwStatus      in number,
                                     MsgSender_Cur  out sys_refcursor);
  --生成转正审批消息
  procedure CreatePromotionAfwMsgById(WorkflowId     in varchar2,
                                      ApprovalUserId in varchar2,
                                      AfwStatus      in number,
                                      MsgSender_Cur  out sys_refcursor);
  --生成调岗审批消息
  procedure CreateAdjustpostAfwMsgById(WorkflowId     in varchar2,
                                       ApprovalUserId in varchar2,
                                       AfwStatus      in number,
                                       MsgSender_Cur  out sys_refcursor);
end PKG_INS_AFW_USERAPPLY;
/

