create package body pkg_ins_role_permissions is
   --新增角色
  function createrole(datainfo        in varchar2, --新增的角色名称^备注
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增部门ID
                                        ErrMsg          out varchar2)
    return number is
    n_result    number(1):= 0;
    DATAARR     PKG_COMMON.ARR_LONGSTR;
    OA_ROLE_ID  VARCHAR2(32):=LOWER(SYS_GUID());
    sequence_id number(4);
    ROLE_CODE_num varchar2(4);
    v_name number(4);
    begin
        --新增角色名称
        DATAARR:=PKG_COMMON.SPLIT(DataInfo,'^');
        --序列取值
        sequence_id:=OA_ROLE_ROLETYPE.nextval;
        --code补0
        select lpad(sequence_id,4,0)
        into ROLE_CODE_num
        from dual;
        begin
             select count(*) into v_name from lcoa.OA_AUT_ROLE where trim(ROLE_NAME)=trim(DATAARR(3));
        EXCEPTION
             WHEN  OTHERS THEN
             v_name:=0;
            -- ErrMsg:='角色名称重复~';
            -- return -1;
        end;

        if v_name = 0 then

        --新增OA角色开始
        insert into lcoa.OA_AUT_ROLE(
        C_ROLE_ID, ROLE_CODE, ROLE_NAME, DELETED, N_IS_CUSTOM, ROLE_TYPE,V_REMARK)
        values (OA_ROLE_ID,--32位的ID
                ROLE_CODE_num,--序列填充后的编码
                DATAARR(3),--新增角色名称
                0,--状态正常
                0,--是否是自定义，内置为1，非内置为0
                sequence_id,--自增序列
                DATAARR(6)
                );
        --新OA角色新增结束

        --同步到业务系统
        --lcyw角色新增开始
        insert into lcyw.OA_ROLES(
               ID,
               ROLE_CODE,
               ROLE_NAME,
               INSERT_USER_ID,
               INSERT_DATE_TIME,
               UPDATE_USER_ID,
               UPDATE_DATE_TIME,
               COMPANY_ID,
               DELETED,
               ROLE_TYPE,
               N_IS_CUSTOM)
        values(OA_ROLE_ID,--ID
               ROLE_CODE_num,--ROLE_CODE
               DATAARR(3),--新增角色名称
               OperationUserId,--INSERT_USER_ID
               sysdate,--INSERT_DATE_TIME
               OperationUserId,--UPDATE_USER_ID
               sysdate,--UPDATE_DATE_TIME
               'lcsm0000000000000000000000000001',--COMPANY_ID
               0,--ROLE_TYPE
               sequence_id,--自增序列
               0--N_IS_CUSTOM
            );
        --lcyw角色新增结束

        commit ;
        DataId:=OA_ROLE_ID;--返回新增的id
        return n_result;
        else
          ErrMsg:='角色名称重复~';
          return -1;
        end if;
    EXCEPTION
        WHEN  OTHERS THEN
            ErrMsg:='角色数据插入失败';
        rollback ;
        return -1;
    end;

  --部门下添加角色
  function create_organization_role(organizationid  in varchar2, --
                      DataInfo        IN VARCHAR2,
                      ErrMsg          out varchar2)
  return number is
  DATAADDR PKG_COMMON.ARR_LONGSTR;
  N_RESULT VARCHAR2(2000);
  n_count  number(3);
   begin
    DATAADDR:=PKG_COMMON.SPLIT(DataInfo,'^');
    --删除部门原角色列表
    delete from OA_AUT_ROLE_ORGANIZATION org where org.C_ORGANIZATION_ID  = organizationid ;
    --统计角色个数
    n_count:=DATAADDR.COUNT;
    --新增部门角色
    for i in 1 .. n_count loop
      if DATAADDR(i) is not null then
        insert into  lcoa.OA_AUT_ROLE_ORGANIZATION
        values (organizationid,DATAADDR(i));
       end if;
    end loop;
    --新增部门角色结束
    commit;
    return N_RESULT;

    EXCEPTION
       WHEN  OTHERS  THEN
        ErrMsg:='部门添加角色数据失败！';
        rollback ;
        return -1;
    end;
  --新增用户角色
  function create_user_role(userid            in varchar2, --新增角色的用户id
                            DataInfo          IN VARCHAR2,--角色id集合
                            entrytype         in number,
                            ErrMsg            out varchar2)
  return number is
  DATAADDR PKG_COMMON.ARR_LONGSTR;
  N_RESULT VARCHAR2(2000);
  n_count  number(3);
  role_ids  varchar2(4000);
  v_node varchar2(2000);
    begin
    DATAADDR:=PKG_COMMON.SPLIT(DataInfo,'^');
    --yw删除人员原角色列表
    delete from lcyw.OA_USER_ROLES u where u.OA__ID2  in (

    select urole.c_role_id
    from lcoa.OA_AUT_USER_ROLE urole
    where urole.C_USER_ID  = userid
    and urole.n_entry_type=entrytype

    ) and u.OA__ID  = userid ;
    --oa删除人员原角色列表
    delete from lcoa.OA_AUT_USER_ROLE u where u.c_role_id in (
    select urole.c_role_id
    from lcoa.OA_AUT_USER_ROLE urole
    where urole.C_USER_ID  = userid
    and urole.n_entry_type=entrytype) and u.C_USER_ID  = userid ;

    --统计角色个数
    n_count:=DATAADDR.COUNT;
    --新增人员角色
    for i in 1 .. n_count loop
      if DATAADDR(i) is not null then
        v_node:='  insert into  lcoa.OA_AUT_USER_ROLE
        values ('''||userid||''','''||DATAADDR(i)||''','||entrytype||');';
        --oa新增
        insert into  lcoa.OA_AUT_USER_ROLE
        values (userid,DATAADDR(i),entrytype);
        --yw新增
        insert into lcyw.OA_USER_ROLES
        values (LOWER(SYS_GUID()),userid,DATAADDR(i));
       end if;
    end loop;
    --新增人员角色结束
    commit;
    return N_RESULT;

    EXCEPTION
      when DUP_VAL_ON_INDEX then
        ErrMsg := '选中角色已被分配,请刷新页面后重新选择~';
        rollback ;
        return -1;
       WHEN  OTHERS  THEN
       ErrMsg :=  SQLCODE || ',' || SQLERRM || ',' ;
              --  DBMS_UTILITY.format_error_backtrace;
        rollback ;
        return -1;
    end;
  --查询副部们角色信息
  function get_parentorg_role(organizationid            in varchar2, --部门id
                              roles                     out sys_refcursor,
                              ErrMsg                    out varchar2)
  return number is
  parent_orgid varchar2(32);
  begin
    --查询副部们ID
    select
    org.c_organization_parent_id into parent_orgid
    from
    lcbase.t_zip_organization org
    where org.c_organization_id=organizationid
    and org.d_enddate>sysdate;
    if  parent_orgid <> '997c2b49b01d4bdba3c5ea4e0f615617' then
      --查询副部们角色信息
      open roles for
      select * from
      lcoa.oa_aut_role_organization roleorg
      where roleorg.c_organization_id=parent_orgid;
    else
      --begin
      -- RAISE_APPLICATION_ERROR(-20001, '顶级部门无法继承父部们角色', false);
     -- EXCEPTION
       -- when DUP_VAL_ON_INDEX then
        ErrMsg := '顶级部门无法继承父部们角色 ~';
        rollback ;
        return -1;
    --  end;
    end if;
    return 0;
  end;

  --修改角色
  function update_role(datainfo        in varchar2, --修改角色名称
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增角色ID
                                        ErrMsg          out varchar2)
  return number is
    n_result    number(1):= 0;
    DATAARR     PKG_COMMON.ARR_LONGSTR;
    OA_ROLE_ID  VARCHAR2(32):=LOWER(SYS_GUID());
    sequence_id number(4);
    ROLE_CODE_num varchar2(4);
    v_name varchar2(4);
  begin
        --新增角色名称
        DATAARR:=PKG_COMMON.SPLIT(DataInfo,'^');

        begin
             select ROLE_NAME into v_name from lcoa.OA_AUT_ROLE where ROLE_NAME=DATAARR(3);
        EXCEPTION
             WHEN  OTHERS THEN
             v_name:=null;
        end;

        if v_name is null then

        --修改OA角色开始
        update lcoa.OA_AUT_ROLE role
        set ROLE_NAME =DATAARR(3),
          v_remark=DATAARR(6)
        where C_ROLE_ID=DATAARR(1);
        --新OA角色修改结束

        --同步到业务系统
        --lcyw角色修改开始
        update lcyw.OA_ROLES
        set ROLE_NAME =DATAARR(3)
        where ID=DATAARR(1);
        --lcyw角色修改结束
        commit ;
        DataId:=DATAARR(1);--返回新增的id
        return n_result;
        else
          ErrMsg:='角色名称重复~';
          return -1;
        end if;
    EXCEPTION
        WHEN  OTHERS THEN
            ErrMsg:='角色数据插入失败';
        rollback ;
        return -1;
    end;
  --停用角色
  function update_delrole(datainfo        in varchar2, --修改角色名称
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增角色ID
                                        ErrMsg          out varchar2)
  return number is
    n_result    number(1):= 0;
    DATAARR     PKG_COMMON.ARR_LONGSTR;
    OA_ROLE_ID  VARCHAR2(32):=LOWER(SYS_GUID());
    sequence_id number(4);
    ROLE_CODE_num varchar2(4);
  begin
        --新增角色名称
        DATAARR:=PKG_COMMON.SPLIT(DataInfo,'^');

        --修改OA角色开始
        update lcoa.OA_AUT_ROLE
        set  deleted=DATAARR(4)
        where C_ROLE_ID=DATAARR(1);
        --新OA角色修改结束

        --同步到业务系统
        --lcyw角色修改开始
        update lcyw.OA_ROLES
        set  deleted=DATAARR(4)
        where  ID=DATAARR(1);
        --lcyw角色修改结束
        commit ;
        DataId:=DATAARR(1);--返回新增的id
        return n_result;
    EXCEPTION
        WHEN  OTHERS THEN
            ErrMsg:='角色数据插入失败';
        rollback ;
        return -1;
    end;
end pkg_ins_role_permissions;

/

