create package body PKG_EXT_MSG_MESSAGEINFO is
  function Insert_UserMsgFeed(PUserMsgFeed    IN VARCHAR2,
                              OperationUserId IN VARCHAR2,
                              MsgFeedId       out varchar2,
                              ErrMsg          out VARCHAR2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  begin
    time_start := systimestamp;
    begin
      n_optype := 2;
      n_result := lcoa.pkg_user_msg.Insert_UserMsgFeed(PUserMsgFeed,
                                                       OperationUserId,
                                                       MsgFeedId,
                                                       ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '新增用户消息评论信息异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Insert_UserMsgFeed',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  function Update_UserMsgFeed(PUserMsgFeed    IN VARCHAR2,
                              OperationUserId IN VARCHAR2,
                              ErrMsg          out VARCHAR2) return NUMBER as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_user_msg.Update_UserMsgFeed(PUserMsgFeed,
                                                       OperationUserId,
                                                       ErrMsg);
    
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '更新用户消息评论信息异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
  
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Update_UserMsgFeed',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  END;
  function Update_UserMsgReaded(MsgId           IN VARCHAR2,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_user_msg.Update_UserMsgReaded(MsgId           => MsgId,
                                                         OperationUserId => OperationUserId,
                                                         ErrMsg          => ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '更新用户消息已读状态异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Update_UserMsgReaded',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  END;
  function Update_UserMsgTop(PNewsInfo       IN VARCHAR2,
                             OperationUserId IN VARCHAR2,
                             ErrMsg          OUT VARCHAR2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_user_msg.Update_UserMsgTop(PNewsInfo,
                                                      OperationUserId,
                                                      ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '设置公告置顶状态异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Update_UserMsgTop',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  END;
  function Get_News_Info(DataId          in varchar2,
                         OperationUserId in varchar2,
                         CUR_INFO        out sys_refcursor,
                         CUR_NUMB        out sys_refcursor,
                         CUR_FLOW        out sys_refcursor,
                         CUR_FILE        out sys_refcursor,
                         CUR_FEED        out sys_refcursor,
                         ErrMsg          out varchar2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_user_get.Get_News_Info(DataId,
                                                  OperationUserId,
                                                  CUR_INFO,
                                                  CUR_NUMB,
                                                  CUR_FLOW,
                                                  CUR_FILE,
                                                  CUR_FEED,
                                                  ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '获取公告信息异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Get_News_Info',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  END;
  function Insert_News_Info(DataInfo        in varchar2,
                            NewsContent     in clob,
                            ArrFile         in arr_longstr,
                            OrgRange        in arr_longstr,
                            OperationUserId in varchar2,
                            DataId          out varchar2,
                            ErrMsg          out varchar2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_user_schedule.Insert_News_Info(DataInfo,
                                                          NewsContent,
                                                          ArrFile,
                                                          OrgRange,
                                                          OperationUserId,
                                                          DataId,
                                                          ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '新增公告信息异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Insert_News_Info',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  END;
  function Update_News_Info(DataInfo        in varchar2,
                            NewsContent     in clob,
                            ArrFile         in arr_longstr,
                            OrgRange        in arr_longstr,
                            OperationUserId in varchar2,
                            DataId          out varchar2,
                            ErrMsg          out varchar2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_user_schedule.Update_News_Info(DataInfo,
                                                          NewsContent,
                                                          ArrFile,
                                                          OrgRange,
                                                          OperationUserId,
                                                          DataId,
                                                          ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '更新公告信息异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Update_News_Info',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  END;
  function Remove_News_Info(NewsId          IN VARCHAR2,
                            OperationUserId IN VARCHAR2,
                            ErrMsg          OUT VARCHAR2) return NUMBER as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_user_schedule.Remove_News_Info(NewsId,
                                                          OperationUserId,
                                                          ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '删除公告信息异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Remove_News_Info',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  END;

  function Get_Email_Content(EmailList out sys_refcursor,
                             ErrMsg    OUT VARCHAR2) return NUMBER as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.PKG_INS_AFW_USERAPPLY.get_email_content(EmailList,
                                                               ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := 'Get_Email_Content: ' || SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog('emaillog',
                                  'Get_Email_Content',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  END;

  function Get_Message_List(UserID     in varchar2,
                            MsgType    in varchar2,
                            pageNum    in number,
                            PageSize   in number,
                            DataInfo   out sys_refcursor,
                            totalPage  out number,
                            totalCount out number,
                            ErrMsg     out varchar2) return NUMBER as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.PKG_INS_MSG_MESSAGEINFO.Get_Message_List(UserID,
                                                                MsgType,
                                                                pageNum,
                                                                PageSize,
                                                                DataInfo,
                                                                totalPage,
                                                                totalCount,
                                                                ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := 'Get_Message_List: ' || SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog('messagelog',
                                  'Get_Message_List',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  END;

  function GetPayMentUserToDo(OperationUserId in varchar2,
                              skipStatus      in number,
                              GetUserTodo     out sys_refcursor,
                              Errmsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.PKG_INS_MSG_MESSAGEINFO.get_payment_usertodo(OperationUserId,
                                                                    skipStatus,
                                                                    GetUserTodo,
                                                                    ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'GetPayMentUserToDo',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

end PKG_EXT_MSG_MESSAGEINFO;
/

