create package body PKG_ZL_ROLE is
  --新增部门
  function CREATEROLE(DataInfo        in varchar2, --新增的部门名称^父部门ID^LEVEL
                                        ErrMsg          out varchar2)
    return number is
  begin
  end; 

end PKG_ZL_ROLE;
/

