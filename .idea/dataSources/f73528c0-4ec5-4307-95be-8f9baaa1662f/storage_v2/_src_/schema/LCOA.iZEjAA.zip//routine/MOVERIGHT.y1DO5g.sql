create function moveright(a in int,n in int) return int
is

begin
   return floor(a/power(2,n));
end;
/

