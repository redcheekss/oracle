create package body PKG_INS_MSG_MESSAGEINFO is

  function Get_Message_List(UserID     in varchar2,
                            MsgType    in varchar2,
                            pageNum    in number,
                            PageSize   in number,
                            DataInfo   out sys_refcursor,
                            totalPage  out number,
                            totalCount out number,
                            ErrMsg     out varchar2) return number is
    n_result     number(3);
    msg_type_sql varchar2(4000);
    vSql         varchar2(4000);
    char1        varchar2(40) := '1970-01-01';
    char2        varchar2(40) := 'yyyy-mm-dd';
    char3        varchar2(40) := 'C_MSG_ID';
    char4        varchar2(40) := 'cdf8fe6fda614f0f99f03de91e7c178d';
    char5        varchar2(40) := '';
  begin
    --公告 纪要 留言
    if MsgType is not null and MsgType > 50 then
      msg_type_sql := 'C_MSG_USER_ID = ' || '''' || UserID || '''' ||
                      ' and N_MSG_TYPE = ' || '''' || MsgType || '''' || '';
      --心情
    elsif MsgType is not null and MsgType = 50 then
      msg_type_sql := ' N_MSG_TYPE = ' || '''' || MsgType || '''' ||
                      ' and (C_MSG_USER_ID = ' || '''' || UserID || '''' || ')';
      --审批流
    elsif MsgType is not null and MsgType < 50 and MsgType > 0 then
      msg_type_sql := 'C_MSG_USER_ID = ' || '''' || UserID || '''' ||
                      ' and N_MSG_TYPE < 50 ';
    else
      msg_type_sql := '(C_MSG_USER_ID = ' || '''' || UserID || '''' || ')';
    end if;
    vSql := 'SELECT * FROM (select t.C_MSG_ID,
           t.N_MSG_TYPE,
           t.N_ISTOP_FLAG,
           t.D_ISTOP_TIME,
           t.V_MSG_TITLE,
           t.D_MSG_TIME,
           t.N_READ_FLAG,
           t.C_MSG_USER_ID,
           t.C_MSG_SRC,
           t.V_MSG_CONTENT,
           t.V_MSG_SENDER,
           t.N_ENABLE
      from OA_MSG_MESSAGE_INFO t
      union all
                    select
                    C_MSG_ID,
                    N_MSG_TYPE,
                    N_ISTOP_FLAG,
                    D_ISTOP_TIME,
                    V_MSG_TITLE,
                    D_MSG_TIME,
                    N_READ_FLAG,
                    C_MSG_USER_ID,
                    C_MSG_SRC,
                    V_MSG_CONTENT,
                    V_MSG_SENDER,
                    N_ENABLE
     from (select msg.C_MSG_ID C_MSG_IDs,
                    ' || '''' || char3 || '''' || ' as C_MSG_ID,
           decode(t.n_news_type, 0, 50, 1, 51, 50) N_MSG_TYPE,
           t.N_ISTOP_FLAG,
          
           null D_ISTOP_TIME,
           t.v_news_title V_MSG_TITLE,
           t.d_input_time D_MSG_TIME,
           1 N_READ_FLAG,
           ' || '''' || UserID || '''' || ' C_MSG_USER_ID,
           t.c_news_id C_MSG_SRC,
           ' || '''' || char5 || '''' ||
            ' V_MSG_CONTENT,
           t.v_input_user_name V_MSG_SENDER,
           msg.N_ENABLE N_ENABLE
      from OA_MSG_PUBLISH_INFO t
      left join OA_MSG_PUBLISH_RANGE r
        on t.c_news_id = r.c_news_id
      left join (select *
                   from OA_MSG_MESSAGE_INFO
                  where c_msg_user_id = ' || '''' || UserID || '''' ||
            ') msg
        on t.c_news_id = msg.c_msg_src
     where ((t.n_news_type = 0 and t.N_STATUS <> -2) or (t.n_news_type = 1 and t.N_NEWS_RANGE = 2 and t.N_STATUS = 2))
        or (t.n_news_type = 1 and t.n_news_range = 1 and t.N_STATUS = 2 and
           r.c_target_id in
           (SELECT o.c_organization_id
               FROM (SELECT *
                       FROM LCBASE.T_ZIP_ORGANIZATION
                      WHERE D_ENDDATE > SYSDATE) o
              start with o.c_organization_id in
                         (select u.c_organization_id
                            from lcbase.t_zip_user u
                           where u.c_user_id = ' || '''' ||
            UserID || '''' || '
                             and u.d_enddate > sysdate)
             connect by prior
                         o.c_organization_parent_id = o.c_organization_id))) c
       where c.C_MSG_IDs is null) t
        where ' || msg_type_sql || '
       order by t.n_istop_flag desc,
                    nvl(t.d_istop_time, to_date(' || '''' ||
            char1 || '''' || ', ' || '''' || char2 || '''' ||
            ')) desc,
                    t.D_MSG_TIME desc';
    /*for i in 1 .. 5 loop
      dbms_output.put_line(substr(vSql, 1900 * (i - 1) + 1, 1900));
    end loop;*/
    n_result := lcoa.pkg_common.GetPagingInfo(vSql,
                                              PageSize,
                                              pageNum,
                                              DataInfo,
                                              totalCount,
                                              totalPage);
    return n_result;
  exception
    when others then
      ErrMsg := 'Get_Message_List: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function get_user_todo(userId      in varchar2,
                         skipStatus  in number,
                         pageNum     in number,
                         PageSize    in number,
                         getUserTodo out sys_refcursor,
                         totalPage   out number,
                         totalCount  out number,
                         errmsg      out varchar2) return number is
    n_result number(6);
    v_sql    varchar2(2000);
  begin
    --插入审批代办
    n_result := PKG_INS_MSG_MESSAGEINFO.add_usertodo_forward(userId,
                                                             skipStatus,
                                                             errmsg);
    --插入会议纪要代办
    n_result := PKG_INS_MSG_MESSAGEINFO.add_usertodo_meetinfo(userId,
                                                              errmsg);
    --插入转正代办
    n_result := PKG_INS_MSG_MESSAGEINFO.add_usertodo_promotion(userId,
                                                               skipStatus,
                                                               errmsg);
    --插入借款应还提醒代办
    n_result := PKG_INS_MSG_MESSAGEINFO.add_usertodo_loan(userId,
                                                          skipStatus,
                                                          errmsg);
    --插入还款确认代办
    n_result := PKG_INS_MSG_MESSAGEINFO.add_usertodo_repayment(userId,
                                                               skipStatus,
                                                               errmsg);
    --插入借款支付代办
    n_result := PKG_INS_MSG_MESSAGEINFO.add_usertodo_loanpay(userId,
                                                             skipStatus,
                                                             errmsg);
    --插入数据修改分发代办
    n_result := PKG_INS_MSG_MESSAGEINFO.add_usertodo_dataModify(userId,
                                                                skipStatus,
                                                                errmsg);
    v_sql    := 'select DISTINCT TODOID, TODOUSERID, TODOTIME, TODOTYPE, TODOTITLE,
										 INPUTTIME, STATUS, DONETIME, TODODATAID
										 from lcoa.oa_tdo_todo_list where TODODATAID is not null ORDER BY TODOTIME desc';
    n_result := lcoa.pkg_common.GetPagingInfo(v_sql,
                                              PageSize,
                                              pageNum,
                                              getUserTodo,
                                              totalCount,
                                              totalPage);
    delete from lcoa.oa_tdo_todo_list;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'get_user_todo: ' || sqlcode || ',' || sqlerrm;
      raise;
      rollback;
      return 1;
  end;

  function add_usertodo_forward(userid     in varchar2,
                                skipStatus in number,
                                errmsg     out varchar2) return number is
  begin
    if skipStatus = 1 then
      insert into lcoa.oa_tdo_todo_list
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    as todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               f.c_workflow_id  as todoDataId
          from lcoa.oa_tdo_todo_info t
          left join lcoa.oa_afw_workflow_approval_flow f
            on f.c_data_id = t.c_todo_data_id
         where t.n_todo_type < 31
           and t.n_status = 0
           and t.c_todo_user_id = userid
           and f.n_skip_flag = 0;
    else
      insert into lcoa.oa_tdo_todo_list
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    as todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               f.c_workflow_id  as todoDataId
          from lcoa.oa_tdo_todo_info t
          left join lcoa.oa_afw_workflow_approval_flow f
            on f.c_data_id = t.c_todo_data_id
         where t.n_todo_type < 31
           and t.n_status = 0
           and t.c_todo_user_id = userid;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_usertodo_forward: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_usertodo_meetinfo(userid in varchar2, errmsg out varchar2)
    return number is
  begin
    insert into lcoa.oa_tdo_todo_list
      select t.C_TODO_ID as todoId,
             t.C_TODO_USER_ID as todoUserId,
             TO_DATE(TO_CHAR(t.D_TODO_TIME, 'YYYYMMDD') ||
                     TO_CHAR(s.D_SCH_START_TIME, 'hh24mi'),
                     'YYYYMMDDHH24mi') AS todoTime,
             t.N_TODO_TYPE as todoType,
             t.V_TODO_TITLE as todoTitle,
             t.D_INPUT_TIME as inputTime,
             t.N_STATUS as status,
             t.D_DONE_TIME as doneTime,
             t.C_TODO_DATA_ID as todoDataId
        from lcoa.oa_tdo_todo_info t
        LEFT JOIN lcoa.oa_sde_scheduling_flow f
          ON t.c_todo_data_id = f.c_flow_id
        LEFT JOIN lcoa.oa_sde_schedule_info s
          ON s.c_sch_id = f.c_sch_id
       where t.n_todo_type = 52
         and t.n_status = 0
         and t.D_TODO_TIME < TRUNC(SYSDATE, 'dd') + 2
         and t.c_todo_user_id = userid;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_usertodo_meetinfo: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise;
  end;

  function add_usertodo_promotion(userid     in varchar2,
                                  skipStatus in number,
                                  errmsg     out varchar2) return number is
    countuser number(6);
  begin
    select count(*)
      into countuser
      from lcoa.oa_afw_promotion_info p
     where p.c_promotion_user_id = userid;
    if countuser = 0 then
      if skipStatus = 1 then
        insert into lcoa.oa_tdo_todo_list
          select t.C_TODO_ID      as todoId,
                 t.C_TODO_USER_ID as todoUserId,
                 t.D_TODO_TIME    AS todoTime,
                 t.N_TODO_TYPE    as todoType,
                 t.V_TODO_TITLE   as todoTitle,
                 t.D_INPUT_TIME   as inputTime,
                 t.N_STATUS       as status,
                 t.D_DONE_TIME    as doneTime,
                 t.C_TODO_DATA_ID as todoDataId
            from lcoa.oa_tdo_todo_info t
            LEFT JOIN lcoa.oa_afw_workflow_approval_flow f
              ON t.c_todo_data_id = f.c_data_id
           where t.n_todo_type = 53
             and t.n_status = 0
             and t.c_todo_user_id = userid
             and f.n_skip_flag = 0;
      else
        insert into lcoa.oa_tdo_todo_list
          select t.C_TODO_ID      as todoId,
                 t.C_TODO_USER_ID as todoUserId,
                 t.D_TODO_TIME    AS todoTime,
                 t.N_TODO_TYPE    as todoType,
                 t.V_TODO_TITLE   as todoTitle,
                 t.D_INPUT_TIME   as inputTime,
                 t.N_STATUS       as status,
                 t.D_DONE_TIME    as doneTime,
                 t.C_TODO_DATA_ID as todoDataId
            from lcoa.oa_tdo_todo_info t
            LEFT JOIN lcoa.oa_afw_workflow_approval_flow f
              ON t.c_todo_data_id = f.c_data_id
           where t.n_todo_type = 53
             and t.n_status = 0
             and t.c_todo_user_id = userid;
      end if;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_usertodo_promotion: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise;
  end;

  --待办业务类型(54:数据修改分发提醒)
  function add_usertodo_dataModify(userid     in varchar2,
                                   skipStatus in number,
                                   errmsg     out varchar2) return number is
    countuser number(6);
  begin
    if skipStatus = 1 then
      insert into lcoa.oa_tdo_todo_list
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    AS todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               t.C_TODO_DATA_ID as todoDataId
          from lcoa.oa_tdo_todo_info t
          LEFT JOIN lcoa.oa_afw_workflow_approval_flow f
            ON t.c_todo_data_id = f.c_data_id
         where t.n_todo_type = 54
           and t.n_status = 0
           and t.c_todo_user_id = userid
           and f.n_skip_flag = 0;
    else
      insert into lcoa.oa_tdo_todo_list
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    AS todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               t.C_TODO_DATA_ID as todoDataId
          from lcoa.oa_tdo_todo_info t
          LEFT JOIN lcoa.oa_afw_workflow_approval_flow f
            ON t.c_todo_data_id = f.c_data_id
         where t.n_todo_type = 54
           and t.n_status = 0
           and t.c_todo_user_id = userid;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_usertodo_dataModify: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise;
  end;

  --待办业务类型(55:借款应还提醒)
  function add_usertodo_loan(userid     in varchar2,
                             skipStatus in number,
                             errmsg     out varchar2) return number is
    countuser number(6);
  begin
    if skipStatus = 1 then
      insert into lcoa.oa_tdo_todo_list
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    AS todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               t.C_TODO_DATA_ID as todoDataId
          from lcoa.oa_tdo_todo_info t
          LEFT JOIN lcoa.oa_afw_workflow_approval_flow f
            ON t.c_todo_data_id = f.c_data_id
         where t.n_todo_type = 55
           and t.n_status = 0
           and t.c_todo_user_id = userid
           and f.n_skip_flag = 0;
    else
      insert into lcoa.oa_tdo_todo_list
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    AS todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               t.C_TODO_DATA_ID as todoDataId
          from lcoa.oa_tdo_todo_info t
          LEFT JOIN lcoa.oa_afw_workflow_approval_flow f
            ON t.c_todo_data_id = f.c_data_id
         where t.n_todo_type = 55
           and t.n_status = 0
           and t.c_todo_user_id = userid;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_usertodo_loan: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise;
  end;

  --待办业务类型(56:还款确认)
  function add_usertodo_repayment(userid     in varchar2,
                                  skipStatus in number,
                                  errmsg     out varchar2) return number is
    countuser number(6);
  begin
    if skipStatus = 1 then
      insert into lcoa.oa_tdo_todo_list
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    AS todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               t.C_TODO_DATA_ID as todoDataId
          from lcoa.oa_tdo_todo_info t
          LEFT JOIN lcoa.oa_afw_repayment_info f
            ON t.c_todo_data_id = f.c_id
         where t.n_todo_type = 56
           and t.n_status = 0
           and t.c_todo_user_id = userid
           and f.n_skip_flag = 0;
    else
      insert into lcoa.oa_tdo_todo_list
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    AS todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               t.C_TODO_DATA_ID as todoDataId
          from lcoa.oa_tdo_todo_info t
          LEFT JOIN lcoa.oa_afw_repayment_info f
            ON t.c_todo_data_id = f.c_id
         where t.n_todo_type = 56
           and t.n_status = 0
           and t.c_todo_user_id = userid;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_usertodo_repayment: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise;
  end;

  --待办业务类型(57借款支付)
  function add_usertodo_loanpay(userid     in varchar2,
                                skipStatus in number,
                                errmsg     out varchar2) return number is
    countuser number(6);
  begin
    if skipStatus = 1 then
      insert into lcoa.oa_tdo_todo_list
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    AS todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               t.C_TODO_DATA_ID as todoDataId
          from lcoa.oa_tdo_todo_info t
          LEFT JOIN lcoa.oa_afw_workflow_approval_flow f
            ON t.c_todo_data_id = f.c_data_id
         where t.n_todo_type = 57
           and t.n_status = 0
           and t.c_todo_user_id = userid
           and f.n_skip_flag = 0;
    else
      insert into lcoa.oa_tdo_todo_list
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    AS todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               t.C_TODO_DATA_ID as todoDataId
          from lcoa.oa_tdo_todo_info t
          LEFT JOIN lcoa.oa_afw_workflow_approval_flow f
            ON t.c_todo_data_id = f.c_data_id
         where t.n_todo_type = 57
           and t.n_status = 0
           and t.c_todo_user_id = userid;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_usertodo_loanpay: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise;
  end;

  function get_payment_usertodo(userid      in varchar2,
                                skipStatus  in number,
                                GetUserTodo out sys_refcursor,
                                errmsg      out varchar2) return number is
  begin
    if skipStatus = 1 then
      open GetUserTodo for
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    AS todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               t.C_TODO_DATA_ID as todoDataId
          from lcoa.oa_tdo_todo_info t
          LEFT JOIN lcoa.oa_afw_workflow_approval_flow f
            ON t.c_todo_data_id = f.c_data_id
         where t.n_todo_type = 56
           and t.n_status = 0
           and t.c_todo_user_id = userid
           and f.n_skip_flag = 0;
    else
      open GetUserTodo for
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    AS todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               t.C_TODO_DATA_ID as todoDataId
          from lcoa.oa_tdo_todo_info t
          LEFT JOIN lcoa.oa_afw_workflow_approval_flow f
            ON t.c_todo_data_id = f.c_data_id
         where t.n_todo_type = 56
           and t.n_status = 0
           and t.c_todo_user_id = userid;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'get_payment_usertodo: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise;
  end;

end;
/

