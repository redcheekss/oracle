create package PKG_LIHUAWEI_USER_INFO is
  type ApprovalUsersType is Record(
    UserId    lcbase.t_zip_user.c_user_id%type,
    UserName  lcbase.t_zip_user.v_pet_name%type,
    UserTitle varchar2(32));

  TYPE ArrayUsersType IS TABLE OF ApprovalUsersType INDEX BY BINARY_INTEGER; --定义存放记录的数组类型

  user_rec ApprovalUsersType; --声明变量，类型：记录类型

  --  user_rec_array user_type_array; --声明变量，类型：存放记录的数组类型

  FUNCTION OAGetUserInfo(UserID   IN VARCHAR2,
                         User_CUR OUT sys_refcursor,
                         ErrMsg   OUT VARCHAR2) return number;
  procedure GetDirectSuperiorByUserId(UserId            in varchar2,
                                      SuperiorUserId    out varchar2,
                                      SuperiorUserName  out varchar2,
                                      SuperiorUserTitle out varchar2);
  procedure GetDirectSuperiorByOrgId(OrganizationId    in varchar2,
                                     SuperiorUserId    out varchar2,
                                     SuperiorUserName  out varchar2,
                                     SuperiorUserTitle out varchar2);

  procedure GetVPByUserId(UserId      in varchar2,
                          VPUserId    out varchar2,
                          VPUserName  out varchar2,
                          VPUserTitle out varchar2);
  procedure GetBPByOrgId(OrganizationId in varchar2,
                         BPUserId       out varchar2,
                         BPUserName     out varchar2,
                         BPUserTitle    out varchar2);
  function GetPOByUserId(UserId in varchar2) return ArrayUsersType;
  function GetPLByUserId(UserId in varchar2) return ArrayUsersType;
  function GetCEO return ArrayUsersType;
  function GetMilitaryCommittee return ArrayUsersType;

  procedure GetCEO(CEOId    out varchar2,
                   CEOName  out varchar2,
                   CEOTitle out varchar2);
  procedure GetMilitaryCommittee(PUserIds   out varchar2,
                                 PUserNames out varchar2);
  procedure GetTechnicalCommittee(PUserIds   out varchar2,
                                  PUserNames out varchar2);
  function GetSpecialDepartmentOwner(nRoleId in number) return ArrayUsersType;
  function GetCommonLeaderByUserId(UserId in varchar2) return ArrayUsersType;

  procedure GetSpecialDepartmentOwner(nRoleId    in number,
                                      PUserIds   out varchar2,
                                      PUserNames out varchar2);
  function IsVPUserByUserId(UserId      in varchar2,
                            VPUserId    out varchar2,
                            VPUserName  out varchar2,
                            VPUserTitle out varchar2) return number;
  function IsCEOByUserId(UserId   in varchar2,
                         CEOId    out varchar2,
                         CEOName  out varchar2,
                         CEOTitle out varchar2) return number;
  --是否为常委                         
  function IsMilitaryCommitteeByUserId(UserId     in varchar2,
                                       PUserId    out varchar2,
                                       PUserName  out varchar2,
                                       PUserTitle out varchar2) return number;
  --是否为技术委员会
  function IsTechnicalCommitteeByUserId(UserId     in varchar2,
                                        PUserId    out varchar2,
                                        PUserName  out varchar2,
                                        PUserTitle out varchar2)
    return number;
  --是否为属于特殊部门
  function IsSpecialDepartmentByUserId(UserId  in varchar2,
                                       nRoleId out number) return number;
  function IsSpecialDepartmentByOrgId(OrgId   in varchar2,
                                      nRoleId out number) return number;

  --针对二级部门负责人                         
  function IsLv2OwnerByUserId(UserId        in varchar2,
                              Lv2OrgType    out number,
                              Lv2OwnerId    out varchar2,
                              Lv2OwnerName  out varchar2,
                              Lv2OwnerTitle out varchar2) return number;

  function GetOwnerUntileLv2(WorkflowUserId in varchar2)
    return ArrayUsersType;

  function GetLv2OwnerByUserId(WorkflowUserId in varchar2)
    return ArrayUsersType;

  function GetNearestBP(WorkflowUserId    in varchar2,
                        NewOrganizationId in varchar default '')
    return ArrayUsersType;
  -- 调岗      
  procedure workflow_approval_Reset;
end PKG_LIHUAWEI_USER_INFO;
/

