create package body pkg_mahaowei_role is
  procedure get_meet_message is
    curdata number(1);
  begin
    curdata := 1;
  end;

  /**
  部门上移下移
  **/
  function count_roleuserid(OperationUserId IN VARCHAR2,
                            ErrMsg          out varchar2) return number is
    countrole number(6);
  begin
    SELECT count(*)
      into countrole
      FROM lcoa.OA_AUT_ROLE r
      LEFT JOIN lcoa.OA_AUT_USER_ROLE ur
        ON r.C_ROLE_ID = ur.C_ROLE_ID
     WHERE r.ROLE_TYPE IN ('11', '502', '503', '504', '505', '506')
       AND ur.c_user_id = OperationUserId;
    if countrole > 0 then
      countrole := 1;
    end if;
    return countrole;
  exception
    when others then
      ErrMsg := 'count_roleuserid: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function Cansee_Roleorg(OperationUserId IN VARCHAR2,
                          DataInfo        out sys_refcursor,
                          ErrMsg          out varchar2) return number is
    countrole  number(6);
    countadmin number(6);
    n_result   number(6);
  begin
    SELECT count(*)
      into countrole
      FROM lcoa.OA_AUT_ROLE r
      LEFT JOIN lcoa.OA_AUT_USER_ROLE ur
        ON r.C_ROLE_ID = ur.C_ROLE_ID
     WHERE r.ROLE_TYPE = '505'
       and ur.c_user_id = OperationUserId;
    SELECT count(*)
      into countadmin
      FROM lcoa.OA_AUT_ROLE r
      LEFT JOIN lcoa.OA_AUT_USER_ROLE ur
        ON r.C_ROLE_ID = ur.C_ROLE_ID
     WHERE r.ROLE_TYPE = '502'
       and ur.c_user_id = OperationUserId;
    if countadmin > 0 then
      n_result := pkg_organization.get_organizationdownward('997c2b49b01d4bdba3c5ea4e0f615617',
                                                            OperationUserId,
                                                            DataInfo,
                                                            ErrMsg);
    elsif countrole > 0 then
      open DataInfo for
        SELECT DISTINCT *
          FROM (SELECT DISTINCT *
                  FROM (SELECT *
                          FROM LCBASE.T_ZIP_ORGANIZATION
                         WHERE D_ENDDATE > SYSDATE) t
                 start with t.c_organization_id in
                            (select w.c_organization_id
                               from (SELECT *
                                       FROM (SELECT *
                                               FROM lcbase.t_zip_organization
                                              WHERE n_status = 0
                                                AND D_ENDDATE > SYSDATE) t
                                      START WITH t.c_organization_id in
                                                 (SELECT o.C_ORGANIZATION_ID
                                                    FROM (SELECT *
                                                            FROM lcbase.T_ZIP_ORGANIZATION o
                                                           WHERE o.D_ENDDATE >
                                                                 SYSDATE) o
                                                   WHERE o.C_ORGANIZATION_PO =
                                                         OperationUserId)
                                     CONNECT BY t.c_organization_parent_id = PRIOR
                                                t.c_organization_id
                                            AND t.n_status = 0
                                     union
                                     SELECT *
                                       FROM (SELECT *
                                               FROM lcbase.t_zip_organization
                                              WHERE n_status = 0
                                                AND D_ENDDATE > SYSDATE) t
                                      START WITH t.c_organization_id in
                                                 (SELECT o.C_ORGANIZATION_ID
                                                    FROM (SELECT *
                                                            FROM lcbase.T_ZIP_ORGANIZATION o
                                                           WHERE o.D_ENDDATE >
                                                                 SYSDATE) o
                                                   WHERE o.c_organization_owner =
                                                         OperationUserId)
                                     CONNECT BY t.c_organization_parent_id = PRIOR
                                                t.c_organization_id
                                            AND t.n_status = 0) w)
                connect by prior
                            t.c_organization_parent_id = t.c_organization_id
                UNION
                SELECT *
                  FROM (SELECT *
                          FROM lcbase.t_zip_organization
                         WHERE n_status = 0
                           AND D_ENDDATE > SYSDATE) t
                 START WITH t.c_organization_id =
                            'a7260eacce5c5289e050a8c0020125b3'
                CONNECT BY t.c_organization_parent_id = PRIOR
                           t.c_organization_id
                       AND t.n_status = 0) w;
    else
      open DataInfo for
        SELECT DISTINCT *
          FROM (SELECT *
                  FROM LCBASE.T_ZIP_ORGANIZATION
                 WHERE D_ENDDATE > SYSDATE) t
         start with t.c_organization_id in
                    (select w.c_organization_id
                       from (SELECT *
                               FROM (SELECT *
                                       FROM lcbase.t_zip_organization
                                      WHERE n_status = 0
                                        AND D_ENDDATE > SYSDATE) t
                              START WITH t.c_organization_id in
                                         (SELECT o.C_ORGANIZATION_ID
                                            FROM (SELECT *
                                                    FROM lcbase.T_ZIP_ORGANIZATION o
                                                   WHERE o.D_ENDDATE > SYSDATE) o
                                           WHERE o.C_ORGANIZATION_PO =
                                                 OperationUserId)
                             CONNECT BY t.c_organization_parent_id = PRIOR
                                        t.c_organization_id
                                    AND t.n_status = 0
                             union
                             SELECT *
                               FROM (SELECT *
                                       FROM lcbase.t_zip_organization
                                      WHERE n_status = 0
                                        AND D_ENDDATE > SYSDATE) t
                              START WITH t.c_organization_id in
                                         (SELECT o.C_ORGANIZATION_ID
                                            FROM (SELECT *
                                                    FROM lcbase.T_ZIP_ORGANIZATION o
                                                   WHERE o.D_ENDDATE > SYSDATE) o
                                           WHERE o.c_organization_owner =
                                                 OperationUserId)
                             CONNECT BY t.c_organization_parent_id = PRIOR
                                        t.c_organization_id
                                    AND t.n_status = 0) w)
        connect by prior t.c_organization_parent_id = t.c_organization_id;
    end if;
    return 0;
  exception
    when others then
      ErrMsg := 'Cansee_Roleorg: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function get_roleemployees_list(OrganizationId  in varchar2,
                                  status          in varchar2,
                                  pageNum         in number,
                                  PageSize        in number,
                                  OperationUserId IN VARCHAR2,
                                  DataList        out sys_refcursor,
                                  owner           out varchar2,
                                  BpName          out varchar2,
                                  VpName          out varchar2,
                                  totalPage       out number,
                                  totalCount      out number,
                                  dataCount       out number,
                                  ErrMsg          out varchar2) return number is
    n_result        number(3);
    nOrganizationId varchar2(32);
  begin
    if nOrganizationId is null then 
      dataCount := pkg_mahaowei_role.getrole_dataCount(OperationUserId,
                                                     ErrMsg);
    if dataCount = 0 then
      return 0;
    end if;
      n_result        := pkg_mahaowei_role.get_employees_rolelist(nOrganizationId,
                                                                  status,
                                                                  pageNum,
                                                                  PageSize,
                                                                  OperationUserId,
                                                                  DataList,
                                                                  owner,
                                                                  BpName,
                                                                  VpName,
                                                                  totalPage,
                                                                  totalCount,
                                                                  ErrMsg);
    else 
      nOrganizationId := OrganizationId;
      dataCount := pkg_mahaowei_role.get_roleCount(nOrganizationId,
                                                       OperationUserId,
                                                       ErrMsg);
    if dataCount = 0 then
      return 0;
    end if;
      n_result        := pkg_mahaowei_role.noorg_employees_rolelist(nOrganizationId,
                                                                       status,
                                                                       pageNum,
                                                                       PageSize,
                                                                       OperationUserId,
                                                                       DataList,
                                                                       owner,
                                                                       BpName,
                                                                       VpName,
                                                                       totalPage,
                                                                       totalCount,
                                                                       ErrMsg);
    end if;
    return n_result;
  exception
    when others then
      ErrMsg := 'get_roleemployees_list: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function get_employees_rolelist(nOrganizationId in varchar2,
                                  status          in varchar2,
                                  pageNum         in number,
                                  PageSize        in number,
                                  OperationUserId IN VARCHAR2,
                                  DataList        out sys_refcursor,
                                  owner           out varchar2,
                                  BpName          out varchar2,
                                  VpName          out varchar2,
                                  totalPage       out number,
                                  totalCount      out number,
                                  ErrMsg          out varchar2) return number is
    n_result number(3);
    vSql     varchar2(8000);
    --nOrganizationId varchar2(32);
    o        varchar(32) := '997c2b49b01d4bdba3c5ea4e0f615617';
    o1        varchar(32) := 'a7260eacce5c5289e050a8c0020125b3';
    char1    varchar(40) := '-';
    char2    varchar(40) := '-北京乐卡车联科技有限公司-';
    char3    varchar(40) := '';
    char4    varchar(40) := '-北京乐卡车联科技有限公司';
    char5    varchar(40) := '北京乐卡车联科技有限公司';
    char6    varchar(40) := '0';
    countrole  number(6);
    countadmin number(6);
  begin
    n_result := pkg_mahaowei_role.count_adminrole(OperationUserId,countrole,countadmin,ErrMsg);
    
    vSql := 'select * from (SELECT
                u.v_pet_name AS userName,
                u.V_EMAIL AS email,
                u.C_ORGANIZATION_ID AS organizationId,
                o.V_ORGANIZATION_NAME AS organizationName,
                u.c_user_id AS cUserId,
                e.n_work_place AS nWorkPlace,
                e.n_possession AS nPossession,
                e.v_user_title AS vUserTitle,
                e.c_id_card_number AS cIdCardNumber,
                e.d_hire_date AS dHireDate,
                e.n_political_apperar AS nPoliticalApperar,
                e.v_nation AS vNation,
                e.n_marriage AS nMarriage,
                e.v_id_card_address AS vIdCardAddress,
                e.n_hu_kou_type AS nHuKouType,
                e.v_present_address AS vPresentAddress,
                e.v_urgency_link_man AS vUrgencyLinkMan,
                e.v_urgency_link_tel AS vUrgencyLinkTel,
                e.v_college AS vCollege,
                e.v_major AS vMajor,
                e.n_learning AS nLearning,
                e.d_entrance AS dEntrance,
                e.d_graduation AS dGraduation,
                e.n_hobbies AS nHobbies,
                e.v_grades AS vGrades,
                e.d_promotion AS dPromotion,
                e.n_education AS nEducation,
                e.v_bank_card_number AS vBankCardNumber,
                e.v_accumulation_fund_type AS vAccumulationFundType,
                e.v_opening_bank AS vOpeningBank,
                e.v_remark AS vRemark,
                e.n_social_security_type AS nSocialSecurityType,
                e.d_leave AS dLeave,
                LPAD(e.n_work_num,4,' || '''' || char6 || '''' ||
            ') AS nWorkNum,
                LPAD(e.N_WORK_NUM_OLD,4,' || '''' || char6 || '''' ||
            ') AS nWorkNumOld,
                e.c_labor_ref AS cLaborRef,
                e.n_status AS nStatus,
                e.c_lk_company_id AS lkCompanyId,
                u.N_MOBILE_1 as tel,
                CASE
                    WHEN e.N_WORK_NUM_OLD IS NULL THEN -1
                    ELSE e.N_WORK_NUM_OLD
                END AS nWorkNumOldOrder,
                u.V_PET_NAME as petName,
                REPLACE(REPLACE(o1.v_organization_name,
                             ' || '''' || char2 || '''' || ',
                             ' || '''' || char3 || '''' || '),
                     ' || '''' || char4 || '''' || ',
                     ' || '''' || char5 || '''' ||
            ') as organizationNameAll
              FROM
                lcbase.t_zip_user u 
              LEFT JOIN lcbase.t_employees_info e ON 
                u.c_user_id = e.c_user_id 
              LEFT JOIN (SELECT * FROM LCBASE.T_ZIP_ORGANIZATION
                   WHERE D_ENDDATE > SYSDATE) o ON 
                u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID 
              LEFT JOIN (SELECT t.c_organization_id c_organization_id,
                          SYS_CONNECT_BY_PATH(t.v_organization_name, ' || '''' ||
            char1 || '''' || ') v_organization_name
                     FROM (SELECT * FROM LCBASE.T_ZIP_ORGANIZATION 
                     WHERE D_ENDDATE > SYSDATE) t 
                    START WITH t.c_organization_id =
                               LOWER(' || '''' || o || '''' || ')
                   CONNECT BY PRIOR t.c_organization_id =
                               t.c_organization_parent_id) o1
          ON u.C_ORGANIZATION_ID = o1.c_organization_id
       where e.n_work_place is not null and o.n_status = 0
       and u.d_enddate > SYSDATE
       and u.c_organization_id IN ';
       
    if countadmin > 0 then
      vSql := vSql || '(SELECT c_organization_id
        FROM (SELECT *
                FROM LCBASE.T_ZIP_ORGANIZATION
               WHERE D_ENDDATE > SYSDATE) t
       start with t.c_organization_id = ' || '''' || o || '''' || '
      connect by prior t.c_organization_parent_id = t.c_organization_id)';
    elsif countrole > 0 then
    vSql := vSql || '(SELECT c_organization_id FROM (SELECT DISTINCT * FROM
	(SELECT * FROM
		(SELECT * FROM
			(SELECT * FROM
				lcbase.t_zip_organization
			WHERE n_status = 0
				AND D_ENDDATE > SYSDATE) t
		START WITH t.c_organization_id IN (
			SELECT o.C_ORGANIZATION_ID FROM
				(SELECT * FROM
					lcbase.T_ZIP_ORGANIZATION o
				WHERE o.D_ENDDATE > SYSDATE) o
			WHERE o.C_ORGANIZATION_PO = ' || '''' || OperationUserId || '''' || ')
		CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id
			AND t.n_status = 0
	UNION
		SELECT * FROM
			(SELECT * FROM
				lcbase.t_zip_organization
			WHERE n_status = 0
				AND D_ENDDATE > SYSDATE) t
		START WITH t.c_organization_id IN (
			SELECT o.C_ORGANIZATION_ID FROM
				(SELECT * FROM
					lcbase.T_ZIP_ORGANIZATION o
				WHERE o.D_ENDDATE > SYSDATE) o
			WHERE o.c_organization_owner = ' || '''' || OperationUserId || '''' || ')
		CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id
			AND t.n_status = 0)
UNION
	SELECT * FROM
		(SELECT * FROM lcbase.t_zip_organization WHERE n_status = 0
			AND D_ENDDATE > SYSDATE) t
	START WITH t.c_organization_id = ' || '''' || o1 || '''' || '
	CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id
		AND t.n_status = 0) w ))';
    else 
      vSql := vSql || '(SELECT c_organization_id FROM (SELECT DISTINCT * FROM
		(SELECT * FROM (SELECT * FROM lcbase.t_zip_organization
			WHERE n_status = 0 AND D_ENDDATE > SYSDATE) t
		START WITH t.c_organization_id IN (
			SELECT o.C_ORGANIZATION_ID FROM
				(SELECT * FROM lcbase.T_ZIP_ORGANIZATION o
				WHERE o.D_ENDDATE > SYSDATE) o
			WHERE o.C_ORGANIZATION_PO = ' || '''' || OperationUserId || '''' || ')
		CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id AND t.n_status = 0
	UNION
		SELECT * FROM (SELECT * FROM
				lcbase.t_zip_organization
			WHERE n_status = 0 AND D_ENDDATE > SYSDATE) t
		START WITH t.c_organization_id IN (
			SELECT o.C_ORGANIZATION_ID FROM
				(SELECT * FROM
					lcbase.T_ZIP_ORGANIZATION o
				WHERE o.D_ENDDATE > SYSDATE) o
			WHERE o.c_organization_owner = ' || '''' || OperationUserId || '''' || ')
		CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id
			AND t.n_status = 0) w ))';
    end if;
    
    vSql := vSql || ' and e.n_status = ' || char6 || ' ';
    vSql := vSql || ') o order by o.nWorkNumOldOrder desc';
    for i in 1 .. 5 loop
      dbms_output.put_line(substr(vSql, 1900 * (i - 1) + 1, 1900));
    end loop;
    n_result := lcoa.pkg_common.GetPagingInfo(vSql,
                                              PageSize,
                                              pageNum,
                                              DataList,
                                              totalCount,
                                              totalPage);
    if nOrganizationId is not null then
      n_result := pkg_ins_employees_admin.get_obvnames(nOrganizationId,
                                                       owner,
                                                       BpName,
                                                       VpName,
                                                       ErrMsg);
    end if;
    return n_result;
  exception
    when others then
      ErrMsg := 'get_employees_rolelist: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;
  
  function noorg_employees_rolelist(nOrganizationId in varchar2,
                                  status          in varchar2,
                                  pageNum         in number,
                                  PageSize        in number,
                                  OperationUserId IN VARCHAR2,
                                  DataList        out sys_refcursor,
                                  owner           out varchar2,
                                  BpName          out varchar2,
                                  VpName          out varchar2,
                                  totalPage       out number,
                                  totalCount      out number,
                                  ErrMsg          out varchar2) return number is
    n_result number(3);
    vSql     varchar2(8000);
    --nOrganizationId varchar2(32);
    o        varchar(32) := '997c2b49b01d4bdba3c5ea4e0f615617';
    o1        varchar(32) := 'a7260eacce5c5289e050a8c0020125b3';
    char1    varchar(40) := '-';
    char2    varchar(40) := '-北京乐卡车联科技有限公司-';
    char3    varchar(40) := '';
    char4    varchar(40) := '-北京乐卡车联科技有限公司';
    char5    varchar(40) := '北京乐卡车联科技有限公司';
    char6    varchar(40) := '0';
    countrole  number(6);
    countadmin number(6);
    poroleuser varchar(40);
    ownerroleuser varchar(40);
  begin
    n_result := pkg_mahaowei_role.count_adminrole(OperationUserId,countrole,countadmin,ErrMsg); 
    
    select o.C_ORGANIZATION_PO into poroleuser from lcbase.t_zip_organization o 
    WHERE o.D_ENDDATE > SYSDATE AND o.c_organization_id = nOrganizationId;
    
    select o.C_ORGANIZATION_OWNER into ownerroleuser from lcbase.t_zip_organization o 
    WHERE o.D_ENDDATE > SYSDATE AND o.c_organization_id = nOrganizationId;
  
    vSql := 'select * from (SELECT
                u.v_pet_name AS userName,
                u.V_EMAIL AS email,
                u.C_ORGANIZATION_ID AS organizationId,
                o.V_ORGANIZATION_NAME AS organizationName,
                u.c_user_id AS cUserId,
                e.n_work_place AS nWorkPlace,
                e.n_possession AS nPossession,
                e.v_user_title AS vUserTitle,
                e.c_id_card_number AS cIdCardNumber,
                e.d_hire_date AS dHireDate,
                e.n_political_apperar AS nPoliticalApperar,
                e.v_nation AS vNation,
                e.n_marriage AS nMarriage,
                e.v_id_card_address AS vIdCardAddress,
                e.n_hu_kou_type AS nHuKouType,
                e.v_present_address AS vPresentAddress,
                e.v_urgency_link_man AS vUrgencyLinkMan,
                e.v_urgency_link_tel AS vUrgencyLinkTel,
                e.v_college AS vCollege,
                e.v_major AS vMajor,
                e.n_learning AS nLearning,
                e.d_entrance AS dEntrance,
                e.d_graduation AS dGraduation,
                e.n_hobbies AS nHobbies,
                e.v_grades AS vGrades,
                e.d_promotion AS dPromotion,
                e.n_education AS nEducation,
                e.v_bank_card_number AS vBankCardNumber,
                e.v_accumulation_fund_type AS vAccumulationFundType,
                e.v_opening_bank AS vOpeningBank,
                e.v_remark AS vRemark,
                e.n_social_security_type AS nSocialSecurityType,
                e.d_leave AS dLeave,
                LPAD(e.n_work_num,4,' || '''' || char6 || '''' ||
            ') AS nWorkNum,
                LPAD(e.N_WORK_NUM_OLD,4,' || '''' || char6 || '''' ||
            ') AS nWorkNumOld,
                e.c_labor_ref AS cLaborRef,
                e.n_status AS nStatus,
                e.c_lk_company_id AS lkCompanyId,
                u.N_MOBILE_1 as tel,
                CASE
                    WHEN e.N_WORK_NUM_OLD IS NULL THEN -1
                    ELSE e.N_WORK_NUM_OLD
                END AS nWorkNumOldOrder,
                u.V_PET_NAME as petName,
                REPLACE(REPLACE(o1.v_organization_name,
                             ' || '''' || char2 || '''' || ',
                             ' || '''' || char3 || '''' || '),
                     ' || '''' || char4 || '''' || ',
                     ' || '''' || char5 || '''' ||
            ') as organizationNameAll
              FROM
                lcbase.t_zip_user u 
              LEFT JOIN lcbase.t_employees_info e ON 
                u.c_user_id = e.c_user_id 
              LEFT JOIN (SELECT * FROM LCBASE.T_ZIP_ORGANIZATION
                   WHERE D_ENDDATE > SYSDATE) o ON 
                u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID 
              LEFT JOIN (SELECT t.c_organization_id c_organization_id,
                          SYS_CONNECT_BY_PATH(t.v_organization_name, ' || '''' ||
            char1 || '''' || ') v_organization_name
                     FROM (SELECT * FROM LCBASE.T_ZIP_ORGANIZATION 
                     WHERE D_ENDDATE > SYSDATE) t 
                    START WITH t.c_organization_id =
                               LOWER(' || '''' || o || '''' || ')
                   CONNECT BY PRIOR t.c_organization_id =
                               t.c_organization_parent_id) o1
          ON u.C_ORGANIZATION_ID = o1.c_organization_id
       where e.n_work_place is not null and o.n_status = 0
       and u.d_enddate > SYSDATE
       and u.c_organization_id IN ';

    if countadmin > 0 then
      vSql := vSql || '(SELECT t.C_ORGANIZATION_ID FROM (SELECT * FROM LCBASE.T_ZIP_ORGANIZATION WHERE D_ENDDATE > SYSDATE) t 
       START WITH t.c_organization_id = ' || '''' ||
            nOrganizationId || '''' ||
            ' CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id) ';
    elsif countrole > 0 then
    if OperationUserId <> poroleuser and OperationUserId <> ownerroleuser then
    vSql := vSql || '(SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
                where t.c_organization_id not in (SELECT c_organization_id
        FROM (SELECT *
                FROM LCBASE.T_ZIP_ORGANIZATION
               WHERE D_ENDDATE > SYSDATE) t
       start with t.c_organization_id in 
       (SELECT o.C_ORGANIZATION_PARENT_ID FROM LCBASE.T_ZIP_ORGANIZATION o 
       WHERE o.D_ENDDATE > SYSDATE AND o.c_organization_id = ' || '''' || nOrganizationId || '''' || ')
      connect by prior t.c_organization_parent_id = t.c_organization_id)
               START WITH t.c_organization_id in
                          (select c_organization_id
                             from (SELECT DISTINCT *
                                     FROM (SELECT DISTINCT *
                                             FROM (SELECT *
                                                     FROM LCBASE.T_ZIP_ORGANIZATION
                                                    WHERE D_ENDDATE > SYSDATE) t
                                            start with t.c_organization_id in
                                                       (select w.c_organization_id
                                                          from (SELECT *
                                                                  FROM (SELECT *
                                                                          FROM lcbase.t_zip_organization
                                                                         WHERE n_status = 0
                                                                           AND D_ENDDATE >
                                                                               SYSDATE) t
                                                                 START WITH t.c_organization_id in
                                                                            (SELECT o.C_ORGANIZATION_ID
                                                                               FROM (SELECT *
                                                                                       FROM lcbase.T_ZIP_ORGANIZATION o
                                                                                      WHERE o.D_ENDDATE >
                                                                                            SYSDATE) o
                                                                              WHERE o.C_ORGANIZATION_PO =
                                                                                    ' || '''' || OperationUserId || '''' || ')
                                                                CONNECT BY t.c_organization_parent_id = PRIOR
                                                                           t.c_organization_id
                                                                       AND t.n_status = 0
                                                                union
                                                                SELECT *
                                                                  FROM (SELECT *
                                                                          FROM lcbase.t_zip_organization
                                                                         WHERE n_status = 0
                                                                           AND D_ENDDATE >
                                                                               SYSDATE) t
                                                                 START WITH t.c_organization_id in
                                                                            (SELECT o.C_ORGANIZATION_ID
                                                                               FROM (SELECT *
                                                                                       FROM lcbase.T_ZIP_ORGANIZATION o
                                                                                      WHERE o.D_ENDDATE >
                                                                                            SYSDATE) o
                                                                              WHERE o.c_organization_owner =
                                                                                    ' || '''' || OperationUserId || '''' || ')
                                                                CONNECT BY t.c_organization_parent_id = PRIOR
                                                                           t.c_organization_id
                                                                       AND t.n_status = 0) w)
                                           connect by prior t.c_organization_parent_id =
                                                       t.c_organization_id
                                           UNION
                                           SELECT *
                                             FROM (SELECT *
                                                     FROM lcbase.t_zip_organization
                                                    WHERE n_status = 0
                                                      AND D_ENDDATE > SYSDATE) t
                                            START WITH t.c_organization_id =
                                                       ' || '''' || o1 || '''' || '
                                           CONNECT BY t.c_organization_parent_id = PRIOR
                                                      t.c_organization_id
                                                  AND t.n_status = 0) w) q)
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id)
         and e.n_status = 0 ';
         else 
           vSql := vSql || '(SELECT t.C_ORGANIZATION_ID FROM 
           (SELECT * FROM LCBASE.T_ZIP_ORGANIZATION WHERE D_ENDDATE > SYSDATE) t 
           START WITH t.c_organization_id = ' || '''' || nOrganizationId || '''' || ' 
            CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id) ';
         end if;
    else 
    if OperationUserId <> poroleuser and OperationUserId <> ownerroleuser then
      vSql := vSql || '(SELECT c_organization_id FROM (SELECT DISTINCT * FROM
		(SELECT * FROM (SELECT * FROM lcbase.t_zip_organization
			WHERE n_status = 0 AND D_ENDDATE > SYSDATE) t
     where t.c_organization_id not in (SELECT c_organization_id
        FROM (SELECT *
                FROM LCBASE.T_ZIP_ORGANIZATION
               WHERE D_ENDDATE > SYSDATE) t
       start with t.c_organization_id in 
       (SELECT o.C_ORGANIZATION_PARENT_ID FROM LCBASE.T_ZIP_ORGANIZATION o 
       WHERE o.D_ENDDATE > SYSDATE AND o.c_organization_id = ' || '''' || nOrganizationId || '''' || ')
      connect by prior t.c_organization_parent_id = t.c_organization_id)
		START WITH t.c_organization_id IN (
			SELECT o.C_ORGANIZATION_ID FROM
				(SELECT * FROM lcbase.T_ZIP_ORGANIZATION o
				WHERE o.D_ENDDATE > SYSDATE) o
			WHERE o.C_ORGANIZATION_PO = ' || '''' || OperationUserId || '''' || ')
		CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id AND t.n_status = 0
	UNION
		SELECT * FROM (SELECT * FROM
				lcbase.t_zip_organization
			WHERE n_status = 0 AND D_ENDDATE > SYSDATE) t
		START WITH t.c_organization_id IN (
			SELECT o.C_ORGANIZATION_ID FROM
				(SELECT * FROM
					lcbase.T_ZIP_ORGANIZATION o
				WHERE o.D_ENDDATE > SYSDATE) o
			WHERE o.c_organization_owner = ' || '''' || OperationUserId || '''' || ')
		CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id
			AND t.n_status = 0) w ))';
         else 
           vSql := vSql || '(SELECT t.C_ORGANIZATION_ID FROM 
           (SELECT * FROM LCBASE.T_ZIP_ORGANIZATION WHERE D_ENDDATE > SYSDATE) t 
           START WITH t.c_organization_id = ' || '''' || nOrganizationId || '''' || ' 
            CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id) ';
         end if;
    end if;
  

    vSql := vSql || ' and e.n_status = ' || char6 || ' ';
    vSql := vSql || ') o order by o.nWorkNumOldOrder desc';
    for i in 1 .. 5 loop
      dbms_output.put_line(substr(vSql, 1900 * (i - 1) + 1, 1900));
    end loop;
    n_result := lcoa.pkg_common.GetPagingInfo(vSql,
                                              PageSize,
                                              pageNum,
                                              DataList,
                                              totalCount,
                                              totalPage);
    if nOrganizationId is not null then
      n_result := pkg_ins_employees_admin.get_obvnames(nOrganizationId,
                                                       owner,
                                                       BpName,
                                                       VpName,
                                                       ErrMsg);
    end if;
    return n_result;
  exception
    when others then
      ErrMsg := 'noorg_employees_rolelist: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function getrole_dataCount(OperationUserId in varchar2,
                             ErrMsg          out varchar2) return number is
    countoId   number(6);
    countrole  number(6);
    countadmin number(6);
    n_result   number(6);
  begin
    n_result := pkg_mahaowei_role.count_adminrole(OperationUserId,countrole,countadmin,ErrMsg);
  
    if countadmin > 0 then
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where e.n_work_place is not null
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and o.n_status = 0
         and e.n_status = 0
         AND u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id =
                          '997c2b49b01d4bdba3c5ea4e0f615617'
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id);
    elsif countrole > 0 then
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where o.n_status = 0
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id in
                          (select c_organization_id
                             from (SELECT DISTINCT *
                                     FROM (select *
                                          from (SELECT *
                                                  FROM (SELECT *
                                                          FROM lcbase.t_zip_organization
                                                         WHERE n_status = 0
                                                           AND D_ENDDATE >
                                                               SYSDATE) t
                                                 START WITH t.c_organization_id in
                                                            (SELECT o.C_ORGANIZATION_ID
                                                               FROM (SELECT *
                                                                       FROM lcbase.T_ZIP_ORGANIZATION o
                                                                      WHERE o.D_ENDDATE >
                                                                            SYSDATE) o
                                                                              WHERE o.C_ORGANIZATION_PO =
                                                                                    OperationUserId)
                                                                CONNECT BY t.c_organization_parent_id = PRIOR
                                                                           t.c_organization_id
                                                                       AND t.n_status = 0
                                                                union
                                                                SELECT *
                                                                  FROM (SELECT *
                                                                          FROM lcbase.t_zip_organization
                                                                         WHERE n_status = 0
                                                                           AND D_ENDDATE >
                                                                               SYSDATE) t
                                                                 START WITH t.c_organization_id in
                                                                            (SELECT o.C_ORGANIZATION_ID
                                                                               FROM (SELECT *
                                                                                       FROM lcbase.T_ZIP_ORGANIZATION o
                                                                                      WHERE o.D_ENDDATE >
                                                                                            SYSDATE) o
                                                                              WHERE o.c_organization_owner =
                                                                                    OperationUserId)
                                                                CONNECT BY t.c_organization_parent_id = PRIOR
                                                                           t.c_organization_id
                                                                       AND t.n_status = 0) w)
                                           UNION
                                           SELECT *
                                             FROM (SELECT *
                                                     FROM lcbase.t_zip_organization
                                                    WHERE n_status = 0
                                                      AND D_ENDDATE > SYSDATE) t
                                            START WITH t.c_organization_id =
                                                       'a7260eacce5c5289e050a8c0020125b3'
                                           CONNECT BY t.c_organization_parent_id = PRIOR
                                                      t.c_organization_id
                                                  AND t.n_status = 0) w)
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id)
         and e.n_status = 0;
    else
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where o.n_status = 0
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id in
                          (select w.c_organization_id
                             from (select w.c_organization_id
                                                  from (SELECT *
                                                          FROM (SELECT *
                                                                  FROM lcbase.t_zip_organization
                                                                 WHERE n_status = 0
                                                                   AND D_ENDDATE >
                                                                       SYSDATE) t
                                                         START WITH t.c_organization_id in
                                                                    (SELECT o.C_ORGANIZATION_ID
                                                                       FROM (SELECT *
                                                                               FROM lcbase.T_ZIP_ORGANIZATION o
                                                                              WHERE o.D_ENDDATE >
                                                                                    SYSDATE) o
                                                                      WHERE o.C_ORGANIZATION_PO =
                                                                            OperationUserId)
                                                        CONNECT BY t.c_organization_parent_id = PRIOR
                                                                   t.c_organization_id
                                                               AND t.n_status = 0
                                                        union
                                                        SELECT *
                                                          FROM (SELECT *
                                                                  FROM lcbase.t_zip_organization
                                                                 WHERE n_status = 0
                                                                   AND D_ENDDATE >
                                                                       SYSDATE) t
                                                         START WITH t.c_organization_id in
                                                                    (SELECT o.C_ORGANIZATION_ID
                                                                       FROM (SELECT *
                                                                               FROM lcbase.T_ZIP_ORGANIZATION o
                                                                              WHERE o.D_ENDDATE >
                                                                                    SYSDATE) o
                                                                      WHERE o.c_organization_owner =
                                                                            OperationUserId)
                                                        CONNECT BY t.c_organization_parent_id = PRIOR
                                                                   t.c_organization_id
                                                               AND t.n_status = 0) w) w)
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id)
         and e.n_status = 0;
    end if;
    return countoId;
  exception
    when others then
      ErrMsg := 'getrole_dataCount: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;
  
  function get_roleCount(nOrganizationId in varchar2,
                         OperationUserId IN VARCHAR2, 
                         ErrMsg out varchar2)
    return number is
    countoId   number(6);
    countrole  number(6);
    countadmin number(6);
    n_result   number(6);
  begin
    n_result := pkg_mahaowei_role.count_adminrole(OperationUserId,countrole,countadmin,ErrMsg);
  
    if countadmin > 0 then
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where e.n_work_place is not null
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and o.n_status = 0
         and e.n_status = 0
         AND u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id = nOrganizationId
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id);
    elsif countrole > 0 then
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where o.n_status = 0
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id in
                          (select c_organization_id
                             from (SELECT DISTINCT *
                                     FROM (select *
                                          from (SELECT *
                                                  FROM (SELECT *
                                                          FROM lcbase.t_zip_organization
                                                         WHERE n_status = 0
                                                           AND D_ENDDATE >
                                                               SYSDATE) t
                                                 START WITH t.c_organization_id in
                                                            (SELECT o.C_ORGANIZATION_ID
                                                               FROM (SELECT *
                                                                       FROM lcbase.T_ZIP_ORGANIZATION o
                                                                      WHERE o.D_ENDDATE >
                                                                            SYSDATE) o
                                                                              WHERE o.C_ORGANIZATION_PO =
                                                                                    OperationUserId)
                                                                CONNECT BY t.c_organization_parent_id = PRIOR
                                                                           t.c_organization_id
                                                                       AND t.n_status = 0
                                                                union
                                                                SELECT *
                                                                  FROM (SELECT *
                                                                          FROM lcbase.t_zip_organization
                                                                         WHERE n_status = 0
                                                                           AND D_ENDDATE >
                                                                               SYSDATE) t
                                                                 START WITH t.c_organization_id in
                                                                            (SELECT o.C_ORGANIZATION_ID
                                                                               FROM (SELECT *
                                                                                       FROM lcbase.T_ZIP_ORGANIZATION o
                                                                                      WHERE o.D_ENDDATE >
                                                                                            SYSDATE) o
                                                                              WHERE o.c_organization_owner =
                                                                                    OperationUserId)
                                                                CONNECT BY t.c_organization_parent_id = PRIOR
                                                                           t.c_organization_id
                                                                       AND t.n_status = 0) w)
                                           UNION
                                           SELECT *
                                             FROM (SELECT *
                                                     FROM lcbase.t_zip_organization
                                                    WHERE n_status = 0
                                                      AND D_ENDDATE > SYSDATE) t
                                            START WITH t.c_organization_id =
                                                       'a7260eacce5c5289e050a8c0020125b3'
                                           CONNECT BY t.c_organization_parent_id = PRIOR
                                                      t.c_organization_id
                                                  AND t.n_status = 0) w)
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id)
         and e.n_status = 0;
    else
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where o.n_status = 0
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
                where t.c_organization_id not in (SELECT c_organization_id
        FROM (SELECT *
                FROM LCBASE.T_ZIP_ORGANIZATION
               WHERE D_ENDDATE > SYSDATE) t
       start with t.c_organization_id = nOrganizationId
      connect by prior t.c_organization_parent_id = t.c_organization_id)
               START WITH t.c_organization_id in
                          (select w.c_organization_id
                             from (select w.c_organization_id
                                                  from (SELECT *
                                                          FROM (SELECT *
                                                                  FROM lcbase.t_zip_organization
                                                                 WHERE n_status = 0
                                                                   AND D_ENDDATE >
                                                                       SYSDATE) t
                                                         START WITH t.c_organization_id in
                                                                    (SELECT o.C_ORGANIZATION_ID
                                                                       FROM (SELECT *
                                                                               FROM lcbase.T_ZIP_ORGANIZATION o
                                                                              WHERE o.D_ENDDATE >
                                                                                    SYSDATE) o
                                                                      WHERE o.C_ORGANIZATION_PO =
                                                                            OperationUserId)
                                                        CONNECT BY t.c_organization_parent_id = PRIOR
                                                                   t.c_organization_id
                                                               AND t.n_status = 0
                                                        union
                                                        SELECT *
                                                          FROM (SELECT *
                                                                  FROM lcbase.t_zip_organization
                                                                 WHERE n_status = 0
                                                                   AND D_ENDDATE >
                                                                       SYSDATE) t
                                                         START WITH t.c_organization_id in
                                                                    (SELECT o.C_ORGANIZATION_ID
                                                                       FROM (SELECT *
                                                                               FROM lcbase.T_ZIP_ORGANIZATION o
                                                                              WHERE o.D_ENDDATE >
                                                                                    SYSDATE) o
                                                                      WHERE o.c_organization_owner =
                                                                            OperationUserId)
                                                        CONNECT BY t.c_organization_parent_id = PRIOR
                                                                   t.c_organization_id
                                                               AND t.n_status = 0) w) w)
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id)
         and e.n_status = 0;
    end if;
    return countoId;
  exception
    when others then
      ErrMsg := 'get_roleCount: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;
  
  function count_adminrole(OperationUserId IN VARCHAR2,
                           countrole out number,
                           countadmin out number,
                            ErrMsg          out varchar2) return number is
  begin
    SELECT count(*)
      into countrole
      FROM lcoa.OA_AUT_ROLE r
      LEFT JOIN lcoa.OA_AUT_USER_ROLE ur
        ON r.C_ROLE_ID = ur.C_ROLE_ID
     WHERE r.ROLE_TYPE = '505'
       and ur.c_user_id = OperationUserId;
    SELECT count(*)
      into countadmin
      FROM lcoa.OA_AUT_ROLE r
      LEFT JOIN lcoa.OA_AUT_USER_ROLE ur
        ON r.C_ROLE_ID = ur.C_ROLE_ID
     WHERE r.ROLE_TYPE = '502'
       and ur.c_user_id = OperationUserId;
    return 0;
  exception
    when others then
      ErrMsg := 'count_adminrole: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

end;
/

