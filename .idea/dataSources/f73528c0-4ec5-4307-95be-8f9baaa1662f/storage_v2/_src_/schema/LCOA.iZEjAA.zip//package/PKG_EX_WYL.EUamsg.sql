create package PKG_EX_WYL is

  -- Author  : 王永利
  -- Created : 2020/4/2 15:40:21
  -- Purpose : 

  -- Public function and procedure declarations
  function underLinePayment(userId     in varchar2,
                            expensesId in varchar2,
                            resultMsg  out varchar2) return number;

   function refusePayment(userId     in varchar2,
                         expensesId in varchar2,
                         reason     in varchar2,
                         resultMsg out varchar2) return number;

end PKG_EX_WYL;
/

