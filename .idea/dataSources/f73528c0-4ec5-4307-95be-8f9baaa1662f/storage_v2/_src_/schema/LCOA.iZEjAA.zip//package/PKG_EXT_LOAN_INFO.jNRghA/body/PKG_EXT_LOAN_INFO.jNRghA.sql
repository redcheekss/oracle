create package body PKG_EXT_LOAN_INFO is
  function save_loan_info(datainfo        in varchar2,
                          OperationUserId IN VARCHAR2,
                          c_cursor        out sys_refcursor,
                          ErrMsg          OUT VARCHAR2) return number is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
  begin
    time_start := systimestamp;
    begin
      n_optype := 2;
      n_result := lcoa.PKG_INS_LOAN_INFO.save_loan_info(datainfo,
                                                        OperationUserId,
                                                        c_cursor,
                                                        ErrMsg);
    
    EXCEPTION
      WHEN OTHERS THEN
        --ErrMsg := pkg_common.g_errmsg_common;
        ErrMsg   := SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'save_loan_info',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end save_loan_info;

  function getLoanInfo(loanId          in varchar2, --借款信息ID
                       operationUserId in varchar2, --操作人ID
                       loanInfo        out sys_refcursor, --借款单详情 
                       ApproveUsers    out sys_refcursor, --审批人详情
                       roleCount       out number,
                       accountantCount out number,
                       cashierCount    out number,
                       ErrMsg          out varchar2) return number is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
  begin
    time_start := systimestamp;
    begin
      n_optype := 1;
      n_result := lcoa.PKG_INS_LOAN_INFO.getLoanInfo(loanId,
                                                     operationUserId,
                                                     loanInfo,
                                                     ApproveUsers,
                                                     roleCount,
                                                     accountantCount,
                                                     cashierCount,
                                                     ErrMsg);
    
    EXCEPTION
      WHEN OTHERS THEN
        --ErrMsg := pkg_common.g_errmsg_common;
        ErrMsg   := SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'getLoanInfo',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function get_Loan_Approval(WorkflowUserId     in varchar2,
                             WorkflowType       in number,
                             WorkflowSubtype    in number,
                             DStartTime         in varchar2,
                             DEndTime           in varchar2,
                             New_OrganizationId in varchar2,
                             Days               out number,
                             Hours              out number,
                             CUR_DATA           out sys_refcursor,
                             companyId          out varchar2,
                             caiwuRoleCount     out number,
                             ErrMsg             out varchar2) return number is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
  begin
    time_start := systimestamp;
    begin
      n_optype := 1;
      n_result := lcoa.PKG_INS_LOAN_INFO.get_Loan_Approval(WorkflowUserId,
                                                           WorkflowType,
                                                           WorkflowSubtype,
                                                           DStartTime,
                                                           DEndTime,
                                                           New_OrganizationId,
                                                           Days,
                                                           Hours,
                                                           CUR_DATA,
                                                           companyId,
                                                           caiwuRoleCount,
                                                           ErrMsg);
    
    EXCEPTION
      WHEN OTHERS THEN
        --ErrMsg := pkg_common.g_errmsg_common;
        ErrMsg   := SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(WorkflowUserId,
                                  'get_Loan_Approval',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function SetCompanyId(datainfo        in varchar2,
                        OperationUserId IN VARCHAR2,
                        ErrMsg          OUT VARCHAR2) return number is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
  begin
    time_start := systimestamp;
    begin
      n_optype := 2;
      n_result := lcoa.PKG_INS_LOAN_INFO.SetCompanyId(datainfo,
                                                      OperationUserId,
                                                      ErrMsg);
    
    EXCEPTION
      WHEN OTHERS THEN
        --ErrMsg := pkg_common.g_errmsg_common;
        ErrMsg   := SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'SetCompanyId',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end SetCompanyId;

  function remindRepay(ErrMsg out varchar2) return number is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
  begin
    time_start := systimestamp;
    begin
      n_optype := 2;
      n_result := lcoa.PKG_INS_LOAN_INFO.remindRepay(ErrMsg);
    
    EXCEPTION
      WHEN OTHERS THEN
        --ErrMsg := pkg_common.g_errmsg_common;
        ErrMsg   := SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog('定时任务推送还款通知',
                                  'remindRepay',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end remindRepay;

end;
/

