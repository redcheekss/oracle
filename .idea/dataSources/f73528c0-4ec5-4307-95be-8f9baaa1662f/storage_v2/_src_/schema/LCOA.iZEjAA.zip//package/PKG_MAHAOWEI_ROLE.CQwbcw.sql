create package pkg_mahaowei_role is
  procedure get_meet_message;

  function count_roleuserid(OperationUserId IN VARCHAR2,
                            ErrMsg          out varchar2) return number;

  function Cansee_Roleorg(OperationUserId IN VARCHAR2,
                          DataInfo        out sys_refcursor,
                          ErrMsg          out varchar2) return number;

  function get_roleemployees_list(OrganizationId  in varchar2,
                                  status          in varchar2,
                                  pageNum         in number,
                                  PageSize        in number,
                                  OperationUserId IN VARCHAR2,
                                  DataList        out sys_refcursor,
                                  owner           out varchar2,
                                  BpName          out varchar2,
                                  VpName          out varchar2,
                                  totalPage       out number,
                                  totalCount      out number,
                                  dataCount       out number,
                                  ErrMsg          out varchar2) return number;

  function get_employees_rolelist(nOrganizationId in varchar2,
                                  status          in varchar2,
                                  pageNum         in number,
                                  PageSize        in number,
                                  OperationUserId IN VARCHAR2,
                                  DataList        out sys_refcursor,
                                  owner           out varchar2,
                                  BpName          out varchar2,
                                  VpName          out varchar2,
                                  totalPage       out number,
                                  totalCount      out number,
                                  ErrMsg          out varchar2) return number;
                                  
  function noorg_employees_rolelist(nOrganizationId in varchar2,
                                  status          in varchar2,
                                  pageNum         in number,
                                  PageSize        in number,
                                  OperationUserId IN VARCHAR2,
                                  DataList        out sys_refcursor,
                                  owner           out varchar2,
                                  BpName          out varchar2,
                                  VpName          out varchar2,
                                  totalPage       out number,
                                  totalCount      out number,
                                  ErrMsg          out varchar2) return number;

  function getrole_dataCount(OperationUserId in varchar2,
                             ErrMsg          out varchar2) return number;

  function get_roleCount(nOrganizationId in varchar2,
                                  OperationUserId IN VARCHAR2, ErrMsg out varchar2)
    return number;
    
  function count_adminrole(OperationUserId IN VARCHAR2,
                           countrole out number,
                           countadmin out number,
                            ErrMsg          out varchar2) return number;

end;
/

