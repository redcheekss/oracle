create package PKG_EXT_MSG_MESSAGEINFO is

  -- Author  : LIHUAWEI
  -- Created : 2020/4/20 14:34:41
  -- Purpose : 对外提供消息相关接口

  -- Public function and procedure declarations
  function Insert_UserMsgFeed(PUserMsgFeed    IN VARCHAR2,
                              OperationUserId IN VARCHAR2,
                              MsgFeedId       out varchar2,
                              ErrMsg          out VARCHAR2) return number;
  function Update_UserMsgFeed(PUserMsgFeed    IN VARCHAR2,
                              OperationUserId IN VARCHAR2,
                              ErrMsg          out VARCHAR2) return NUMBER;
  function Update_UserMsgReaded(MsgId           IN VARCHAR2,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) return number;
  function Update_UserMsgTop(PNewsInfo       IN VARCHAR2,
                             OperationUserId IN VARCHAR2,
                             ErrMsg          OUT VARCHAR2) return number;
  function Get_News_Info(DataId          in varchar2,
                         OperationUserId in varchar2,
                         CUR_INFO        out sys_refcursor,
                         CUR_NUMB        out sys_refcursor,
                         CUR_FLOW        out sys_refcursor,
                         CUR_FILE        out sys_refcursor,
                         CUR_FEED        out sys_refcursor,
                         ErrMsg          out varchar2) return number;
  function Insert_News_Info(DataInfo        in varchar2,
                            NewsContent     in clob,
                            ArrFile         in arr_longstr,
                            OrgRange        in arr_longstr,
                            OperationUserId in varchar2,
                            DataId          out varchar2,
                            ErrMsg          out varchar2) return number;
  function Update_News_Info(DataInfo        in varchar2,
                            NewsContent     in clob,
                            ArrFile         in arr_longstr,
                            OrgRange        in arr_longstr,
                            OperationUserId in varchar2,
                            DataId          out varchar2,
                            ErrMsg          out varchar2) return number;
  function Remove_News_Info(NewsId          IN VARCHAR2,
                            OperationUserId IN VARCHAR2,
                            ErrMsg          OUT VARCHAR2) return NUMBER;

  function Get_Email_Content(EmailList out sys_refcursor,
                             ErrMsg    OUT VARCHAR2) return NUMBER;

  function Get_Message_List(UserID     in varchar2,
                            MsgType    in varchar2,
                            pageNum    in number,
                            PageSize   in number,
                            DataInfo   out sys_refcursor,
                            totalPage  out number,
                            totalCount out number,
                            ErrMsg     out varchar2) return NUMBER;
  function GetPayMentUserToDo(OperationUserId in varchar2,
                              skipStatus      in number,
                              GetUserTodo     out sys_refcursor,
                              Errmsg          out varchar2) return number;

end PKG_EXT_MSG_MESSAGEINFO;
/

