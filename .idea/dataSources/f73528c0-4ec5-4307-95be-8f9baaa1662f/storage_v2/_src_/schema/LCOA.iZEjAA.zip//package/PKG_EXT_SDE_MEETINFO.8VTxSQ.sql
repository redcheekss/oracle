create package PKG_EXT_SDE_MEETINFO is

  -- Author  : EDZ
  -- Created : 2020/4/20 14:33:30
  -- Purpose : 

  -- Public function and procedure declarations
  function GET_MEETING_MAJOR(DataId          in varchar2,
                             DataSource      in number,
                             OperationUserId in varchar2,
                             getmeetinginfo  out sys_refcursor,
                             getmeetcontent  out sys_refcursor,
                             gettodolist     out sys_refcursor,
                             getuploadinfo   out sys_refcursor,
                             getattendeelist out sys_refcursor,
                             getschedulenum  out sys_refcursor,
                             getuserschedule out sys_refcursor,
                             countmeetingid  out number,
                             ErrMsg          out varchar2) return number;

  function ADD_MEETINGSUMMARY_INFO(SDE_MEETING_INFO         IN varchar2,
                                   SDE_ATTENDEE_LIST        IN ARR_LONGSTR,
                                   SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                   OA_SDE_TODO_LIST         IN ARR_LONGSTR,
                                   USER_UPLOAD_INFO         IN ARR_LONGSTR,
                                   operation_id             in varchar2,
                                   ErrMsg                   OUT VARCHAR2,
                                   sys_meeting_id           out varchar2)
    return number;

  function MEETING_MSG_RELEASEINFO(SDE_MEETING_INFO         IN varchar2,
                                   SDE_ATTENDEE_LIST        IN ARR_LONGSTR,
                                   SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                   OA_SDE_TODO_LIST         IN ARR_LONGSTR,
                                   USER_UPLOAD_INFO         IN ARR_LONGSTR,
                                   operation_id             in varchar2,
                                   ErrMsg                   OUT VARCHAR2)
    return number;

end PKG_EXT_SDE_MEETINFO;
/

