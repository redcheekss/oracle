create package body test_zhaochao is

  procedure Create_Next_Approval_Todo(WorkflowId in varchar2,
                                      TodoTitle  in varchar2) is
    CUR_FLOW sys_refcursor;
    ROW_FLOW oa_afw_workflow_approval_flow%rowtype;
    FLG_MODE number(1);
  begin
    FLG_MODE := -1;
    open CUR_FLOW for
      select *
        from oa_afw_workflow_approval_flow t
       where t.c_workflow_id = WorkflowId
         and t.n_approval_status = 0
       order by t.n_approval_order;
    fetch CUR_FLOW
      into ROW_FLOW;
    while CUR_FLOW%found loop
      if (FLG_MODE = -1) or
         (FLG_MODE = 0 and ROW_FLOW.N_APPROVAL_MODEL = 0) then
        insert into oa_tdo_todo_info
          (c_todo_id,
           c_todo_user_id,
           d_todo_time,
           n_todo_type,
           v_todo_title,
           d_input_time,
           n_status,
           c_todo_data_id)
        values
          (lower(sys_guid()),
           ROW_FLOW.C_APPROVAL_USER_ID,
           sysdate,
           ROW_FLOW.N_WORKFLOW_TYPE,
           TodoTitle,
           sysdate,
           0,
           ROW_FLOW.C_DATA_ID);
        FLG_MODE := ROW_FLOW.N_APPROVAL_MODEL;
      else
        exit;
      end if;
      fetch CUR_FLOW
        into ROW_FLOW;
    end loop;
    commit;
    close CUR_FLOW;
  end;

  function Create_Part_Approval_Userlist(ROW_CONF       in oa_afw_workflow_config%rowtype,
                                         WorkflowId     in varchar2,
                                         OrganizationId in varchar2,
                                         LST            out T_FLOW)
    return number is
    cur_org_owner sys_refcursor;
    flowusercount number(1) := 1;
  begin
    flowusercount := 1;
    if ROW_CONF.N_APPROVAL_USER_TYPE = 1 then
      /*
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               w.c_user_id,
               w.v_user_name,
               '直接上级',
               0,
               null,
               null
          into LST(1).c_data_id,
               LST(1).n_workflow_type,
               LST(1).c_workflow_id,
               LST(1).n_approval_order,
               LST(1).n_approval_model,
               LST(1).c_approval_user_id,
               LST(1).v_approval_user_name,
               LST(1).v_approval_user_title,
               LST(1).n_approval_status,
               LST(1).d_approval_time,
               LST(1).v_approval_remark
          from lcbase.t_organization g
          left join lcbase.t_user w
            on w.c_user_id = g.c_organization_owner
         where g.c_organization_id = OrganizationId;
      */
      with all_g as
       (select *
          from lcbase.t_organization g
        connect by prior g.c_organization_parent_id = g.c_organization_id
         start with g.c_organization_id = OrganizationId)
      select lower(sys_guid()),
             ROW_CONF.N_WORKFLOW_TYPE,
             WorkflowId,
             0,
             ROW_CONF.N_APPROVAL_MODEL,
             w.c_user_id,
             w.v_user_name,
             '直接上级',
             0,
             null,
             null
        into LST(1)
        from all_g g
        left join lcbase.t_user w
          on w.c_user_id = g.c_organization_owner
       where g.n_organization_level >= 2;
    
    elsif ROW_CONF.N_APPROVAL_USER_TYPE = 2 then
      open cur_org_owner for
        with all_g as
         (select *
            from lcbase.t_organization g
          connect by prior g.c_organization_parent_id = g.c_organization_id
           start with g.c_organization_id = OrganizationId)
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               w.c_user_id,
               w.v_user_name,
               case
                 when g.n_organization_level = 1 then
                  '主管副总'
                 else
                  '上级'
               end,
               0,
               null,
               null
          from all_g g
          left join lcbase.t_user w
            on w.c_user_id = g.c_organization_owner
         where nvl(g.n_organization_level, 5) > 0;
      fetch cur_org_owner
        into LST(0);
      while cur_org_owner%found loop
        LST(flowusercount) := LST(0);
        flowusercount := flowusercount + 1;
        fetch cur_org_owner
          into LST(0);
      end loop;
      close cur_org_owner;
    
    elsif ROW_CONF.N_APPROVAL_USER_TYPE = 3 then
      /*select lower(sys_guid()),
            ROW_CONF.N_WORKFLOW_TYPE,
            WorkflowId,
            0,
            ROW_CONF.N_APPROVAL_MODEL,
            w.c_user_id,
            w.v_user_name,
            '主管副总',
            0,
            null,
            null
       into LST(1).c_data_id,
            LST(1).n_workflow_type,
            LST(1).c_workflow_id,
            LST(1).n_approval_order,
            LST(1).n_approval_model,
            LST(1).c_approval_user_id,
            LST(1).v_approval_user_name,
            LST(1).v_approval_user_title,
            LST(1).n_approval_status,
            LST(1).d_approval_time,
            LST(1).v_approval_remark
       from lcbase.t_organization g
       left join lcbase.t_user w
         on w.c_user_id = g.c_organization_vp
      where g.c_organization_id = OrganizationId;*/
    
      with all_g as
       (select *
          from lcbase.t_organization g
        connect by prior g.c_organization_parent_id = g.c_organization_id
         start with g.c_organization_id = OrganizationId)
      select lower(sys_guid()),
             ROW_CONF.N_WORKFLOW_TYPE,
             WorkflowId,
             0,
             ROW_CONF.N_APPROVAL_MODEL,
             w.c_user_id,
             w.v_user_name,
             '主管副总',
             0,
             null,
             null
        into LST(1)
        from all_g g
        left join lcbase.t_user w
          on w.c_user_id = g.c_organization_vp
       where g.n_organization_level = 2;
    
    elsif ROW_CONF.N_APPROVAL_USER_TYPE = 4 then
      with all_g as
       (select *
          from lcbase.t_organization g
        connect by prior g.c_organization_parent_id = g.c_organization_id
         start with g.c_organization_id = OrganizationId)
      select lower(sys_guid()),
             ROW_CONF.N_WORKFLOW_TYPE,
             WorkflowId,
             0,
             ROW_CONF.N_APPROVAL_MODEL,
             w.c_user_id,
             w.v_user_name,
             '最近BP',
             0,
             null,
             null
        into LST(1)
        from all_g g
        left join lcbase.t_user w
          on w.c_user_id = g.c_organization_bp
       where g.c_organization_bp is not null;else
    
      select lower(sys_guid()),
             ROW_CONF.N_WORKFLOW_TYPE,
             WorkflowId,
             0,
             ROW_CONF.N_APPROVAL_MODEL,
             u.v_approval_user_id,
             u.v_approval_user_name,
             u.v_approval_user_title,
             0,
             null,
             null
        into LST(1)
        from oa_afw_workflow_user_type u
       where u.n_approval_user_type =
             ROW_CONF.N_APPROVAL_USER_TYPE;
    end if;
    return flowusercount;
  end;

  procedure Create_All_Approval_Userlist(WorkflowId         in varchar2,
                                         WorkflowType       in number,
                                         DaysCount          in number,
                                         Old_OrganizationId in varchar2,
                                         New_OrganizationId in varchar2) is
    CUR_CONF sys_refcursor;
    ROW_CONF oa_afw_workflow_config%rowtype;
    P_LST    T_FLOW;
    P_NUM    number(1);
    P_ALL    number(1);
    P_EXIST  number(1);
  begin
    P_ALL := 0;
    open CUR_CONF for
      select *
        from oa_afw_workflow_config
       where n_workflow_type = WorkflowType
       order by n_approval_order;
    fetch CUR_CONF
      into ROW_CONF;
    while CUR_CONF%found loop
      P_NUM := Create_Part_Approval_Userlist(ROW_CONF,
                                             WorkflowId,
                                             case
                                               when WorkflowType = 12 and P_ALL >= 2 then
                                                New_OrganizationId
                                               else
                                                Old_OrganizationId
                                             end,
                                             P_LST);
      for I in 1 .. P_NUM loop
        select count(1)
          into P_EXIST
          from oa_afw_workflow_approval_flow t
         where t.c_workflow_id = WorkflowId
           and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        if P_EXIST = 0 then
          insert into oa_afw_workflow_approval_flow
            (c_data_id,
             n_workflow_type,
             c_workflow_id,
             n_approval_order,
             n_approval_model,
             c_approval_user_id,
             v_approval_user_name,
             v_approval_user_title,
             n_approval_status)
          values
            (P_LST(I).c_data_id,
             P_LST(I).n_workflow_type,
             P_LST(I).c_workflow_id,
             P_ALL + I, --P_LST(I).n_approval_order,
             P_LST(I).n_approval_model,
             P_LST(I).c_approval_user_id,
             P_LST(I).v_approval_user_name,
             P_LST(I).v_approval_user_title,
             P_LST(I).n_approval_status);
        else
          update oa_afw_workflow_approval_flow t
             set t.v_approval_user_title = t.v_approval_user_title || ',' || P_LST(I)
                                          .v_approval_user_title
           where t.c_workflow_id = WorkflowId
             and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        end if;
      end loop;
      P_ALL := P_ALL + P_NUM;
      if P_ALL > 0 and WorkflowType in (1, 2) and DaysCount < 3 then
        exit;
      end if;
      fetch CUR_CONF
        into ROW_CONF;
    end loop;
    close CUR_CONF;
    commit;
  end;

  procedure Create_Approval_By_Id(WorkflowId   in varchar2,
                                  WorkflowType in number) is
    WorkflowUserId     char(32);
    Old_OrganizationId char(32);
    New_OrganizationId char(32);
    DaysCount          number(5, 1);
  begin
    delete from oa_afw_workflow_approval_flow t
     where t.c_workflow_id = WorkflowId
       and t.n_approval_status in (0, 2);
    case
      when WorkflowType = 1 then
        select t.n_leave_days, t.c_leave_user_id
          into DaysCount, WorkflowUserId
          from oa_afw_leave_info t
         where t.c_leave_id = WorkflowId;
      when WorkflowType = 2 then
        select t.n_egress_days, t.c_egress_user_id
          into DaysCount, WorkflowUserId
          from oa_afw_egress_info t
         where t.c_egress_id = WorkflowId;
      when WorkflowType = 3 then
        select t.c_input_user_id
          into WorkflowUserId
          from oa_msg_publish_info t
         where t.c_news_id = WorkflowId;
      
      when WorkflowType = 4 then
        select t.c_expenses_user_id
          into WorkflowUserId
          from oa_eps_expenses_info t
         where t.c_expenses_id = WorkflowId;
      
      when WorkflowType = 12 then
      
        select 'Old_OrganizationId', 'New_OrganizationId'
          into Old_OrganizationId, New_OrganizationId
          from dual; --待实现
      else
        DaysCount := 0;
    end case;
    select c_organization_id
      into Old_OrganizationId
      from lcbase.t_user
     where c_user_id = WorkflowUserId;
    Create_All_Approval_Userlist(WorkflowId,
                                 WorkflowType,
                                 DaysCount,
                                 Old_OrganizationId,
                                 New_OrganizationId);
  end;

  function Update_Workflow_Leave_Office(LeaveUserwId in varchar2)
    return number is
  begin
    update oa_afw_workflow_approval_flow t
       set t.n_approval_status = 2
     where t.c_approval_user_id = LeaveUserwId
       and t.n_approval_status = 0;
    commit;
    return 0;
  end;

  function Update_Workflow_Assume_Office return number is
    CUR_FLOW     sys_refcursor;
    WorkflowId   char(32);
    WorkflowType number(2);
  begin
    open CUR_FLOW for
      select distinct t.c_workflow_id, t.n_workflow_type
        from oa_afw_workflow_approval_flow t
       where t.n_approval_status = 2;
    fetch CUR_FLOW
      into WorkflowId, WorkflowType;
    while CUR_FLOW%found loop
      Create_Approval_By_Id(WorkflowId, WorkflowType);
      fetch CUR_FLOW
        into WorkflowId, WorkflowType;
    end loop;
    close CUR_FLOW;
    return 0;
  end;

  procedure Send_Workflow_Approval_Message(WorkflowId     in varchar2,
                                           ApprovalUserId in varchar2,
                                           WorkflowType   in number,
                                           ApprovalResult in number) is
    errmsg           varchar2(2000);
    P_ApprovalResult varchar2(40);
    approvalusername varchar2(20);
  begin
    select u.v_user_name
      into approvalusername
      from lcbase.t_user u
     where u.c_user_id = ApprovalUserId;
    P_ApprovalResult := case
                          when ApprovalResult = 1 then
                           approvalusername || '已经完成你的审批申请'
                          when ApprovalResult = -1 then
                           approvalusername || '已驳回你的审批申请'
                          when ApprovalResult = -2 then
                           '申请已被撤回'
                          else
                           approvalusername || '正在处理你的审批申请'
                        end;
    if WorkflowType = 1 then
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult,
               sysdate,
               0,
               t.c_leave_user_id,
               WorkflowId,
               u.v_user_name || '的' ||
               decode(t.n_leave_type,
                      1,
                      '事假',
                      2,
                      '病假',
                      3,
                      '调休',
                      4,
                      '年假',
                      5,
                      '产假',
                      6,
                      '哺乳假',
                      7,
                      '婚假',
                      8,
                      '丧假',
                      '其它请假') || t.n_leave_days || '天【' ||
               to_char(t.d_leave_start_time, 'yyyy-MM-dd HH:mi') || '至' ||
               to_char(t.d_leave_end_time, 'yyyy-MM-dd HH:mi') || '】',
               '系统',
               sysdate,
               1
          from oa_afw_leave_info t
          left join lcbase.t_user u
            on u.c_user_id = t.c_leave_user_id
         where t.c_leave_id = WorkflowId;
    
    elsif WorkflowType = 2 then
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult,
               sysdate,
               0,
               t.c_egress_user_id,
               WorkflowId,
               u.v_user_name || '的' ||
               decode(t.n_egress_type, 1, '市内外出', 2, '出差', '其它外出') ||
               t.n_egress_days || '小时【' ||
               to_char(t.d_egress_start_time, 'yyyy-MM-dd HH:mi') || '至' ||
               to_char(t.d_egress_end_time, 'yyyy-MM-dd HH:mi') || '】',
               '系统',
               sysdate,
               1
          from oa_afw_egress_info t
          left join lcbase.t_user u
            on u.c_user_id = t.c_egress_user_id
         where t.c_egress_id = WorkflowId;
    elsif WorkflowType = 3 then
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               t.v_news_title,
               sysdate,
               0,
               c_user_id,
               WorkflowId,
               t.v_news_content,
               t.v_signature_name,
               sysdate,
               1
          from (select u.c_user_id
                  from LCBASE.t_User u
                 where u.c_organization_id in
                       (select g.c_organization_id
                          from LCBASE.t_organization g
                        connect by prior g.c_organization_parent_id =
                                    g.c_organization_id
                         start with g.c_organization_id in
                                    (select r.c_target_id
                                       from oa_msg_publish_range r
                                      where r.c_news_id = WorkflowId
                                        and r.n_target_type = 1))
                union
                select r.c_target_id
                  from oa_msg_publish_range r
                 where r.c_news_id = WorkflowId
                   and r.n_target_type = 0) mu
          left join oa_msg_publish_info t
            on t.c_news_id = WorkflowId;
    elsif WorkflowType = 4 then
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult,
               sysdate,
               0,
               t.c_expenses_user_id,
               WorkflowId,
               t.v_expenses_user_name || '的报销',
               '系统',
               sysdate,
               1
          from oa_eps_expenses_info t
         where t.c_expenses_id = WorkflowId;
    end if;
  exception
    when others then
      errmsg := 'Send_New_Message: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;

  /**
  功能：当前审批人审批通过
  
  处理事项：  
  1.修改当前审批人的审批状态; 
  2.修改待办处理结果; 
  3.检查工作流状态，如果审批完成，修改总状态为审批完成并发消息给申请人；否则，给下一个审批人生成待办。
  **/
  function Approval_Target_Pass(WorkflowId     in varchar2,
                                WorkflowType   in number,
                                ApprovalUserId in varchar2,
                                ApprovalRemark in varchar2,
                                ErrMsg         out varchar2) return number as
    UnDone_Cnt number(2);
    TodoTitle  varchar2(20);
  begin
    update oa_afw_workflow_approval_flow t
       set t.n_approval_status = 1,
           t.d_approval_time   = sysdate,
           t.v_approval_remark = ApprovalRemark
     where t.c_workflow_id = WorkflowId
       and t.c_approval_user_id = ApprovalUserId
       and t.n_approval_status = 0;
    update oa_tdo_todo_info t
       set t.n_status = 1, t.d_done_time = sysdate
     where t.c_todo_user_id = ApprovalUserId
       and t.c_todo_data_id in
           (select f.c_data_id
              from lcoa.oa_afw_workflow_approval_flow f
             where f.c_workflow_id = WorkflowId);
  
    select sum(case
                 when t.n_approval_status = 1 then
                  0
                 else
                  1
               end)
      into UnDone_Cnt
      from oa_afw_workflow_approval_flow t
     where t.c_workflow_id = WorkflowId;
  
    if WorkflowType = 1 then
    
      if UnDone_Cnt = 0 then
        update oa_afw_leave_info t
           set t.n_status = 2
         where t.c_leave_id = WorkflowId;
        Send_Workflow_Approval_Message(WorkflowId,
                                       ApprovalUserId,
                                       WorkflowType,
                                       1);
      else
        -- 匹配请假申请人名字
        SELECT CONCAT(tu.V_USER_NAME, '的请假申请')
          INTO TodoTitle
          FROM oa_afw_leave_info t
          LEFT JOIN lcbase.t_user tu
            ON tu.c_user_id = t.c_leave_user_id
         WHERE t.c_leave_id = WorkflowId;
        Send_Workflow_Approval_Message(WorkflowId,
                                       ApprovalUserId,
                                       WorkflowType,
                                       0);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle);
      end if;
    
    elsif WorkflowType = 2 then
    
      if UnDone_Cnt = 0 then
        update oa_afw_egress_info t
           set t.n_status = 2
         where t.c_egress_id = WorkflowId;
        Send_Workflow_Approval_Message(WorkflowId,
                                       ApprovalUserId,
                                       WorkflowType,
                                       1);
      else
        -- 匹配外出申请人名字
        SELECT CONCAT(tu.V_USER_NAME, '的外出申请')
          INTO TodoTitle
          FROM LCOA.OA_AFW_EGRESS_INFO oaei
          LEFT JOIN LCBASE.T_USER tu
            ON oaei.C_EGRESS_USER_ID = tu.C_USER_ID
         WHERE OAEI.C_EGRESS_ID = WorkflowId;
        Send_Workflow_Approval_Message(WorkflowId,
                                       ApprovalUserId,
                                       WorkflowType,
                                       0);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle);
      end if;
    
    elsif WorkflowType = 3 then
    
      if UnDone_Cnt = 0 then
        update oa_msg_publish_info t
           set t.n_status = 2
         where t.c_news_id = WorkflowId;
        Send_Workflow_Approval_Message(WorkflowId,
                                       ApprovalUserId,
                                       WorkflowType,
                                       1);
      else
        -- 匹配公告申请人名字
        SELECT CONCAT(tu.V_USER_NAME, '的公告申请')
          INTO TodoTitle
          FROM LCOA.oa_msg_publish_info oaei
          LEFT JOIN LCBASE.T_USER tu
            ON oaei.C_INPUT_USER_ID = tu.C_USER_ID
         WHERE OAEI.C_NEWS_ID = WorkflowId;
        Send_Workflow_Approval_Message(WorkflowId,
                                       ApprovalUserId,
                                       WorkflowType,
                                       0);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle);
      end if;
    
    elsif WorkflowType = 4 then
    
      if UnDone_Cnt = 0 then
        update oa_eps_expenses_info t
           set t.n_status = 2
         where t.c_expenses_id = WorkflowId;
        Send_Workflow_Approval_Message(WorkflowId,
                                       ApprovalUserId,
                                       WorkflowType,
                                       1);
      else
        -- 匹配报销申请人名字
        SELECT CONCAT(tu.V_USER_NAME, '的报销申请')
          INTO TodoTitle
          FROM LCOA.oa_eps_expenses_info oaei
          LEFT JOIN LCBASE.T_USER tu
            ON oaei.C_EXPENSES_USER_ID = tu.C_USER_ID
         WHERE OAEI.C_EXPENSES_ID = WorkflowId;
        Send_Workflow_Approval_Message(WorkflowId,
                                       ApprovalUserId,
                                       WorkflowType,
                                       0);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle);
      end if;
    
    end if;
    commit;
    return 0;
  end;

  /**
  功能：当前审批人审批驳回
  
  处理事项：  
  1.修改当前审批人的审批状态; 
  2.修改待办处理结果; 
  3.总状态改为已驳回;
  4.发送消息给申请人
  **/
  function Approval_Target_Reject(WorkflowId     in varchar2,
                                  WorkflowType   in number,
                                  ApprovalUserId in varchar2,
                                  ApprovalRemark in varchar2,
                                  ErrMsg         out varchar2) return number as
  begin
    update oa_afw_workflow_approval_flow t
       set t.n_approval_status = -1,
           t.d_approval_time   = sysdate,
           t.v_approval_remark = ApprovalRemark
     where t.c_workflow_id = WorkflowId
       and t.c_approval_user_id = ApprovalUserId
       and t.n_approval_status = 0;
    update oa_tdo_todo_info t
       set t.n_status = 1, t.d_done_time = sysdate
     where t.c_todo_user_id = ApprovalUserId
       and t.c_todo_data_id in
           (select f.c_data_id
              from lcoa.oa_afw_workflow_approval_flow f
             where f.c_workflow_id = WorkflowId);
  
    if WorkflowType = 1 then
    
      update oa_afw_leave_info t
         set t.n_status = 3
       where t.c_leave_id = WorkflowId;
    
    elsif WorkflowType = 2 then
    
      update oa_afw_egress_info t
         set t.n_status = 3
       where t.c_egress_id = WorkflowId;
    
    elsif WorkflowType = 3 then
    
      update oa_msg_publish_info t
         set t.n_status = 3
       where t.c_news_id = WorkflowId;
    
    elsif WorkflowType = 4 then
    
      update oa_eps_expenses_info t
         set t.n_status = 3
       where t.c_expenses_id = WorkflowId;
    
    end if;
  
    if SQL%ROWCOUNT > 0 then
      Send_Workflow_Approval_Message(WorkflowId,
                                     ApprovalUserId,
                                     WorkflowType,
                                     -1);
      commit;
      return 0;
    else
      RAISE_APPLICATION_ERROR(-20001, '审批拒绝失败', false);
    end if;
  
    return 0;
  end;

  /**
  功能：申请人撤回申请
  
  处理事项：  
  1.判断当前申请是否可以撤回，如果可以则撤回;
  2.发送消息给申请人
  **/
  function Approval_Target_Cancel(WorkflowId     in varchar2,
                                  WorkflowType   in number,
                                  WorkflowUserId in varchar2,
                                  ApprovalRemark in varchar2,
                                  ErrMsg         out varchar2) return number as
  begin
  
    delete from oa_tdo_todo_info t
     where t.n_status = 0
       and t.c_todo_data_id in
           (select f.c_data_id
              from lcoa.oa_afw_workflow_approval_flow f
             where f.c_workflow_id = WorkflowId);
  
    if WorkflowType = 1 then
    
      update oa_afw_leave_info t
         set t.n_status = -1
       where t.c_leave_id = WorkflowId
         and t.c_leave_user_id = WorkflowUserId;
    
    elsif WorkflowType = 2 then
    
      update oa_afw_egress_info t
         set t.n_status = -1
       where t.c_egress_id = WorkflowId
         and t.c_egress_user_id = WorkflowUserId;
    
    elsif WorkflowType = 3 then
    
      update oa_msg_publish_info t
         set t.n_status = -1
       where t.c_news_id = WorkflowId
         and t.c_input_user_id = WorkflowUserId;
    
    elsif WorkflowType = 4 then
    
      update oa_eps_expenses_info t
         set t.n_status = -1
       where t.c_expenses_id = WorkflowId
         and t.c_expenses_user_id = WorkflowUserId;
    
    end if;
    if SQL%ROWCOUNT = 1 then
      Send_Workflow_Approval_Message(WorkflowId,
                                     WorkflowUserId,
                                     WorkflowType,
                                     -2);
      commit;
      return 0;
    else
      RAISE_APPLICATION_ERROR(-20001, '撤回失败', false);
    end if;
  
  end;

  function Get_Approval_Status_By_Id(WorkflowId in varchar2,
                                     CUR_DATA   OUT SYS_REFCURSOR,
                                     ErrMsg     out varchar2) return number as
  begin
    open CUR_DATA for
      select f.c_data_id,
             f.n_workflow_type,
             f.c_workflow_id,
             f.n_approval_order,
             f.n_approval_model,
             f.c_approval_user_id,
             f.v_approval_user_name,
             f.v_approval_user_title,
             f.n_approval_status,
             f.d_approval_time,
             f.v_approval_remark
        from oa_afw_workflow_approval_flow f
       where f.c_workflow_id = WorkflowId
       order by f.n_approval_order;
    return 0;
  exception
    when others THEN
      ErrMsg := 'Get_Approval_Status_By_Id: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;

  function Get_Pre_Approval_Userlist(WorkflowUserId     in varchar2,
                                     WorkflowType       in number,
                                     DaysCount          in number,
                                     New_OrganizationId in varchar2,
                                     CUR_DATA           out sys_refcursor,
                                     ErrMsg             out varchar2)
    return number is
    CUR_CONF       sys_refcursor;
    ROW_CONF       oa_afw_workflow_config%rowtype;
    P_LST          T_FLOW;
    WorkflowId     char(32);
    OrganizationId char(32);
    P_NUM          number(1);
    P_ALL          number(1);
    P_EXIST        number(1);
  begin
    P_ALL      := 0;
    WorkflowId := lower(sys_guid());
    select u.c_organization_id
      into OrganizationId
      from lcbase.t_user u
     where u.c_user_id = WorkflowUserId;
    open CUR_CONF for
      select *
        from oa_afw_workflow_config
       where n_workflow_type = WorkflowType
       order by n_approval_order;
    fetch CUR_CONF
      into ROW_CONF;
    while CUR_CONF%found loop
      P_NUM := Create_Part_Approval_Userlist(ROW_CONF,
                                             WorkflowId,
                                             case
                                               when WorkflowType = 12 and P_ALL >= 2 then
                                                New_OrganizationId
                                               else
                                                OrganizationId
                                             end,
                                             P_LST);
      for I in 1 .. P_NUM loop
        select count(1)
          into P_EXIST
          from oa_afw_workflow_approval_temp t
         where t.c_workflow_id = WorkflowId
           and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        if P_EXIST = 0 then
          insert into oa_afw_workflow_approval_temp
            (c_data_id,
             n_workflow_type,
             c_workflow_id,
             n_approval_order,
             n_approval_model,
             c_approval_user_id,
             v_approval_user_name,
             v_approval_user_title,
             n_approval_status)
          values
            (P_LST(I).c_data_id,
             P_LST(I).n_workflow_type,
             P_LST(I).c_workflow_id,
             P_ALL + I, --P_LST(I).n_approval_order,
             P_LST(I).n_approval_model,
             P_LST(I).c_approval_user_id,
             P_LST(I).v_approval_user_name,
             P_LST(I).v_approval_user_title,
             P_LST(I).n_approval_status);
        else
          update oa_afw_workflow_approval_temp t
             set t.v_approval_user_title = t.v_approval_user_title || ',' || P_LST(I)
                                          .v_approval_user_title
           where t.c_workflow_id = WorkflowId
             and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        end if;
      end loop;
      P_ALL := P_ALL + P_NUM;
      if P_ALL > 0 and WorkflowType in (1, 2) and DaysCount < 3 then
        exit;
      end if;
      fetch CUR_CONF
        into ROW_CONF;
    end loop;
    close CUR_CONF;
    commit;
    open CUR_DATA for
      select f.c_data_id,
             f.n_workflow_type,
             f.c_workflow_id,
             f.n_approval_order,
             f.n_approval_model,
             f.c_approval_user_id,
             f.v_approval_user_name,
             f.v_approval_user_title,
             f.n_approval_status,
             f.d_approval_time,
             f.v_approval_remark
        from oa_afw_workflow_approval_temp f
       where f.c_workflow_id = WorkflowId
       order by f.n_approval_order;
    return 0;
  end;

  --请假类型(1事假2病假3调休4年假5产假6哺乳假7婚假8丧假9陪产假10产检假)
  function Check_Leave_Info(LeaveUserId in varchar2,
                            StartDate   in date,
                            EndDate     in date,
                            LeaveType   in number,
                            LeaveHours  out number,
                            ErrMsg      out varchar2) return number is
  begin
  
    return 0;
  end;

end test_zhaochao;
/

