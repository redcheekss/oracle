create package PKG_EXT_LOAN_INFO is
  --添加借款
  function save_loan_info(datainfo        in varchar2,
                          OperationUserId IN VARCHAR2,
                          c_cursor        out sys_refcursor,
                          ErrMsg          OUT VARCHAR2) return number;
  function getLoanInfo(loanId          in varchar2, --借款信息ID
                       operationUserId in varchar2, --操作人ID
                       loanInfo        out sys_refcursor, --借款单详情 
                       ApproveUsers    out sys_refcursor, --审批人详情
                       roleCount       out number, --操作人权限
                       accountantCount out number, --看此用户是不是费用会计
                       cashierCount    out number,
                       ErrMsg          out varchar2) return number;

  function get_Loan_Approval(WorkflowUserId     in varchar2,
                             WorkflowType       in number,
                             WorkflowSubtype    in number,
                             DStartTime         in varchar2,
                             DEndTime           in varchar2,
                             New_OrganizationId in varchar2,
                             Days               out number,
                             Hours              out number,
                             CUR_DATA           out sys_refcursor,
                             companyId          out varchar2,
                             caiwuRoleCount     out number,
                             ErrMsg             out varchar2) return number;
  function SetCompanyId(datainfo        in varchar2,
                        OperationUserId IN VARCHAR2,
                        ErrMsg          OUT VARCHAR2) return number;
  function remindRepay(ErrMsg out varchar2) return number;
end;
/

