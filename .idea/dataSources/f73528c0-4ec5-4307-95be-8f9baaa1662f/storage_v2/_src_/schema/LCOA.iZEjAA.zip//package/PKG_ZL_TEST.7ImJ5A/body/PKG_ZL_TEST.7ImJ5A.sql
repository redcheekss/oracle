create package body PKG_ZL_TEST is

--使用方法
--可以在plsql中一次性执行多个测试用例，然后查看Output

/*
检查某个人直接上级sql
select
o.c_organization_parent_id,o.v_organization_name,u.v_user_name,pu.v_pet_name from lcbase.t_zip_user u 
left join lcbase.t_zip_organization o on u.c_organization_id = o.c_organization_id and o.d_enddate=to_date('99991231','yyyymmdd')
left join lcbase.t_zip_organization po on o.c_organization_parent_id = po.c_organization_id and po.d_enddate =to_date('99991231','yyyymmdd')
left join lcbase.t_zip_user pu on o.c_organization_owner = pu.c_user_id and pu.d_enddate = to_date('99991231','yyyymmdd')
where u.d_enddate = to_date('99991231','yyyymmdd') and u.v_user_name='付君怡'
*/
declare
  procedure TestInsertORG(datainfo in varchar2,
                          org_id out varchar2,
                          msg  out   varchar2) as
  n_result number(1):=0;
  user_id varchar2(32):='c17a789f957b42998cf5242a614d49c8';
  data_id varchar2(32);
  v_leave number(1):=2;
  v_type number(1):=4;
  str_data varchar2(2000):='';
  begin
    org_id:= lcoa.pkg_ins_dept_info.insert_children_organization(
    DataInfo,--新增的部门名称^父部门ID^LEVEL
    user_id, --userId
    DataId, --返回新增部门ID
    ErrMsg
    );   
end;
 begin
  
  --产品
  data_id:=TestInsertORG('测试新增01^997c2b49b01d4bdba3c5ea4e0f615617'); --产品
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('测试新增02'); --产品
  str_data:=str_data||data_id;
  --小兵团
  data_id:=TestInsertORG('测试新增01'); --士兵
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('倪守信', 1, '李勇(740)', '李勇'); --班长
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('杨森', 1, '张伟', ''); --连长
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('陈科江', 1, '路书勋', '');
  --职能部门
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('付君怡', 1, '李亚南', '张瑶');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('李亚南', 1, '张瑶', '张瑶');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('张瑶', 1, '丛纹弨', '丛纹弨');
  --数据部
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('马豪伟', 1, '李华伟', '李华伟');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('李华伟', 1, '丛纹弨', '丛纹弨');
  --项目部
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('候朋光', 1, '耿旭', '耿旭');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('耿旭', 1, '丛纹弨', '丛纹弨');
  --OA/BI项目组
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('陈昭华', 1, '张晓林', '石晓波');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('张晓林', 1, '石晓波', '石晓波');
  --专业市场
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('李海娇', 1, '张伟(703)', '张伟(703)');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('张伟(703)', 1, '丛纹弨', '丛纹弨');
  --财务
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('王力冬', 1, '袁玲娜', '曹春艳'); --财务
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('袁玲娜', 1, '曹春艳', '曹春艳'); --财务部门
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('曹春艳', 1, '丛纹弨', '丛纹弨'); --财务本部
  --调度项目组
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('张宏伟', 1, '赵超', '丛纹弨');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('赵超', 1, '丛纹弨', '丛纹弨');
  --公共组件
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('李贺刚', 1, '刘发正', '刘发正');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('李贺刚', 1, '戴俊', '戴俊');
  --技术委员会
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('戴俊', 1, '丛纹弨', '丛纹弨');
  --政委
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('谢玉超', 1, '王丽芬', '张瑶');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('王丽芬', 1, '张瑶', '');
  --呼叫中心
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('汪俊', 1, '江爱玲', '江爱玲');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('江爱玲', 1, '丛纹弨', '丛纹弨');
  --效率本部
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('汪俊', 1, '江爱玲', '江爱玲');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('计红', 1, '丛纹弨', '丛纹弨');
  --军委委员
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('贾玉涛',1,'路书勋','路书勋');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('贾玉涛',1,'张伟(703)','张伟(703)');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('贾玉涛',1,'杨海龙','杨海龙');    
  --军委常委
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('路书勋', 1, '丛纹弨', '丛纹弨');
  str_data:=str_data||data_id;
  data_id:=TestInsertORG('杨海龙', 1, '杨海龙', '丛纹弨');
  str_data:=str_data||data_id;
exception
  when others then
    dbms_output.put_line('Get_Pre_Approval_Userlist: ' || SQLCODE || ',' ||
                         SQLERRM || ',' ||
                         DBMS_UTILITY.format_error_backtrace);
end;


end PKG_ZL_TEST;
/

