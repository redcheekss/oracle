create package PKG_INS_AFW_WORKFLOW is
  type T_FLOW is Table OF lcoa.oa_afw_workflow_approval_flow%rowtype INDEX BY pls_integer;
  -- Author  : USER
  -- Created : 2020/4/12 16:43:10
  -- Purpose : TEMP

  -- Public type declarations
  --type <TypeName> is <Datatype>;

  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  --<VariableName> <Datatype>;
  -- Public function and procedure declarations
  --function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;

  --检查发布人
  --传入参数：IssuerUserId发布人ID
  --传出参数：ErrMsg错误输出
  --返回值：0身份合法，非0身份非法
  procedure Create_Approval_By_Id(WorkflowId   in varchar2,
                                  WorkflowType in number);
  function Create_Part_Approval_Userlist(ROW_CONF       in oa_afw_workflow_config%rowtype,
                                         WorkflowId     in varchar2,
                                         WorkflowUserId in varchar2,
                                         OrganizationId in varchar2,
                                         LST            out T_FLOW)
    return number;
  procedure Create_All_Approval_Userlist(WorkflowId         in varchar2,
                                         WorkflowUserId     in varchar2,
                                         WorkflowType       in number,
                                         RangeType          in number,
                                         DaysCount          in number,
                                         Old_OrganizationId in varchar2,
                                         New_OrganizationId in varchar2);
  procedure GetWorkflowConfByFlowType(WorkFlowType in number,
                                      CUR_CONF     out sys_refcursor);
  procedure CreateLeaveFullWorkflow(WorkflowId     in varchar2,
                                    WorkflowType   in number,
                                    WorkflowUserId in varchar2,
                                    DaysCount      in number);
  procedure InsertApprovelWorkflow(ROW_FLOW oa_afw_workflow_approval_flow%rowtype);
  --生成预审批人列表，供申请前显示审批人列表使用
  --传入参数：
  --          WorkflowType:业务类型
  --          WorkflowId:业务编号
  --          WorkflowUserId:业务申请人ID
  --          OrganizationId:组织ID
  --传出参数：
  --          LST:
  procedure CreatePreApprovalUserList(WorkflowType    in number,
                                      WorkflowSubtype in number,
                                      WorkflowId      in varchar2,
                                      WorkflowUserId  in varchar2,
                                      OrganizationId  in varchar2,
                                      LST             out T_FLOW);
  procedure InsertApprovelWorkflowTmp(ROW_FLOW oa_afw_workflow_approval_temp%rowtype);

  function Get_Pre_Approval_Userlist(WorkflowUserId     in varchar2,
                                     WorkflowType       in number,
                                     WorkflowSubtype    in number,
                                     DStartTime         in varchar2,
                                     DEndTime           in varchar2,
                                     New_OrganizationId in varchar2,
                                     Days               out number,
                                     Hours              out number,
                                     CUR_DATA           out sys_refcursor,
                                     ErrMsg             out varchar2)
    return number;
  function Approval_Target_Delay(WorkflowId     in varchar2,
                                 WorkflowType   in number,
                                 WorkflowUserId in varchar2,
                                 ApprovalRemark in varchar2,
                                 ErrMsg         out varchar2) return number;
  procedure Send_Workflow_Approval_Message(WorkflowId     in varchar2,
                                           ApprovalUserId in varchar2,
                                           WorkflowType   in number,
                                           ApprovalResult in number);
  procedure Create_Next_Approval_Todo(WorkflowId     in varchar2,
                                      TodoTitle      in varchar2,
                                      TodoSender_Cur out sys_refcursor);
  function Approval_Target_Pass(WorkflowId      in varchar2,
                                WorkflowType    in number,
                                ApprovalUserId  in varchar2,
                                ApprovalRemark  in varchar2,
                                MsgSender_Cur   out sys_refcursor,
                                TodoSender_Cur  out sys_refcursor,
                                IsAll_MsgSender out number, --0是否，1是全部
                                ErrMsg          out varchar2) return number;
  function Approval_Target_Reject(WorkflowId      in varchar2,
                                  WorkflowType    in number,
                                  ApprovalUserId  in varchar2,
                                  ApprovalRemark  in varchar2,
                                  MsgSender_Cur   out sys_refcursor,
                                  TodoSender_Cur  out sys_refcursor,
                                  IsAll_MsgSender out number, --0是否，1是全部
                                  ErrMsg          out varchar2) return number;

  function Approval_Target_Cancel(WorkflowId      in varchar2,
                                  WorkflowType    in number,
                                  WorkflowUserId  in varchar2,
                                  ApprovalRemark  in varchar2,
                                  MsgSender_Cur   out sys_refcursor,
                                  TodoSender_Cur  out sys_refcursor,
                                  IsAll_MsgSender out number, --0是否，1是全部
                                  ErrMsg          out varchar2) return number;
  function Approval_Target_Delay(WorkflowId      in varchar2,
                                 WorkflowType    in number,
                                 ApprovalUserId  in varchar2,
                                 ApprovalRemark  in varchar2,
                                 MsgSender_Cur   out sys_refcursor,
                                 TodoSender_Cur  out sys_refcursor,
                                 IsAll_MsgSender out number, --0是否，1是全部
                                 ErrMsg          out varchar2) return number;
  --设置审批流指定记录状态
  --根据业务ID+审批人ID确定某一条唯一记录
  procedure SetApprovalFlowStatus(WorkflowId     in varchar2,
                                  ApprovalUserId in varchar2,
                                  ApprovalRemark in varchar2,
                                  ApprovalStatus number);
  --更新待办事件状态   
  --完成待办                               
  procedure SetToDoStatus(WorkflowId     in varchar2,
                          ApprovalUserId in varchar2);
  --统计指定业务ID审批流未完结量
  procedure GetUnDoneApprovalCount(WorkflowId in varchar2,
                                   UnDoneCnt  out number);
  --清除已撤回的未审批的待办消息
  procedure RemoveInvalidToDoInfo(WorkflowId in varchar2);
end PKG_INS_AFW_WORKFLOW;
/

