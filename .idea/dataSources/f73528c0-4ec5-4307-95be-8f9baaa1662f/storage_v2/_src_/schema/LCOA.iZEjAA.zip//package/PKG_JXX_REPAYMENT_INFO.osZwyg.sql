create package PKG_JXX_repayment_info is

	  function add_test_afw_loan_info(data_values      in ARR_LONGSTR,
                                  out_v_c_id       out varchar2,
                                  out_V_FLOWNUMBER out varchar2,
                                  ErrMsg           OUT VARCHAR2)
    return number;

end PKG_JXX_repayment_info;
/

