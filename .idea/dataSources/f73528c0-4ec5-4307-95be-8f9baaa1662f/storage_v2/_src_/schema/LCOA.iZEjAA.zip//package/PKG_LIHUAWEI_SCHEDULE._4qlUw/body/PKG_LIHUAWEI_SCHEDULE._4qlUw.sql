create package body PKG_LIHUAWEI_SCHEDULE is

  -- Private type declarations
  --type <TypeName> is <Datatype>;

  -- Private constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Private variable declarations
  --<VariableName> <Datatype>;
  i number(1);

  function Insert_News_info(cbNewsContent clob, ErrMsg OUT VARCHAR2)
    return NUMBER is
  begin
    insert into lcoa.oa_msg_publish_info values(
    lower(sys_guid()),
    1,
    1,
    'test',
    cbNewsContent,
    'test0001',
    0,
    '11223344',
    'test',
    0,
    0,
    0,
    '11223344',
    'test',
    sysdate,
    0
    )
    ;
    return 0;
  end;

--此块进行变量初始化，可删除
begin
  -- Initialization
  i := 1;
end PKG_LIHUAWEI_SCHEDULE;
/

