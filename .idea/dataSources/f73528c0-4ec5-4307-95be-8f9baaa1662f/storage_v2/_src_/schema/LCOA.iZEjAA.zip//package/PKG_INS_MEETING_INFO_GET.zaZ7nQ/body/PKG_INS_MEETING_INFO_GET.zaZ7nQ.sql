create package body PKG_INS_MEETING_INFO_GET is
  procedure get_meet_message is
    curdata number(1);
  begin
    curdata := 1;
  end;
  /**
  1.发布之前的状态，只有记录人可查，
  也就是operaterid为会议纪要记录人时才返回；
  2.发布之后，根据会议私密级别，
  公开不限制；
  保密，只有会议对应参会人列表及办公会中的人可查；
  绝密：只有办公会的人可查。
  **/
  function get_meeting_major(dataid          in varchar2,
                             datasource      in number,
                             operationuserid in varchar2,
                             getmeetinginfo  out sys_refcursor,
                             getmeetcontent  out sys_refcursor,
                             gettodolist     out sys_refcursor,
                             getuploadinfo   out sys_refcursor,
                             getattendeelist out sys_refcursor,
                             getschedulenum  out sys_refcursor,
                             getuserschedule out sys_refcursor,
                             countmeetingid  out number,
                             errmsg          out varchar2) return number is
    secrettype  number(1);
    clerkid     varchar2(40);
    status      number;
    n_result    number(1) := 0;
    usernumber  number(4);
    userteam    number(4);
    meetingid   varchar2(40);
    countstatus varchar(4);
  begin
    countmeetingid := PKG_INS_MEETING_INFO_GET.GET_MEETINGID_COUNT(DataId,
                                                                   DataSource,
                                                                   OperationUserId,
                                                                   ErrMsg);
    select count(*)
      into countstatus
      from lcoa.oa_sde_meeting_info t
     where t.c_meeting_id = dataid
       and t.n_status = -1;
    if countstatus > 0 then
      ErrMsg := '该会议已被删除';
      return 1;
    end if;
    if countmeetingid = 0 then
      -- 获取用户日程信息
      open getuserschedule for
        SELECT ti.C_SCH_ID             AS schId,
               ti.D_SCH_DATE           AS schDate,
               ti.D_SCH_START_TIME     AS schStartTime,
               ti.d_sch_end_time       AS schEndTime,
               ti.C_SCH_USER_ID        AS schUserId,
               ti.V_SCH_TITLE          AS schTitle,
               ti.V_SCH_REMARK         AS schRemark,
               ti.N_REPEAD_TYPE        AS repeadType,
               ti.N_SCH_TYPE           AS schType,
               ti.N_MEETING_TYPE       AS meetingType,
               ti.C_MEETING_CLERK_ID   AS meetingClerkId,
               ti.C_MEETING_CLERK_NAME AS meetingClerkName,
               ti.C_MROOM_NO           AS mroomNo,
               tsmi.v_mroom_name       AS roomName,
               flow.d_flow_date        AS flowDate
          FROM LCOA.oa_sde_schedule_info ti
          LEFT JOIN LCOA.OA_SDE_MEETINGROOM_INFO tsmi
            ON ti.C_MROOM_NO = tsmi.C_MROOM_NO
          LEFT JOIN lcoa.OA_SDE_SCHEDULING_FLOW flow
            ON flow.C_SCH_ID = ti.C_SCH_ID
         where flow.C_flow_id = DataId;
    end if;
    if countmeetingid > 0 then
      -- 获取会议发布状态
      status := PKG_INS_MEETING_INFO_GET.get_meeting_status(dataid,
                                                            operationuserid,
                                                            errmsg);
      -- 获取会议记录人id
      clerkid := PKG_INS_MEETING_INFO_GET.get_clerk_id(dataid,
                                                       operationuserid,
                                                       errmsg);
      -- 获取会议保密级别
      secrettype := PKG_INS_MEETING_INFO_GET.get_secret_type(dataid,
                                                             operationuserid,
                                                             errmsg);
      -- 判断当前用户是否为参会人
      usernumber := PKG_INS_MEETING_INFO_GET.check_meetinguser(dataid,
                                                               datasource,
                                                               operationuserid,
                                                               errmsg);
      -- 判断当前用户是否在办公人组织中
      userteam := PKG_INS_MEETING_INFO_GET.check_userteam(operationuserid,
                                                          errmsg);
    
      if status = 0 then
        if clerkid <> operationuserid then
          return 1;
        end if;
      elsif status = 1 then
        -- 判断保密级别
        if secrettype = 0 then
          n_result := 0;
        elsif secrettype = 1 then
          if usernumber > 0 then
            n_result := 0;
          elsif userteam > 0 then
            n_result := 0;
          else
            return 1;
          end if;
        elsif secrettype = 2 then
          if userteam < 1 then
            return 1;
          end if;
        end if;
      end if;
    
      -- 获取会议详情
      open getmeetinginfo for
        select c_meeting_id,
               c_sch_id,
               n_secret_type,
               v_depart_name,
               n_meeting_type,
               v_meeting_title,
               v_clerk_name,
               d_meeting_start_time,
               d_meeting_end_time,
               v_meeting_room
          from lcoa.oa_sde_meeting_info t
         where t.c_meeting_id = dataid
           and t.n_status <> -1;
      -- 获取会议纪要内容列表
      open getmeetcontent for
        select c_id, c_meeting_id, v_content, d_input_time
          from lcoa.oa_sde_meeting_content_list t
         where t.c_meeting_id = dataid
         order by t.n_seq;
      -- 获取会议纪要待办事项
      open gettodolist for
        select c_todo_id,
               c_meeting_id,
               v_todo_content,
               v_todo_trace,
               d_limit_time,
               c_ask_user_id,
               v_ask_user_name,
               c_duty_user_id,
               v_duty_user_name,
               d_input_time
          from lcoa.oa_sde_todo_list t
         where t.c_meeting_id = dataid
         order by t.n_seq;
      -- 获取附件信息
      open getuploadinfo for
        select c_file_id,
               n_file_type,
               c_forign_id,
               v_file_name,
               v_file_path,
               d_upload_time
          from lcoa.oa_user_upload_info t
         where t.c_forign_id = dataid;
      -- 获取参会人信息(是否缺席)
      open getattendeelist for
        select mn.c_meeting_id,
               mn.c_user_id,
               mn.n_absent_flag,
               u.v_pet_name || decode(ei.n_status,
                                      1,
                                      '(注销)',
                                      2,
                                      '(离职)',
                                      3,
                                      '(开除)',
                                      4,
                                      '(淘汰)') v_user_name
          from oa_sde_attendee_list mn
          left join lcbase.t_zip_user u
            on mn.c_user_id = u.c_user_id
          left join lcbase.temp_employees_info ei
            on u.c_user_id = ei.c_user_id
         where mn.c_meeting_id = dataid
           and mn.n_absent_flag = 1
           and u.d_enddate > SYSDATE;
      -- 获取参会人信息(区别身份)
      open getschedulenum for
        select mn.c_meeting_id,
               mn.c_user_id userId,
               mn.n_absent_flag,
               u.v_pet_name || decode(ei.n_status,
                                      1,
                                      '(注销)',
                                      2,
                                      '(离职)',
                                      3,
                                      '(开除)',
                                      4,
                                      '(淘汰)') v_user_name
          from oa_sde_attendee_list mn
          left join lcbase.t_zip_user u
            on mn.c_user_id = u.c_user_id
          left join lcbase.temp_employees_info ei
            on u.c_user_id = ei.c_user_id
         where mn.c_meeting_id = dataid
           and u.d_enddate > SYSDATE;
      -- 获取用户日程信息
      open getuserschedule for
        select ti.c_sch_id             as schid,
               ti.d_sch_date           as schdate,
               ti.d_sch_start_time     as schstarttime,
               ti.d_sch_end_time       as schendtime,
               ti.c_sch_user_id        as schuserid,
               ti.v_sch_title          as schtitle,
               ti.v_sch_remark         as schremark,
               ti.n_repead_type        as repeadtype,
               ti.n_sch_type           as schtype,
               ti.n_meeting_type       as meetingtype,
               ti.c_meeting_clerk_id   as meetingclerkid,
               ti.c_meeting_clerk_name as meetingclerkname,
               ti.c_mroom_no           as mroomno,
               tsmi.v_mroom_name       as roomname,
               flow.d_flow_date        as flowdate
          from lcoa.oa_sde_schedule_info ti
          left join lcoa.oa_sde_meetingroom_info tsmi
            on ti.c_mroom_no = tsmi.c_mroom_no
          left join lcoa.oa_sde_scheduling_flow flow
            on flow.c_sch_id = ti.c_sch_id
          left join lcoa.oa_sde_meeting_info meet
            on meet.c_meeting_id = flow.c_flow_id
         where meet.c_meeting_id = dataid;
    end if;
    return 0;
  exception
    when others then
      errmsg := 'get_meeting_major: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;
  /**
    function get_meeting_info(dataid          in varchar2,
                              operationuserid in varchar2,
                              getmeetinginfo  out sys_refcursor,
                              getmeetcontent  out sys_refcursor,
                              gettodolist     out sys_refcursor,
                              getuploadinfo   out sys_refcursor,
                              getattendeelist out sys_refcursor,
                              getschedulenum  out sys_refcursor,
                              errmsg          out varchar2) return number is
      secrettype number(1);
      clerkid    varchar(40);
      status     number;
      n_result   number(1) := 0;
    begin
      -- 获取会议发布状态
      status := pkg_mahaowei.get_meeting_status(dataid,
                                                operationuserid,
                                                errmsg);
      -- 获取会议记录人id
      clerkid := pkg_mahaowei.get_clerk_id(dataid, operationuserid, errmsg);
      -- 获取会议保密级别
      secrettype := pkg_mahaowei.get_secret_type(dataid,
                                                 operationuserid,
                                                 errmsg);
      if status = 0 then
        if clerkid <> operationuserid then
          return 1;
        end if;
      elsif status = 1 then
        if secrettype = 0 then
          n_result := 1;
        elsif secrettype = 1 then
          n_result := 1;
        elsif secrettype = 2 then
          n_result := 1;
        end if;
      end if;
      -- 获取会议详情
      open getmeetinginfo for
        select c_meeting_id,
               c_sch_id,
               n_secret_type,
               v_depart_name,
               n_meeting_type,
               v_meeting_title,
               v_clerk_name,
               d_meeting_start_time,
               d_meeting_end_time,
               v_meeting_room
          from lcoa.oa_sde_meeting_info t
         where t.c_sch_id = dataid;
      -- 获取会议纪要内容列表
      open getmeetcontent for
        select c_id, c_meeting_id, v_content, d_input_time
          from lcoa.oa_sde_meeting_content_list t
         where t.c_meeting_id = dataid;
      -- 获取会议纪要待办事项
      open gettodolist for
        select c_todo_id,
               c_meeting_id,
               v_todo_content,
               v_todo_trace,
               d_limit_time,
               c_ask_user_id,
               v_ask_user_name,
               c_duty_user_id,
               v_duty_user_name,
               d_input_time
          from lcoa.oa_sde_todo_list t
         where t.c_meeting_id = dataid;
      -- 获取附件信息
      open getuploadinfo for
        select c_file_id,
               n_file_type,
               c_forign_id,
               v_file_name,
               v_file_path,
               d_upload_time
          from lcoa.oa_user_upload_info t
         where t.c_forign_id = dataid;
      -- 获取参会人信息(是否缺席)
      open getattendeelist for
        select mn.c_meeting_id, mn.c_user_id, mn.n_absent_flag, u.v_user_name
          from oa_sde_attendee_list mn
          left join lcbase.t_user u
            on mn.c_user_id = u.c_user_id
         where mn.c_meeting_id = dataid;
      -- 获取参会人信息(区别身份)
      open getschedulenum for
        select su.c_sch_id,
               su.c_user_id,
               su.n_type,
               u.v_user_name v_user_name
          from oa_sde_schedule_number su
          left join lcbase.t_user u
            on su.c_user_id = u.c_user_id
         where su.c_sch_id = dataid;
      return 0;
    exception
      when others then
        errmsg := 'check_meeting_major: ' || sqlcode || ',' || sqlerrm;
        raise_application_error(-20008, errmsg, false);
    end;
  **/
  -- 获取会议发布状态
  function get_meeting_status(dataid          in varchar2,
                              operationuserid in varchar2,
                              errmsg          out varchar2) return number is
    status number(1);
  begin
    select t.n_status
      into status
      from lcoa.oa_sde_meeting_info t
     where t.c_meeting_id = dataid;
    return status;
  exception
    when others then
      errmsg := 'get_meeting_status: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;

  -- 获取会议记录人id
  function get_clerk_id(dataid          in varchar2,
                        operationuserid in varchar2,
                        errmsg          out varchar2) return varchar2 is
    clerkid varchar(40);
  begin
    select si.c_meeting_clerk_id
      into clerkid
      from lcoa.oa_sde_meeting_info t
      left join lcoa.oa_sde_schedule_info si
        on t.c_sch_id = si.c_sch_id
     where t.c_meeting_id = dataid;
    return clerkid;
  exception
    when others then
      errmsg := 'get_clerk_id: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;

  -- 获取会议保密级别
  function get_secret_type(dataid          in varchar2,
                           operationuserid in varchar2,
                           errmsg          out varchar2) return number is
    secrettype number(1);
  begin
    select n_secret_type
      into secrettype
      from lcoa.oa_sde_meeting_info t
     where t.c_meeting_id = dataid;
    return secrettype;
  exception
    when others then
      errmsg := 'get_secret_type: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;

  -- 获取参会人
  function check_meetinguser(dataid          in varchar2,
                             datasource      in number,
                             operationuserid in varchar2,
                             errmsg          out varchar2) return number is
    usernumber number(4);
  begin
    usernumber := -1;
    select count(*)
      into usernumber
      from lcoa.oa_sde_attendee_list
     where c_meeting_id = dataid
       and c_user_id = operationuserid;
    return usernumber;
  exception
    when others then
      errmsg := 'check_meetinguser: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;

  -- 是否有meetingid
  function get_meetingid_count(dataid          in varchar2,
                               datasource      in number,
                               operationuserid in varchar2,
                               errmsg          out varchar2) return number is
    countid number(4);
  begin
    select count(*)
      into countid
      from lcoa.oa_sde_meeting_info t
     where t.c_meeting_id = dataid
       and t.n_status <> -1;
    return countid;
  exception
    when others then
      errmsg := 'get_meetingid_count: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;

  -- 是否在办公会组织中
  function check_userteam(operationuserid in varchar2, errmsg out varchar2)
    return number is
    countid number(4);
  begin
    -- 判断当前用户是否在办公人组织中
    select count(*)
      into countid
      from lcbase.t_project_team t, lcbase.t_user_team ut
     where t.c_team_id = ut.c_team_id
       and t.v_team_name = '办公会'
       and ut.c_user_id = operationuserid;
    return countid;
  exception
    when others then
      errmsg := 'get_meetingid_count: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;
end PKG_INS_MEETING_INFO_GET;
/

