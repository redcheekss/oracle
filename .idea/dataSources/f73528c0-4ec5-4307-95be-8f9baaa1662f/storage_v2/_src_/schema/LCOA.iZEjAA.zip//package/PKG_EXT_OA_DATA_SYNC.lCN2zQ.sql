create package PKG_EXT_OA_DATA_SYNC is

  -- Author  : LIHUAWEI
  -- Created : 2020/4/29 14:42:10
  -- Purpose : OA USER INFO SYNC

  -- Public type declarations
  --type <TypeName> is <Datatype>;

  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  --<VariableName> <Datatype>;
  -- Public function and procedure declarations
  --function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;

  --新旧OA用户信息同步
  --传入参数：无
  --传出参数：无
  --存储过程内部记录错误信息
  --返回值：0成功，非0失败
  function OAUserInfoSync return number;
  --检查新旧OA用户信息是否存在差异
  --参数：无
  --返回值：0表示无差异，按bit位1表示相应差异
  --第1位 是否有新增
  function CheckOAUserDiff return number;

  procedure InsertOAUser(vCallContent out varchar2);
  procedure UpdateOAUserMobile(vCallContent out varchar2);
  procedure UpdateOAUserStatus(vCallContent out varchar2);
  procedure UpdateOAUserPwd(vCallContent out varchar2);
  procedure UpdateOAUserType(vCallContent out varchar2);
  procedure UpdateOAUserPetName;
  procedure NOA2OAUser;
  procedure UpdateAFWUsers(vCallContent out varchar2);
end PKG_EXT_OA_DATA_SYNC;

/

