create package PKG_TEST is

  -- Author  : ADMINISTRATOR
  -- Created : 2020/4/2 17:48:32
  -- Purpose : 
  --报销新增
  FUNCTION Insert_Expenses_Info(Data            in type_expenses_list,
                                DataItem        in type_expenses_item_list, --报销明细表
                                ArrFile         in ARR_LONGSTR,
                                OperationUserId in varchar2,
                                DataId          out varchar2,
                                ErrMsg          out varchar2) return number;
  --报销单明细录入                                
  function Insert_Expenses_Item(DataInfo   in type_expenses_item,
                                ExpensesId in varchar2,
                                DataId     out varchar2,
                                ErrMsg     out varchar2) return number;

  --申请
  function Apply_Expenses(DataInfo        in type_expenses_list,
                          OperationUserId in varchar2,
                          ErrMsg          out varchar2) return number;

  --撤回
  function Withdrawn_Expenses(DataInfo        in type_expenses_list,
                              OperationUserId in varchar2,
                              ErrMsg          out varchar2) return number;

  --删除
  function Delete_Expenses(DataInfo        in type_expenses_list,
                           OperationUserId in varchar2,
                           ErrMsg          out varchar2) return number;

  --获取公司主体集合
  function Get_Lk_Company_List(CUR_DATA OUT SYS_REFCURSOR,
                               ErrMsg   out varchar2) return number;

  --插入费用项目
  FUNCTION Insert_Fee_Project(DataInfo        in oa_eps_fee_project%rowtype,
                              OperationUserId in varchar2,
                              DataId          out varchar2,
                              ErrMsg          out varchar2) return number;
  --修改费用项目
  FUNCTION Update_Fee_Project(DataInfo        in oa_eps_fee_project%rowtype,
                              OperationUserId in varchar2,
                              ErrMsg          out varchar2) return number;
  --获取报销用户默认报销项目
  function Get_Default_Expenses_ProjectId(UserId in varchar2,
                                          ErrMsg out varchar2)
    return varchar2;

  --查询费用项目明细
  function Get_Fee_Project_By_Id(ProjectId in varchar2,
                                 CUR_DATA  OUT SYS_REFCURSOR,
                                 ErrMsg    out varchar2) return number;
  --获取费用所属项目
  function Get_Fee_Project_List(CUR_DATA OUT SYS_REFCURSOR,
                                ErrMsg   out varchar2) RETURN NUMBER;
  --通知作废
  function Invalid_Expenses(ExpensesId      in varchar2,
                            OperationUserId in varchar2,
                            InvalidMemo     in varchar2,
                            ErrMsg          out varchar2) RETURN NUMBER;
  --作废同意/拒绝操作
  --OperationType;0:同意，1:拒绝
  function FeedBackInvalid(ExpensesId in varchar2, OperationType in number)
    return number;

  --发送通知
  function Send_Expenses_Message(ExpensesId          in varchar2,
                                 OperationUserId     in varchar2,
                                 NoticePayableAmount in number,
                                 Memo                in varchar2,
                                 ErrMsg              out varchar2)
    RETURN NUMBER;
  --通知同意/拒绝操作
  --OperationType;0:同意，1:拒绝
  function FeedBackMessage(ExpensesId in varchar2, OperationType in number)
    return number;
  --用户重名返回工号
  function getUserWorkNo(UserId in varchar2) RETURN VARCHAR2;
end PKG_TEST;
/

