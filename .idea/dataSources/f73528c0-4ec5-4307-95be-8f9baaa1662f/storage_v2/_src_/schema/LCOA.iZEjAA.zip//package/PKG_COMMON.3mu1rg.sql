create package PKG_COMMON as
  type ref_cursor is ref cursor;
  type total_record is record(
    totalrows number);
  type ARR_UID is Table OF varchar2(32) INDEX BY pls_integer;
  type ARR_LONGSTR is Table OF varchar2(32767) INDEX BY pls_integer;
  EXP_PARAM exception;
  pragma EXCEPTION_INIT(EXP_PARAM, -20001);
  EXP_CHECK exception;
  pragma EXCEPTION_INIT(EXP_CHECK, -20002);
  EXP_EXIT exception;
  pragma EXCEPTION_INIT(EXP_EXIT, -20003);
  EXP_EXECUTE exception;
  pragma EXCEPTION_INIT(EXP_EXECUTE, -20004);
  EXP_NOLEADER exception;
  pragma EXCEPTION_INIT(EXP_EXECUTE, -20005);
  g_errcode_exception CONSTANT NUMBER := -20998;
  --添加常量错误码及错误描述，以方便后续变更
  --lihuawei at 2020.4.2
  g_errcode_afw_status     CONSTANT NUMBER := 201003;
  g_errmsg_afw_status      CONSTANT VARCHAR2(50) := '已经审批中，不能修改，请先撤回';
  g_errcode_afw_permission CONSTANT NUMBER := 201004;
  g_errmsg_afw_permission  CONSTANT VARCHAR2(50) := '审批流程错误，无审批权限';
  g_errcode_afw_pms_expire CONSTANT NUMBER := 201005;
  g_errmsg_afw_pms_expire  CONSTANT VARCHAR2(50) := '审批流程错误，审批权限已过期';
  g_errcode_afw_previous   CONSTANT NUMBER := 201006;
  g_errmsg_afw_previous    CONSTANT VARCHAR2(50) := '审批流程错误，前一步审批尚未完成';
  g_errcode_afw_repeat     CONSTANT NUMBER := 201007;
  g_errmsg_afw_repeat      CONSTANT VARCHAR2(50) := '审批流程错误，重复审批';
  g_errcode_afw_expire     CONSTANT NUMBER := 201008;
  g_errmsg_afw_expire      CONSTANT VARCHAR2(50) := '已经过期，不能撤销';
  g_errcode_afw_payed      CONSTANT NUMBER := 201009;
  g_errmsg_afw_payed       CONSTANT VARCHAR2(50) := '已经支付，不能撤销';
  --添加错误分类 mahaowei at 2020.4.7
  g_errcode_afw_param   CONSTANT NUMBER := 201010;
  g_errmsg_afw_param    CONSTANT VARCHAR2(50) := '传入参数错误';
  g_errcode_afw_overlap CONSTANT NUMBER := 201011;
  g_errmsg_afw_overlap  CONSTANT VARCHAR2(50) := '流程错误，重复操作';
  g_errcode_afw_nodata  CONSTANT NUMBER := 201012;
  g_errmsg_afw_nodata   CONSTANT VARCHAR2(50) := '未查询到数据';
  g_errcode_afw_upt_nodata CONSTANT NUMBER := 201013;
  g_errmsg_afw_upt_nodata  CONSTANT VARCHAR2(50) := '流程错误，没有符合条件的更新记录';
  g_errmsg_common       CONSTANT VARCHAR2(50) := '数据错误';
  g_errcode_afw_no_leader CONSTANT NUMBER := 201014;
  g_errmsg_afw_no_leader  CONSTANT VARCHAR2(50) := '请联系管理员设置负责人/BP/VP';

  
  g_result_status CONSTANT NUMBER := 201900;

  function IsDateNumbers(CC CHAR) return NUMBER;
  function FormatNumber(N IN NUMBER, F IN VARCHAR2) return VARCHAR2;
  function SPLIT(P_STR IN VARCHAR2, P_DELIMITER IN VARCHAR2 := '^')
    return ARR_LONGSTR;
  procedure InsertOperationLog(UserID    IN VARCHAR2,
                               TableName IN VARCHAR2,
                               nOpType   IN NUMBER,
                               nStatus   IN NUMBER,
                               nDuration IN NUMBER := 0,
                               nStep     IN NUMBER := 0);
  procedure InsertOperationLog2(UserId          in varchar2,
                                ActionName      in varchar2,
                                CallName        in varchar2,
                                SummeryInfo     in varchar2,
                                ActionStartTime in date,
                                ActionEndTime   in date,
                                ActionStatus    in number);
  function GetFlowNumber(prefix in varchar2, flowLength in number)
    return varchar2;
  function GetPagingInfo(vSql          IN VARCHAR2,
                         nPageSize     IN NUMBER,
                         nPageCur      IN NUMBER,
                         CUR_DATA      OUT SYS_REFCURSOR,
                         nOutRows      OUT number,
                         nOutPageCount OUT number) return NUMBER;
  procedure InsertSpCallLog(vSpName    IN VARCHAR2,
                            dOpStart   IN DATE,
                            vOpContent IN VARCHAR2,
                            cSpCallId  out varchar2);
  procedure UpdateSpCallLog(cSpCallId  IN varchar2,
                            dOpEnd     IN DATE,
                            nDuration  IN NUMBER,
                            vOpContent IN VARCHAR2,
                            nStatus    IN NUMBER);
end PKG_COMMON;
/

