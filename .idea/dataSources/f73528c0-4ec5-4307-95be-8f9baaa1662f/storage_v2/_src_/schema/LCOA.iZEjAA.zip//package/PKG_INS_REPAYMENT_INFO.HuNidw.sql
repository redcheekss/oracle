create package pkg_ins_repayment_info is

  --1 查询到期还款
  function repaymentStatus(ErrMsg OUT VARCHAR2) RETURN NUMBER;

  --2 未还清借款列表
  function no_loanList(OperationUserId in varchar2,
                       loanList        OUT SYS_REFCURSOR,
                       loanFiles       OUT SYS_REFCURSOR,
                       ErrMsg          OUT VARCHAR2) RETURN NUMBER;

  --3 新增立即还款
  --list<loanId,amount,picAddress>
  function add_installRepayment(data_value   IN ARR_LONGSTR,
                                data_images  in ARR_LONGSTR,
                                operation_id in char,
                                c_cursor     out sys_refcursor,
                                ErrMsg       OUT VARCHAR2) RETURN NUMBER;

  --3.3报销还款
  --list<loanId,amount：报销id，还款总金额>
  function add_installRepayment2(data_value   IN varchar2,
                                 operation_id in char,
                                 c_cursor     out sys_refcursor,
                                 ErrMsg       OUT VARCHAR2) RETURN NUMBER;

  --4 确认还款单详情
  function getRepaymentInfo(dataId                   in varchar2,
                            operationId              in char,
                            OaAfwRepaymentInfoEntity OUT SYS_REFCURSOR, --还款确认单详情
                            loanList                 OUT SYS_REFCURSOR, --借款单列表--包含图片
                            files                    OUT SYS_REFCURSOR, --还款单附件列表
                            ErrMsg                   OUT VARCHAR2)
    RETURN NUMBER;

  --5 确认还款确认单
  /*
   参数list<loanId,arrivalTime>
   逻辑：
     - 关系表中更新入账时间
     - 借款单中更新未还金额 是否还清
     - 确认收款后，申请人、借款审批人都会收到一条还款成功的通知
     - 确认收款后，我的记录中该条数据的状态同步更新为“已还款”
   return 回款是否成。
  */

  function passRepayment(Repayment   IN ARR_LONGSTR,
	                       v_id        in char,
                         operationId in char,
                         c_cursor    out sys_refcursor,
                         ErrMsg      OUT VARCHAR2)
  
   RETURN NUMBER;

  function passRepayment2(Repayment   IN varchar2,
                          operationId in char,
                          ErrMsg      OUT VARCHAR2)
  
   RETURN NUMBER;

  --6 报销生成还款单
  function get_RepaymentBills(RepaymentBills OUT ARR_LONGSTR,
                              ErrMsg         OUT VARCHAR2)
  
   RETURN NUMBER;

  --7 收款列表
  function get_Payment_list(data_value   in varchar2,
                            pageNum      in number,
                            PageSize     in number,
                            operationId  in char,
                            getapplylist out sys_refcursor,
                            totalPage    out number,
                            totalCount   out number,
                            errmsg       out varchar2) RETURN NUMBER;

  --8辅助存储过程
  function add_todo_info(user_id     in char,
                         flow_number in char,
                         ErrMsg      OUT VARCHAR2) RETURN NUMBER;

  --send message
  function add_OA_MSG_MESSAGE_info(user_id                 in char, --userid
                                   C_MSG_SRC               in char, --消息关联数据id
                                   total_REPLAYMENT_AMOUNT in number, --还款总金额
                                   send_author             in varchar2, --消息发送者
                                   ErrMsg                  OUT VARCHAR2)
    RETURN NUMBER;

  ------------------------------------------------------------------
  --测试函数辅助
  function add_test_afw_loan_info(data_values      in ARR_LONGSTR,
                                  out_v_c_id       out varchar2,
                                  out_V_FLOWNUMBER out varchar2,
                                  ErrMsg           OUT VARCHAR2)
    return number;

  --重置 
  function ResetSkip(ApprovalUserId in varchar2, ErrMsg out varchar2)
    return number;

  --跳过
  function Target_Skip(repay_id     in varchar2,
                       operation_id in char,
                       ErrMsg       out varchar2) return number;
											 
											 
											 
  --撤回内容
	function  clear_content_info(V_CLAIM_FORMID in char,operation_id in char,ErrMsg out varchar2) 
	return number;
											 
end pkg_ins_repayment_info;
/

