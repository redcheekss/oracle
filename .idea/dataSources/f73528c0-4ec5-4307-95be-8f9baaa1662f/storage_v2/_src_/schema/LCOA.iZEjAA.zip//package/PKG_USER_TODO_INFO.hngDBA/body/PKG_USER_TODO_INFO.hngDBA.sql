create package body PKG_USER_TODO_INFO as
   function Get_UserToDoInfo (UserId IN VARCHAR2,OperationUserId IN VARCHAR2,PageSize IN NUMBER,PageCur IN NUMBER,CUR_DATA OUT SYS_REFCURSOR,OutRows OUT number,OutPageCount OUT number) return NUMBER as
   n_result number(1) := 0;
    v_sql varchar2(3000);
    errcode number(8);
    errmsg varchar2(2000);

     BEGIN
       BEGIN
        v_sql := 'SELECT C_TODO_ID 待办ID,
         DECODE(N_TODO_TYPE,1,''请假审批'',2,''外出审批'',3,''报销审批'',4,''转正审批'',5,''付款审批'',6,''需求评审'',7,''公告审批'',''未知'') 待办类型,
         v_todo_title 待办标题,to_char(d_todo_time,''yyyy-mm-dd hh24:mi:ss'') 待办时间,
         C_TODO_DATA_ID FROM PKG_USER_TODO_INFO WHERE C_TODO_USER_ID = ''' || UserId || ''' and n_status = 0 order by d_todo_time desc';

         n_result := pkg_common.GetPagingInfo(vSql => v_sql,nPageSize => PageSize, nPageCur =>PageCur,CUR_DATA => CUR_DATA, nOutRows => OutRows, nOutPageCount => OutPageCount);

       EXCEPTION
         WHEN OTHERS THEN
           errcode := SQLCODE;
           errmsg := '错误信息:' || SQLERRM || ',错误行号:' || DBMS_UTILITY.format_error_backtrace;
           n_result := 1;
       END;
       PKG_COMMON.InsertOperationLog(OperationUserId, 'PKG_USER_TODO_INFO', 1, n_result);
       dbms_output.put_line('当前函数:' || get_myprocedure_name);
       --正常返回
       if n_result = 0 then
        return 0;
       end if;
       --异常返回
      RAISE_APPLICATION_ERROR(errcode, errmsg, false);
     END;
end PKG_USER_TODO_INFO;

/

