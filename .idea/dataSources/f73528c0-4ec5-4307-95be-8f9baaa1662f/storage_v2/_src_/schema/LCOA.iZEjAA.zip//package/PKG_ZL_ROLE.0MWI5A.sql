create package PKG_ZL_ROLE is

  function CREATEROLE(DataInfo        in varchar2,
                      ErrMsg          out varchar2) return NUMBER;

end PKG_ZL_ROLE;
/

