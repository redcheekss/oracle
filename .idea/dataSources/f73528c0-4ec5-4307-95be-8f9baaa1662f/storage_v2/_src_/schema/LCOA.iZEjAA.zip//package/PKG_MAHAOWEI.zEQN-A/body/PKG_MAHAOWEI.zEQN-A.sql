create package body pkg_mahaowei is
  procedure get_meet_message is
    curdata number(1);
  begin
    curdata := 1;
  end;
  /**
  1.发布之前的状态，只有记录人可查，
  也就是operaterid为会议纪要记录人时才返回；
  2.发布之后，根据会议私密级别，
  公开不限制；
  保密，只有会议对应参会人列表及办公会中的人可查；
  绝密：只有办公会的人可查。
  **/
  function get_meeting_major(dataid          in varchar2,
                             datasource      in number,
                             operationuserid in varchar2,
                             getmeetinginfo  out sys_refcursor,
                             getmeetcontent  out sys_refcursor,
                             gettodolist     out sys_refcursor,
                             getuploadinfo   out sys_refcursor,
                             getattendeelist out sys_refcursor,
                             getschedulenum  out sys_refcursor,
                             getuserschedule out sys_refcursor,
                             countmeetingid  out number,
                             errmsg          out varchar2) return number is
    secrettype number(1);
    clerkid    varchar2(40);
    status     number;
    n_result   number(1) := 0;
    usernumber number(4);
    userteam   number(4);
    meetingid  varchar2(40);
  begin
    countmeetingid := pkg_mahaowei.GET_MEETINGID_COUNT(DataId,
                                                       DataSource,
                                                       OperationUserId,
                                                       ErrMsg);
    if countmeetingid = 0 then
      -- 获取用户日程信息
      open getuserschedule for
        SELECT ti.C_SCH_ID             AS schId,
               ti.D_SCH_DATE           AS schDate,
               ti.D_SCH_START_TIME     AS schStartTime,
               ti.d_sch_end_time       AS schEndTime,
               ti.C_SCH_USER_ID        AS schUserId,
               ti.V_SCH_TITLE          AS schTitle,
               ti.V_SCH_REMARK         AS schRemark,
               ti.N_REPEAD_TYPE        AS repeadType,
               ti.N_SCH_TYPE           AS schType,
               ti.N_MEETING_TYPE       AS meetingType,
               ti.C_MEETING_CLERK_ID   AS meetingClerkId,
               ti.C_MEETING_CLERK_NAME AS meetingClerkName,
               ti.C_MROOM_NO           AS mroomNo,
               tsmi.v_mroom_name       AS roomName,
               flow.d_flow_date        AS flowDate
          FROM LCOA.oa_sde_schedule_info ti
          LEFT JOIN LCOA.OA_SDE_MEETINGROOM_INFO tsmi
            ON ti.C_MROOM_NO = tsmi.C_MROOM_NO
          LEFT JOIN lcoa.OA_SDE_SCHEDULING_FLOW flow
            ON flow.C_SCH_ID = ti.C_SCH_ID
         where flow.C_flow_id = DataId;
    end if;
    if countmeetingid > 0 then
      -- 获取会议发布状态
      status := pkg_mahaowei.get_meeting_status(dataid,
                                                operationuserid,
                                                errmsg);
      -- 获取会议记录人id
      clerkid := pkg_mahaowei.get_clerk_id(dataid, operationuserid, errmsg);
      -- 获取会议保密级别
      secrettype := pkg_mahaowei.get_secret_type(dataid,
                                                 operationuserid,
                                                 errmsg);
      -- 判断当前用户是否为参会人
      usernumber := pkg_mahaowei.check_meetinguser(dataid,
                                                   datasource,
                                                   operationuserid,
                                                   errmsg);
      -- 判断当前用户是否在办公人组织中
      userteam := pkg_mahaowei.check_userteam(operationuserid, errmsg);
    
      if status = 0 then
        if clerkid <> operationuserid then
          return 1;
        end if;
      elsif status = 1 then
        -- 判断保密级别
        if secrettype = 0 then
          n_result := 0;
        elsif secrettype = 1 then
          if usernumber > 0 then
            n_result := 0;
          elsif userteam > 0 then
            n_result := 0;
          else
            return 1;
          end if;
        elsif secrettype = 2 then
          if userteam < 1 then
            return 1;
          end if;
        end if;
      end if;
    
      -- 获取会议详情
      open getmeetinginfo for
        select c_meeting_id,
               c_sch_id,
               n_secret_type,
               v_depart_name,
               n_meeting_type,
               v_meeting_title,
               v_clerk_name,
               d_meeting_start_time,
               d_meeting_end_time,
               v_meeting_room
          from lcoa.oa_sde_meeting_info t
         where t.c_meeting_id = dataid;
      -- 获取会议纪要内容列表
      open getmeetcontent for
        select c_id, c_meeting_id, v_content, d_input_time
          from lcoa.oa_sde_meeting_content_list t
         where t.c_meeting_id = dataid
         order by t.n_seq;
      -- 获取会议纪要待办事项
      open gettodolist for
        select c_todo_id,
               c_meeting_id,
               v_todo_content,
               v_todo_trace,
               d_limit_time,
               c_ask_user_id,
               v_ask_user_name,
               c_duty_user_id,
               v_duty_user_name,
               d_input_time
          from lcoa.oa_sde_todo_list t
         where t.c_meeting_id = dataid
         order by t.n_seq;
      -- 获取附件信息
      open getuploadinfo for
        select c_file_id,
               n_file_type,
               c_forign_id,
               v_file_name,
               v_file_path,
               d_upload_time
          from lcoa.oa_user_upload_info t
         where t.c_forign_id = dataid;
      -- 获取参会人信息(是否缺席)
      open getattendeelist for
        select mn.c_meeting_id,
               mn.c_user_id,
               mn.n_absent_flag,
               u.v_user_name || decode(ei.n_status,
                                       1,
                                       '(注销)',
                                       2,
                                       '(离职)',
                                       3,
                                       '(开除)',
                                       4,
                                       '(淘汰)') v_user_name
          from oa_sde_attendee_list mn
          left join lcbase.t_user u
            on mn.c_user_id = u.c_user_id
          left join lcbase.temp_employees_info ei
            on u.c_user_id = ei.c_user_id
         where mn.c_meeting_id = dataid
           and mn.n_absent_flag = 1;
      -- 获取参会人信息(区别身份)
      open getschedulenum for
        select mn.c_meeting_id,
               mn.c_user_id,
               mn.n_absent_flag,
               u.v_user_name || decode(ei.n_status,
                                       1,
                                       '(注销)',
                                       2,
                                       '(离职)',
                                       3,
                                       '(开除)',
                                       4,
                                       '(淘汰)') v_user_name
          from oa_sde_attendee_list mn
          left join lcbase.t_user u
            on mn.c_user_id = u.c_user_id
          left join lcbase.temp_employees_info ei
            on u.c_user_id = ei.c_user_id
         where mn.c_meeting_id = dataid;
      -- 获取用户日程信息
      open getuserschedule for
        select ti.c_sch_id             as schid,
               ti.d_sch_date           as schdate,
               ti.d_sch_start_time     as schstarttime,
               ti.d_sch_end_time       as schendtime,
               ti.c_sch_user_id        as schuserid,
               ti.v_sch_title          as schtitle,
               ti.v_sch_remark         as schremark,
               ti.n_repead_type        as repeadtype,
               ti.n_sch_type           as schtype,
               ti.n_meeting_type       as meetingtype,
               ti.c_meeting_clerk_id   as meetingclerkid,
               ti.c_meeting_clerk_name as meetingclerkname,
               ti.c_mroom_no           as mroomno,
               tsmi.v_mroom_name       as roomname,
               flow.d_flow_date        as flowdate
          from lcoa.oa_sde_schedule_info ti
          left join lcoa.oa_sde_meetingroom_info tsmi
            on ti.c_mroom_no = tsmi.c_mroom_no
          left join lcoa.oa_sde_scheduling_flow flow
            on flow.c_sch_id = ti.c_sch_id
          left join lcoa.oa_sde_meeting_info meet
            on meet.c_meeting_id = flow.c_flow_id
         where meet.c_meeting_id = dataid;
    end if;
    return 0;
  exception
    when others then
      errmsg := 'get_meeting_major: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;
  /**
    function get_meeting_info(dataid          in varchar2,
                              operationuserid in varchar2,
                              getmeetinginfo  out sys_refcursor,
                              getmeetcontent  out sys_refcursor,
                              gettodolist     out sys_refcursor,
                              getuploadinfo   out sys_refcursor,
                              getattendeelist out sys_refcursor,
                              getschedulenum  out sys_refcursor,
                              errmsg          out varchar2) return number is
      secrettype number(1);
      clerkid    varchar(40);
      status     number;
      n_result   number(1) := 0;
    begin
      -- 获取会议发布状态
      status := pkg_mahaowei.get_meeting_status(dataid,
                                                operationuserid,
                                                errmsg);
      -- 获取会议记录人id
      clerkid := pkg_mahaowei.get_clerk_id(dataid, operationuserid, errmsg);
      -- 获取会议保密级别
      secrettype := pkg_mahaowei.get_secret_type(dataid,
                                                 operationuserid,
                                                 errmsg);
      if status = 0 then
        if clerkid <> operationuserid then
          return 1;
        end if;
      elsif status = 1 then
        if secrettype = 0 then
          n_result := 1;
        elsif secrettype = 1 then
          n_result := 1;
        elsif secrettype = 2 then
          n_result := 1;
        end if;
      end if;
      -- 获取会议详情
      open getmeetinginfo for
        select c_meeting_id,
               c_sch_id,
               n_secret_type,
               v_depart_name,
               n_meeting_type,
               v_meeting_title,
               v_clerk_name,
               d_meeting_start_time,
               d_meeting_end_time,
               v_meeting_room
          from lcoa.oa_sde_meeting_info t
         where t.c_sch_id = dataid;
      -- 获取会议纪要内容列表
      open getmeetcontent for
        select c_id, c_meeting_id, v_content, d_input_time
          from lcoa.oa_sde_meeting_content_list t
         where t.c_meeting_id = dataid;
      -- 获取会议纪要待办事项
      open gettodolist for
        select c_todo_id,
               c_meeting_id,
               v_todo_content,
               v_todo_trace,
               d_limit_time,
               c_ask_user_id,
               v_ask_user_name,
               c_duty_user_id,
               v_duty_user_name,
               d_input_time
          from lcoa.oa_sde_todo_list t
         where t.c_meeting_id = dataid;
      -- 获取附件信息
      open getuploadinfo for
        select c_file_id,
               n_file_type,
               c_forign_id,
               v_file_name,
               v_file_path,
               d_upload_time
          from lcoa.oa_user_upload_info t
         where t.c_forign_id = dataid;
      -- 获取参会人信息(是否缺席)
      open getattendeelist for
        select mn.c_meeting_id, mn.c_user_id, mn.n_absent_flag, u.v_user_name
          from oa_sde_attendee_list mn
          left join lcbase.t_user u
            on mn.c_user_id = u.c_user_id
         where mn.c_meeting_id = dataid;
      -- 获取参会人信息(区别身份)
      open getschedulenum for
        select su.c_sch_id,
               su.c_user_id,
               su.n_type,
               u.v_user_name v_user_name
          from oa_sde_schedule_number su
          left join lcbase.t_user u
            on su.c_user_id = u.c_user_id
         where su.c_sch_id = dataid;
      return 0;
    exception
      when others then
        errmsg := 'check_meeting_major: ' || sqlcode || ',' || sqlerrm;
        raise_application_error(-20008, errmsg, false);
    end;
  **/
  -- 获取会议发布状态
  function get_meeting_status(dataid          in varchar2,
                              operationuserid in varchar2,
                              errmsg          out varchar2) return number is
    status number(1);
  begin
    select t.n_status
      into status
      from lcoa.oa_sde_meeting_info t
     where t.c_meeting_id = dataid;
    return status;
  exception
    when others then
      errmsg := 'get_meeting_status: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;

  -- 获取会议记录人id
  function get_clerk_id(dataid          in varchar2,
                        operationuserid in varchar2,
                        errmsg          out varchar2) return varchar2 is
    clerkid varchar(40);
  begin
    select si.c_meeting_clerk_id
      into clerkid
      from lcoa.oa_sde_meeting_info t
      left join lcoa.oa_sde_schedule_info si
        on t.c_sch_id = si.c_sch_id
     where t.c_meeting_id = dataid;
    return clerkid;
  exception
    when others then
      errmsg := 'get_clerk_id: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;

  -- 获取会议保密级别
  function get_secret_type(dataid          in varchar2,
                           operationuserid in varchar2,
                           errmsg          out varchar2) return number is
    secrettype number(1);
  begin
    select n_secret_type
      into secrettype
      from lcoa.oa_sde_meeting_info t
     where t.c_meeting_id = dataid;
    return secrettype;
  exception
    when others then
      errmsg := 'get_secret_type: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;

  -- 获取参会人
  function check_meetinguser(dataid          in varchar2,
                             datasource      in number,
                             operationuserid in varchar2,
                             errmsg          out varchar2) return number is
    usernumber number(4);
  begin
    select count(*)
      into usernumber
      from oa_sde_attendee_list su
     where su.c_meeting_id = dataid
       and su.c_user_id = operationuserid;
    return usernumber;
  exception
    when others then
      errmsg := 'get_secret_type: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;

  -- 是否有meetingid
  function get_meetingid_count(dataid          in varchar2,
                               datasource      in number,
                               operationuserid in varchar2,
                               errmsg          out varchar2) return number is
    countid number(4);
  begin
    select count(*)
      into countid
      from lcoa.oa_sde_meeting_info t
     where t.c_meeting_id = dataid;
    return countid;
  exception
    when others then
      errmsg := 'get_meetingid_count: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;

  -- 是否在办公会组织中
  function check_userteam(operationuserid in varchar2, errmsg out varchar2)
    return number is
    countid number(4);
  begin
    -- 判断当前用户是否在办公人组织中
    select count(*)
      into countid
      from lcbase.t_project_team t, lcbase.t_user_team ut
     where t.c_team_id = ut.c_team_id
       and t.v_team_name = '办公会'
       and ut.c_user_id = operationuserid;
    return countid;
  exception
    when others then
      errmsg := 'get_meetingid_count: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(-20999, errmsg, false);
  end;

  function get_approval_list(recordvo        in varchar2,
                             getapprovallist out sys_refcursor,
                             errmsg          out varchar2) return number is
    dataarr  pkg_common.arr_longstr;
    listtype number(1);
    n_result number(2);
  begin
    dataarr  := pkg_common.split(recordvo, '^');
    listtype := dataarr(2);
    -- 查询插入请假列表
    n_result := pkg_mahaowei.add_leave_list(dataarr(1),
                                            dataarr(3),
                                            dataarr(4),
                                            1,
                                            errmsg);
    -- 查询插入外出列表
    n_result := pkg_mahaowei.add_egress_list(dataarr(1),
                                             dataarr(3),
                                             dataarr(4),
                                             1,
                                             errmsg);
    -- 查询插入公告列表
    n_result := pkg_mahaowei.add_news_list(dataarr(1),
                                           dataarr(3),
                                           dataarr(4),
                                           1,
                                           errmsg);
    -- 判断是否传入查询类型参数 如果没有就查询全部，否则按传入类型查询列表
    if listtype is null then
      open getapprovallist for
        select * from lcoa.oa_afw_approval_list;
    else
      open getapprovallist for
        select *
          from lcoa.oa_afw_approval_list oaal
         where oaal.types = listtype;
    end if;
    return 0;
  exception
    when others then
      errmsg := 'get_approval_list: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function get_apply_list(recordvo     in varchar2,
                          getapplylist out sys_refcursor,
                          errmsg       out varchar2) return number is
    dataarr  pkg_common.arr_longstr;
    listtype number(1);
    n_result number(2);
  begin
    dataarr  := pkg_common.split(recordvo, '^');
    listtype := dataarr(2);
    -- 查询插入请假列表
    n_result := pkg_mahaowei.add_leave_list(dataarr(1),
                                            dataarr(3),
                                            dataarr(4),
                                            2,
                                            errmsg);
    -- 查询插入外出列表
    n_result := pkg_mahaowei.add_egress_list(dataarr(1),
                                             dataarr(3),
                                             dataarr(4),
                                             2,
                                             errmsg);
    -- 查询插入公告列表
    n_result := pkg_mahaowei.add_news_list(dataarr(1),
                                           dataarr(3),
                                           dataarr(4),
                                           2,
                                           errmsg);
    -- 判断是否传入查询类型参数 如果没有就查询全部，否则按传入类型查询列表
    if listtype is null then
      open getapplylist for
        select * from lcoa.oa_afw_approval_list;
    else
      open getapplylist for
        select *
          from lcoa.oa_afw_approval_list oaal
         where oaal.types = listtype;
    end if;
    return 0;
  exception
    when others then
      errmsg := 'get_apply_list: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_leave_list(userid            in varchar2,
                          startdate         in varchar2,
                          enddate           in varchar2,
                          approvalapplytype in number,
                          errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT a.c_leave_id AS id,
                       1 AS types,
                       '请假' AS typeName,
                       t.v_user_name AS userName,
                       a.n_status AS status,
                       a.d_leave_start_time AS startTime,
                       a.d_leave_end_time AS endTime,
                       a.c_leave_user_id AS inputUserId,
                       DECODE(a.n_leave_type,
                              1,
                              '事假',
                              2,
                              '病假',
                              3,
                              '调休',
                              4,
                              '年假',
                              5,
                              '产假',
                              6,
                              '哺乳假',
                              7,
                              '婚假',
                              8,
                              '丧假',
                              9,
                              '陪产假',
                              10,
                              '产检假',
                              '其它请假') || CASE
                         WHEN a.n_leave_days > 0 THEN
                          a.n_leave_days || '天'
                         ELSE
                          NULL
                       END || CASE
                         WHEN a.n_leave_hours > 0 THEN
                          a.n_leave_hours || '小时'
                         ELSE
                          NULL
                       END || '【' ||
                       TO_CHAR(a.d_leave_start_time, 'yyyy-MM-dd HH24:mi') ||
                       ' 至 ' ||
                       TO_CHAR(a.d_leave_end_time, 'yyyy-MM-dd HH24:mi') || '】' AS abstracts,
                       DECODE(a.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       a.d_input_date AS inputDate
                  FROM lcoa.OA_AFW_LEAVE_INFO a
                  LEFT JOIN lcbase.t_user t
                    ON a.c_leave_user_id = t.c_user_id
                 WHERE a.c_leave_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0)) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT a.c_leave_id AS id,
                       1 AS types,
                       '请假' AS typeName,
                       t.v_user_name AS userName,
                       a.n_status AS status,
                       a.d_leave_start_time AS startTime,
                       a.d_leave_end_time AS endTime,
                       a.c_leave_user_id AS inputUserId,
                       DECODE(a.n_leave_type,
                              1,
                              '事假',
                              2,
                              '病假',
                              3,
                              '调休',
                              4,
                              '年假',
                              5,
                              '产假',
                              6,
                              '哺乳假',
                              7,
                              '婚假',
                              8,
                              '丧假',
                              9,
                              '陪产假',
                              10,
                              '产检假',
                              '其它请假') || CASE
                         WHEN a.n_leave_days > 0 THEN
                          a.n_leave_days || '天'
                         ELSE
                          NULL
                       END || CASE
                         WHEN a.n_leave_hours > 0 THEN
                          a.n_leave_hours || '小时'
                         ELSE
                          NULL
                       END || '【' ||
                       TO_CHAR(a.d_leave_start_time, 'yyyy-MM-dd HH24:mi') ||
                       ' 至 ' ||
                       TO_CHAR(a.d_leave_end_time, 'yyyy-MM-dd HH24:mi') || '】' AS abstracts,
                       DECODE(a.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       a.d_input_date AS inputDate
                  FROM lcoa.OA_AFW_LEAVE_INFO a
                  LEFT JOIN LCBASE.t_user t
                    ON a.c_leave_user_id = t.c_user_id
                 WHERE a.c_leave_user_id = userid) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_leave_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_egress_list(userid            in varchar2,
                           startdate         in varchar2,
                           enddate           in varchar2,
                           approvalapplytype in number,
                           errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT b.c_egress_id AS id,
                       2 AS types,
                       '外出' AS typeName,
                       t.v_user_name AS userName,
                       B.n_status AS status,
                       B.d_egress_start_time AS startTime,
                       B.d_egress_end_time AS endTime,
                       B.C_EGRESS_USER_ID AS inputUserId,
                       DECODE(b.n_egress_type,
                              1,
                              '市内外出',
                              2,
                              '出差',
                              '其它外出') || CASE
                         WHEN b.n_egress_days > 0 THEN
                          b.n_egress_days || '天'
                         ELSE
                          NULL
                       END || CASE
                         WHEN b.n_egress_hours > 0 THEN
                          b.n_egress_hours || '小时'
                         ELSE
                          NULL
                       END || '【' ||
                       TO_CHAR(b.d_egress_start_time, 'yyyy-MM-dd HH24:mi') ||
                       ' 至 ' ||
                       TO_CHAR(b.d_egress_end_time, 'yyyy-MM-dd HH24:mi') || '】' AS abstracts,
                       DECODE(B.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       B.d_input_date AS inputDate
                  FROM LCOA.OA_AFW_EGRESS_INFO b
                  LEFT JOIN lcbase.t_user t
                    ON b.c_egress_user_id = t.c_user_id
                 WHERE b.c_egress_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0)) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT b.c_egress_id AS id,
                       2 AS types,
                       '外出' AS typeName,
                       t.v_user_name AS userName,
                       B.n_status AS status,
                       B.d_egress_start_time AS startTime,
                       B.d_egress_end_time AS endTime,
                       B.C_EGRESS_USER_ID AS inputUserId,
                       DECODE(b.n_egress_type,
                              1,
                              '市内外出',
                              2,
                              '出差',
                              '其它外出') || CASE
                         WHEN b.n_egress_days > 0 THEN
                          b.n_egress_days || '天'
                         ELSE
                          NULL
                       END || CASE
                         WHEN b.n_egress_hours > 0 THEN
                          b.n_egress_hours || '小时'
                         ELSE
                          NULL
                       END || '【' ||
                       TO_CHAR(b.d_egress_start_time, 'yyyy-MM-dd HH24:mi') ||
                       ' 至 ' ||
                       TO_CHAR(b.d_egress_end_time, 'yyyy-MM-dd HH24:mi') || '】' AS abstracts,
                       DECODE(B.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       B.d_input_date AS inputDate
                  FROM LCOA.OA_AFW_EGRESS_INFO b
                  LEFT JOIN LCBASE.t_user t
                    ON b.c_egress_user_id = t.c_user_id
                 WHERE b.c_egress_user_id = userid) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_egress_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_news_list(userid            in varchar2,
                         startdate         in varchar2,
                         enddate           in varchar2,
                         approvalapplytype in number,
                         errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_news_id AS id,
                       3 AS types,
                       '公告' AS typeName,
                       t.v_user_name AS userName,
                       c.n_status AS status,
                       c.d_input_time AS startTime,
                       c.d_input_time AS endTime,
                       c.c_input_user_id AS inputUserId,
                       c.v_news_title || ' -- ' ||
                       DECODE(d.n_target_type,
                              0,
                              '个人',
                              1,
                              '部门',
                              2,
                              '全员') || ' -- ' ||
                       DECODE(c.N_SIGNATURE_TYPE,
                              0,
                              '匿名发布',
                              1,
                              '实名发布',
                              2,
                              '部门发布') || ' -- ' ||
                       DECODE(N_COMMENT_ALLOW,
                              1,
                              '允许评论',
                              0,
                              '不允许评论') || ' -- ' ||
                       DECODE(c.N_MUST_FEEDBACK,
                              1,
                              '需要点击"我已阅"',
                              '不需要点击"我已阅"') ||
                       DECODE(c.N_ISTOP_FLAG, 1, ' -- 置顶') AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       c.N_ISTOP_FLAG AS isTop,
                       c.d_input_time AS inputDate
                  FROM LCOA.OA_MSG_PUBLISH_INFO c
                  LEFT JOIN LCOA.OA_MSG_PUBLISH_RANGE d
                    ON c.c_news_id = d.c_news_id
                  LEFT JOIN LCBASE.t_user t
                    ON c.c_input_user_id = t.c_user_id
                 WHERE c.c_news_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0
                           AND c.N_STATUS <> -2)) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_news_id AS id,
                       3 AS types,
                       '公告' AS typeName,
                       t.v_user_name AS userName,
                       c.n_status AS status,
                       c.d_input_time AS startTime,
                       c.d_input_time AS endTime,
                       c.c_input_user_id AS inputUserId,
                       c.v_news_title || ' -- ' ||
                       DECODE(d.n_target_type,
                              0,
                              '个人',
                              1,
                              '部门',
                              2,
                              '全员') || ' -- ' ||
                       DECODE(c.N_SIGNATURE_TYPE,
                              0,
                              '匿名发布',
                              1,
                              '实名发布',
                              2,
                              '部门发布') || ' -- ' ||
                       DECODE(N_COMMENT_ALLOW,
                              1,
                              '允许评论',
                              0,
                              '不允许评论') || ' -- ' ||
                       DECODE(c.N_MUST_FEEDBACK,
                              1,
                              '需要点击"我已阅"',
                              '不需要点击"我已阅"') ||
                       DECODE(c.N_ISTOP_FLAG, 1, ' -- 置顶') AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       c.N_ISTOP_FLAG AS isTop,
                       c.d_input_time AS inputDate
                  FROM LCOA.OA_MSG_PUBLISH_INFO c
                  LEFT JOIN LCOA.OA_MSG_PUBLISH_RANGE d
                    ON c.c_news_id = d.c_news_id
                  LEFT JOIN LCBASE.t_user t
                    ON c.c_input_user_id = t.c_user_id
                 WHERE c.c_input_user_id = userid
                   AND c.N_NEWS_TYPE = 1
                   AND c.N_STATUS <> -2) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_news_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_adjustpost_list(userid            in varchar2,
                               startdate         in varchar2,
                               enddate           in varchar2,
                               approvalapplytype in number,
                               errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_adjust_id AS id,
                       4 AS types,
                       '调岗' AS typeName,
                       t.v_user_name AS userName,
                       c.n_status AS status,
                       c.d_input_date AS startTime,
                       c.d_input_date AS endTime,
                       c.c_adjust_user_id AS inputUserId,
                       '现部门：' || oldn.v_organization_name || '- 现岗位：' ||
                       c.v_old_post || '- 调整后部门：' ||
                       newn.v_organization_name || ' -调整后岗位：' ||
                       c.v_new_post AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '待审批',
                              0,
                              '审批中',
                              2,
                              '审批完成',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       c.d_input_date AS inputDate
                  FROM LCOA.Oa_Afw_Adjustpost_Info c
                  LEFT JOIN LCBASE.t_user t
                    ON c.c_adjust_user_id = t.c_user_id
                  left join lcbase.t_organization oldn
                    on c.c_old_orgnization_id = oldn.c_organization_id
                  left join lcbase.t_organization newn
                    on c.c_old_orgnization_id = newn.c_organization_id
                 WHERE c.c_adjust_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0)) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_adjust_id AS id,
                       4 AS types,
                       '调岗' AS typeName,
                       t.v_user_name AS userName,
                       c.n_status AS status,
                       c.d_input_date AS startTime,
                       c.d_input_date AS endTime,
                       '' AS inputUserId,
                       '现部门：' || oldn.v_organization_name || '- 现岗位：' ||
                       c.v_old_post || '- 调整后部门：' ||
                       newn.v_organization_name || ' -调整后岗位：' ||
                       c.v_new_post AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '待审批',
                              0,
                              '审批中',
                              2,
                              '审批完成',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       c.d_input_date AS inputDate
                  FROM LCOA.Oa_Afw_Adjustpost_Info c
                  LEFT JOIN LCBASE.t_user t
                    ON c.c_adjust_user_id = t.c_user_id
                  left join lcbase.t_organization oldn
                    on c.c_old_orgnization_id = oldn.c_organization_id
                  left join lcbase.t_organization newn
                    on c.c_old_orgnization_id = newn.c_organization_id
                 WHERE c.c_adjust_user_id = userid) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_adjustpost_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

end pkg_mahaowei;
/

