create PACKAGE BODY PKG_COMMON AS

  FUNCTION IsDateNumbers(CC CHAR) RETURN NUMBER IS
    Y NUMBER(4);
    M NUMBER(2);
    D NUMBER(2);
  BEGIN
    Y := SUBSTR(CC, 1, 4);
    M := SUBSTR(CC, 5, 2);
    D := SUBSTR(CC, 7, 2);
    IF Y > 2099 OR Y < 2000 THEN
      RETURN - 1;
    END IF;
    IF M IN (1, 3, 5, 7, 8, 10, 12) AND D <= 31 THEN
      RETURN 0;
    ELSIF M IN (4, 6, 9, 11) AND D <= 30 THEN
      RETURN 0;
    ELSIF MOD(Y, 4) = 0 AND D <= 29 THEN
      RETURN 0;
    ELSIF MOD(Y, 4) > 0 AND D <= 28 THEN
      RETURN 0;
    END IF;
    RETURN - 1;
  END;

  FUNCTION FormatNumber(N IN NUMBER, F IN VARCHAR2) RETURN VARCHAR2 IS
    S VARCHAR2(20);
  BEGIN
    S := TO_CHAR(N, 'FM9999999999D9999');
    IF S IS NULL THEN
      RETURN '0';
    ELSIF SUBSTR(S, 1, 1) = '.' THEN
      RETURN '0' || S;
    ELSIF SUBSTR(S, LENGTH(S), 1) = '.' THEN
      RETURN SUBSTR(S, 1, LENGTH(S) - 1);
    ELSE
      RETURN S;
    END IF;
  END;

  FUNCTION SPLIT(P_STR IN VARCHAR2, P_DELIMITER IN VARCHAR2 := '^')
    RETURN ARR_LONGSTR IS
    L_IDX   PLS_INTEGER;
    L_STR   VARCHAR2(32767) := P_STR;
    L_VALUE VARCHAR2(32767);
    i       NUMBER := 1;
    RtnList ARR_LONGSTR;
  BEGIN
    LOOP
      L_IDX := INSTR(L_STR, P_DELIMITER);
      IF L_IDX > 0 THEN
        L_VALUE := SUBSTR(L_STR, 1, L_IDX - 1);
        L_STR := SUBSTR(L_STR, L_IDX + LENGTH(P_DELIMITER));
        RtnList(i) := L_VALUE;
        i := i + 1;
      ELSE
        RtnList(i) := L_STR;
        EXIT;
      END IF;
    END LOOP;
    RETURN RtnList;
  END;

  --插入用户操作
  --参数：用户ID   操作类型  操作表名  描述
  PROCEDURE InsertOperationLog(UserID    IN VARCHAR2,
                               TableName IN VARCHAR2,
                               nOpType   IN NUMBER,
                               nStatus   IN NUMBER,
                               nDuration IN NUMBER := 0,
                               nStep     IN NUMBER := 0) IS
  BEGIN
    INSERT INTO LCOA.OA_LOG
      (C_USER_ID,
       D_LOG_DATE,
       V_TABLENAME,
       N_OP_TYPE,
       N_STATUS,
       N_OP_DURATION,
       N_STEP)
    VALUES
      (UserID, SYSDATE, TableName, nOpType, nStatus, nDuration, nStep);
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('记录日志异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                           DBMS_UTILITY.format_error_backtrace);
      ROLLBACK;
      RETURN;
  END;

  procedure InsertOperationLog2(UserId          in varchar2,
                                ActionName      in varchar2,
                                CallName        in varchar2,
                                SummeryInfo     in varchar2,
                                ActionStartTime in date,
                                ActionEndTime   in date,
                                ActionStatus    in number) is
  begin
    insert into lcoa.oa_call_log
      (c_user_id,
       v_act_name,
       v_tablename,
       v_act_summery,
       d_act_start,
       d_act_end,
       n_status)
    values
      (UserId,
       ActionName,
       CallName,
       SummeryInfo,
       ActionStartTime,
       ActionEndTime,
       ActionStatus);
    commit;
  exception
    when others then
      --errcode := SQLCODE;
      --errmsg  := SQLERRM;
      rollback;
      return;
  end;

  function GetFlowNumber(prefix in varchar2, flowLength in number)
    return varchar2 is
    cur_seq number(10);
  begin
    select lcoa.seq_incflow.nextval into cur_seq from dual;
    return prefix || to_char(sysdate, 'yyyymmdd') || substr(cur_seq,
                                                            length(cur_seq) -
                                                            flowLength + 1,
                                                            flowLength);
  end;

  /*
  函数功能：分页获取数据信息
  编写：李华伟
  时间：2020年三月二十一日
  */
  FUNCTION GetPagingInfo(vSql          IN VARCHAR2,
                         nPageSize     IN NUMBER, --每页显示大小>0
                         nPageCur      IN NUMBER, --当前页码[1-总页数]
                         CUR_DATA      OUT SYS_REFCURSOR, --oracle标准游标
                         nOutRows      OUT number, --输出总记录数
                         nOutPageCount OUT number --输出总页数
                         ) RETURN NUMBER IS
    n_result     number(1) := 0; --0表示成功 非0表示失败
    v_sql        varchar2(4000);
    v_sql_select varchar2(4000);
    v_start      number(4);
    v_end        number(4);
    errcode      number(8);
    errmsg       varchar2(2000);
  
  BEGIN
    BEGIN
      if nPageSize < 1 then
        n_result := 1;
        errcode  := -20001;
        errmsg   := pkg_common.g_errmsg_afw_param;
        RAISE EXP_PARAM;
      end if;
      v_start := nPageSize * (nPageCur - 1) + 1;
      v_end   := nPageSize * nPageCur;
    
      v_sql := 'select t2.* from (select t1.*,rownum rn from (' || vSql ||
               ')t1 where rownum<=' || v_end || ') t2 where rn>=' ||
               v_start;
    
      --打开游标，让游标指向结果集
      OPEN CUR_DATA FOR v_sql;
    
      --查询共有多少条记录
      v_sql_select := 'select count(*) from (' || vSql || ')';
      execute immediate v_sql_select
        into nOutRows;
    
      --统计多少页记录
      nOutPageCount := ceil(nOutRows / nPageSize);
    
      n_result := 0;
    
      --关闭游标 外面还要用，不能关闭??
      --close CUR_DATA;
    EXCEPTION
      WHEN EXP_PARAM THEN
        dbms_output.put_line('自定义异常!');
      WHEN OTHERS THEN
        errcode  := lcoa.pkg_common.g_errcode_exception;
        errmsg   := lcoa.pkg_common.g_errmsg_common;
        n_result := 1;
    END;
  
    --正常返回
    if n_result = 0 then
      return 0;
    end if;
    --异常返回
    RAISE_APPLICATION_ERROR(errcode, errmsg, false);
  END;

  --插入用户操作
  --参数：用户ID   操作类型  操作表名  描述
  PROCEDURE InsertSpCallLog(vSpName    IN VARCHAR2,
                            dOpStart   IN DATE,
                            vOpContent IN VARCHAR2,
                            cSpCallId  out varchar2) IS
    cCallId char(32);
  BEGIN
    cCallId := lower(sys_guid());
    INSERT INTO LCOA.OA_SP_CALL_LOG
      (c_call_id, v_sp_name, d_op_start, v_op_result)
    VALUES
      (cCallId, vSpName, dOpStart, vOpContent);
    cSpCallId := cCallId;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('InsertSpCallLog: ' || SQLCODE || ',' ||
                           SQLERRM || ',' ||
                           DBMS_UTILITY.format_error_backtrace);
      ROLLBACK;
      RETURN;
  END;
  --插入用户操作
  --参数：用户ID   操作类型  操作表名  描述
  PROCEDURE UpdateSpCallLog(cSpCallId  IN varchar2,
                            dOpEnd     IN DATE,
                            nDuration  IN NUMBER,
                            vOpContent IN VARCHAR2,
                            nStatus    IN NUMBER) IS
  BEGIN
    update LCOA.OA_SP_CALL_LOG
       set d_op_end      = dOpEnd,
           n_op_duration = nDuration,
           v_op_result   = vOpContent,
           n_status      = nStatus
     where c_call_id = cSpCallId;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.put_line('UpdateSpCallLog: ' || SQLCODE || ',' ||
                           SQLERRM || ',' ||
                           DBMS_UTILITY.format_error_backtrace);
      ROLLBACK;
      RETURN;
  END;
END PKG_COMMON;
/

