create package body PKG_EXT_OA_ADMIN_INFO is
  --新增部门
  function insert_children_organization(DataInfo        in varchar2, --新增的部门名称^父部门ID
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增部门ID
                                        ErrMsg          out varchar2)
    return number is
    n_optype   number(1); --1查2插3更4删
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  begin
    time_start := systimestamp;
    BEGIN
      n_optype := 2;
      n_result := lcoa.pkg_ins_dept_info.insert_children_organization(DataInfo,
                                                                      OperationUserId,
                                                                      DataId,
                                                                      ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := '部门插入异常: ' || pkg_common.g_errcode_exception || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := -20999;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'insert_children_organinzation',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = -20999 then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  --修改部门名称
  function update_children_organization(DataInfo        in varchar2, --部门id^部门名称
                                        OperationUserId IN VARCHAR2,
                                        ErrMsg          out varchar2)
    return number is
    n_optype   number(1); --1查2插3更4删
    n_result   number(6) := 0; --0成功1失败
    time_start timestamp; --程序起始时间
    time_end   timestamp; --程序结束时间
    n_duration number(10); --耗时
    n_status   number(1) := 0; --0成功1失败
  begin
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_ins_dept_info.update_children_organization(DataInfo,
                                                                      OperationUserId,
                                                                      ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := '部门更改异常: ' || pkg_common.g_errcode_exception || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := -20999;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'update_children_organinzation',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = -20999 then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  --修改部门BP,VP
  function update_organization_leader(DataInfo in varchar2, --部门id^负责人id^
                                      --负责人类型1负责人 2 BP 3 VP
                                      OperationUserId IN VARCHAR2,
                                      ErrMsg          out varchar2)
    return number is
    n_optype   number(1); --1查2插3更4删
    n_result   number(6) := 0; --0成功1失败
    time_start timestamp; --程序起始时间
    time_end   timestamp; --程序结束时间
    n_duration number(10); --耗时
    n_status   number(1) := 0; --0成功1失败
  begin
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_ins_dept_info.update_organization_leader(DataInfo,
                                                                    OperationUserId,
                                                                    ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := '部门Leader更改异常: ' || pkg_common.g_errcode_exception || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := -20999;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'update_organinzation_leader',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = -20999 then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  --删除部门
  function delete_organization(OrganizationId  in varchar2, --部门id
                               OperationUserId IN VARCHAR2,
                               ErrMsg          out varchar2) return number is
    n_optype   number(1); --1查2插3更4删
    n_result   number(6) := 0; --0成功1失败
    time_start timestamp; --程序起始时间
    time_end   timestamp; --程序结束时间
    n_duration number(10); --耗时
    n_status   number(1) := 0; --0成功1失败
  begin
    time_start := systimestamp;
    BEGIN
      n_optype := 4;
      n_result := lcoa.pkg_ins_dept_info.delete_organization(organizationId,
                                                             OperationUserId,
                                                             ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := '部门删除异常: ' || pkg_common.g_errcode_exception || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := -20999;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'update_organinzation_leader',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = -20999 then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  /**
  部门上移下移
  **/
  function move_order(DataInfo        in varchar2,
                      OperationUserId IN VARCHAR2,
                      ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_ins_employees_admin.move_order(DataInfo,
                                                          OperationUserId,
                                                          ErrMsg);

    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'move_order: ' || SQLCODE || ',' || SQLERRM || ',' ||
        --DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;

    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);

    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'move_order',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  /**
  用户部门模糊查询
  **/
  function get_organization_userlist(OperationUserId    IN VARCHAR2,
                                     UserOrOrganization in varchar2,
                                     OrganizationList   out sys_refcursor,
                                     UserInfoList       out sys_refcursor,
                                     ErrMsg             out varchar2)
    return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_ins_employees_admin.get_organization_userlist(OperationUserId,
                                                                         UserOrOrganization,
                                                                         organizationlist,
                                                                         userinfolist,
                                                                         ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'get_organization_userlist',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    elsif n_result = -1 then
      ErrMsg := '本部等级不能设置本部等级的子部门,请重新设置部门';
      return n_result;
    else
      return n_result;
    end if;
  END;

  /**
  获取成员列表
  **/
  function get_employees_list(OrganizationId  in varchar2,
                              status          in varchar2,
                              pageNum         in number,
                              PageSize        in number,
                              OperationUserId IN VARCHAR2,
                              DataList        out sys_refcursor,
                              owner           out varchar2,
                              BpName          out varchar2,
                              VpName          out varchar2,
                              totalPage       out number,
                              totalCount      out number,
                              dataCount       out number,
                              ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_ins_employees_admin.get_employees_list(OrganizationId,
                                                                  status,
                                                                  pageNum,
                                                                  PageSize,
                                                                  OperationUserId,
                                                                  DataList,
                                                                  owner,
                                                                  bpname,
                                                                  vpname,
                                                                  totalPage,
                                                                  totalCount,
                                                                  dataCount,
                                                                  ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(organizationid,
                                  'get_employees_list',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    elsif n_result = -1 then
      ErrMsg := '本部等级不能设置本部等级的子部门,请重新设置部门';
      return n_result;
    else
      return n_result;
    end if;
  END;

  /**
  获取成员详情
  **/
  function query_employeeinfo(OperationUserId IN VARCHAR2,
                              UserId          in varchar2,
                              DataSource      in number, --1userid是身份证 2userid是userid
                              owner           out number,
                              bp              out number,
                              vp              out number,
                              EmployeesInfo   out sys_refcursor,
                              UserInfo        out sys_refcursor,
                              UserpicList     out sys_refcursor,
                              ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.pkg_ins_employees_admin.query_employeeinfo(OperationUserId,
                                                                  userid,
                                                                  DataSource,
                                                                  owner,
                                                                  bp,
                                                                  vp,
                                                                  employeesinfo,
                                                                  userinfo,
                                                                  userpiclist,
                                                                  ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'query_employeeinfo: ' || SQLCODE || ',' || SQLERRM || ',' ||
        --DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(userid,
                                  'query_employeeinfo',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    elsif n_result = -1 then
      ErrMsg := '本部等级不能设置本部等级的子部门,请重新设置部门';
      return n_result;
    else
      return n_result;
    end if;
  END;

  --新增成员
  function insert_employeeInfo(bp              IN integer,
                               owner           IN integer,
                               vp              IN integer,
                               employeesInfo   IN VARCHAR2,
                               userInfo        IN VARCHAR2,
                               userPicList     IN ARR_LONGSTR,
                               OperationUserId IN VARCHAR2,
                               -- UserId          IN OUT VARCHAR2,
                               user_teminfo out sys_refcursor,
                               ErrMsg       OUT VARCHAR2

                               ) return number

   is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;

    begin
      n_optype := 2;
      n_result := PKG_INS_employee_info.insert_employeeInfo(bp,
                                                            owner,
                                                            vp,
                                                            employeesInfo,
                                                            userInfo,
                                                            userPicList,
                                                            OperationUserId,
                                                            user_teminfo,
                                                            ErrMsg);

      if n_result = 0 then
        commit;
      else
        rollback;
        n_result := pkg_common.g_result_status;
      end if;

    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception;
        --ErrMsg   := pkg_common.g_errmsg_common;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'insert_employeeInfo',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  end;

  --更新成员
  function update_employeeInfo(bp              IN integer,
                               owner           IN integer,
                               vp              IN integer,
                               employeesInfo   IN VARCHAR2,
                               userInfo        IN VARCHAR2,
                               userPicList     IN ARR_LONGSTR,
                               OperationUserId IN VARCHAR2,
                               --UserId          IN OUT VARCHAR2,
                               ErrMsg OUT VARCHAR2

                               ) return number

   is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;

    begin
      n_optype := 3;
      n_result := PKG_INS_employee_info.update_employeeInfo(bp,
                                                            owner,
                                                            vp,
                                                            employeesInfo,
                                                            userInfo,
                                                            userPicList,
                                                            OperationUserId,
                                                            --UserId,
                                                            ErrMsg);
      if n_result = 0 then
        commit;
      else
        rollback;
        n_result := pkg_common.g_result_status;
      end if;

    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception;
        ErrMsg   := pkg_common.g_errmsg_common;
        rollback;
        --ErrMsg := 'update_employeeInfo 信息失败: ' || P_STEP || ',' || SQLCODE || ',' ||
      --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;

    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'update_employeeInfo',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  end;
  --设置成员部门
  function update_user_organization(userId          IN lcoa.ARR_LONGSTR,
                                    organizationId  IN VARCHAR2,
                                    OperationUserId IN VARCHAR2,
                                    ErrMsg          OUT VARCHAR2)
    return number

   is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;

    begin
      n_optype := 3;
      n_result := PKG_INS_employee_info.update_user_organization(userId,
                                                                 organizationId,
                                                                 OperationUserId,
                                                                 ErrMsg);
      if n_result = 0 then
        commit;
      else
        rollback;
        n_result := pkg_common.g_result_status;
      end if;

    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception;
        ErrMsg   := pkg_common.g_errmsg_common;
        rollback;
        --ErrMsg := 'update_employeeInfo 信息失败: ' || P_STEP || ',' || SQLCODE || ',' ||
      --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;

    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'update_user_organization',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  end;

  --操作记录
  function operation_user_recordinfo(DATAINFO IN ARR_LONGSTR,
                                     ErrMsg   OUT VARCHAR2

                                     ) return number

   is
    P_STEP NUMBER(2);

  begin
    dbms_output.put_line('---------------------------------');
    return 0;
  end;

  function insert_rest_days(DataInfo        in arr_longstr,
                            OperationUserId IN VARCHAR2,
                            ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 2;
      n_result := lcoa.pkg_ins_employees_admin.insert_rest_days(DataInfo,
                                                                OperationUserId,
                                                                ErrMsg);

    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'insert_rest_days: ' || SQLCODE || ',' || SQLERRM || ',' ||
        --DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;

    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);

    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'insert_rest_days',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function Cansee_Roleorg(OperationUserId IN VARCHAR2,
                          DataInfo        out sys_refcursor,
                          ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.PKG_INS_USER_INFO.Cansee_Roleorg(OperationUserId,
                                                        DataInfo,
                                                        ErrMsg);

    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'move_order: ' || SQLCODE || ',' || SQLERRM || ',' ||
        --DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;

    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);

    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Cansee_Roleorg',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

end PKG_EXT_OA_ADMIN_INFO;

/

