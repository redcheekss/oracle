create package body PKG_INS_LOAN_INFO is
  function save_loan_info(datainfo        in varchar2,
                          OperationUserId IN VARCHAR2,
                          c_cursor        out sys_refcursor,
                          ErrMsg          OUT VARCHAR2) return number is
    DATAARR   Pkg_Common.ARR_LONGSTR;
    loanId    char(32);
    userId    char(32);
    todoTitle varchar2(40);
  begin
    DATAARR := PKG_COMMON.SPLIT(datainfo, '^');
    loanId  := DATAARR(1);
    userId  := DATAARR(3);
    if loanId is not null then
      UPDATE OA_AFW_LOAN_INFO
         SET C_USER_ID             = DATAARR(3),
             N_AMOUNT              = DATAARR(4),
             V_CAUSE               = DATAARR(5),
             N_LOAN_TYPE           = DATAARR(6),
             D_PLAN_REPAYMENT_DATE = to_date(DATAARR(7), 'yyyymmddhh24miss'),
             D_EXTENSION_DATE      = to_date(DATAARR(7), 'yyyymmddhh24miss'),
             C_USER_CORP_ID        = DATAARR(19)
       WHERE C_ID = loanId;
    else
      loanId := LOWER(SYS_GUID());
      insert into OA_AFW_LOAN_INFO
        (C_ID,
         V_FLOW_NUMBER,
         C_USER_ID,
         N_AMOUNT,
         V_CAUSE,
         N_LOAN_TYPE,
         D_PLAN_REPAYMENT_DATE,
         D_EXTENSION_DATE,
         N_EXTENSION_TIMES,
         N_REPAID_AMOUNT,
         N_STATUS,
         N_APPROVAL_STATUS,
         N_PAYOFF_STATUS,
         D_APPLY_TIME,
         C_PAYMENT_ID,
         N_PAYMENT_TYPE,
         C_USER_CORP_ID,
         C_PAYMENT_CORP_ID,
         N_UNCONFIRMED_AMOUNT,
         D_PAYOFF_TIME)
      values
        (loanId,
         pkg_common.GetFlowNumber('JK', 4),
         DATAARR(3),
         DATAARR(4),
         DATAARR(5),
         DATAARR(6),
         to_date(DATAARR(7), 'yyyymmddhh24miss'),
         to_date(DATAARR(7), 'yyyymmddhh24miss'),
         0,
         0,
         0,
         0,
         0,
         sysdate,
         DATAARR(15),
         DATAARR(16),
         DATAARR(17),
         DATAARR(17),
         DATAARR(19),
         to_date(DATAARR(20), 'yyyymmddhh24miss'));
      select u.v_pet_name || '的借款申请'
        into todoTitle
        from lcbase.t_zip_user u
       where u.c_user_id = userId
         and u.d_enddate > sysdate;
      lcoa.pkg_ins_afw_workflow.Create_Approval_By_Id(loanId, 5);
      lcoa.pkg_ins_afw_workflow.Create_Next_Approval_Todo(loanId,
                                                          todoTitle,
                                                          c_cursor);
    end if;
    return 0;
  exception
    when others then
      ErrMsg := 'save_loan_info: ' || sqlcode || ',' || sqlerrm;
      raise;
      return - 1;
  end save_loan_info;

  function getLoanInfo(loanId          in varchar2, --借款信息ID
                       operationUserId in varchar2, --操作人ID
                       loanInfo        out sys_refcursor, --借款单详情 
                       ApproveUsers    out sys_refcursor, --审批人详情
                       roleCount       out number,
                       accountantCount out number,
                       cashierCount    out number,
                       ErrMsg          out varchar2) return number is
    loanUserId    varchar2(32); --借款人员ID
    approveStatus number(2);
    approvalOrder number(2);
    v_Pet_Name    lcbase.t_zip_user.v_user_name%type; --转正人员姓名
    d_approdate   date;
  begin
    begin
      select info.d_apply_time
        into d_approdate
        from LCOA.OA_AFW_LOAN_INFO info
       where info.c_id = loanId;
      --查询借款人ID,
      select info.c_user_id
        into loanUserId
        from LCOA.OA_AFW_LOAN_INFO info
       where info.c_id = loanId;
      --查询借款人员姓名
      select u.v_pet_name
        into v_Pet_Name
        from lcbase.t_zip_user u
       where u.c_user_id = loanUserId
         and d_approdate <= trunc(u.D_ENDDATE)
         and d_approdate >= trunc(u.d_startdate);
    
      --查询借款信息
      open loanInfo for
        select info.*,
               u.v_headpic_aly,
               u.v_pet_name,
               emp.v_user_title,
               lk.v_company            as V_USER_CORP_NAME,
               lk2.v_company           as V_PAYMENT_CORP_NAME,
               org.v_organization_name
          from LCOA.OA_AFW_LOAN_INFO info
          left join lcbase.t_zip_user u
            on u.c_user_id = info.c_user_id
          left join lcbase.t_employees_info emp
            on info.c_user_id = emp.c_user_id
          left join lcbase.t_zip_organization org
            on u.c_organization_id = org.c_organization_id
          left join lcbase.T_LK_COMPANY_INFO lk
            on lk.c_company_id = info.c_user_corp_id
          left join lcbase.T_LK_COMPANY_INFO lk2
            on lk2.c_company_id = info.c_payment_corp_id
         where info.c_id = loanId
           and d_approdate <= trunc(u.D_ENDDATE)
           and d_approdate >= trunc(u.d_startdate);
    
      --查询审批人详情包括申请人信息
      open ApproveUsers for
        select f.*, u.v_headpic_aly, info.v_user_title,s.l_pic as "V_SIGNATURE_PIC"
          from (select * --查询审批人信息
                  from oa_afw_workflow_approval_flow f
                union
                select --查询申请人信息  
                 null,
                 11,
                 loanId,
                 0,
                 null,
                 loanUserId,
                 v_Pet_Name,
                 null,
                 1,
                 null,
                 null,
                 0,
                 1
                  from dual) f
          left join lcbase.t_zip_user u
            on f.c_approval_user_id = u.c_user_id
          left join lcbase.t_employees_info info
            on u.c_user_id = info.c_user_id
                  left join lcbase.t_signature_pic s
                    on f.c_approval_user_id = s.c_user_id
         where f.c_workflow_id = loanId
           and d_approdate <= trunc(u.D_ENDDATE)
           and d_approdate >= trunc(u.d_startdate)
         order by f.n_approval_order;
    
      SELECT count(*)
        into roleCount
        FROM Oa_Aut_Role r
        LEFT JOIN oa_aut_user_role ur
          ON r.c_role_id = ur.c_role_id
       WHERE ur.c_user_id = operationUserId
         AND r.c_role_id IN (SELECT ro.c_role_id
                               FROM Oa_Aut_Role ro
                              WHERE ro.role_type = 61
                                 OR ro.role_type = 62
                                 OR ro.role_type = 65
                                 OR ro.role_type = 64
                                 OR ro.role_type = 6);
    
      SELECT OALI.N_APPROVAL_STATUS
        into approveStatus
        FROM lcoa.OA_AFW_LOAN_INFO oali
       WHERE C_ID = loanId;
    
      select min(flow.n_approval_order)
        into approvalOrder
        from lcoa.oa_afw_workflow_approval_flow flow
       where flow.c_workflow_id = loanId
         and flow.n_approval_status = 0;
    
      if approveStatus > 3 then
        if approvalOrder = 3 then
          SELECT count(*)
            into accountantCount
            FROM Oa_Aut_Role r
            LEFT JOIN oa_aut_user_role ur
              ON r.c_role_id = ur.c_role_id
           WHERE ur.c_user_id = operationUserId
             AND r.c_role_id IN (SELECT ro.c_role_id
                                   FROM Oa_Aut_Role ro
                                  WHERE ro.role_type = 62);
        end if;
        --查询用户是否有出纳角色
        --SELECT count(*)
        --into cashierCount
        --FROM Oa_Aut_Role r
        --LEFT JOIN oa_aut_user_role ur
        --ON r.c_role_id = ur.c_role_id
        -- WHERE ur.c_user_id = operationUserId
        -- AND r.c_role_id IN (SELECT ro.c_role_id
        --FROM Oa_Aut_Role ro
        --WHERE ro.role_type = 61);
      else
        accountantCount := 0;
        cashierCount    := 0;
      end if;
    
      return 0;
    exception
      when others then
        ErrMsg := 'getLoanInfo: ' || sqlcode || ',' || sqlerrm;
        raise;
        return - 1;
    end;
  end;

  function get_Loan_Approval(WorkflowUserId     in varchar2,
                             WorkflowType       in number,
                             WorkflowSubtype    in number,
                             DStartTime         in varchar2,
                             DEndTime           in varchar2,
                             New_OrganizationId in varchar2,
                             Days               out number,
                             Hours              out number,
                             CUR_DATA           out sys_refcursor,
                             companyId          out varchar2,
                             caiwuRoleCount     out number,
                             ErrMsg             out varchar2) return number is
    n_result       NUMBER(6);
    companyIdCount NUMBER(1);
  begin
    begin
      --查询审批人详情包括申请人信息
      n_result := LCOA.PKG_EXT_AFW_WORKFLOW.Get_Pre_Approval_Userlist(WorkflowUserId, --WorkflowUserId用户ID
                                                                      5, --WorkflowType申请类型
                                                                      '', --WorkflowSubType--具体类型
                                                                      null, --开始时间
                                                                      null, --结束时间
                                                                      '', --NewOrganizationId新部门
                                                                      Days,
                                                                      Hours,
                                                                      CUR_DATA, --游标审批人列表
                                                                      ErrMsg);
      SELECT count(*)
        into caiwuRoleCount
        FROM Oa_Aut_Role r
        LEFT JOIN oa_aut_user_role ur
          ON r.c_role_id = ur.c_role_id
       WHERE ur.c_user_id = WorkflowUserId
         AND r.c_role_id IN (SELECT ro.c_role_id
                               FROM Oa_Aut_Role ro
                              WHERE ro.role_type = 61
                                 OR ro.role_type = 62
                                 OR ro.role_type = 65
                                 OR ro.role_type = 64
                                 OR ro.role_type = 6);
    
      select count(*)
        into companyIdCount
        from lcbase.t_employees_info info
       where c_user_id = WorkflowUserId
         and info.c_lk_company_id is not null;
      if companyIdCount > 0 then
        select info.c_lk_company_id
          into companyId
          from lcbase.t_employees_info info
         where c_user_id = WorkflowUserId
           and info.c_lk_company_id is not null;
      end if;
      return n_result;
    exception
      when others then
        ErrMsg := 'get_Loan_Approval: ' || sqlcode || ',' || sqlerrm;
        raise;
        return - 1;
    end;
  end;

  function SetCompanyId(datainfo        in varchar2,
                        OperationUserId IN VARCHAR2,
                        ErrMsg          OUT VARCHAR2) return number is
    DATAARR   Pkg_Common.ARR_LONGSTR;
    loanId    char(32);
    userId    char(32);
    todoTitle varchar2(40);
  begin
    begin
      DATAARR := pkg_common.SPLIT(datainfo, '^');
      if DATAARR(1) is null then
        ErrMsg := '借款单ID不能为空';
        return 1;
      elsif DATAARR(2) is null then
        ErrMsg := '借款单付款主体ID不能为空';
        return 1;
      else
        update lcoa.Oa_Afw_Loan_Info info
           set info.c_payment_corp_id = DATAARR(2)
         where info.c_id = DATAARR(1);
      end if;
      return 0;
    exception
      when others then
        ErrMsg := 'SetCompanyId: ' || sqlcode || ',' || sqlerrm;
        raise;
        return - 1;
    end;
  end SetCompanyId;

  function remindRepay(ErrMsg out varchar2) return number is
  
  begin
    begin
      INSERT INTO OA_TDO_TODO_INFO
        (SELECT lower(SYS_GUID()),
                OALI.C_USER_ID,
                SYSDATE,
                55,
                '您有借款待归还',
                SYSDATE,
                0,
                NULL,
                OALI.C_ID
           FROM lcoa.OA_AFW_LOAN_INFO oali
           LEFT JOIN lcoa.OA_AFW_LOAN_EXTENSION delay
             ON oali.C_ID = DELAY.C_LOAN_ID
          WHERE TRUNC(OALI.D_EXTENSION_DATE, 'dd') = TRUNC(SYSDATE, 'dd')
            and oali.N_APPROVAL_STATUS = 5
            and (oali.N_UNCONFIRMED_AMOUNT = 0 or
                 oali.N_UNCONFIRMED_AMOUNT is null)
            AND (delay.N_APPROVAL_STATUS = 2 OR delay.N_APPROVAL_STATUS = 3 OR
                 delay.N_APPROVAL_STATUS IS null)
            and oali.N_PAYOFF_STATUS = 0);
    
      INSERT INTO lcoa.OA_MSG_EMAIL_INFO
        (SELECT lower(SYS_GUID()),
                oali.C_ID,
                13,
                2,
                1,
                tu.V_USER_NAME,
                tu.V_EMAIL,
                '【借款归待还】您有借款待归还',
                '您有借款待归还，可登录OA系统查看，并及时归还。',
                0,
                0,
                SYSDATE,
                NULL,
                1,
                1
           FROM lcoa.OA_AFW_LOAN_INFO oali
           LEFT JOIN lcoa.OA_AFW_LOAN_EXTENSION delay
             ON oali.C_ID = DELAY.C_LOAN_ID
           LEFT JOIN lcbase.T_ZIP_USER tu
             ON tu.C_USER_ID = oali.C_USER_ID
          WHERE TRUNC(OALI.D_EXTENSION_DATE, 'dd') = TRUNC(SYSDATE, 'dd')
            and oali.N_APPROVAL_STATUS = 5
            and (oali.N_UNCONFIRMED_AMOUNT = 0 or
                 oali.N_UNCONFIRMED_AMOUNT is null)
            AND (delay.N_APPROVAL_STATUS = 2 OR delay.N_APPROVAL_STATUS = 3 OR
                 delay.N_APPROVAL_STATUS IS null)
            and oali.N_PAYOFF_STATUS = 0
            AND tu.D_STARTDATE <= oali.D_APPLY_TIME
            AND tu.D_ENDDATE > oali.D_APPLY_TIME);
    
      INSERT INTO OA_MSG_RECIPIENT_ADDR
        (SELECT omei.C_ID, omei.V_FROM_NAME, omei.V_FROM_ADDR
           FROM lcoa.OA_MSG_EMAIL_INFO omei
          WHERE omei.C_DATAID in
                (SELECT oali.C_ID
                   FROM lcoa.OA_AFW_LOAN_INFO oali
                   LEFT JOIN lcoa.OA_AFW_LOAN_EXTENSION delay
                     ON oali.C_ID = DELAY.C_LOAN_ID
                   LEFT JOIN lcbase.T_ZIP_USER tu
                     ON tu.C_USER_ID = oali.C_USER_ID
                  WHERE TRUNC(OALI.D_EXTENSION_DATE, 'dd') =
                        TRUNC(SYSDATE, 'dd')
                    and oali.N_APPROVAL_STATUS = 5
                    and (oali.N_UNCONFIRMED_AMOUNT = 0 or
                         oali.N_UNCONFIRMED_AMOUNT is null)
                    AND (delay.N_APPROVAL_STATUS = 2 OR
                         delay.N_APPROVAL_STATUS = 3 OR
                         delay.N_APPROVAL_STATUS IS null)
                    and oali.N_PAYOFF_STATUS = 0
                    AND tu.D_STARTDATE <= oali.D_APPLY_TIME
                    AND tu.D_ENDDATE > oali.D_APPLY_TIME)
            AND omei.N_OPERATION_TYPE = 13
            AND omei.N_SEND_STATUS = 0);
    
      return 0;
    exception
      when others then
        ErrMsg := 'remindRepay: ' || sqlcode || ',' || sqlerrm;
        raise;
        return - 1;
    end;
  end remindRepay;

end;
/

