create package pkg_ins_dept_info is
  --更新记录操作
  function HISTORY_TABLE_LOG(OperationDataId       in varchar2, --更新数据ID
                             OperationIdColumnName in varchar2, --更新ID字段名
                             OperationTableName    in varchar2, --更新表名
                             OperationType         in varchar2, --操作类型0新增1更改
                             OperationUserId       IN VARCHAR2,
                             ErrMsg                out varchar2)
    return number;
  --新增部门
  function insert_children_organization(DataInfo        in varchar2, --新增的部门名称^父部门ID
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增部门ID
                                        ErrMsg          out varchar2)
    return number;
  --修改部门名称
  function update_children_organization(DataInfo        in varchar2, --部门id^部门名称
                                        OperationUserId IN VARCHAR2,
                                        ErrMsg          out varchar2)
    return number;
  --修改部门BP,VP
  function update_organization_leader(DataInfo        in varchar2, --部门id^负责人id^负责人类型1负责人 2 BP 3 VP
                                      OperationUserId IN VARCHAR2,
                                      ErrMsg          out varchar2)
    return number;
  --删除部门
  function delete_organization(OrganizationId  in varchar2, --部门id
                               OperationUserId IN VARCHAR2,
                               ErrMsg          out varchar2) return number;
end pkg_ins_dept_info;

/

