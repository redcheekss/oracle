create package PKG_USER_MSG as
  function Insert_UserMsgFeed(PUserMsgFeed    IN VARCHAR2,
                              OperationUserId IN VARCHAR2,
                              MsgFeedId       out varchar2,
                              ErrMsg          out VARCHAR2) return number;
  function Update_UserMsgFeed(PUserMsgFeed    IN VARCHAR2,
                              OperationUserId IN VARCHAR2,
                              ErrMsg          out VARCHAR2) return NUMBER;
  function Update_UserMsgReaded(MsgId           IN VARCHAR2,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) return number;
  function Update_UserMsgTop(PNewsInfo       IN VARCHAR2,
                             OperationUserId IN VARCHAR2,
                             ErrMsg          OUT VARCHAR2) return number;
end PKG_USER_MSG;
/

