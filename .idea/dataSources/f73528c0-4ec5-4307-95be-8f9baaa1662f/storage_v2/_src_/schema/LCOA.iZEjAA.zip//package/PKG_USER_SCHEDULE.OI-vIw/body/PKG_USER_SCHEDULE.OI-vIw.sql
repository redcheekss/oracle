create package body pkg_user_schedule as
  function VerifyIssuerIdentity(IssuerUserId in varchar2,
                                ErrMsg       out varchar2) return number is
    n_count integer;
  begin
    select count(*)
      into n_count
      from lcbase.t_project_team pt, lcbase.t_user_team ut
     where ut.c_team_id = pt.c_team_id
       and pt.v_team_name = '发布组'
       and ut.c_user_id = IssuerUserId;
    if n_count > 0 then
      return 0;
    end if;
    return 1;
  end;
  function Insert_Leave_Info(DataInfo        in varchar2,
                             ArrFile         in ARR_LONGSTR,
                             OperationUserId in varchar2,
                             DataId          out varchar2,
                             ErrMsg          out varchar2) return number as
    DATAARR             PKG_COMMON.ARR_LONGSTR;
    P_ID                char(32);
    FirstApprovalUserId char(32);
    TodoTitle           varchar2(100);
    n_result            number(1) := 0;
    time_start          timestamp;
    time_end            timestamp;
    n_duration          number(10);
    n_errcode           number(6);
  begin
    time_start := systimestamp;
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      P_ID    := LOWER(SYS_GUID());
      insert into LCOA.OA_AFW_LEAVE_INFO
        (c_leave_id,
         n_leave_type,
         c_leave_user_id,
         d_leave_start_time,
         d_leave_end_time,
         n_leave_days,
         n_leave_hours,
         v_leave_reason,
         n_enclosure_count,
         d_input_date,
         n_status,
         c_leave_no)
      values
        (P_ID,
         DATAARR(2),
         DATAARR(3),
         to_date(DATAARR(4), 'yyyymmddhh24miss'),
         to_date(DATAARR(5), 'yyyymmddhh24miss'),
         DATAARR(6),
         DATAARR(7),
         DATAARR(8),
         DATAARR(9),
         sysdate,
         0,
         LCOA.pkg_common.getflownumber('QJ', 4));
      DataId := P_ID;
      select t.v_user_name || '的请假审批'
        into TodoTitle
        from lcbase.t_user t
       where t.c_user_id = DATAARR(3);
    
      lcoa.pkg_user_workflow.Create_Approval_By_Id(DataId, 1);
      lcoa.pkg_user_workflow.Create_Next_Approval_Todo(DataId, TodoTitle);
    
      Insert_User_Upload_File(DataId   => DataId,
                              FileType => 1,
                              ArrFile  => ArrFile);
    
      commit;
      n_result  := 0;
      n_errcode := 0;
    exception
      when others then
        ErrMsg := 'Insert_Leave_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        rollback;
        n_result  := 1;
        n_errcode := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Insert_Leave_Info',
                                  2,
                                  n_result,
                                  n_duration);
  
    if n_errcode = 0 then
      return 0;
    elsif n_errcode = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(n_errcode, errmsg, false);
    else
      return n_errcode;
    end if;
  
  end;

  function Update_Leave_Info(DataInfo        in varchar2,
                             OperationUserId in varchar2,
                             ErrMsg          out varchar2) return number as
    DATAARR    PKG_COMMON.ARR_LONGSTR;
    P_ID       char(32);
    P_STATUS   number(1);
    n_result   number(1) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_errcode  number(6);
  begin
    time_start := systimestamp;
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      P_ID    := DATAARR(1);
      select n_status
        into P_STATUS
        from LCOA.OA_AFW_LEAVE_INFO
       where c_leave_id = P_ID;
    
      if P_STATUS in (-1, 0, 3) then
        update LCOA.OA_AFW_LEAVE_INFO
           set n_leave_type       = DATAARR(2),
               c_leave_user_id    = DATAARR(3),
               d_leave_start_time = to_date(DATAARR(4), 'yyyymmddhh24miss'),
               d_leave_end_time   = to_date(DATAARR(5), 'yyyymmddhh24miss'),
               n_leave_days       = DATAARR(6),
               n_leave_hours      = DATAARR(7),
               v_leave_reason     = DATAARR(8),
               n_enclosure_count  = DATAARR(9)
         where c_leave_id = P_ID;
        commit;
      
        n_errcode := 0;
      else
        ErrMsg    := pkg_common.g_errmsg_afw_status;
        n_errcode := pkg_common.g_errcode_afw_status;
      end if;
    
    exception
      when others then
        ErrMsg := 'Update_Leave_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        rollback;
        n_errcode := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if n_errcode <> 0 then
      n_result := 1;
    else
      n_result := 0;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Update_Leave_Info',
                                  3,
                                  n_result,
                                  n_duration);
  
    if n_errcode = 0 then
      return 0;
    elsif n_errcode = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(n_errcode, errmsg, false);
    else
      return n_errcode;
    end if;
  end;
  function Insert_Egress_Info(DataInfo        in varchar2,
                              ArrFile         in ARR_LONGSTR,
                              OperationUserId in varchar2,
                              DataId          out varchar2,
                              ErrMsg          out varchar2) return number as
    DATAARR             PKG_COMMON.ARR_LONGSTR;
    P_ID                char(32);
    FirstApprovalUserId char(32);
    TodoTitle           varchar2(100);
    n_result            number(1) := 0;
    time_start          timestamp;
    time_end            timestamp;
    n_duration          number(10);
    n_errcode           number(6);
  begin
    time_start := systimestamp;
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      P_ID    := LOWER(SYS_GUID());
    
      insert into LCOA.OA_AFW_EGRESS_INFO
        (c_egress_id,
         n_egress_type,
         c_egress_user_id,
         d_egress_start_time,
         d_egress_end_time,
         n_egress_days,
         n_egress_hours,
         v_egress_addr,
         v_egress_reason,
         n_enclosure_count,
         d_input_date,
         n_status,
         c_egress_no)
      values
        (P_ID,
         DATAARR(2),
         DATAARR(3),
         to_date(DATAARR(4), 'yyyymmddhh24miss'),
         to_date(DATAARR(5), 'yyyymmddhh24miss'),
         DATAARR(6),
         DATAARR(7),
         DATAARR(8),
         DATAARR(9),
         DATAARR(10),
         sysdate,
         0,
         LCOA.pkg_common.getflownumber('WC', 4));
      DataId := P_ID;
    
      select t.v_user_name || '的外出审批'
        into TodoTitle
        from lcbase.t_user t
       where t.c_user_id = DATAARR(3);
    
      lcoa.pkg_user_workflow.Create_Approval_By_Id(DataId, 2);
      lcoa.pkg_user_workflow.Create_Next_Approval_Todo(DataId, TodoTitle);
    
      Insert_User_Upload_File(DataId   => DataId,
                              FileType => 2,
                              ArrFile  => ArrFile);
      commit;
      n_errcode := 0;
    exception
      when others then
        ErrMsg := 'Insert_Egress_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        rollback;
        n_errcode := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if n_errcode <> 0 then
      n_result := 1;
    else
      n_result := 0;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Insert_Egress_Info',
                                  2,
                                  n_result,
                                  n_duration);
  
    if n_errcode = 0 then
      return 0;
    elsif n_errcode = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(n_errcode, errmsg, false);
    else
      return n_errcode;
    end if;
  end;
  function Update_Egress_Info(DataInfo        in varchar2,
                              OperationUserId in varchar2,
                              ErrMsg          out varchar2) return number as
    DATAARR    PKG_COMMON.ARR_LONGSTR;
    P_ID       char(32);
    P_STATUS   number(1);
    n_result   number(1) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_errcode  number(6);
  begin
    time_start := systimestamp;
  
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      P_ID    := DATAARR(1);
      select n_status
        into P_STATUS
        from LCOA.OA_AFW_EGRESS_INFO
       where c_egress_id = P_ID;
      if P_STATUS in (-1, 0, 3) then
        update LCOA.OA_AFW_EGRESS_INFO
           set n_egress_type       = DATAARR(2),
               c_egress_user_id    = DATAARR(3),
               d_egress_start_time = to_date(DATAARR(4), 'yyyymmddhh24miss'),
               d_egress_end_time   = to_date(DATAARR(5), 'yyyymmddhh24miss'),
               n_egress_days       = DATAARR(6),
               n_egress_hours      = DATAARR(7),
               v_egress_addr       = DATAARR(8),
               v_egress_reason     = DATAARR(9),
               n_enclosure_count   = DATAARR(10)
         where c_egress_id = P_ID;
        commit;
        n_errcode := 0;
      else
        ErrMsg    := pkg_common.g_errmsg_afw_status;
        n_errcode := pkg_common.g_errcode_afw_status;
      end if;
    
    exception
      when others then
        ErrMsg := 'Update_Egress_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        rollback;
        n_errcode := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if n_errcode <> 0 then
      n_result := 1;
    else
      n_result := 0;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Update_Egress_Info',
                                  3,
                                  n_result,
                                  n_duration);
  
    if n_errcode = 0 then
      return 0;
    elsif n_errcode = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(n_errcode, errmsg, false);
    else
      return n_errcode;
    end if;
  end;
  function Insert_News_Info(DataInfo        in varchar2,
                            NewsContent     in clob,
                            ArrFile         in arr_longstr,
                            OrgRange        in arr_longstr,
                            OperationUserId in varchar2,
                            DataId          out varchar2,
                            ErrMsg          out varchar2) return number as
    DATAARR             PKG_COMMON.ARR_LONGSTR;
    ORGARR              PKG_COMMON.ARR_LONGSTR;
    P_ID                char(32);
    FirstApprovalUserId char(32);
    n_result            number(1) := 0;
    n_errcode           number(6);
    v_orginfo           varchar2(50);
    TodoTitle           varchar2(100);
    v_datainfo          varchar2(32767);
  begin
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      P_ID    := LOWER(SYS_GUID());
      insert into LCOA.OA_MSG_PUBLISH_INFO
        (c_news_id,
         n_news_type,
         n_news_range,
         v_news_title,
         v_news_content,
         c_news_no,
         n_signature_type,
         v_signature_id,
         v_signature_name,
         n_comment_allow,
         n_must_feedback,
         n_istop_flag,
         c_input_user_id,
         v_input_user_name,
         d_input_time,
         n_status)
      values
        (P_ID,
         DATAARR(2),
         DATAARR(3),
         DATAARR(4),
         NewsContent, --DATAARR(5), 为了避免调整排序，java仍传此字段，置空 added by lihuawei at 2020.5.26
         LCOA.pkg_common.getflownumber('XG', 4), --c_news_no 心情或公告
         DATAARR(7),
         DATAARR(8),
         DATAARR(9),
         DATAARR(10),
         DATAARR(11),
         DATAARR(12),
         DATAARR(13),
         DATAARR(14),
         sysdate,
         0);
      DataId := P_ID;
      if DATAARR(2) = 0 then
        --心情：发给所有人
        insert into oa_msg_message_info
          (c_msg_id,
           n_msg_type,
           n_istop_flag,
           v_msg_title,
           d_msg_time,
           n_read_flag,
           c_msg_user_id,
           c_msg_src,
           --v_msg_content,
           v_msg_sender,
           d_update_time,
           n_enable)
          select lower(sys_guid()),
                 50,
                 t.n_istop_flag,
                 t.v_news_title,
                 sysdate,
                 0,
                 c_user_id,
                 DataId,
                 --t.v_news_content,
                 t.v_signature_name,
                 sysdate,
                 1
            from (select u.c_user_id
                    from LCBASE.t_user u
                   where u.n_status = 0
                     and u.c_organization_id in
                         (select g.c_organization_id
                            from LCBASE.t_organization g
                          connect by prior g.c_organization_id =
                                      g.c_organization_parent_id
                           start with g.c_organization_id =
                                      '997c2b49b01d4bdba3c5ea4e0f615617')) mu
            left join oa_msg_publish_info t
              on t.c_news_id = DataId;
        /*--心情
        insert into lcoa.oa_msg_message_info
          (c_msg_id,
           n_msg_type,
           n_istop_flag,
           d_istop_time,
           v_msg_title,
           d_msg_time,
           n_read_flag,
           c_msg_user_id,
           c_msg_src,
           v_msg_content,
           v_msg_sender,
           d_update_time,
           n_enable)
        values
          (P_ID,
           50,
           DATAARR(12),
           sysdate,
           DATAARR(4),
           sysdate,
           0,
           '00000000000000000000000000000000',
           P_ID,
           DATAARR(5),
           DATAARR(9),
           sysdate,
           1);*/
      else
        if DATAARR(3) = 2 then
          --全员
          if VerifyIssuerIdentity(OperationUserId, ErrMsg => ErrMsg) <> 0 then
            raise pkg_common.EXP_EXIT;
          end if;
        end if;
        if DATAARR(3) = 1 then
          if OrgRange is not null and OrgRange.Count > 0 then
            --如果传入数据为null或数组长度为0，则不处理
            for i in OrgRange.FIRST .. OrgRange.LAST loop
              v_orginfo := OrgRange(i);
              ORGARR    := PKG_COMMON.Split(v_orginfo, '^');
            
              insert into lcoa.oa_msg_publish_range
                (c_news_id, c_target_id, n_target_type, n_publish_status)
              values
                (DataId, ORGARR(1), 1, 0);
            end loop;
          end if;
        end if;
        SELECT CONCAT(tu.V_USER_NAME, '的公告申请')
          INTO TodoTitle
          FROM LCOA.oa_msg_publish_info oaei
          LEFT JOIN LCBASE.T_USER tu
            ON oaei.C_INPUT_USER_ID = tu.C_USER_ID
         WHERE OAEI.C_NEWS_ID = DataId;
        lcoa.pkg_user_workflow.Create_Approval_By_Id(DataId, 3);
        lcoa.pkg_user_workflow.Create_Next_Approval_Todo(DataId, TodoTitle);
        Insert_User_Upload_File(DataId   => DataId,
                                FileType => 3,
                                ArrFile  => ArrFile);
      end if;
      commit;
      n_errcode := 0;
    exception
      when others then
        ErrMsg := 'Insert_News_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        rollback;
        n_errcode := pkg_common.g_errcode_exception;
    end;
  
    if n_errcode = 0 then
      return 0;
    elsif n_errcode = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(n_errcode, errmsg, false);
    else
      return n_errcode;
    end if;
  end;
  function Update_News_Info(DataInfo        in varchar2,
                            NewsContent     in clob,
                            ArrFile         in arr_longstr,
                            OrgRange        in arr_longstr,
                            OperationUserId in varchar2,
                            DataId          out varchar2,
                            ErrMsg          out varchar2) return number as
    DATAARR             PKG_COMMON.ARR_LONGSTR;
    ORGARR              PKG_COMMON.ARR_LONGSTR;
    P_ID                char(32);
    FirstApprovalUserId char(32);
    n_result            number(1) := 0;
    n_errcode           number(6);
    v_orginfo           varchar2(50);
    TodoTitle           varchar2(100);
    P_STATUS            number(1) := 0;
    v_datainfo          varchar2(32767);
  begin
    begin
      /*
      for i in DataInfo.FIRST .. DataInfo.LAST loop
        v_datainfo := v_datainfo || DataInfo(i);
      end loop;*/
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      P_ID    := DATAARR(1);
    
      DataId := P_ID;
    
      select n_status
        into P_STATUS
        from LCOA.OA_MSG_PUBLISH_INFO
       where c_news_id = P_ID;
      if P_STATUS in (-1, 0, 3) then
        update LCOA.OA_MSG_PUBLISH_INFO
           set n_news_type       = DATAARR(2),
               n_news_range      = DATAARR(3),
               v_news_title      = DATAARR(4),
               v_news_content    = NewsContent,--DATAARR(5),
               n_signature_type  = DATAARR(7),
               v_signature_id    = DATAARR(8),
               v_signature_name  = DATAARR(9),
               n_comment_allow   = DATAARR(10),
               n_must_feedback   = DATAARR(11),
               n_istop_flag      = DATAARR(12),
               c_input_user_id   = DATAARR(13),
               v_input_user_name = DATAARR(14),
               d_input_time      = sysdate,
               n_status          = 0
         where c_news_id = P_ID;
        if DATAARR(2) = 0 then
          --心情：发给所有人
          insert into oa_msg_message_info
            (c_msg_id,
             n_msg_type,
             n_istop_flag,
             v_msg_title,
             d_msg_time,
             n_read_flag,
             c_msg_user_id,
             c_msg_src,
             --v_msg_content,
             v_msg_sender,
             d_update_time,
             n_enable)
            select lower(sys_guid()),
                   50,
                   t.n_istop_flag,
                   t.v_news_title,
                   sysdate,
                   0,
                   c_user_id,
                   DataId,
                   --t.v_news_content,
                   t.v_signature_name,
                   sysdate,
                   1
              from (select u.c_user_id
                      from LCBASE.t_user u
                     where u.n_status = 0
                       and u.c_organization_id in
                           (select g.c_organization_id
                              from LCBASE.t_organization g
                            connect by prior g.c_organization_id =
                                        g.c_organization_parent_id
                             start with g.c_organization_id =
                                        '997c2b49b01d4bdba3c5ea4e0f615617')) mu
              left join oa_msg_publish_info t
                on t.c_news_id = DataId;
        else
          if DATAARR(3) = 2 then
            --全员
            if VerifyIssuerIdentity(OperationUserId, ErrMsg => ErrMsg) <> 0 then
              raise pkg_common.EXP_EXIT;
            end if;
          end if;
          if DATAARR(3) = 1 then
            if OrgRange is not null and OrgRange.Count > 0 then
              --如果传入数据为null或数组长度为0，则不处理
              delete from lcoa.oa_msg_publish_range
               where c_news_id = DataId;
              for i in OrgRange.FIRST .. OrgRange.LAST loop
                v_orginfo := OrgRange(i);
                ORGARR    := PKG_COMMON.Split(v_orginfo, '^');
              
                insert into lcoa.oa_msg_publish_range
                  (c_news_id, c_target_id, n_target_type, n_publish_status)
                values
                  (DataId, ORGARR(1), 1, 0);
              end loop;
            end if;
          end if;
          SELECT CONCAT(tu.V_USER_NAME, '的公告申请')
            INTO TodoTitle
            FROM LCOA.oa_msg_publish_info oaei
            LEFT JOIN LCBASE.T_USER tu
              ON oaei.C_INPUT_USER_ID = tu.C_USER_ID
           WHERE OAEI.C_NEWS_ID = DataId;
          delete from lcoa.oa_afw_workflow_approval_flow f
           where f.c_workflow_id = DataId;
          lcoa.pkg_user_workflow.Create_Approval_By_Id(DataId, 3);
          lcoa.pkg_user_workflow.Create_Next_Approval_Todo(DataId,
                                                           TodoTitle);
          delete from lcoa.oa_user_upload_info where c_forign_id = DataId;
          Insert_User_Upload_File(DataId   => DataId,
                                  FileType => 3,
                                  ArrFile  => ArrFile);
        end if;
        commit;
        n_errcode := 0;
      
      else
        ErrMsg    := pkg_common.g_errmsg_afw_status;
        n_errcode := pkg_common.g_errcode_afw_status;
      end if;
    exception
      when others then
        ErrMsg := 'Update_News_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        rollback;
        n_errcode := pkg_common.g_errcode_exception;
    end;
  
    if n_errcode = 0 then
      return 0;
    elsif n_errcode = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(n_errcode, errmsg, false);
    else
      return n_errcode;
    end if;
  end;

  function Remove_News_Info(NewsId          IN VARCHAR2,
                            OperationUserId IN VARCHAR2,
                            ErrMsg          OUT VARCHAR2) return NUMBER as
  begin
    delete from lcoa.oa_msg_message_info t where t.c_msg_src = NewsId;
    update lcoa.oa_msg_publish_info t
       set t.n_status = -2
     where t.c_news_id = NewsId;
    commit;
    return 0;
  end;

  function Insert_Expense_Info(DataInfo        in varchar2,
                               OperationUserId in varchar2,
                               DataId          out varchar2,
                               ErrMsg          out varchar2) return number as
    DATAARR             PKG_COMMON.ARR_LONGSTR;
    P_ID                char(32);
    FirstApprovalUserId char(32);
    TodoTitle           varchar2(100);
    n_result            number(1) := 0;
    time_start          timestamp;
    time_end            timestamp;
    n_duration          number(10);
    n_errcode           number(6);
  begin
    time_start := systimestamp;
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      P_ID    := LOWER(SYS_GUID());
      insert into LCOA.OA_EPS_EXPENSES_INFO
        (c_expenses_id,
         n_expenses_type,
         c_expenses_user_id,
         v_expenses_user_name,
         v_expenses_user_tel,
         c_dept_id,
         v_dept_name,
         c_top1_dept_id,
         c_top2_dept_id,
         c_top3_dept_id,
         c_top4_dept_id,
         v_dept_full_name,
         c_position_id,
         v_position_name,
         c_lk_corp_id,
         v_expenses_reason,
         c_project_id,
         v_project_name,
         n_borrowed_fee,
         n_total_fee,
         n_payable_fee,
         v_expenses_no,
         v_bar_code,
         n_repay_flag,
         n_repay_type,
         n_repay_amount,
         d_input_time,
         d_reject_time,
         c_reject_user_id,
         v_reject_user_name,
         v_reject_remark,
         d_update_time,
         c_update_user_id,
         n_status,
         n_approval_avoid_flag,
         n_finance_status,
         n_current_level,
         n_paid_fee,
         c_pay_lk_corp_id,
         n_ebank_pay_status,
         v_payment_flow_no,
         v_payment_flow_no_prefix,
         v_bank_flow_no,
         n_payment_fee,
         v_payment_failed_reason,
         v_payment_account_no,
         c_payment_user_id,
         d_payment_date,
         v_payment_purpose,
         n_record_flag,
         d_record_time,
         n_check_flag,
         v_check_remark,
         d_check_time,
         c_check_user_id,
         n_notice_payable_fee,
         n_notice_status,
         v_notice_remark,
         n_disabled_flag,
         c_last_invalid_userid,
         d_last_invalid_date,
         v_last_invalid_memo,
         v_finance_reject_reson,
         d_finance_reject_date,
         c_finance_reject_user_id,
         v_finance_reject_user_name,
         n_invalid_status,
         v_ex_memo)
      values
        (P_ID,
         DATAARR(2),
         DATAARR(3),
         DATAARR(4),
         DATAARR(5),
         DATAARR(6),
         DATAARR(7),
         DATAARR(8),
         DATAARR(9),
         DATAARR(10),
         DATAARR(11),
         DATAARR(12),
         DATAARR(13),
         DATAARR(14),
         DATAARR(15),
         DATAARR(16),
         DATAARR(17),
         DATAARR(18),
         DATAARR(19),
         DATAARR(20),
         DATAARR(21),
         DATAARR(22),
         DATAARR(23),
         DATAARR(24),
         DATAARR(25),
         DATAARR(26),
         sysdate,
         DATAARR(28),
         DATAARR(29),
         DATAARR(30),
         DATAARR(31),
         DATAARR(32),
         DATAARR(33),
         DATAARR(34),
         DATAARR(35),
         DATAARR(36),
         DATAARR(37),
         DATAARR(38),
         DATAARR(39),
         DATAARR(40),
         DATAARR(41),
         DATAARR(42),
         DATAARR(43),
         DATAARR(44),
         DATAARR(45),
         DATAARR(46),
         DATAARR(47),
         DATAARR(48),
         DATAARR(49),
         DATAARR(50),
         DATAARR(51),
         DATAARR(52),
         DATAARR(53),
         DATAARR(54),
         DATAARR(55),
         DATAARR(56),
         DATAARR(57),
         DATAARR(58),
         DATAARR(59),
         DATAARR(60),
         DATAARR(61),
         DATAARR(62),
         DATAARR(63),
         DATAARR(64),
         DATAARR(65),
         DATAARR(66),
         DATAARR(67),
         DATAARR(68));
      DataId := P_ID;
      select t.v_user_name || '的报销审批'
        into TodoTitle
        from lcbase.t_user t
       where t.c_user_id = DATAARR(3);
      lcoa.pkg_user_workflow.Create_Approval_By_Id(DataId, 4);
      lcoa.pkg_user_workflow.Create_Next_Approval_Todo(DataId, TodoTitle);
      commit;
      n_errcode := 0;
    exception
      when others then
        ErrMsg := 'Insert_Expense_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        rollback;
        n_errcode := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if n_errcode <> 0 then
      n_result := 1;
    else
      n_result := 0;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Insert_Expense_Info',
                                  2,
                                  n_result,
                                  n_duration);
  
    if n_errcode = 0 then
      return 0;
    elsif n_errcode = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(n_errcode, errmsg, false);
    else
      return n_errcode;
    end if;
  end;
  function Update_Expense_Info(DataInfo        in varchar2,
                               OperationUserId in varchar2,
                               ErrMsg          out varchar2) return number as
    DATAARR    PKG_COMMON.ARR_LONGSTR;
    P_ID       char(32);
    P_STATUS   number(1);
    n_result   number(1) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_errcode  number(6);
  begin
    time_start := systimestamp;
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      P_ID    := DATAARR(1);
      select n_status
        into P_STATUS
        from LCOA.OA_MSG_PUBLISH_INFO
       where c_news_id = P_ID;
      if P_STATUS in (-1, 0, 3) then
        update LCOA.OA_MSG_PUBLISH_INFO
           set n_news_type       = DATAARR(2),
               n_news_range      = DATAARR(3),
               v_news_title      = DATAARR(4),
               v_news_content    = DATAARR(5),
               n_signature_type  = DATAARR(6),
               v_signature_id    = DATAARR(7),
               v_signature_name  = DATAARR(8),
               n_comment_allow   = DATAARR(9),
               n_must_feedback   = DATAARR(10),
               n_istop_flag      = DATAARR(11),
               c_input_user_id   = DATAARR(12),
               v_input_user_name = DATAARR(13)
         where c_news_id = P_ID;
        commit;
        n_errcode := 0;
      else
        ErrMsg    := pkg_common.g_errmsg_afw_status;
        n_errcode := pkg_common.g_errcode_afw_status;
      end if;
    exception
      when others then
        ErrMsg := 'Update_Expense_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        rollback;
        n_errcode := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if n_errcode <> 0 then
      n_result := 1;
    else
      n_result := 0;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Update_Expense_Info',
                                  3,
                                  n_result,
                                  n_duration);
  
    if n_errcode = 0 then
      return 0;
    elsif n_errcode = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(n_errcode, errmsg, false);
    else
      return n_errcode;
    end if;
  end;

  procedure Recreate_Schedule_Flow(DataId       varchar2,
                                   RepeadType   in number,
                                   ScheduleType in number,
                                   Today        in date,
                                   TodoUserId   in varchar2,
                                   TodoTitle    in varchar2) is
    P_ID char(32);
    W_IX number(1);
  begin
    --删除上次生成的日程待办（当前时间之后的）
    delete from lcoa.oa_tdo_todo_info t
     where t.n_status = 0
       and t.c_todo_data_id in
           (select c_flow_id
              from LCOA.OA_SDE_SCHEDULING_FLOW f
             where f.c_sch_id = DataId);
    --删除上次生成的日程（当前时间之后的）
    delete from LCOA.OA_SDE_SCHEDULING_FLOW f
     where f.c_sch_id = DataId --and f.d_flow_date > trunc(sysdate, 'dd')
       and f.c_flow_id not in (select c_meeting_id
                                 from lcoa.oa_sde_meeting_info
                                where c_sch_id = DataId);
    --重新生成当前时间之后的日程
    --重复方式(0不重复1每日2工作日3每周4每月)
    if RepeadType = 0 then
      P_ID := lower(sys_guid());
      insert into LCOA.OA_SDE_SCHEDULING_FLOW
        (c_flow_id, c_sch_id, d_flow_date)
      values
        (P_ID, DataId, Today);
      if ScheduleType = 2 then
        insert into lcoa.oa_tdo_todo_info
          (c_todo_id,
           c_todo_user_id,
           d_todo_time,
           n_todo_type,
           v_todo_title,
           d_input_time,
           n_status,
           --d_done_time,
           c_todo_data_id)
        values
          (lower(sys_guid()),
           TodoUserId,
           Today,
           52,
           TodoTitle,
           sysdate,
           0,
           --null,
           P_ID);
      end if;
    elsif RepeadType = 1 then
      for i in 0 .. 365 loop
        P_ID := lower(sys_guid());
        insert into LCOA.OA_SDE_SCHEDULING_FLOW
          (c_flow_id, c_sch_id, d_flow_date)
        values
          (P_ID, DataId, Today + i);
        if ScheduleType = 2 then
          insert into lcoa.oa_tdo_todo_info
            (c_todo_id,
             c_todo_user_id,
             d_todo_time,
             n_todo_type,
             v_todo_title,
             d_input_time,
             n_status,
             --d_done_time,
             c_todo_data_id)
          values
            (lower(sys_guid()),
             TodoUserId,
             Today + i,
             52,
             TodoTitle,
             sysdate,
             0,
             --null,
             P_ID);
        end if;
      end loop;
    elsif RepeadType = 2 then
      W_IX := to_char(Today, 'd');
      for i in 0 .. 365 loop
        if MOD(W_IX + i, 7) > 1 then
          -- in (0,1)
          P_ID := lower(sys_guid());
          insert into LCOA.OA_SDE_SCHEDULING_FLOW
            (c_flow_id, c_sch_id, d_flow_date)
          values
            (P_ID, DataId, Today + i);
          if ScheduleType = 2 then
            insert into lcoa.oa_tdo_todo_info
              (c_todo_id,
               c_todo_user_id,
               d_todo_time,
               n_todo_type,
               v_todo_title,
               d_input_time,
               n_status,
               --d_done_time,
               c_todo_data_id)
            values
              (lower(sys_guid()),
               TodoUserId,
               Today + i,
               52,
               TodoTitle,
               sysdate,
               0,
               --null,
               P_ID);
          end if;
        end if;
      end loop;
    elsif RepeadType = 3 then
      for i in 0 .. 52 loop
        P_ID := lower(sys_guid());
        insert into LCOA.OA_SDE_SCHEDULING_FLOW
          (c_flow_id, c_sch_id, d_flow_date)
        values
          (P_ID, DataId, Today + i * 7);
        if ScheduleType = 2 then
          insert into lcoa.oa_tdo_todo_info
            (c_todo_id,
             c_todo_user_id,
             d_todo_time,
             n_todo_type,
             v_todo_title,
             d_input_time,
             n_status,
             --d_done_time,
             c_todo_data_id)
          values
            (lower(sys_guid()),
             TodoUserId,
             Today + i * 7,
             52,
             TodoTitle,
             sysdate,
             0,
             --null,
             P_ID);
        end if;
      end loop;
    elsif RepeadType = 4 then
      for i in 0 .. 12 loop
        P_ID := lower(sys_guid());
        insert into LCOA.OA_SDE_SCHEDULING_FLOW
          (c_flow_id, c_sch_id, d_flow_date)
        values
          (P_ID, DataId, add_months(Today, i));
        if ScheduleType = 2 then
          insert into lcoa.oa_tdo_todo_info
            (c_todo_id,
             c_todo_user_id,
             d_todo_time,
             n_todo_type,
             v_todo_title,
             d_input_time,
             n_status,
             --d_done_time,
             c_todo_data_id)
          values
            (lower(sys_guid()),
             TodoUserId,
             add_months(Today, i),
             52,
             TodoTitle,
             sysdate,
             0,
             --null,
             P_ID);
        end if;
      end loop;
    end if;
  end;

  function Insert_Schedule_Info(DataInfo        in varchar2,
                                ArrAttendee     in ARR_LONGSTR,
                                OperationUserId in varchar2,
                                DataId          out varchar2,
                                ErrMsg          out varchar2) return number as
    DATAARR   PKG_COMMON.ARR_LONGSTR;
    ATTEARR   PKG_COMMON.ARR_LONGSTR;
    P_ID      char(32);
    T_DY      date;
    TodoTitle varchar2(100);
  
    n_result   number(1) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_errcode  number(6);
  begin
    time_start := systimestamp;
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      P_ID    := LOWER(SYS_GUID());
      insert into OA_SDE_SCHEDULE_INFO
        (c_sch_id,
         d_sch_date,
         d_sch_start_time,
         d_sch_end_time,
         c_sch_user_id,
         v_sch_title,
         v_sch_remark,
         n_repead_type,
         n_sch_type,
         n_meeting_type,
         c_meeting_clerk_id,
         c_meeting_clerk_name,
         c_mroom_no)
      values
        (P_ID,
         to_date(DATAARR(2), 'yyyymmddhh24miss'),
         to_date(DATAARR(3), 'yyyymmddhh24miss'),
         to_date(DATAARR(4), 'yyyymmddhh24miss'),
         DATAARR(5),
         DATAARR(6),
         DATAARR(7),
         DATAARR(8),
         DATAARR(9),
         DATAARR(10),
         DATAARR(11),
         DATAARR(12),
         DATAARR(13));
      DataId := P_ID;
    
      delete from lcoa.oa_sde_schedule_number where c_sch_id = DataId;
      if ArrAttendee is not null and ArrAttendee.Count > 0 then
        for I in ArrAttendee.First .. ArrAttendee.Last loop
          ATTEARR := PKG_COMMON.Split(ArrAttendee(I), '^');
          insert into lcoa.oa_sde_schedule_number
            (c_sch_id, c_user_id, n_type)
          values
            (DataId, ATTEARR(1), 1);
        end loop;
      end if;
    
      T_DY      := trunc(to_date(DATAARR(2), 'yyyymmddhh24miss'), 'dd');
      TodoTitle := '【' || DATAARR(6) || '】会议纪要';
      Recreate_Schedule_Flow(DataId       => DataId,
                             RepeadType   => DATAARR(8),
                             ScheduleType => DATAARR(9),
                             Today        => T_DY,
                             TodoUserId   => DATAARR(11),
                             TodoTitle    => TodoTitle);
    
      /*
      --删除上次生成的日程（当前时间之后的）
      delete from LCOA.OA_SDE_SCHEDULING_FLOW f
       where f.c_sch_id = DataId
         and f.d_flow_date > trunc(sysdate, 'dd');
      --重新生成当前时间之后的日程
      --重复方式(0不重复1每日2工作日3每周4每月)
      T_DY := trunc(to_date(DATAARR(2), 'yyyymmddhh24miss'), 'dd');
      if DATAARR(8) = 0 then
        P_ID := lower(sys_guid());
        insert into LCOA.OA_SDE_SCHEDULING_FLOW
          (c_flow_id, c_sch_id, d_flow_date)
        values
          (P_ID, DataId, T_DY);
        if DATAARR(9) = 2 then
          insert into lcoa.oa_tdo_todo_info
            (c_todo_id,
             c_todo_user_id,
             d_todo_time,
             n_todo_type,
             v_todo_title,
             d_input_time,
             n_status,
             --d_done_time,
             c_todo_data_id)
          values
            (lower(sys_guid()),
             DATAARR(11),
             T_DY,
             52,
             DATAARR(6),
             sysdate,
             0,
             --null,
             P_ID);
        end if;
      elsif DATAARR(8) = 1 then
        for i in 1 .. 365 loop
          P_ID := lower(sys_guid());
          insert into LCOA.OA_SDE_SCHEDULING_FLOW
            (c_flow_id, c_sch_id, d_flow_date)
          values
            (P_ID, DataId, T_DY + i);
          if DATAARR(9) = 2 then
            insert into lcoa.oa_tdo_todo_info
              (c_todo_id,
               c_todo_user_id,
               d_todo_time,
               n_todo_type,
               v_todo_title,
               d_input_time,
               n_status,
               --d_done_time,
               c_todo_data_id)
            values
              (lower(sys_guid()),
               DATAARR(11),
               T_DY,
               52,
               DATAARR(6),
               sysdate,
               0,
               --null,
               P_ID);
          end if;
        end loop;
      elsif DATAARR(8) = 2 then
        W_IX := to_char(T_DY, 'd');
        for i in 1 .. 365 loop
          if MOD(W_IX + i, 7) > 1 then
            -- in (0,1)
            P_ID := lower(sys_guid());
            insert into LCOA.OA_SDE_SCHEDULING_FLOW
              (c_flow_id, c_sch_id, d_flow_date)
            values
              (P_ID, DataId, T_DY + i);
            if DATAARR(9) = 2 then
              insert into lcoa.oa_tdo_todo_info
                (c_todo_id,
                 c_todo_user_id,
                 d_todo_time,
                 n_todo_type,
                 v_todo_title,
                 d_input_time,
                 n_status,
                 --d_done_time,
                 c_todo_data_id)
              values
                (lower(sys_guid()),
                 DATAARR(11),
                 T_DY,
                 52,
                 DATAARR(6),
                 sysdate,
                 0,
                 --null,
                 P_ID);
            end if;
          end if;
        end loop;
      elsif DATAARR(8) = 3 then
        for i in 1 .. 52 loop
          P_ID := lower(sys_guid());
          insert into LCOA.OA_SDE_SCHEDULING_FLOW
            (c_flow_id, c_sch_id, d_flow_date)
          values
            (P_ID, DataId, T_DY + i * 7);
          if DATAARR(9) = 2 then
            insert into lcoa.oa_tdo_todo_info
              (c_todo_id,
               c_todo_user_id,
               d_todo_time,
               n_todo_type,
               v_todo_title,
               d_input_time,
               n_status,
               --d_done_time,
               c_todo_data_id)
            values
              (lower(sys_guid()),
               DATAARR(11),
               T_DY,
               52,
               DATAARR(6),
               sysdate,
               0,
               --null,
               P_ID);
          end if;
        end loop;
      elsif DATAARR(8) = 4 then
        for i in 1 .. 12 loop
          P_ID := lower(sys_guid());
          insert into LCOA.OA_SDE_SCHEDULING_FLOW
            (c_flow_id, c_sch_id, d_flow_date)
          values
            (P_ID, DataId, add_months(T_DY, i));
          if DATAARR(9) = 2 then
            insert into lcoa.oa_tdo_todo_info
              (c_todo_id,
               c_todo_user_id,
               d_todo_time,
               n_todo_type,
               v_todo_title,
               d_input_time,
               n_status,
               --d_done_time,
               c_todo_data_id)
            values
              (lower(sys_guid()),
               DATAARR(11),
               T_DY,
               52,
               DATAARR(6),
               sysdate,
               0,
               --null,
               P_ID);
          end if;
        end loop;
      end if;*/
      commit;
      n_errcode := 0;
    exception
      when others then
        ErrMsg := 'Insert_Schedule_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        rollback;
        n_errcode := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if n_errcode <> 0 then
      n_result := 1;
    else
      n_result := 0;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Insert_Schedule_Info',
                                  2,
                                  n_result,
                                  n_duration);
  
    if n_errcode = 0 then
      return 0;
    elsif n_errcode = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(n_errcode, errmsg, false);
    else
      return n_errcode;
    end if;
  end;
  function Update_Schedule_Info(DataInfo        IN VARCHAR2,
                                ArrAttendee     in ARR_LONGSTR,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) return NUMBER as
    DATAARR    PKG_COMMON.ARR_LONGSTR;
    ATTEARR    PKG_COMMON.ARR_LONGSTR;
    DataId     char(32);
    T_DY       date;
    TodoTitle  varchar2(100);
    n_result   number(1) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_errcode  number(6);
  begin
    time_start := systimestamp;
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      DataId  := DATAARR(1);
      UPDATE OA_SDE_SCHEDULE_INFO
         SET d_sch_date           = to_date(DATAARR(2), 'yyyymmddhh24miss'),
             d_sch_start_time     = to_date(DATAARR(3), 'yyyymmddhh24miss'),
             d_sch_end_time       = to_date(DATAARR(4), 'yyyymmddhh24miss'),
             c_sch_user_id        = DATAARR(5),
             v_sch_title          = DATAARR(6),
             v_sch_remark         = DATAARR(7),
             n_repead_type        = DATAARR(8),
             n_sch_type           = DATAARR(9),
             n_meeting_type       = DATAARR(10),
             c_meeting_clerk_id   = DATAARR(11),
             c_meeting_clerk_name = DATAARR(12),
             c_mroom_no           = DATAARR(13)
       WHERE c_sch_id = DataId;
    
      delete from lcoa.oa_sde_schedule_number where c_sch_id = DataId;
      if ArrAttendee is not null and ArrAttendee.Count > 0 then
        for I in ArrAttendee.First .. ArrAttendee.Last loop
          ATTEARR := PKG_COMMON.Split(ArrAttendee(I), '^');
          insert into lcoa.oa_sde_schedule_number
            (c_sch_id, c_user_id, n_type)
          values
            (DataId, ATTEARR(1), 1);
        end loop;
      end if;
    
      T_DY := trunc(to_date(DATAARR(2), 'yyyymmddhh24miss'), 'dd');
    
      TodoTitle := '《' || DATAARR(6) || '》会议纪要';
      Recreate_Schedule_Flow(DataId       => DataId,
                             RepeadType   => DATAARR(8),
                             ScheduleType => DATAARR(9),
                             Today        => T_DY,
                             TodoUserId   => DATAARR(11),
                             TodoTitle    => TodoTitle);
    
      /*
        --删除上次生成的日程待办（当前时间之后的）
        delete from lcoa.oa_tdo_todo_info t
         where t.n_status = 0
           and t.c_todo_data_id in
               (select c_flow_id
                  from LCOA.OA_SDE_SCHEDULING_FLOW f
                 where f.c_sch_id = DataId);
        --删除上次生成的日程（当前时间之后的）
        delete from LCOA.OA_SDE_SCHEDULING_FLOW f
         where f.c_sch_id = DataId
           and f.d_flow_date > trunc(sysdate, 'dd');
        --重新生成当前时间之后的日程
        --重复方式(0不重复1每日2工作日3每周4每月)
        T_DY := trunc(to_date(DATAARR(2), 'yyyymmddhh24miss'), 'dd');
        if DATAARR(8) = 0 then
          insert into LCOA.OA_SDE_SCHEDULING_FLOW
            (c_flow_id, c_sch_id, d_flow_date)
          values
            (lower(sys_guid()), DataId, T_DY);
        
          if DATAARR(9) = 2 then
            insert into lcoa.oa_tdo_todo_info
              (c_todo_id,
               c_todo_user_id,
               d_todo_time,
               n_todo_type,
               v_todo_title,
               d_input_time,
               n_status,
               --d_done_time,
               c_todo_data_id)
            values
              (lower(sys_guid()),
               DATAARR(11),
               T_DY,
               52,
               DATAARR(6),
               sysdate,
               0,
               --null,
               P_ID);
          end if;
        elsif DATAARR(8) = 1 then
          for i in 1 .. 365 loop
            insert into LCOA.OA_SDE_SCHEDULING_FLOW
              (c_flow_id, c_sch_id, d_flow_date)
            values
              (lower(sys_guid()), DataId, T_DY + i);
          end loop;
        elsif DATAARR(8) = 2 then
          W_IX := to_char(T_DY, 'd');
          for i in 1 .. 365 loop
            if MOD(W_IX + i, 7) > 1 then
              -- in (0,1)
              insert into LCOA.OA_SDE_SCHEDULING_FLOW
                (c_flow_id, c_sch_id, d_flow_date)
              values
                (lower(sys_guid()), DataId, T_DY + i);
            end if;
          end loop;
        elsif DATAARR(8) = 3 then
          for i in 1 .. 52 loop
            insert into LCOA.OA_SDE_SCHEDULING_FLOW
              (c_flow_id, c_sch_id, d_flow_date)
            values
              (lower(sys_guid()), DataId, T_DY + i * 7);
          
          end loop;
        elsif DATAARR(8) = 4 then
          for i in 1 .. 12 loop
            insert into LCOA.OA_SDE_SCHEDULING_FLOW
              (c_flow_id, c_sch_id, d_flow_date)
            values
              (lower(sys_guid()), DataId, add_months(T_DY, i));
          end loop;
        end if;
      */
      commit;
      n_errcode := 0;
    exception
      when others then
        ErrMsg := 'Update_Schedule_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        rollback;
        n_errcode := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if n_errcode <> 0 then
      n_result := 1;
    else
      n_result := 0;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Update_Schedule_Info',
                                  3,
                                  n_result,
                                  n_duration);
  
    if n_errcode = 0 then
      return 0;
    elsif n_errcode = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(n_errcode, errmsg, false);
    else
      return n_errcode;
    end if;
  end;
  function Remove_Schedule_Info(ScheduleId      IN VARCHAR2,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) return NUMBER as
    n_result   number(1) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_errcode  number(6);
  begin
    time_start := systimestamp;
    begin
      delete from lcoa.oa_sde_schedule_number where c_sch_id = ScheduleId;
      delete from OA_SDE_SCHEDULE_INFO WHERE c_sch_id = ScheduleId;
      --删除上次生成的日程待办（当前时间之后的）
      delete from lcoa.oa_tdo_todo_info t
       where t.n_status = 0
         and t.c_todo_data_id in
             (select c_flow_id
                from LCOA.OA_SDE_SCHEDULING_FLOW f
               where f.c_sch_id = ScheduleId);
      --删除上次生成的日程（当前时间之后的）
      delete from LCOA.OA_SDE_SCHEDULING_FLOW f
       where f.c_sch_id = ScheduleId --and f.d_flow_date > trunc(sysdate, 'dd')
         and f.c_flow_id not in
             (select c_meeting_id
                from lcoa.oa_sde_meeting_info
               where c_sch_id = ScheduleId);
      commit;
      n_errcode := 0;
    exception
      when others then
        ErrMsg := 'Remove_Schedule_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        rollback;
        n_errcode := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if n_errcode <> 0 then
      n_result := 1;
    else
      n_result := 0;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Remove_Schedule_Info',
                                  4,
                                  n_result,
                                  n_duration);
  
    if n_errcode = 0 then
      return 0;
    elsif n_errcode = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(n_errcode, errmsg, false);
    else
      return n_errcode;
    end if;
  end;

  procedure Insert_User_Upload_File(DataId   varchar2,
                                    FileType number,
                                    ArrFile  ARR_LONGSTR) as
    vFileInfo varchar2(1000);
    errmsg    varchar2(2000);
    DATAARR   PKG_COMMON.ARR_LONGSTR;
  begin
    --批量上传附件，逐个存入数据
    if ArrFile is null or ArrFile.Count = 0 then
      return;
    end if;
    for i in ArrFile.FIRST .. ArrFile.LAST loop
      vFileInfo := ArrFile(i);
      DATAARR   := PKG_COMMON.Split(vFileInfo, '^');
      if DATAARR.count <> 2 then
        RAISE PKG_COMMON.EXP_PARAM;
      end if;
    
      insert into lcoa.oa_user_upload_info
        (c_file_id,
         n_file_type,
         c_forign_id,
         v_file_name,
         v_file_path,
         d_upload_time)
      values
        (lower(sys_guid()),
         FileType,
         DataId,
         DATAARR(1),
         DATAARR(2),
         sysdate);
    end loop;
  exception
    when others then
      errmsg := 'Insert_User_Upload_File: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;
end pkg_user_schedule;
/

