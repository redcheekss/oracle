create function setbit(a in int,pos in int,value in int) return int
is
begin
    if value=1 then
       return bitor(a,power(2,pos-1));
   else
       return a-power(2,pos-1);
   end if;
end;
/

