create package body pkg_zl_dept_info is
  --新增部门
  function insert_children_organization(DataInfo        in varchar2, --新增的部门名称^父部门ID^LEVEL
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增部门ID
                                        ErrMsg          out varchar2)
    return number is
    DATAARR  PKG_COMMON.ARR_LONGSTR;
    P_ID     CHAR(32);
    P_STEP   NUMBER(2);
    P_OPTYPE NUMBER(1) := 1;
    P_SORT   number(3);
    n_result number(3);
    n_status number(3);
  BEGIN
    BEGIN
      
      P_STEP  := 0;
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      P_ID    := LOWER(SYS_GUID());
      --查看副部们状态
      select t.n_status
      into   n_status
      from   lcbase.t_zip_organization t
      where  t.C_ORGANIZATION_ID = DATAARR(2);
      if n_status = 0 then
        --排序默认序号
        select (count(*) + 1)
        into   P_SORT
        from   lcbase.t_zip_organization t
        where  t.C_ORGANIZATION_PARENT_ID = DATAARR(2)
        and    t.n_status = 0;
        --新增开始
        INSERT INTO lcbase.t_zip_organization
          (select sysdate,
                  to_date('9999-12-31','yyyy-mm-dd'),
                  P_ID,
                  DATAARR(1), --部门名称
                  DATAARR(2), --副本们ID
                  DATAARR(3), --level
                  DATAARR(4), --type
                  '', --OWNER
                  0, --status
                  DATAARR(1), --简称
                  '', --BP
                  P_SORT, --排序
                  '' --VP
           from   lcbase.t_zip_organization t
           where  t.c_organization_id = DATAARR(2));
        --新增结束
        DataId := P_ID;
        --更改记录日志
        n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(P_ID,
                                                             'C_ORGANIZATION_ID',
                                                             'LCBASE.T_ORGANIZATION',
                                                             '0',
                                                             OperationUserId,
                                                             ErrMsg);
        COMMIT;
        return 0;
      else
        return - 1;
        ErrMsg := '此部门异常,无法添加子部门';
      end if;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '新增/更新组织信息失败';
        ROLLBACK;
        return - 1;
    END;
  END;

  --修改部门名称
  function update_children_organization(DataInfo        in varchar2, --部门名称^部门id^lEvel^type
                                        OperationUserId IN VARCHAR2,
                                        ErrMsg          out varchar2)
    return number is
    DATAARR  PKG_COMMON.ARR_LONGSTR;
    P_ID     CHAR(32);
    P_STEP   NUMBER(2);
    P_OPTYPE NUMBER(1) := 1;
    P_SORT   number(3);
    n_result number(3);
    update_count Date;
    current_time Date;
  begin
    begin
      current_time:= sysdate;
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      --判断是否是当天首次修改
      --查最新数据的起始时间是否是当天
      begin 
        select 
        D_STARTDATE 
        into update_count 
        from lcbase.t_zip_organization
        where C_ORGANIZATION_ID = DATAARR(2)
        and trunc(D_startdate)= trunc(sysdate);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
        update_count := NULL;
      end;
      --判断开始 if起始日期是当天，则不是当天首次修改 直接修改最新记录
      if trunc(update_count) = trunc(current_time) then 
         --修改开始
         UPDATE lcbase.t_zip_organization o
         SET    V_ORGANIZATION_NAME    = DATAARR(1),
                v_organization_abbname = DATAARR(1),
                n_organization_level   = DATAARR(3),
                n_organization_type    = DATAARR(4)
         WHERE  C_ORGANIZATION_ID = DATAARR(2)
         and D_ENDDATE= to_date('9999-12-31','yyyy-mm-dd');
         --修改结束
      else--起始日期不是当天，则是当天首次修改，先更新有效期，再新增,再修改
         --更新原始数据有效期时间
         UPDATE lcbase.t_zip_organization o
         SET    D_ENDDATE    = sysdate
         WHERE  o.c_organization_id= DATAARR(2)
         and    D_ENDDATE= to_date('9999-12-31','yyyy-mm-dd');
         
         --新增开始
         insert into lcbase.t_zip_organization o
         (
           select * from lcbase.t_zip_organization o
           where C_ORGANIZATION_ID = DATAARR(2)
           and D_ENDDATE= sysdate
         );
         
         --更新最新记录
         update lcbase.t_zip_organization 
         SET    V_ORGANIZATION_NAME    = DATAARR(1),
                v_organization_abbname = DATAARR(1),
                n_organization_level   = DATAARR(3),
                n_organization_type    = DATAARR(4),
                D_STARTDATE            = sysdate,
                D_ENDDATE              = to_date('9999-12-31','yyyy-mm-dd')
         WHERE  C_ORGANIZATION_ID = DATAARR(2)
         and    D_ENDDATE= sysdate
         and    rownum= 1;
         
      end if;
      --修改结束
      --更改记录日志
      n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(DATAARR(2),
                                                           'C_ORGANIZATION_ID',
                                                           'LCBASE.T_ORGANIZATION',
                                                           '1',
                                                           OperationUserId,
                                                           ErrMsg);
      COMMIT;
      return 0;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '新增/更新组织信息失败';
        ROLLBACK;
        return - 1;
    END;
  END;

  --修改部门BP,VP
  function update_organization_leader(DataInfo in varchar2, --部门id^负责人id^
                                      --负责人类型1负责人 2 BP 3 VP
                                      OperationUserId IN VARCHAR2,
                                      ErrMsg          out varchar2)
    return number is
    DATAARR  PKG_COMMON.ARR_LONGSTR;
    P_ID     CHAR(32);
    P_STEP   NUMBER(2);
    P_OPTYPE NUMBER(1) := 1;
    P_SORT   number(3);
    n_result number(3) := 0;
    n_level  number(3);
    update_count Date;
    current_time Date;
    v_colunmName varchar2(100);
  begin
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      current_time := sysdate;
      --判断是否是当天首次修改
      --查最新数据的起始时间是否是当天
      begin 
      select 
      D_STARTDATE 
      into update_count 
      from lcbase.t_zip_organization
      where C_ORGANIZATION_ID = DATAARR(1)
      and trunc(D_startdate)= trunc(sysdate);    
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      update_count := NULL;
      end;
      --查询部门等级
      select o.n_organization_level
      into   n_level
      from   lcbase.t_zip_organization o
      where  o.c_organization_id = DATAARR(1);
      --判断开始 if起始日期是当天，则不是当天首次修改 直接修改最新记录
      if trunc(update_count) = trunc(current_time) then 
        --设置部门负责人
        if DATAARR(3) = 1 then
          --修改开始
          UPDATE lcbase.t_zip_organization o
          SET    o.c_organization_owner = DATAARR(2)
          WHERE  C_ORGANIZATION_ID = DATAARR(1)
          and    D_ENDDATE= to_date('9999-12-31','yyyy-mm-dd');
          --修改结束
          --设置部门BP
        elsif DATAARR(3) = 2 then
          --修改开始
          UPDATE lcbase.t_zip_organization o
          SET    o.c_organization_bp = DATAARR(2)
          WHERE  C_ORGANIZATION_ID = DATAARR(1)
          and D_ENDDATE= to_date('9999-12-31','yyyy-mm-dd');
          --修改结束
          --设置部门VP
        else
          if n_level = 2 then
            --修改开始
            UPDATE lcbase.t_zip_organization o
            SET    o.c_organization_po = DATAARR(2)
            WHERE  C_ORGANIZATION_ID = DATAARR(1)
            and D_ENDDATE= to_date('9999-12-31','yyyy-mm-dd');
            --修改结束
          else
            ErrMsg   := '非本部级别的部门不能设置VP~';
            n_result := -1;
          end if;
        end if;
      else--起始日期不是当天，则是当天首次修改，先更新有效期，再新增,再修改
        --修改有效期开始
          UPDATE lcbase.t_zip_organization o
          SET    o.d_enddate= sysdate
          WHERE  C_ORGANIZATION_ID = DATAARR(1)
          and D_ENDDATE= to_date('9999-12-31','yyyy-mm-dd');
          
          insert into lcbase.t_zip_organization o
          (
           select * from lcbase.t_zip_organization o
           where C_ORGANIZATION_ID = DATAARR(1)
           and D_ENDDATE= sysdate
          );
        --设置部门负责人
        if DATAARR(3) = 1 then
          --修改开始
          UPDATE lcbase.t_zip_organization o
          SET    o.c_organization_owner= DATAARR(2),
                 D_STARTDATE            = sysdate,
                 D_ENDDATE              = to_date('9999-12-31','yyyy-mm-dd')
          WHERE  C_ORGANIZATION_ID = DATAARR(1)
          and D_ENDDATE= sysdate
          and rownum= 1;
          --修改结束
          --设置部门BP
        elsif DATAARR(3) = 2 then
          --修改开始
          UPDATE lcbase.t_zip_organization o
          SET    o.c_organization_bp= DATAARR(2),
                 D_STARTDATE            = sysdate,
                 D_ENDDATE              = to_date('9999-12-31','yyyy-mm-dd')
          WHERE  C_ORGANIZATION_ID = DATAARR(1)
          and D_ENDDATE= sysdate
          and rownum= 1;
          --修改结束
          --设置部门VP
        else
          if n_level = 2 then
            --修改开始
            UPDATE lcbase.t_zip_organization o
            SET    o.c_organization_po = DATAARR(2),
                   D_STARTDATE            = sysdate,
                   D_ENDDATE              = to_date('9999-12-31','yyyy-mm-dd')
            WHERE  C_ORGANIZATION_ID = DATAARR(1)
            and D_ENDDATE= sysdate
            and rownum= 1;
            --修改结束
          else
            ErrMsg   := '非本部级别的部门不能设置VP~';
            n_result := -1;
          end if;
        end if;
      end if;
      if n_result = 0 then
        --更改记录日志
        n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(DATAARR(1),
                                                             'C_ORGANIZATION_ID',
                                                             'LCBASE.T_ORGANIZATION',
                                                             '1',
                                                             OperationUserId,
                                                             ErrMsg);
      end if;
      COMMIT;
      return n_result;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '新增/更新组织信息失败';
    END;
    ROLLBACK;
    return - 1;
  END;

  --删除部门
  function delete_organization(OrganizationId  in varchar2, --部门id
                               OperationUserId IN VARCHAR2,
                               ErrMsg          out varchar2) return number is
    P_OPTYPE    NUMBER(1) := 4;
    n_result    number(3);
    P_c_dept    number(3); --子部门数量
    P_C_emp     number(3); --部门成员数量
    P_PARENT_ID varchar2(32); --副部们ID
    P_SORTNUM   number(3); --排序序号
    v_sql       varchar2(3000);
    --声明游标 排序序号
    v_organizationIds SYS_REFCURSOR; --游标类型
    V_countNumber     lcbase.t_zip_organization.c_organization_id%type;
    current_time Date;
    update_count Date;
  BEGIN
    BEGIN
      current_time :=sysdate;
      update_count :=sysdate;
      --计算部门下子部门数量
      select count(*)
      into   P_c_dept
      from   lcbase.t_zip_organization o
      left   join lcbase.t_zip_organization org
      on     o.c_organization_id = org.c_organization_parent_id
      where  org.c_organization_parent_id = OrganizationId
      and    org.D_ENDDATE= to_date('9999-12-31','yyyy-mm-dd')
      and    org.n_status = 0;
      --计算部门下人员情况
      select count(*)
      into   P_C_emp
      from   lcbase.t_zip_user u
      where  u.c_organization_id = OrganizationId
      and    D_ENDDATE= to_date('9999-12-31','yyyy-mm-dd');
      n_result := -1;
      --查当前部门的副部们ID
      select org.c_organization_parent_id
      into   P_PARENT_ID
      from   lcbase.t_zip_organization org
      where  org.c_organization_id = OrganizationId
      and    D_ENDDATE= to_date('9999-12-31','yyyy-mm-dd');
      --查当前排序序号
      select org.n_order
      into   P_SORTNUM
      from   lcbase.t_zip_organization org
      where  org.c_organization_id = OrganizationId
      and    D_ENDDATE= to_date('9999-12-31','yyyy-mm-dd');
       --查最新数据的起始时间是否是当天
      begin 
        select 
        D_STARTDATE 
        into update_count 
        from lcbase.t_zip_organization
        where C_ORGANIZATION_ID = OrganizationId
        and trunc(D_startdate)= trunc(sysdate);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
        update_count := NULL;
      end;
      --判断开始 if起始日期是当天，则不是当天首次修改 直接修改最新记录
      
      if P_c_dept = 0 and P_C_emp = 0 then
        if trunc(update_count) = trunc(current_time) then 
        UPDATE lcbase.t_zip_organization o
        SET    n_status = 1
        WHERE  c_organization_id = OrganizationId
        and o.D_ENDDATE= to_date('9999-12-31','yyyy-mm-dd');
        else--当天首次修改
        --更改数据有效期
        UPDATE lcbase.t_zip_organization o
        SET    o.d_enddate= sysdate
        WHERE  c_organization_id = OrganizationId
        and    o.D_ENDDATE= to_date('9999-12-31','yyyy-mm-dd');
        
        --插入数据
        insert into lcbase.t_zip_organization o
        (
           select * from lcbase.t_zip_organization o
           where C_ORGANIZATION_ID = OrganizationId
           and D_ENDDATE= sysdate
         );
        --逻辑删除部门开始
        UPDATE lcbase.t_zip_organization o
        SET    n_status = 1,
               D_STARTDATE            = sysdate,
               D_ENDDATE              = to_date('9999-12-31','yyyy-mm-dd')
        WHERE  c_organization_id = OrganizationId
        and o.D_ENDDATE= sysdate
        and rownum= 1;
        --逻辑删除部门结束
        n_result := 0;
        v_sql    := 'select org.c_organization_id
               from LCBASE.T_ORGANIZATION org
               WHERE org.c_organization_parent_id = ''' ||
                    P_PARENT_ID || '''
               and org.N_ORDER > ' || P_SORTNUM || '';
        --打开游标
        open v_organizationIds for v_sql;
        --提取游标数据
        fetch v_organizationIds
          into V_countNumber;
        while v_organizationIds%found loop
          --大于当前序号的，自动减一
          update LCBASE.T_zip_ORGANIZATION o
          SET    o.n_order = o.N_ORDER - 1
          WHERE  o.c_organization_id = V_countNumber;
          --更改记录日志(修改下游序号操作记录)
          n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(V_countNumber,
                                                               'C_ORGANIZATION_ID',
                                                               'LCBASE.T_ORGANIZATION',
                                                               '2',
                                                               OperationUserId,
                                                               ErrMsg);
          --取出下一条
          fetch v_organizationIds
            into V_countNumber;
        end loop;
        --更改记录日志
        n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(OrganizationId,
                                                             'C_ORGANIZATION_ID',
                                                             'LCBASE.T_ORGANIZATION',
                                                             '2',
                                                             OperationUserId,
                                                             ErrMsg);
        COMMIT;
      
      end if;
      else
        ErrMsg := '请删除此部门下的成员或子部门后，再删除此部门';
      end if;
      if OrganizationId = '997c2b49b01d4bdba3c5ea4e0f615617' then
        ErrMsg := '根部门不允许删除';
      end if;
      RETURN n_result;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '删除组织信息失败';
    END;
    ROLLBACK;
    RETURN 1;
  END;
   --新增角色
  function createrole(datainfo        in varchar2, --新增的角色名称^备注
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增部门ID
                                        ErrMsg          out varchar2)
    return number is
    n_result    number(1):= 0;
    DATAARR     PKG_COMMON.ARR_LONGSTR;
    OA_ROLE_ID  VARCHAR2(32):=LOWER(SYS_GUID());
    sequence_id number(4);
    ROLE_CODE_num varchar2(4);
    begin
        --新增角色名称
        DATAARR:=PKG_COMMON.SPLIT(DataInfo,'^');
        --序列取值
        sequence_id:=OA_ROLE_ROLETYPE.nextval;
        --code补0
        select lpad(sequence_id,4,0)
        into ROLE_CODE_num
        from dual;
 
        --新增OA角色开始
        insert into lcoa.OA_AUT_ROLE(
        C_ROLE_ID, ROLE_CODE, ROLE_NAME, DELETED, N_IS_CUSTOM, ROLE_TYPE,V_REMARK)
        values (OA_ROLE_ID,--32位的ID
                ROLE_CODE_num,--序列填充后的编码
                DATAARR(3),--新增角色名称
                0,--状态正常
                0,--是否是自定义，内置为1，非内置为0
                sequence_id,--自增序列
                DATAARR(6)
                );
        --新OA角色新增结束

        --同步到业务系统
        --lcyw角色新增开始
        insert into lcyw.OA_ROLES(
               ID,
               ROLE_CODE,
               ROLE_NAME,
               INSERT_USER_ID,
               INSERT_DATE_TIME,
               UPDATE_USER_ID,
               UPDATE_DATE_TIME,
               COMPANY_ID,
               DELETED,
               ROLE_TYPE,
               N_IS_CUSTOM)
        values(OA_ROLE_ID,--ID
               ROLE_CODE_num,--ROLE_CODE
               DATAARR(3),--新增角色名称
               OperationUserId,--INSERT_USER_ID
               sysdate,--INSERT_DATE_TIME
               OperationUserId,--UPDATE_USER_ID
               sysdate,--UPDATE_DATE_TIME
               'lcsm0000000000000000000000000001',--COMPANY_ID
               0,--ROLE_TYPE
               sequence_id,--自增序列
               0--N_IS_CUSTOM
            );
        --lcyw角色新增结束

        commit ;
        DataId:=OA_ROLE_ID;--返回新增的id
        return n_result;
    EXCEPTION
        WHEN  OTHERS THEN
            ErrMsg:='角色数据插入失败';
        rollback ;
        return -1;
    end;

  --部门下添加角色
  function create_organization_role(organizationid  in varchar2, --
                      DataInfo        IN VARCHAR2,
                      ErrMsg          out varchar2)
  return number is
  DATAADDR PKG_COMMON.ARR_LONGSTR;
  N_RESULT VARCHAR2(2000);
  n_count  number(3);
   begin
    DATAADDR:=PKG_COMMON.SPLIT(DataInfo,'^');
    --删除部门原角色列表
    delete from OA_AUT_ROLE_ORGANIZATION org where org.C_ORGANIZATION_ID  = organizationid ;
    --统计角色个数
    n_count:=DATAADDR.COUNT;
    --新增部门角色
    for i in 1 .. n_count loop
      if DATAADDR(i) is not null then 
        insert into  lcoa.OA_AUT_ROLE_ORGANIZATION
        values (organizationid,DATAADDR(i));
       end if;
    end loop;
    --新增部门角色结束
    commit;
    return N_RESULT;

    EXCEPTION
       WHEN  OTHERS  THEN
        ErrMsg:='部门添加角色数据失败！';
        rollback ;
        return -1;
    end;
  --新增用户角色
  function create_user_role(userid            in varchar2, --新增角色的用户id
                            DataInfo          IN VARCHAR2,--角色id集合
                            entrytype         in number,
                            ErrMsg            out varchar2)
  return number is
  DATAADDR PKG_COMMON.ARR_LONGSTR;
  N_RESULT VARCHAR2(2000);
  n_count  number(3);
  role_ids  varchar2(4000);
  v_node varchar2(2000);
    begin
    DATAADDR:=PKG_COMMON.SPLIT(DataInfo,'^');
    
    --oa删除人员原角色列表
    delete from lcoa.OA_AUT_USER_ROLE u where u.c_role_id in (
    select urole.c_role_id
    from lcoa.OA_AUT_USER_ROLE urole
    where urole.C_USER_ID  = userid 
    and urole.n_entry_type=entrytype) and u.C_USER_ID  = userid ;
    --yw删除人员原角色列表
    delete from lcyw.OA_USER_ROLES u where u.OA__ID2  in (
    
    select urole.c_role_id
    from lcoa.OA_AUT_USER_ROLE urole
    where urole.C_USER_ID  = userid 
    and urole.n_entry_type=entrytype
    
    ) and u.OA__ID  = userid ;
    --统计角色个数
    n_count:=DATAADDR.COUNT;
    --新增人员角色
    for i in 1 .. n_count loop
      if DATAADDR(i) is not null then 
        v_node:='  insert into  lcoa.OA_AUT_USER_ROLE
        values ('''||userid||''','''||DATAADDR(i)||''','||entrytype||');';
        --oa新增
        insert into  lcoa.OA_AUT_USER_ROLE
        values (userid,DATAADDR(i),entrytype);
        --yw新增
        insert into lcyw.OA_USER_ROLES
        values (LOWER(SYS_GUID()),userid,DATAADDR(i));
       end if;  
    end loop;
    --新增人员角色结束
    commit;
    return N_RESULT;

    EXCEPTION
       WHEN  OTHERS  THEN
       ErrMsg :=  SQLCODE || ',' || SQLERRM || ',' ; 
              --  DBMS_UTILITY.format_error_backtrace;
        rollback ;
        return -1;
    end;
  --查询副部们角色信息
  function get_parentorg_role(organizationid            in varchar2, --部门id
                              roles                     out sys_refcursor,
                              ErrMsg                    out varchar2)
  return number is 
  parent_orgid varchar2(32);
  begin 
    --查询副部们ID
    select
    org.c_organization_parent_id into parent_orgid  
    from 
    lcbase.t_zip_organization org
    where org.c_organization_id=organizationid
    and org.d_enddate>sysdate;
    --查询副部们角色信息
    open roles for
    select * from 
    lcoa.oa_aut_role_organization roleorg
    where roleorg.c_organization_id=organizationid;
    
  end;
  
  --修改角色
  function update_role(datainfo        in varchar2, --修改角色名称
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增角色ID
                                        ErrMsg          out varchar2)
  return number is 
    n_result    number(1):= 0;
    DATAARR     PKG_COMMON.ARR_LONGSTR;
    OA_ROLE_ID  VARCHAR2(32):=LOWER(SYS_GUID());
    sequence_id number(4);
    ROLE_CODE_num varchar2(4);
  begin
           --新增角色名称
        DATAARR:=PKG_COMMON.SPLIT(DataInfo,'^');
 
        --修改OA角色开始
        update lcoa.OA_AUT_ROLE role
        set ROLE_NAME =DATAARR(3),
          v_remark=DATAARR(6)
        where C_ROLE_ID=DATAARR(1);
        --新OA角色修改结束

        --同步到业务系统
        --lcyw角色修改开始
        update lcyw.OA_ROLES
        set ROLE_NAME =DATAARR(3)
        where ID=DATAARR(1);
        --lcyw角色修改结束
        commit ;
        DataId:=DATAARR(1);--返回新增的id
        return n_result;
    EXCEPTION
        WHEN  OTHERS THEN
            ErrMsg:='角色数据插入失败';
        rollback ;
        return -1;
    end;
  --停用角色
  function update_delrole(datainfo        in varchar2, --修改角色名称
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增角色ID
                                        ErrMsg          out varchar2)
  return number is 
    n_result    number(1):= 0;
    DATAARR     PKG_COMMON.ARR_LONGSTR;
    OA_ROLE_ID  VARCHAR2(32):=LOWER(SYS_GUID());
    sequence_id number(4);
    ROLE_CODE_num varchar2(4);
  begin
        --新增角色名称
        DATAARR:=PKG_COMMON.SPLIT(DataInfo,'^');
 
        --修改OA角色开始
        update lcoa.OA_AUT_ROLE 
        set  deleted=DATAARR(4) 
        where C_ROLE_ID=DATAARR(1);
        --新OA角色修改结束

        --同步到业务系统
        --lcyw角色修改开始
        update lcyw.OA_ROLES
        set  deleted=DATAARR(4) 
        where  ID=DATAARR(1);
        --lcyw角色修改结束
        commit ;
        DataId:=DATAARR(1);--返回新增的id
        return n_result;
    EXCEPTION
        WHEN  OTHERS THEN
            ErrMsg:='角色数据插入失败';
        rollback ;
        return -1;
    end;
end pkg_zl_dept_info;
/

