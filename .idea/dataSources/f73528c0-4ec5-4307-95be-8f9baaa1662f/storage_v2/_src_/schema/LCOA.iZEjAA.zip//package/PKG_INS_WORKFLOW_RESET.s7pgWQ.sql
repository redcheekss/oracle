create package pkg_ins_workflow_reset is

  -- 请假重置
  procedure leave_Reset(Userid in varchar2,Flowid in varchar2) ;
  -- 外出
  procedure egress_Reset(Userid in varchar2,Flowid in varchar2) ;
  -- 公告
  procedure publish_Reset(Userid in varchar2,Flowid in varchar2) ;
  -- 转正
  procedure promotion_Reset(Userid in varchar2,Flowid in varchar2) ;
  
  -- 调岗      
  procedure adjustpost_Reset(Userid in varchar2,Flowid in varchar2) ; 
  
  -- 主调程序  工作日定时作业
  procedure workflowReset;
  
end pkg_ins_workflow_reset;
/

