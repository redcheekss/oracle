create package PKG_EXT_DMD_APPLY is

  FUNCTION INSERT_OADMDAPPLY(OADMDAPPLY      IN VARCHAR2,
                             enclosure_LIST  IN arr_longstr,
                             OperationUserID IN VARCHAR2,
                             TodoSender_Cur  out sys_refcursor,
                             ErrMsg          OUT VARCHAR2) RETURN NUMBER;

  FUNCTION UPDATE_OADMDAPPLY(datamodify_apply_id IN VARCHAR2,
                             OperationUserID     IN VARCHAR2,
                             ErrMsg              OUT VARCHAR2) RETURN NUMBER;
  FUNCTION SELECT_OADMDAPPLY(datamodify_apply_id IN VARCHAR2,
                             OperationUserID     IN VARCHAR2,
                             TodoSender_Cur      out sys_refcursor,
                             enclosure           out sys_refcursor,
                             CUR_FLOW            out sys_refcursor,
                             ErrMsg              OUT VARCHAR2) RETURN NUMBER;

  FUNCTION INSER_OADMDCOMMENT(DataInfo        IN VARCHAR2,
                              OperationUserID IN VARCHAR2,
                              TodoSender_Cur  out VARCHAR2,
                              ErrMsg          OUT VARCHAR2) RETURN NUMBER;
  FUNCTION SELETE_OADMDCOMMENT(datamodify_apply_id in VARCHAR2,
                               OperationUserID     IN VARCHAR2,
                               nPageSize           IN NUMBER, --每页显示大小>0
                               nPageCur            IN NUMBER, --当前页码[1-总页数]
                               CUR_DATA            OUT SYS_REFCURSOR, --oracle标准游标
                               nOutRows            OUT number, --输出总记录数
                               nOutPageCount       OUT number, --输出总页数
                               datamodify          out sys_refcursor,
                               ErrMsg              OUT VARCHAR2)
    RETURN NUMBER;
  --数据处理分发
  FUNCTION distribute_OADMDAPPLY(DataInfo        in VARCHAR2,
                                 OperationUserID IN VARCHAR2,
                                 apply_id        out VARCHAR2,
                                 TodoSender_Cur  out varchar2,
                                 ErrMsg          OUT VARCHAR2) RETURN NUMBER;
  --数据处理驳回
  FUNCTION reject_OADMDAPPLY(DataInfo        in VARCHAR2,
                             OperationUserID IN VARCHAR2,
                             apply_id        out VARCHAR2,
                             
                             ErrMsg OUT VARCHAR2) RETURN NUMBER;
  --数据处理关闭
  FUNCTION close_OADMDAPPLY(DataInfo        in VARCHAR2,
                            OperationUserID IN VARCHAR2,
                            apply_id        out VARCHAR2,
                            
                            ErrMsg OUT VARCHAR2) RETURN NUMBER;
end PKG_EXT_DMD_APPLY;
/

