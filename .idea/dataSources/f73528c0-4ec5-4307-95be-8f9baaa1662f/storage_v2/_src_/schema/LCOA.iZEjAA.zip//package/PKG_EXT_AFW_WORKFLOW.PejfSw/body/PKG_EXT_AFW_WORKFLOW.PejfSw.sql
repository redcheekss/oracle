create package body PKG_EXT_AFW_WORKFLOW is

  /**
  功能：当前审批人审批通过
  
  处理事项：  
  1.修改当前审批人的审批状态; 
  2.修改待办处理结果; 
  3.检查工作流状态，如果审批完成，修改总状态为审批完成并发消息给申请人；否则，给下一个审批人生成待办。
  **/
  function Approval_Target_Pass(WorkflowId      in varchar2,
                                WorkflowType    in number,
                                ApprovalUserId  in varchar2,
                                ApprovalRemark  in varchar2,
                                MsgSender_Cur   out sys_refcursor,
                                TodoSender_Cur  out sys_refcursor,
                                IsAll_MsgSender out number, --0是否，1是全部          
                                ErrMsg          out varchar2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  begin
    time_start := systimestamp;
    begin
      n_optype := 3;
      n_result := lcoa.pkg_ins_afw_workflow.Approval_Target_Pass(WorkflowId,
                                                                 WorkflowType,
                                                                 ApprovalUserId,
                                                                 ApprovalRemark,
                                                                 MsgSender_Cur,
                                                                 TodoSender_Cur,
                                                                 IsAll_MsgSender,
                                                                 ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '审批通过异常: ' || pkg_common.g_errcode_exception || ',' ||
                    SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(ApprovalUserId,
                                  'Approval_Target_Pass',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  /**
  功能：当前审批人审批驳回
  
  处理事项：  
  1.修改当前审批人的审批状态; 
  2.修改待办处理结果; 
  3.总状态改为已驳回;
  4.发送消息给申请人
  **/
  function Approval_Target_Reject(WorkflowId      in varchar2,
                                  WorkflowType    in number,
                                  ApprovalUserId  in varchar2,
                                  ApprovalRemark  in varchar2,
                                  MsgSender_Cur   out sys_refcursor,
                                  TodoSender_Cur  out sys_refcursor,
                                  IsAll_MsgSender out number, --0是否，1是全部          
                                  ErrMsg          out varchar2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  begin
    time_start := systimestamp;
    begin
      n_optype := 3;
      n_result := lcoa.pkg_ins_afw_workflow.Approval_Target_Reject(WorkflowId,
                                                                   WorkflowType,
                                                                   ApprovalUserId,
                                                                   ApprovalRemark,
                                                                   MsgSender_Cur,
                                                                   TodoSender_Cur,
                                                                   IsAll_MsgSender,
                                                                   ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '审批拒绝异常: ' || pkg_common.g_errcode_exception || ',' ||
                    SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(ApprovalUserId,
                                  'Approval_Target_Pass',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  /**
  功能：申请人撤回申请
  
  处理事项：  
  1.判断当前申请是否可以撤回，如果可以则撤回;
  2.发送消息给申请人
  **/
  function Approval_Target_Cancel(WorkflowId      in varchar2,
                                  WorkflowType    in number,
                                  WorkflowUserId  in varchar2,
                                  ApprovalRemark  in varchar2,
                                  MsgSender_Cur   out sys_refcursor,
                                  TodoSender_Cur  out sys_refcursor,
                                  IsAll_MsgSender out number, --0是否，1是全部          
                                  ErrMsg          out varchar2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  begin
    time_start := systimestamp;
    begin
      n_optype := 3;
      n_result := lcoa.pkg_ins_afw_workflow.Approval_Target_Cancel(WorkflowId,
                                                                   WorkflowType,
                                                                   WorkflowUserId,
                                                                   ApprovalRemark,
                                                                   MsgSender_Cur,
                                                                   TodoSender_Cur,
                                                                   IsAll_MsgSender,
                                                                   ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '申请人撤回审批异常: ' || pkg_common.g_errcode_exception || ',' ||
                    SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(WorkflowUserId,
                                  'Approval_Target_Cancel',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  /**
  功能：转正延期
  只有转正申请有此操作功能。
  处理事项：  
  1.
  **/
  function Approval_Target_Delay(WorkflowId      in varchar2,
                                 WorkflowType    in number,
                                 WorkflowUserId  in varchar2,
                                 ApprovalRemark  in varchar2,
                                 MsgSender_Cur   out sys_refcursor,
                                 TodoSender_Cur  out sys_refcursor,
                                 IsAll_MsgSender out number, --0是否，1是全部          
                                 ErrMsg          out varchar2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  begin
    time_start := systimestamp;
    begin
      n_optype := 3;
      n_result := lcoa.pkg_ins_afw_workflow.Approval_Target_Delay(WorkflowId,
                                                                  WorkflowType,
                                                                  WorkflowUserId,
                                                                  ApprovalRemark,
                                                                  MsgSender_Cur,
                                                                  TodoSender_Cur,
                                                                  IsAll_MsgSender,
                                                                  ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '申请人撤回审批异常: ' || pkg_common.g_errcode_exception || ',' ||
                    SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(WorkflowUserId,
                                  'Approval_Target_Cancel',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  /**
  功能：审批跳过
  
  处理事项：  
  1.设置对应业务ID及审批人ID的审批记录跳过标识
  **/
  function Approval_Target_Skip(WorkflowId      in varchar2,
                                WorkflowType    in number,
                                WorkflowUserId  in varchar2,
                                ApprovalRemark  in varchar2,
                                MsgSender_Cur   out sys_refcursor,
                                TodoSender_Cur  out sys_refcursor,
                                IsAll_MsgSender out number, --0是否，1是全部          
                                ErrMsg          out varchar2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  begin
    time_start := systimestamp;
    begin
      n_optype := 3;
      n_result := lcoa.pkg_ins_afw_workflow.Approval_Target_Skip(WorkflowId,
                                                              WorkflowType,
                                                              WorkflowUserId,
                                                              ApprovalRemark,
                                                              ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '审批人跳过审批异常: ' || pkg_common.g_errcode_exception || ',' ||
                    SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(WorkflowUserId,
                                  'Approval_Target_Skip',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  /**
  功能：重置审批跳过标识
  
  处理事项：  
  1.重置审批人所有已跳过审批记录
  **/
  function Approval_Target_ResetSkip(WorkflowUserId in varchar2,
                                     ErrMsg         out varchar2)
    return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  begin
    time_start := systimestamp;
    begin
      n_optype := 3;
      n_result := lcoa.pkg_ins_afw_workflow.Approval_Target_ResetSkip(WorkflowUserId,
                                                                   ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := '重置审批人跳过标识异常: ' || pkg_common.g_errcode_exception || ',' ||
                    SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(WorkflowUserId,
                                  'Approval_Target_ResetSkip',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  function Get_Pre_Approval_Userlist(WorkflowUserId     in varchar2,
                                     WorkflowType       in number,
                                     WorkflowSubtype    in number,
                                     DStartTime         in varchar2,
                                     DEndTime           in varchar2,
                                     New_OrganizationId in varchar2,
                                     Days               out number,
                                     Hours              out number,
                                     CUR_DATA           out sys_refcursor,
                                     ErrMsg             out varchar2)
    return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  begin
    time_start := systimestamp;
    begin
      n_optype := 1;
      n_result := lcoa.pkg_ins_afw_workflow.Get_Pre_Approval_Userlist(WorkflowUserId,
                                                                      WorkflowType,
                                                                      WorkflowSubtype,
                                                                      DStartTime,
                                                                      DEndTime,
                                                                      New_OrganizationId,
                                                                      Days,
                                                                      Hours,
                                                                      CUR_DATA,
                                                                      ErrMsg);
    EXCEPTION
      WHEN PKG_COMMON.EXP_NOLEADER then
        ErrMsg   := pkg_common.g_errmsg_afw_no_leader;
        n_result := pkg_common.g_errcode_afw_no_leader;
      WHEN OTHERS THEN
        ErrMsg   := '获取审批人列表异常: ' || pkg_common.g_errcode_exception || ',' ||
                    SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(WorkflowUserId,
                                  'Get_Pre_Approval_Userlist',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
end PKG_EXT_AFW_WORKFLOW;
/

