create package body pkg_ins_Promotion_info is
  --查询人员转正信息
  function QueryHireDate(UserId         in varchar2, --用户ID
                         HtHireDate             out Date,--入职时间
                         HtPromotionDate        out Date,--转正时间
                         GetApprovalUserList    out sys_refcursor,--审批人列表
                         ErrMsg          out varchar2) return number is
  Days number(3);
  Hours number(3);
  N_HtHireDate date;--入职时间
  N_HtPromotionDate date;--转正时间
  n_result number(6) :=0;
  begin
    begin
      --查询入职时间
      select emp.d_hire_date into N_HtHireDate
      from lcbase.t_employees_info emp
      where emp.c_user_id=UserId;
      --判断入职日期是否为空
      if N_HtHireDate is null then 
        ErrMsg:='查询失败,未查询到入职时间';
        n_result:=1;
      else
        HtHireDate:= N_HtHireDate;
      end if;
      
      --查询转正时间
      select emp.d_promotion into N_HtPromotionDate
      from lcbase.t_employees_info emp
      where emp.c_user_id=UserId;
      --判断转正日期是否为空
      if N_HtPromotionDate is null then 
        HtPromotionDate :=add_months(N_HtHireDate,6);
      else
        HtPromotionDate:= N_HtPromotionDate;
      end if;
      
      --查询审批人列表
      n_result := LCOA.PKG_EXT_AFW_WORKFLOW.Get_Pre_Approval_Userlist(UserId,--WorkflowUserId用户ID
                                                            11,--WorkflowType申请类型
                                                            '',--WorkflowSubType--具体类型
                                                            null,--开始时间
                                                            null,--结束时间
                                                            '',--NewOrganizationId新部门
                                                            Days,
                                                            Hours,
                                                            GetApprovalUserList,--游标审批人列表
                                                            ErrMsg); 
                                                            
      
      return n_result;
      
    end;
      end;  
      
  --查询人员转正审批信息
  function QueryAfwPromotion(PromotionId         in varchar2, --转正信息ID
                             CUR_DATA_HIRE       out sys_refcursor,--转正信息 
                             CUR_DATA_APPRO_LIST out sys_refcursor,--审批流详情
                             ErrMsg              out varchar2) return number is
  v_HireUserId varchar2(32);--转正人员ID
  v_UserName   lcbase.t_user.v_user_name%type;--转正人员姓名
  
  
  begin
    begin
   --查询转正人员ID,
   select 
   u.c_user_id into v_HireUserId
   from LCOA.OA_AFW_PROMOTION_INFO info
   left join lcbase.t_user u
   on info.c_promotion_user_id=u.c_user_id
   where info.c_promotion_id=PromotionId ;
   --查询转正人员姓名
   select
   u.v_user_name into v_UserName
   from LCOA.OA_AFW_PROMOTION_INFO info
   left join lcbase.t_user u
   on info.c_promotion_user_id=u.c_user_id
   where info.c_promotion_id=PromotionId ;
   --查询转正信息ID
   open CUR_DATA_HIRE for
   select info.*,u.v_headpic_aly,u.v_user_name,emp.v_user_title,org.v_organization_name
   from LCOA.OA_AFW_PROMOTION_INFO info
   left join lcbase.t_user u
   on u.c_user_id=info.c_promotion_user_id
   left join lcbase.t_employees_info emp 
   on info.c_promotion_user_id=emp.c_user_id
   left join lcbase.t_organization org
   on u.c_organization_id=org.c_organization_id 
   where info.c_promotion_id=PromotionId;
   
   --查询审批人详情包括申请人信息
   open CUR_DATA_APPRO_LIST for 
   select f.*,u.v_headpic_aly from (
    select * --查询审批人信息
    from oa_afw_workflow_approval_flow f
   union
    select--查询申请人信息  
    null,
    11,
    PromotionId,
    0,
    null,
    v_HireUserId,
    v_UserName,
    null,
    1,
    null,
    null,
    0
    from dual ) f
    left join lcbase.t_user u
    on f.c_approval_user_id=u.c_user_id
    where f.c_workflow_id = PromotionId
    order by f.n_approval_order;
    
    return 0;
    
    
   end;
    end;
 --转正申请-添加 修改
 function SaveAfwPromotion(DataInfo        in varchar2, --c_promotion_id^申请类型^用户id^入职日期^转正日期^申请日期^岗位工作职责
                                                                   --^岗位工作职责^试用期从事得工作及取得的成绩及经验
                                                                   --^对公司管理的改善建议^未来半年的工作目标
                           OperationUserId IN VARCHAR2,
                           NextApproUserID out varchar2,
                           ErrMsg          out varchar2) return number is
  n_result number(3):=0;
  DATAARR  PKG_COMMON.ARR_LONGSTR;
  V_DataID varchar2(32);
  N_Number number(3);
  v_TodoTitle varchar2(500);
  v_UserName   lcbase.t_user.v_user_name%type;--转正人员姓名
  v_NextApproUserID varchar2(32);
  CUR_DATA_TODO  sys_refcursor;--转正代办游标
  CUR_DATA_PROM_NUM  number(3);--转正信息数量
 begin 
   begin
      V_DataID:=lower(sys_guid());
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      N_Number:=DATAARR.count;
     
     --判断是否存在30天自动推送代办，有删除
     open CUR_DATA_TODO for 
     select * 
     from lcoa.oa_tdo_todo_info info
     where info.c_todo_user_id=DATAARR(3)
     and info.n_todo_type=53;
     
     if CUR_DATA_TODO%rowcount<>0 then
       delete from lcoa.oa_tdo_todo_info info 
       where info.c_todo_user_id=DATAARR(3)
       and info.n_todo_type=53;
     end if;
     
     --判断是否已经提过申请
    
     select count(*) into CUR_DATA_PROM_NUM
     from lcoa.OA_AFW_PROMOTION_INFO info
     where info.c_promotion_user_id=DATAARR(3)
     and info.n_status<>3
     and info.n_status<>4
     and info.n_status<>-1;
      
     --新增/更新开始
     --判断是否已经提过申请
     if  CUR_DATA_PROM_NUM=0 then
     --新增/更新开始  
     if DATAARR(1) is not null  then --修改
       update LCOA.OA_AFW_PROMOTION_INFO info
       set 
       info.n_promotion_type=DATAARR(2),
       info.c_promotion_user_id=DATAARR(3),
       info.d_ht_hire_date= to_date(DATAARR(4), 'yyyy-mm-dd hh24:mi:ss'),
       info.d_ht_promotion_date= to_date(DATAARR(5), 'yyyy-mm-dd hh24:mi:ss'),
       info.d_promotion_apply_date= sysdate,
       info.d_promotion_fact_date= null,
       info.c_promotion_no=DATAARR(8),
       info.v_work_duty=DATAARR(9),
       info.v_work_content=DATAARR(10),
       info.v_work_suggest=DATAARR(11),
       info.v_work_expect=DATAARR(12),
       info.d_input_date=sysdate,
       info.n_status=0
       where info.c_promotion_id=DATAARR(1);
      else 
        --新增
        insert into LCOA.OA_AFW_PROMOTION_INFO info
        values(
                V_DataID,
                DATAARR(2),
                DATAARR(3),
                to_date(DATAARR(4), 'yyyy-mm-dd hh24:mi:ss'),
                to_date(DATAARR(5), 'yyyy-mm-dd hh24:mi:ss'),
                sysdate,
                '',
                LCOA.pkg_common.getflownumber('ZZ', 4),
                DATAARR(9),
                DATAARR(10),
                DATAARR(11),
                DATAARR(12),
                sysdate,
                0
               );
      end if;
      commit;
   
      --新增/更新结束
      
      --产生审批流
      if DATAARR(1) is not null then
        V_DataID:=DATAARR(1);
      end if;
      lcoa.pkg_user_workflow.Create_Approval_By_Id(V_DataID,
                                                                 11);
      --产生代办
      select u.v_user_name
      into  v_UserName
      from lcbase.t_user u
      where u.c_user_id=DATAARR(3);
      v_TodoTitle:=v_UserName||'的转正申请';
      lcoa.pkg_user_workflow.Create_Next_Approval_Todo(V_DataID ,
                                                                v_TodoTitle ); 
                                                                                                            
      --返回第一个审批人userId
      select t.c_approval_user_id
      into NextApproUserID
      from oa_afw_workflow_approval_flow t
      where t.n_approval_order=1
      and t.c_workflow_id=V_DataID;
      
      else
         n_result:=1;
         ErrMsg:='你已提交过申请，请勿重复提交';
         rollback;
      end if;
      
      return n_result;
      
  EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '生成转正申请失败';-- || SQLCODE || ',' || SQLERRM || ',' ||
              --  DBMS_UTILITY.format_error_backtrace;
    END;
      ROLLBACK;
      RETURN 1;  
    end;  
    
    
     --未转正员工，自己也没提转正的，在试用期结束前30天，系统应自动为其生成一个转正申请。
   function Create_ToDo_info(--DateCurrent in Date, --当前时间
                             UserId_List out sys_refcursor,
                             ErrMsg          out varchar2) return number is
   D_HireTime Date;  --入职时间
   D_CurrentDay Date;--当前日期
   N_HtPromotionDate Date;--转正时间
   v_UserIdList  sys_refcursor;--当前需要发代办入职的人员ID 游标
   v_UserId    varchar2(32);--人员ID
   v_UserName    varchar2(500);--人员ID
   TodoTitle  varchar2(200);--代办标题
   CUR_DATA_HIRE  number(3);--转正信息
   Apply_Log varchar2(32);
   n_result number(3):=0;
   begin
     begin
      D_CurrentDay :=trunc(sysdate,'dd');--当前日期
      
      
       
      --查询入职人员ID
      open v_UserIdList for
      select emp.c_user_id,u.v_user_name
      from lcbase.t_employees_info emp
      left join lcbase.t_user u
      on emp.c_user_id=u.c_user_id
      where decode(emp.d_promotion,null,add_months(emp.d_hire_date,5),add_months(emp.d_promotion,1))=D_CurrentDay
      --trunc(add_months(emp.d_hire_date,5),'dd')=D_CurrentDay
      and u.n_user_type=1;
       
     
      --判断入职日期是否为空
      if v_UserIdList is not null then 
          --游标取值
          fetch v_UserIdList into v_UserId,v_UserName ; 
          --fetch v_UserIdList.v_user_name into v_UserName;
          TodoTitle:=v_UserName||',你的转正申请在这。';
          --查是否有过申请记录
         -- open CUR_DATA_HIRE for
         -- select * 
         -- from lcoa.oa_afw_promotion_info info 
         -- where info.c_promotion_user_id = v_UserId;
  
            --循环遍历发代办
            while v_UserIdList%found loop
             --查是否有过申请记录
             select count(*) into CUR_DATA_HIRE
             from lcoa.oa_afw_promotion_info info 
             where info.c_promotion_user_id = v_UserId;
             
             --游标取值
            -- fetch CUR_DATA_HIRE.c_promotion_id into User_Apply_Log; 
             Apply_Log:=lower(sys_guid());--当前日期
             
             --判断是否有过申请记录
             if CUR_DATA_HIRE=0 then  
                  insert into oa_tdo_todo_info
                   (c_todo_id,
                   c_todo_user_id,
                   d_todo_time,
                   n_todo_type,
                   v_todo_title,
                   d_input_time,
                   n_status,
                   c_todo_data_id)
                   values
                    (Apply_Log,
                    v_UserId,
                    sysdate,
                    53,
                    TodoTitle,
                    sysdate,
                    0,
                    '');
                     
               commit;
               
               
           end if;
               --游标取值
               fetch v_UserIdList into v_UserId,v_UserName;
               --fetch v_UserIdList.v_user_name into v_UserName;
               TodoTitle:=v_UserName||',你的转正申请在这。';
               
               --查是否有过申请记录
               select count(*) into CUR_DATA_HIRE 
               from lcoa.oa_afw_promotion_info info
               where info.c_promotion_user_id =v_UserId;
          
          end loop;
          
          
      
      end if;
     --返回发送代办USERID集 01
     open UserId_List for 
          select info.c_todo_user_id  
          from lcoa.oa_tdo_todo_info info
          where trunc(info.d_input_time,'dd')=trunc(sysdate,'dd')
          and info.n_todo_type=53;
     return 0;
   end;
     end;
    --更改员工信息
  function update_user_Promotion_info(WorkFlowID in varchar2,
                            ErrMsg          out varchar2) return number is
                            
  n_result varchar2(32);
  appro_syatus number(3);
  User_Id varchar2(32);
  Date_prom Date;
  begin 
    begin 
    --判断是否已经转正通过
    select info.n_status into appro_syatus 
    from  lcoa.oa_afw_promotion_info info 
    where info.c_promotion_id= WorkFlowID;
    
    --查userID
    select info.c_promotion_user_id into User_Id 
    from  lcoa.oa_afw_promotion_info info 
    where info.c_promotion_id= WorkFlowID;
    --查转正时间
    select info.d_ht_promotion_date into Date_prom 
    from  lcoa.oa_afw_promotion_info info 
    where info.c_promotion_id= WorkFlowID;
    
    if appro_syatus= 2 then
      
    --更新用户组织
    UPDATE LCBASE.T_USER u
       SET u.n_user_type = 0
     WHERE C_USER_ID = User_Id;
  
    --更新用户职务
    UPDATE LCBASE.T_EMPLOYEES_INFO info
       SET info.d_promotion= Date_prom
     WHERE C_USER_ID = User_Id;
     
     
    end if;
    return 0;
       end;
      end;
end pkg_ins_Promotion_info;
/

