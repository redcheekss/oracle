create type type_sqlSubWhere as table of PKG_COMMON.ARR_LONGSTR
/

