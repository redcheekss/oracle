create view V_ZIP_USER as
with organization as
 (select o.c_organization_id,
         o.v_organization_name,
         o.c_organization_parent_id,
         o.n_organization_level,
         o.n_organization_type,
         o.c_organization_owner,
         o.c_organization_po,
         level as lv,
         sys_connect_by_path(o.v_organization_name, '->') organization_path
    from (select *
                from lcbase.t_zip_organization g
               where g.d_enddate > sysdate) o
   where o.d_enddate >= sysdate
     and o.n_status = 0
   start with n_organization_level = 0
  connect by prior o.c_organization_id = o.c_organization_parent_id)
select u.c_user_id,
       u.v_user_name,
       u.v_pet_name,
       u.n_mobile_1,
       u.v_email,
       u.n_kindofwork,
       case u.n_kindofwork
         when 0 then
          '默认'
         when 1 then
          '销售'
         when 2 then
          '精拼'
         when 3 then
          '运力'
         when 4 then
          '产品'
         when 5 then
          '项目'
         else
          '其他'
       end as v_kindofwork,
       u.n_user_type,
       case u.n_user_type
         when 0 then
          '正式员工'
         when 1 then
          '试用期'
         when 2 then
          '实习生'
         when 3 then
          '顾问'
         when 4 then
          '外协'
         when 5 then
          '临时工'
         else
          '其他'
       end as v_user_type,
       decode(u.n_status, 0, '正常', 1, '停用', '其他') n_status,
       u.c_organization_id,
       o.v_organization_name,
       o.n_organization_type,
       --组织类型：0 集团公司 1 子公司 2分公司-独立核算 3分公司-非独核算 4VIE公司 5控股公司
       --6参股公司 7虚拟体系 8组织型部门 9项目型部门 10小兵团
       case o.n_organization_type
         when 0 then
          '集团公司'
         when 1 then
          '子公司'
         when 2 then
          '2分公司-独立核算'
         when 3 then
          '分公司-非独核算'
         when 4 then
          'VIE公司'
         when 5 then
          '控股公司'
         when 6 then
          '参股公司'
         when 7 then
          '虚拟体系'
         when 8 then
          '组织型部门'
         when 9 then
          '项目型部门'
         when 10 then
          '小兵团'
         else
          '其他'
       end as v_organization_type,
       o.c_organization_owner,
       (select u2.v_pet_name
          from lcbase.t_zip_user u2
         where u2.c_user_id = o.c_organization_owner
           and u2.d_enddate >= sysdate
           and u2.n_status = 0) as org_ownername,
       o.c_organization_po,
       (select u3.v_pet_name
          from lcbase.t_zip_user u3
         where u3.c_user_id = o.c_organization_po
           and u3.d_enddate >= sysdate
           and u3.n_status = 0) as org_poname,
       substr(o.organization_path,3) as organization_path
  from lcbase.t_zip_user u
  join organization o
    on (u.c_organization_id = o.c_organization_id)
 where u.d_enddate >= sysdate
/

