create package PKG_USER AS

  FUNCTION Update_User(PUserInfo         IN VARCHAR2,
                       OperationUserId   IN VARCHAR2,
                       UserId            IN OUT VARCHAR2,
                       V_ORGANIZATION_ID out char,
                       ErrMsg            OUT VARCHAR2) RETURN NUMBER;

  FUNCTION Delete_User(UserId          IN VARCHAR2,
                       OperationUserId IN VARCHAR2,
                       ErrMsg          OUT VARCHAR2) RETURN NUMBER;

  FUNCTION Get_User(UserId          IN VARCHAR2,
                    OperationUserId IN VARCHAR2,
                    --       PUserInfo       OUT VARCHAR2,
                    CUR_DATA OUT SYS_REFCURSOR,
                    ErrMsg   OUT VARCHAR2) RETURN NUMBER;

  FUNCTION Login_User(UserAccount  VARCHAR2,
                      UserPassword VARCHAR2,
                      LoginType    NUMBER,
                      CUR_DATA     OUT SYS_REFCURSOR,
                      ErrMsg       OUT VARCHAR2) RETURN NUMBER;

  -- 用户重名，返回工号
  function getUserWorkNo(UserId in varchar2) RETURN VARCHAR2;

  FUNCTION OAGetUserMenu(UserID    VARCHAR2,
                         MenuType  NUMBER,
                         RE_CURSOR OUT PKG_COMMON.REF_CURSOR,
                         ErrMsg    OUT VARCHAR) RETURN NUMBER;

  /*
    判断用户手机号是否为空
  */
  function is_phones_exists(N_MOBILE in varchar2,
                            user_id  in char,
                            ErrMsg   out varchar2) RETURN NUMBER;

  function is_phones_exists2(N_MOBILE in varchar2,
                             user_id  in char,
                             ErrMsg   out varchar2) RETURN NUMBER;

  /*
   判断手机号是否存在2_insert
  */
  function is_phones_exists2_insert(N_MOBILE in varchar2,
                                    ErrMsg   out varchar2) RETURN NUMBER;

  --判断 mall 测试
  function is_EMAIL_exists(EMAIL   in varchar2,
                           user_id in char,
                           ErrMsg  out varchar2) RETURN NUMBER;

  function is_phones_exists_insert(N_MOBILE in varchar2,
                                   ErrMsg   out varchar2) RETURN NUMBER;

  --判断 mall 测试_insert
  function is_EMAIL_exists_insert(email in varchar2, ErrMsg out varchar2)
    RETURN NUMBER;
  -- 角色分配权限
  FUNCTION OASaveRoleMenuRights(RIGHT_ROLE      IN VARCHAR2,
                                MENU_LIST       IN PKG_COMMON.ARR_UID,
                                RIGHT_LIST      IN PKG_COMMON.ARR_UID,
                                OperationUserID IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) RETURN NUMBER;
end PKG_USER;

/

