create package pkg_lilin_workflow is

  -- Author  : ROCK
  -- Created : 2020/4/2 14:35:27
  -- Purpose : 
  type T_FLOW is Table OF lcoa.oa_afw_workflow_approval_flow%rowtype INDEX BY pls_integer;

  procedure Create_Next_Approval_Todo(WorkflowId in varchar2,
                                      TodoTitle  in varchar2);

  function Create_Part_Approval_Userlist(ROW_CONF       in oa_afw_workflow_config%rowtype,
                                         WorkflowId     in varchar2,
                                         WorkflowUserId in varchar2,
                                         OrganizationId in varchar2,
                                         LST            out T_FLOW)
    return number;

  procedure Create_All_Approval_Userlist(WorkflowId         in varchar2,
                                         WorkflowUserId     in varchar2,
                                         WorkflowType       in number,
                                         RangeType          in number,
                                         DaysCount          in number,
                                         Old_OrganizationId in varchar2,
                                         New_OrganizationId in varchar2);

  procedure Create_Approval_By_Id(WorkflowId   in varchar2,
                                  WorkflowType in number);

  function Update_Workflow_Leave_Office(LeaveUserwId in varchar2)
    return number;

  function Update_Workflow_Assume_Office return number;

  procedure Send_Workflow_Approval_Message(WorkflowId     in varchar2,
                                           ApprovalUserId in varchar2,
                                           WorkflowType   in number,
                                           ApprovalResult in number);

  function Approval_Target_Pass(WorkflowId     in varchar2,
                                WorkflowType   in number,
                                ApprovalUserId in varchar2,
                                ApprovalRemark in varchar2,
                                ErrMsg         out varchar2) return number;

  function Approval_Target_Reject(WorkflowId     in varchar2,
                                  WorkflowType   in number,
                                  ApprovalUserId in varchar2,
                                  ApprovalRemark in varchar2,
                                  ErrMsg         out varchar2) return number;

  function Approval_Target_Cancel(WorkflowId     in varchar2,
                                  WorkflowType   in number,
                                  WorkflowUserId in varchar2,
                                  ApprovalRemark in varchar2,
                                  ErrMsg         out varchar2) return number;
  --设置审批跳过
  --传入参数：WorkflowId 业务ID，ApprovalUserId审批人ID
  --传出参数：ErrMsg错误输出
  --返回值：0成功，非0失败
  function Approval_Target_Skip(WorkflowId     in varchar2,
                                WorkflowType   in number,
                                ApprovalUserId in varchar2,
                                ApprovalRemark in varchar2,
                                ErrMsg         out varchar2) return number;

  --清除审批跳过标识
  --传入参数：ApprovalUserId审批人ID
  --传出参数：ErrMsg错误输出
  --返回值：0成功，非0失败
  function Approval_Target_ResetSkip(ApprovalUserId in varchar2,
                                     ErrMsg         out varchar2)
    return number;
  function Get_Approval_Status_By_Id(WorkflowId in varchar2,
                                     CUR_DATA   OUT SYS_REFCURSOR,
                                     ErrMsg     out varchar2) return number;

  procedure GetTotalDays(dStartTime in Date,
                         dEndTime   in Date,
                         nDays      out number,
                         nHours     out number);

  function Get_Pre_Approval_Userlist(WorkflowUserId     in varchar2,
                                     WorkflowType       in number,
                                     WorkflowSubtype    in number,
                                     DStartTime         in varchar2,
                                     DEndTime           in varchar2,
                                     New_OrganizationId in varchar2,
                                     Days               out number,
                                     Hours              out number,
                                     CUR_DATA           out sys_refcursor,
                                     ErrMsg             out varchar2)
    return number;

end pkg_lilin_workflow;
/

