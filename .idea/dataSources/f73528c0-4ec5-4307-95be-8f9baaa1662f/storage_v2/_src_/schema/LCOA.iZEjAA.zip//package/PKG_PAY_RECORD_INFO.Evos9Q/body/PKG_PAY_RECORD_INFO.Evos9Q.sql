create package body PKG_PAY_RECORD_INFO is

 function savePayRecordInfo(datainfo        in varchar2,
                          OperationUserId IN VARCHAR2,
                          paymentId       out VARCHAR2,
                          ErrMsg          OUT VARCHAR2) return number is
    DATAARR   Pkg_Common.ARR_LONGSTR;
    id    char(32);
    userId    char(32);
    todoTitle varchar2(40);
    msgId char(32);
  begin
    DATAARR := PKG_COMMON.SPLIT(datainfo, '^');
    id  := DATAARR(1);
    userId  := DATAARR(3);
    if id is not null then
      UPDATE OA_AFW_PAYMENT_RECORD
         SET N_PAY_STATUS         = DATAARR(2),
             V_PAYMENT_FLOW_NO             = DATAARR(3),
             N_PAYMENT_AMOUNT              = DATAARR(4),
             V_PAYMENT_ACCOUNT               = DATAARR(5),
             V_PAYMENT_PURPOSE           = DATAARR(6),
             D_PAYMENT_TIME = TO_DATE(DATAARR(7), 'yyyymmddhh24miss'),
             V_PAYEE_NAME      = DATAARR(8),
             V_PAYEE_BANK     = DATAARR(9),
             V_PAYEE_SUBBRANCH       = DATAARR(10),
             V_PAYEE_ACCOUNT              = DATAARR(11),
             D_CALLBACK_TIME     = TO_DATE(DATAARR(12), 'yyyymmddhh24miss'),
             V_BANK_FLOW_NO      = DATAARR(13),
             V_FAILED_MSG       = DATAARR(14),
             C_PAY_CORP_ID       = DATAARR(15),
             C_OPERATOR_USER       = DATAARR(16),
             D_CREATE_TIME       = TO_DATE(DATAARR(17), 'yyyymmddhh24miss'),
             C_BUSINESS_ID       = DATAARR(18),
             N_WORKFLOW_TYPE       = DATAARR(19)
       WHERE C_ID = id;
       if DATAARR(2) = 2 then
         msgId := LOWER(SYS_GUID());
         insert into oa_msg_email_info
            (C_ID,
           C_DATAID,
           N_OPERATION_TYPE,
           N_MESSAGE_TYPE,
           N_TYPE,
           V_FROM_NAME,
           V_FROM_ADDR,
           V_SUBJECT,
           V_CONTENT,
           N_DEL_STATUS,
           N_SEND_STATUS,
           D_SET_SEND_DATE,
           N_SEND_ONEBYONE,
           N_ALL_USER)
           values(
           msgId,
           DATAARR(18),
           5,
           2,
           1,
          (select u.V_USER_NAME from lcbase.t_zip_user u where u.C_USER_ID = DATAARR(16) and u.D_ENDDATE > sysdate),
          (select u.V_EMAIL from lcbase.t_zip_user u where u.C_USER_ID = DATAARR(16) and u.D_ENDDATE > sysdate),
           '【借款申请】恭喜，您的借款已支付成功！',
            '恭喜，您的借款已支付成功，财务已为您汇款【'|| DATAARR(4) ||'】元，请及时查收',
            0,
            0,
           sysdate,
           1,
           1 
           );
           insert into oa_msg_recipient_addr
           (
           C_ID,
           V_RECIPIENT,
           V_SENDTOS_ADDR
           )
           values
           (
           msgId,
           (select u.V_USER_NAME from lcbase.t_zip_user u where u.C_USER_ID = DATAARR(20) and u.D_ENDDATE > sysdate),
           (select u.V_EMAIL from lcbase.t_zip_user u where u.C_USER_ID = DATAARR(20) and u.D_ENDDATE > sysdate)
           );
           update 
                oa_tdo_todo_info
           set
                N_STATUS = 1
           where
                C_TODO_DATA_ID = DATAARR(18);  
       end if;
    else
      id := LOWER(SYS_GUID());
      insert into OA_AFW_PAYMENT_RECORD
        (C_ID,
          N_PAY_STATUS,
             V_PAYMENT_FLOW_NO,
             N_PAYMENT_AMOUNT,
             V_PAYMENT_ACCOUNT,
             V_PAYMENT_PURPOSE,
             D_PAYMENT_TIME,
             V_PAYEE_NAME,
             V_PAYEE_BANK,
             V_PAYEE_SUBBRANCH,
             V_PAYEE_ACCOUNT,
             D_CALLBACK_TIME,
             V_BANK_FLOW_NO,
             V_FAILED_MSG,
             C_PAY_CORP_ID,
             C_OPERATOR_USER,
             D_CREATE_TIME,
             C_BUSINESS_ID,
             N_WORKFLOW_TYPE)
      values
        (id,
        DATAARR(2),
         DATAARR(3),
         DATAARR(4),
         DATAARR(5),
         DATAARR(6),
         to_date(DATAARR(7), 'yyyymmddhh24miss'),
          DATAARR(8),
          DATAARR(9),
          DATAARR(10),
          DATAARR(11),
          to_date(DATAARR(12), 'yyyymmddhh24miss'),
          DATAARR(13),
          DATAARR(14),
          DATAARR(15),
          DATAARR(16),
          to_date(DATAARR(17), 'yyyymmddhh24miss'),
          DATAARR(18),
          DATAARR(19));
          update
           OA_AFW_LOAN_INFO 
          set 
           C_PAYMENT_ID = id,
           N_PAYMENT_TYPE = 2
           where
            c_id = DATAARR(18);
    end if;
    commit;
     paymentId := id;
    return 0;
   
  exception
    when others then
      ErrMsg := 'savePayRecordInfo: ' || sqlcode || ',' || sqlerrm;
      raise;
      rollback;
      return - 1;
  end savePayRecordInfo;
 function updateLoanStatus(datainfo        in varchar2,
                             OperationUserId IN VARCHAR2,
                             ErrMsg          OUT VARCHAR2) return number is

   DATAARR   Pkg_Common.ARR_LONGSTR;
  begin
    DATAARR := PKG_COMMON.SPLIT(datainfo, '^');
    update
           OA_AFW_LOAN_INFO
    set
       N_APPROVAL_STATUS = DATAARR(1),
       N_PAYMENT_TYPE = DATAARR(3)
    where 
       C_ID = DATAARR(2);
  
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'updateLoanStatus: ' || sqlcode || ',' || sqlerrm;
      raise;
      rollback;
      return - 1;
 end updateLoanStatus;
end PKG_PAY_RECORD_INFO;
/

