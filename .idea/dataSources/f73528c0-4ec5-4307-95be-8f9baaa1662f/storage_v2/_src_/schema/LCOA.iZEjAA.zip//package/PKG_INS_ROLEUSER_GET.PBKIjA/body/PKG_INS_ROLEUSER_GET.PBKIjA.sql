create package body PKG_INS_ROLEUSER_GET is


  function get_roleemployees_list(OrganizationId  in varchar2,
                                  status          in varchar2,
                                  pageNum         in number,
                                  PageSize        in number,
                                  OperationUserId IN VARCHAR2,
                                  DataList        out sys_refcursor,
                                  owner           out varchar2,
                                  BpName          out varchar2,
                                  VpName          out varchar2,
                                  totalPage       out number,
                                  totalCount      out number,
                                  dataCount       out number,
                                  ErrMsg          out varchar2) return number is
    n_result        number(3);
    vSql     varchar2(10000);
    nOrganizationId varchar2(32) := 'a7260eacce5c5289e050a8c0020125b3';
    neOrganizationId varchar2(32);
  begin
    if OrganizationId is null then
      dataCount := PKG_INS_ROLEUSER_GET.getrole_dataCount(OperationUserId,
                                                          ErrMsg);
      --if dataCount = 0 then
        --return 0;
      --end if;
    else
      neOrganizationId := OrganizationId;
      dataCount       := PKG_INS_ROLEUSER_GET.get_roleCount(neOrganizationId,
                                                            OperationUserId,
                                                            ErrMsg);
      --if dataCount = 0 then
        --return 0;
      --end if;
    end if;
    vSql := 'select *
  from (select u.C_USER_ID            AS cUserId,
       u.C_ORGANIZATION_ID    AS organizationId,
       o.V_ORGANIZATION_NAME  AS organizationName,
       u.v_user_name          AS vuserName,
       u.N_USER_TYPE          AS nUserType,
       u.V_PET_NAME           AS userName,
       u.N_MOBILE_1           AS tel,
       u.N_MOBILE_2           AS nMobile2,
       u.V_TEL_1              AS vTel1,
       u.V_TEL_2              AS vTel2,
       u.N_STATUS             AS nStatus,
       u.V_EMAIL              AS email,
       u.C_PASSWORD           AS cPassword,
       u.V_WX_OPEN_ID         AS vWxOpenId,
       u.V_WORK_WX_ACCOUNT    AS vWorkWxAccount,
       u.N_SEX                AS nSex,
       u.N_AUTHORITY          AS nAuthority,
       u.N_WORK_WX_ACTIVATION AS nWorkWxActivation,
       u.v_headpic_aly        AS headpicAly,
       e.n_work_num_old       AS nworkNumOld
          from LCBASE.T_zip_user u
         inner join lcbase.t_Zip_Organization o
            on u.c_organization_id = o.c_organization_id
 inner join lcbase.t_employees_info e
    on u.c_user_id = e.c_user_id
           and u.d_enddate > sysdate
           and o.d_enddate > sysdate
         where （o.c_organization_po = ' || '''' || OperationUserId || '''' || ')
   and u.n_status = 0
   and o.c_organization_id in
       (SELECT t.c_organization_id
          FROM (SELECT c_organization_id, c_organization_parent_id, n_status
                  FROM lcbase.t_zip_organization
                 WHERE n_status = 0
                   AND D_ENDDATE > SYSDATE) t
         START WITH t.c_organization_id = ' || '''' || OrganizationId || '''' || '
        CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id
               AND t.n_status = 0)
union
select u.C_USER_ID            AS cUserId,
       u.C_ORGANIZATION_ID    AS organizationId,
       o.V_ORGANIZATION_NAME  AS organizationName,
       u.v_user_name          AS vuserName,
       u.N_USER_TYPE          AS nUserType,
       u.V_PET_NAME           AS userName,
       u.N_MOBILE_1           AS tel,
       u.N_MOBILE_2           AS nMobile2,
       u.V_TEL_1              AS vTel1,
       u.V_TEL_2              AS vTel2,
       u.N_STATUS             AS nStatus,
       u.V_EMAIL              AS email,
       u.C_PASSWORD           AS cPassword,
       u.V_WX_OPEN_ID         AS vWxOpenId,
       u.V_WORK_WX_ACCOUNT    AS vWorkWxAccount,
       u.N_SEX                AS nSex,
       u.N_AUTHORITY          AS nAuthority,
       u.N_WORK_WX_ACTIVATION AS nWorkWxActivation,
       u.v_headpic_aly        AS headpicAly,
       e.n_work_num_old       AS nworkNumOld
  from LCBASE.T_zip_user u
 inner join lcbase.t_Zip_Organization o
    on u.c_organization_id = o.c_organization_id
 inner join lcbase.t_employees_info e
    on u.c_user_id = e.c_user_id
   and u.d_enddate > sysdate
   and o.d_enddate > sysdate
 where u.n_status = 0
 and 502 in
       (select a.role_type
          from Oa_Aut_Role a
         inner join Oa_Aut_User_Role ur
            on a.c_role_id = ur.c_role_id
         where ur.c_user_id = ' || '''' || OperationUserId || '''' || ')
   and o.c_organization_id in
       (SELECT t.c_organization_id
          FROM (SELECT c_organization_id, c_organization_parent_id, n_status
                  FROM lcbase.t_zip_organization
                 WHERE n_status = 0
                   AND D_ENDDATE > SYSDATE) t
         START WITH t.c_organization_id = ' || '''' || OrganizationId || '''' || '
        CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id
               AND t.n_status = 0)
union
select u.C_USER_ID            AS cUserId,
       u.C_ORGANIZATION_ID    AS organizationId,
       o.V_ORGANIZATION_NAME  AS organizationName,
       u.v_user_name          AS vuserName,
       u.N_USER_TYPE          AS nUserType,
       u.V_PET_NAME           AS userName,
       u.N_MOBILE_1           AS tel,
       u.N_MOBILE_2           AS nMobile2,
       u.V_TEL_1              AS vTel1,
       u.V_TEL_2              AS vTel2,
       u.N_STATUS             AS nStatus,
       u.V_EMAIL              AS email,
       u.C_PASSWORD           AS cPassword,
       u.V_WX_OPEN_ID         AS vWxOpenId,
       u.V_WORK_WX_ACCOUNT    AS vWorkWxAccount,
       u.N_SEX                AS nSex,
       u.N_AUTHORITY          AS nAuthority,
       u.N_WORK_WX_ACTIVATION AS nWorkWxActivation,
       u.v_headpic_aly        AS headpicAly,
       e.n_work_num_old       AS nworkNumOld
  from LCBASE.T_zip_user u
 inner join lcbase.t_Zip_Organization o
    on u.c_organization_id = o.c_organization_id
 inner join lcbase.t_employees_info e
    on u.c_user_id = e.c_user_id
   and u.d_enddate > sysdate
   and o.d_enddate > sysdate
 where u.n_status = 0
 and 505 in
       (select a.role_type
          from Oa_Aut_Role a
         inner join Oa_Aut_User_Role ur
            on a.c_role_id = ur.c_role_id
         where ur.c_user_id = ' || '''' || OperationUserId || '''' || ')
   and o.c_organization_id in
       (

       SELECT t.c_organization_id
          FROM (SELECT c_organization_id, c_organization_parent_id, n_status
                  FROM lcbase.t_zip_organization
                 WHERE n_status = 0
                   AND D_ENDDATE > SYSDATE) t
       START WITH t.c_organization_id = ' || '''' || OrganizationId || '''' || '
        CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id
               AND t.n_status = 0
              AND T.C_ORGANIZATION_ID IN (
              SELECT t.c_organization_id
          FROM (SELECT c_organization_id, c_organization_parent_id, n_status
                  FROM lcbase.t_zip_organization
                 WHERE n_status = 0
                   AND D_ENDDATE > SYSDATE) t 
       START WITH t.c_organization_id = ' || '''' || nOrganizationId || '''' || '
        CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id
               AND t.n_status = 0)
               )
union
select u.C_USER_ID            AS cUserId,
       u.C_ORGANIZATION_ID    AS organizationId,
       o.V_ORGANIZATION_NAME  AS organizationName,
       u.v_user_name          AS vuserName,
       u.N_USER_TYPE          AS nUserType,
       u.V_PET_NAME           AS userName,
       u.N_MOBILE_1           AS tel,
       u.N_MOBILE_2           AS nMobile2,
       u.V_TEL_1              AS vTel1,
       u.V_TEL_2              AS vTel2,
       u.N_STATUS             AS nStatus,
       u.V_EMAIL              AS email,
       u.C_PASSWORD           AS cPassword,
       u.V_WX_OPEN_ID         AS vWxOpenId,
       u.V_WORK_WX_ACCOUNT    AS vWorkWxAccount,
       u.N_SEX                AS nSex,
       u.N_AUTHORITY          AS nAuthority,
       u.N_WORK_WX_ACTIVATION AS nWorkWxActivation,
       u.v_headpic_aly        AS headpicAly,
       e.n_work_num_old       AS nworkNumOld
  from LCBASE.T_zip_user u
 inner join lcbase.t_Zip_Organization o
    on u.c_organization_id = o.c_organization_id
 inner join lcbase.t_employees_info e
    on u.c_user_id = e.c_user_id
   and u.d_enddate > sysdate
   and o.d_enddate > sysdate
  where u.n_status = 0 and o.c_organization_id IN
       (SELECT t.c_organization_id
          FROM (SELECT c_organization_id,
                       c_organization_parent_id,
                       n_status,
                       V_ORGANIZATION_NAME
                  FROM lcbase.t_zip_organization
                 WHERE n_status = 0
                   AND D_ENDDATE > SYSDATE) t
         START WITH t.c_organization_id in
                    (select aip.c_organization_id
                       from lcbase.t_Zip_Organization aip
                      where (aip.c_organization_owner =
                            ' || '''' || OperationUserId || '''' || ' AND
                            aip.D_ENDDATE > SYSDATE ))
        CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id
               AND t.n_status = 0)
    and o.c_organization_id IN (SELECT t.c_organization_id
                                     FROM (SELECT c_organization_id,
                                                  c_organization_parent_id,
                                                  n_status
                                             FROM lcbase.t_zip_organization
                                            WHERE n_status = 0
                                              AND D_ENDDATE > SYSDATE) t
                                    START WITH t.c_organization_id =
                                               ' || '''' || OrganizationId || '''' || '
                                   CONNECT BY t.c_organization_parent_id = PRIOR
                                              t.c_organization_id
                                          AND t.n_status = 0)
) org';

    /*for i in 1 .. 5 loop
      dbms_output.put_line(substr(vSql, 1900 * (i - 1) + 1, 1900));
    end loop;*/
    n_result := lcoa.pkg_common.GetPagingInfo(vSql,
                                              PageSize,
                                              pageNum,
                                              DataList,
                                              totalCount,
                                              totalPage);
    if OrganizationId is not null then
      n_result := pkg_ins_employees_admin.get_obvnames(OrganizationId,
                                                       owner,
                                                       BpName,
                                                       VpName,
                                                       ErrMsg);
    end if;
    return n_result;
  exception
    when others then
      ErrMsg := 'get_roleemployees_list: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function getrole_dataCount(OperationUserId in varchar2,
                             ErrMsg          out varchar2) return number is
    countoId   number(6);
    countrole  number(6);
    countadmin number(6);
    n_result   number(6);
  begin
    n_result := PKG_INS_ROLEUSER_GET.count_adminrole(OperationUserId,
                                                     countrole,
                                                     countadmin,
                                                     ErrMsg);

    if countadmin > 0 then
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where e.n_work_place is not null
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and o.n_status = 0
         and e.n_status = 0
         AND u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id =
                          '997c2b49b01d4bdba3c5ea4e0f615617'
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id);
    elsif countrole > 0 then
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where o.n_status = 0
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id in
                          (select c_organization_id
                             from (SELECT DISTINCT *
                                     FROM (select *
                                             from (SELECT *
                                                     FROM (SELECT *
                                                             FROM lcbase.t_zip_organization
                                                            WHERE n_status = 0
                                                              AND D_ENDDATE >
                                                                  SYSDATE) t
                                                    START WITH t.c_organization_id in
                                                               (SELECT o.C_ORGANIZATION_ID
                                                                  FROM (SELECT *
                                                                          FROM lcbase.T_ZIP_ORGANIZATION o
                                                                         WHERE o.D_ENDDATE >
                                                                               SYSDATE) o
                                                                 WHERE o.C_ORGANIZATION_PO =
                                                                       OperationUserId)
                                                   CONNECT BY t.c_organization_parent_id = PRIOR
                                                              t.c_organization_id
                                                          AND t.n_status = 0
                                                   union
                                                   SELECT *
                                                     FROM (SELECT *
                                                             FROM lcbase.t_zip_organization
                                                            WHERE n_status = 0
                                                              AND D_ENDDATE >
                                                                  SYSDATE) t
                                                    START WITH t.c_organization_id in
                                                               (SELECT o.C_ORGANIZATION_ID
                                                                  FROM (SELECT *
                                                                          FROM lcbase.T_ZIP_ORGANIZATION o
                                                                         WHERE o.D_ENDDATE >
                                                                               SYSDATE) o
                                                                 WHERE o.c_organization_owner =
                                                                       OperationUserId)
                                                   CONNECT BY t.c_organization_parent_id = PRIOR
                                                              t.c_organization_id
                                                          AND t.n_status = 0) w)
                                   UNION
                                   SELECT *
                                     FROM (SELECT *
                                             FROM lcbase.t_zip_organization
                                            WHERE n_status = 0
                                              AND D_ENDDATE > SYSDATE) t
                                    START WITH t.c_organization_id =
                                               'a7260eacce5c5289e050a8c0020125b3'
                                   CONNECT BY t.c_organization_parent_id = PRIOR
                                              t.c_organization_id
                                          AND t.n_status = 0) w)
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id)
         and e.n_status = 0;
    else
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where o.n_status = 0
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id in
                          (select w.c_organization_id
                             from (select w.c_organization_id
                                     from (SELECT *
                                             FROM (SELECT *
                                                     FROM lcbase.t_zip_organization
                                                    WHERE n_status = 0
                                                      AND D_ENDDATE > SYSDATE) t
                                            START WITH t.c_organization_id in
                                                       (SELECT o.C_ORGANIZATION_ID
                                                          FROM (SELECT *
                                                                  FROM lcbase.T_ZIP_ORGANIZATION o
                                                                 WHERE o.D_ENDDATE >
                                                                       SYSDATE) o
                                                         WHERE o.C_ORGANIZATION_PO =
                                                               OperationUserId)
                                           CONNECT BY t.c_organization_parent_id = PRIOR
                                                      t.c_organization_id
                                                  AND t.n_status = 0
                                           union
                                           SELECT *
                                             FROM (SELECT *
                                                     FROM lcbase.t_zip_organization
                                                    WHERE n_status = 0
                                                      AND D_ENDDATE > SYSDATE) t
                                            START WITH t.c_organization_id in
                                                       (SELECT o.C_ORGANIZATION_ID
                                                          FROM (SELECT *
                                                                  FROM lcbase.T_ZIP_ORGANIZATION o
                                                                 WHERE o.D_ENDDATE >
                                                                       SYSDATE) o
                                                         WHERE o.c_organization_owner =
                                                               OperationUserId)
                                           CONNECT BY t.c_organization_parent_id = PRIOR
                                                      t.c_organization_id
                                                  AND t.n_status = 0) w) w)
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id)
         and e.n_status = 0;
    end if;
    return countoId;
  exception
    when others then
      ErrMsg := 'getrole_dataCount: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function get_roleCount(nOrganizationId in varchar2,
                         OperationUserId IN VARCHAR2,
                         ErrMsg          out varchar2) return number is
    countoId   number(6);
    countrole  number(6);
    countadmin number(6);
    n_result   number(6);
  begin
    n_result := PKG_INS_ROLEUSER_GET.count_adminrole(OperationUserId,
                                                     countrole,
                                                     countadmin,
                                                     ErrMsg);

    if countadmin > 0 then
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where e.n_work_place is not null
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and o.n_status = 0
         and e.n_status = 0
         AND u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id = nOrganizationId
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id);
    elsif countrole > 0 then
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where o.n_status = 0
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id in
            (select c_organization_id
               from (SELECT DISTINCT *
                       FROM (select *
                               from (SELECT *
                                       FROM (SELECT *
                                               FROM lcbase.t_zip_organization
                                              WHERE n_status = 0
                                                AND D_ENDDATE >
                                                    SYSDATE) t
                                      START WITH t.c_organization_id in
                                                 (SELECT o.C_ORGANIZATION_ID
                                                    FROM (SELECT *
                                                            FROM lcbase.T_ZIP_ORGANIZATION o
                                                           WHERE o.D_ENDDATE >
                                                                 SYSDATE) o
                                                   WHERE o.C_ORGANIZATION_PO =
                                                         OperationUserId)
                                     CONNECT BY t.c_organization_parent_id = PRIOR
                                                t.c_organization_id
                                            AND t.n_status = 0
                                     union
                                     SELECT *
                                       FROM (SELECT *
                                               FROM lcbase.t_zip_organization
                                              WHERE n_status = 0
                                                AND D_ENDDATE >
                                                    SYSDATE) t
                                      START WITH t.c_organization_id in
                                                 (SELECT o.C_ORGANIZATION_ID
                                                    FROM (SELECT *
                                                            FROM lcbase.T_ZIP_ORGANIZATION o
                                                           WHERE o.D_ENDDATE >
                                                                 SYSDATE) o
                                                   WHERE (o.c_organization_owner = OperationUserId
                                                    AND o.D_ENDDATE > SYSDATE
                                                    and o.c_organization_id IN
                                                        (SELECT t.c_organization_id
                                                           FROM (SELECT c_organization_id,
                                                                        c_organization_parent_id,
                                                                        n_status
                                                                   FROM lcbase.t_zip_organization
                                                                  WHERE n_status = 0
                                                                    AND D_ENDDATE > SYSDATE) t
                                                          START WITH t.c_organization_id = nOrganizationId
                                                         CONNECT BY t.c_organization_parent_id = PRIOR
                                                                    t.c_organization_id
                                                                AND t.n_status = 0)))
                                     CONNECT BY t.c_organization_parent_id = PRIOR
                                                t.c_organization_id
                                            AND t.n_status = 0) w)
                                   UNION
                                   SELECT *
                                     FROM (SELECT *
                                             FROM lcbase.t_zip_organization
                                            WHERE n_status = 0
                                              AND D_ENDDATE > SYSDATE) t
                                    START WITH t.c_organization_id =
                                               'a7260eacce5c5289e050a8c0020125b3'
                                   CONNECT BY t.c_organization_parent_id = PRIOR
                                              t.c_organization_id
                                          AND t.n_status = 0) w)
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id)
         and e.n_status = 0;
    else
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where o.n_status = 0
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id in
                          (select w.c_organization_id
                             from (select w.c_organization_id
                                     from (SELECT *
                                             FROM (SELECT *
                                                     FROM lcbase.t_zip_organization
                                                    WHERE n_status = 0
                                                      AND D_ENDDATE > SYSDATE) t
                                            START WITH t.c_organization_id in
                                                       (SELECT o.C_ORGANIZATION_ID
                                                          FROM (SELECT *
                                                                  FROM lcbase.T_ZIP_ORGANIZATION o
                                                                 WHERE o.D_ENDDATE >
                                                                       SYSDATE) o
                                                         WHERE o.C_ORGANIZATION_PO =
                                                               OperationUserId)
                                           CONNECT BY t.c_organization_parent_id = PRIOR
                                                      t.c_organization_id
                                                  AND t.n_status = 0
                                           union
                                           SELECT *
                                             FROM (SELECT *
                                                     FROM lcbase.t_zip_organization
                                                    WHERE n_status = 0
                                                      AND D_ENDDATE > SYSDATE) t
                                            START WITH t.c_organization_id in
                                                       (SELECT o.C_ORGANIZATION_ID
                                                          FROM (SELECT *
                                                                  FROM lcbase.T_ZIP_ORGANIZATION o
                                                                 WHERE o.D_ENDDATE >
                                                                       SYSDATE) o
                                                         WHERE (o.c_organization_owner = OperationUserId
                      	AND o.D_ENDDATE > SYSDATE
                      	and o.c_organization_id IN
                            (SELECT t.c_organization_id
                               FROM (SELECT c_organization_id,
                                            c_organization_parent_id,
                                            n_status
                                       FROM lcbase.t_zip_organization
                                      WHERE n_status = 0
                                        AND D_ENDDATE > SYSDATE) t
                              START WITH t.c_organization_id = nOrganizationId
                             CONNECT BY t.c_organization_parent_id = PRIOR
                                        t.c_organization_id
                                    AND t.n_status = 0)))
                                           CONNECT BY t.c_organization_parent_id = PRIOR
                                                      t.c_organization_id
                                                  AND t.n_status = 0) w) w)
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id)
         and e.n_status = 0;
    end if;
    return countoId;
  exception
    when others then
      ErrMsg := 'get_roleCount: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function count_adminrole(OperationUserId IN VARCHAR2,
                           countrole       out number,
                           countadmin      out number,
                           ErrMsg          out varchar2) return number is
  begin
    SELECT count(*)
      into countrole
      FROM lcoa.OA_AUT_ROLE r
      LEFT JOIN lcoa.OA_AUT_USER_ROLE ur
        ON r.C_ROLE_ID = ur.C_ROLE_ID
     WHERE r.ROLE_TYPE = '505'
       and ur.c_user_id = OperationUserId;
    SELECT count(*)
      into countadmin
      FROM lcoa.OA_AUT_ROLE r
      LEFT JOIN lcoa.OA_AUT_USER_ROLE ur
        ON r.C_ROLE_ID = ur.C_ROLE_ID
     WHERE r.ROLE_TYPE = '502'
       and ur.c_user_id = OperationUserId;
    return 0;
  exception
    when others then
      ErrMsg := 'count_adminrole: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

end;

/

