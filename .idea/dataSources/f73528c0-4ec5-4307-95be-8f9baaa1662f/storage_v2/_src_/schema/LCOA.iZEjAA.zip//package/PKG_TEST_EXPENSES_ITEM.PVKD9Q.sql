create package PKG_TEST_Expenses_Item is
  --报销新增
  FUNCTION Insert_Expenses_Info(DataInfo        in varchar2,
                                DataItemInfo    in ARR_LONGSTR, --报销明细表
                                ArrFile         in ARR_LONGSTR,
                                OperationUserId in varchar2,
                                DataId          out varchar2,
                                ErrMsg          out varchar2) return number;
  --报销单明细录入                                
  function Insert_Expenses_Item(DataInfo   in varchar2,
                                ExpensesId in varchar2,
                                DataId     out varchar2,
                                ErrMsg     out varchar2) return number;

  --修改
  function Update_Expense_Info(DataInfo        in TYPE_EXPENSES_list,
                               DataItemInfo    in type_expenses_item_list,
                               OperationUserId in varchar2,
                               ErrMsg          out varchar2) return number;

end PKG_TEST_Expenses_Item;
/

