create package body PKG_EXT_AFW_USERAPPLY is

  -- Private type declarations
  --type <TypeName> is <Datatype>;

  -- Private constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Private variable declarations
  --<VariableName> <Datatype>;
  i number(1);

  function Insert_Leave_Info(DataInfo        in varchar2,
                             ArrFile         in ARR_LONGSTR,
                             OperationUserId in varchar2,
                             DataId          out varchar2,
                             ErrMsg          out varchar2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  begin
    time_start := systimestamp;
    begin
      n_optype := 2;
      n_result := lcoa.pkg_user_schedule.Insert_Leave_Info(DataInfo,
                                                      ArrFile,
                                                      OperationUserId,
                                                      DataId,
                                                      ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := 'Insert_Leave_Info: ' || pkg_common.g_errcode_exception || ',' ||
                    SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Insert_Leave_Info',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function Update_Schedule_Info(DataInfo        IN VARCHAR2,
                                ArrAttendee     in ARR_LONGSTR,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  begin
    time_start := systimestamp;
    begin
      n_optype := 2;
      n_result := lcoa.pkg_ins_sde_schedule.Update_Schedule_Info(DataInfo,
                                                                  ArrAttendee,
                                                                  OperationUserId,
                                                                  ErrMsg);
      commit;                                                                  
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := 'Update_Schedule_Info: ' ||
                    pkg_common.g_errcode_exception || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'Update_Schedule_Info',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  --此块进行变量初始化，可删除
begin
  -- Initialization
  i := 1;
end PKG_EXT_AFW_USERAPPLY;
/

