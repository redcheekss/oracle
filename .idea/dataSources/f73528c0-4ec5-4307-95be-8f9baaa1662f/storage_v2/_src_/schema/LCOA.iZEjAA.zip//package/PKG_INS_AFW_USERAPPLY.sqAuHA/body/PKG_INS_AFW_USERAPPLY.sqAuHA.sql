create package body PKG_INS_AFW_USERAPPLY is

  -- Private type declarations
  --type <TypeName> is <Datatype>;

  -- Private constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Private variable declarations
  --<VariableName> <Datatype>;
  i number(1);
  --获取业务当前状态
  --针对(-1撤回0待审批1审批中2审批完成3已拒绝) 0/1属于可审批通过状态，其他状态不予审批通过
  --下同
  procedure GetLeaveAfwStatusById(WorkflowId in varchar2,
                                  AfwStatus  out number,
                                  OperType   in number) is
    StartTime date;
    CurStatus number;
  begin
    case
      when OperType = 0 then
        select case
                 when n_status in (0, 1) then
                  0
                 else
                  n_status
               end
          into AfwStatus
          from oa_afw_leave_info t
         where t.c_leave_id = WorkflowId;
      when OperType = 1 then
        select t.d_leave_start_time, t.n_status
          into StartTime, CurStatus
          from lcoa.oa_afw_leave_info t
         where t.c_leave_id = WorkflowId;
      
        --撤回时间大于开始时间时，不允许撤回 
        --已完成状态，不允许撤回
        if StartTime < sysdate and CurStatus = 2 then
          raise PKG_COMMON.EXP_CHECK;
        elsif CurStatus = -1 then
          raise PKG_COMMON.EXP_CHECK;
        elsif CurStatus = 2 then
          raise PKG_COMMON.EXP_PARAM;
        end if;
    end case;
  end;
  procedure GetEgressAfwStatusById(WorkflowId in varchar2,
                                   AfwStatus  out number,
                                   OperType   in number) is
    StartTime date;
    CurStatus number;
  begin
    case
      when OperType = 0 then
        select case
                 when n_status in (0, 1) then
                  0
                 else
                  n_status
               end
          into AfwStatus
          from oa_afw_egress_info t
         where t.c_egress_id = WorkflowId;
      when OperType = 1 then
        select t.d_egress_start_time, t.n_status
          into StartTime, CurStatus
          from lcoa.oa_afw_egress_info t
         where t.c_egress_id = WorkflowId;
      
        --撤回时间大于开始时间时，不允许撤回 
        --已完成状态，不允许撤回
        if StartTime < sysdate and CurStatus = 2 then
          raise PKG_COMMON.EXP_CHECK;
        elsif CurStatus = -1 then
          raise PKG_COMMON.EXP_CHECK;
        elsif CurStatus = 2 then
          raise PKG_COMMON.EXP_PARAM;
        end if;
    end case;
  end;
  procedure GetPublishAfwStatusById(WorkflowId in varchar2,
                                    AfwStatus  out number,
                                    OperType   in number) is
    CurStatus number;
  begin
    case
      when OperType = 0 then
        select case
                 when n_status in (0, 1) then
                  0
                 else
                  n_status
               end
          into AfwStatus
          from oa_msg_publish_info t
         where t.c_news_id = WorkflowId;
      when OperType = 1 then
        select t.n_status
          into CurStatus
          from lcoa.oa_msg_publish_info t
         where t.c_news_id = WorkflowId;
      
        --已完成状态，不允许撤回
        if CurStatus = -1 then
          raise PKG_COMMON.EXP_CHECK;
        elsif CurStatus = 2 then
          raise PKG_COMMON.EXP_PARAM;
        end if;
    end case;
  end;
  procedure GetExpensesAfwStatusById(WorkflowId in varchar2,
                                     AfwStatus  out number,
                                     OperType   in number) is
    StartTime date;
    CurStatus number;
  begin
    case
      when OperType = 0 then
        select case
                 when n_status in (0, 1) then
                  0
                 else
                  n_status
               end
          into AfwStatus
          from oa_eps_expenses_info t
         where t.c_expenses_id = WorkflowId;
      when OperType = 1 then
        select t.n_status
          into CurStatus
          from lcoa.oa_eps_expenses_info t
         where t.c_expenses_id = WorkflowId;
      
        --撤回时间大于开始时间时，不允许撤回 
        --已完成状态，不允许撤回
        if CurStatus = 2 then
          raise PKG_COMMON.EXP_CHECK;
        elsif CurStatus = -1 then
          raise PKG_COMMON.EXP_CHECK;
        end if;
    end case;
  end;
  -- 获取借款审批状态 0待审批 1审批中 4财务审批中 5 支付成功
  procedure GetLoanAfwStatusById(WorkflowId in varchar2,
                                 AfwStatus  out number,
                                 OperType   in number) is
    StartTime date;
    CurStatus number;
  begin
    case
      when OperType = 0 then
        select case
                 when n_approval_status in (0, 1, 4) then
                  0
                 else
                  n_status
               end
          into AfwStatus
          from oa_afw_loan_info t
         where t.c_id = WorkflowId;
      when OperType = 1 then
        select t.n_approval_status
          into AfwStatus
          from lcoa.oa_afw_loan_info t
         where t.c_id = WorkflowId;
      
        --撤回时间大于开始时间时，不允许撤回 
        --已完成状态，不允许撤回
        if AfwStatus = 2 then
          raise PKG_COMMON.EXP_CHECK;
        elsif AfwStatus = -1 then
          raise PKG_COMMON.EXP_CHECK;
        end if;
    end case;
  end;
  -- 获取借款审批状态 0待审批 1审批中 
  procedure GetExtensionAfwStatusById(WorkflowId in varchar2,
                                      AfwStatus  out number,
                                      OperType   in number) is
    StartTime date;
    CurStatus number;
  begin
    case
      when OperType = 0 then
        select case
                 when n_approval_status in (0, 1) then
                  0
                 else
                  n_status
               end
          into AfwStatus
          from oa_afw_loan_extension t
         where t.c_id = WorkflowId;
      when OperType = 1 then
        select t.n_approval_status
          into AfwStatus
          from lcoa.oa_afw_loan_extension t
         where t.c_id = WorkflowId;
      
        --撤回时间大于开始时间时，不允许撤回 
        --已完成状态，不允许撤回
        if AfwStatus = 2 then
          raise PKG_COMMON.EXP_CHECK;
        elsif AfwStatus = -1 then
          raise PKG_COMMON.EXP_CHECK;
        end if;
    end case;
  end;

  -- 状态（0:已申请(待审批);1:审批中;2:已通过;3：待分发；4：处理中；5：处理完成-1:已驳回；-2：撤回）
  procedure GetDMDAfwStatusById(WorkflowId in varchar2,
                                AfwStatus  out number,
                                OperType   in number) is
    StartTime date;
    CurStatus number;
  begin
    case
      when OperType = 0 then
        select case
                 when n_status in (0, 1) then
                  0
                 else
                  n_status
               end
          into AfwStatus
          from oa_afw_dmd_apply t
         where t.c_datamodify_apply_id = WorkflowId;
      when OperType = 1 then
        select t.n_status
          into AfwStatus
          from lcoa.oa_afw_dmd_apply t
         where t.c_datamodify_apply_id = WorkflowId;
      
        --撤回时间大于开始时间时，不允许撤回 
        --已完成状态，不允许撤回
        if AfwStatus = 2 then
          raise PKG_COMMON.EXP_CHECK;
        elsif AfwStatus = -1 then
          raise PKG_COMMON.EXP_CHECK;
        end if;
    end case;
  end;
  procedure GetPromotionAfwStatusById(WorkflowId in varchar2,
                                      AfwStatus  out number,
                                      OperType   in number) is
    StartTime date;
    CurStatus number;
  begin
    case
      when OperType = 0 then
        select case
                 when n_status in (0, 1) then
                  0
                 else
                  n_status
               end
          into AfwStatus
          from lcoa.oa_afw_promotion_info t
         where t.c_promotion_id = WorkflowId;
      when OperType = 1 then
        select t.n_status
          into CurStatus
          from lcoa.oa_afw_promotion_info t
         where t.c_promotion_id = WorkflowId;
      
        --只有待审批状态，才允许撤回；其他状态都不允许撤回了 
        if CurStatus <> 0 then
          raise PKG_COMMON.EXP_CHECK;
        elsif CurStatus = -1 then
          raise PKG_COMMON.EXP_CHECK;
        end if;
    end case;
  end;
  procedure GetAdjustpostAfwStatusById(WorkflowId in varchar2,
                                       AfwStatus  out number,
                                       OperType   in number) is
    CurStatus number;
  begin
    case
      when OperType = 0 then
        select case
                 when n_status in (0, 1) then
                  0
                 else
                  n_status
               end
          into AfwStatus
          from lcoa.oa_afw_adjustpost_info t
         where t.c_adjust_id = WorkflowId;
      when OperType = 1 then
        select t.n_status
          into CurStatus
          from lcoa.oa_afw_adjustpost_info t
         where t.c_adjust_id = WorkflowId;
      
        --只有待审批状态，才允许撤回；其他状态都不允许撤回了 
        --added by lihuawei at 2020.5.27
        if CurStatus <> 0 then
          raise PKG_COMMON.EXP_CHECK;
        elsif CurStatus = -1 then
          raise PKG_COMMON.EXP_CHECK;
        end if;
    end case;
  end;
  procedure SetLeaveAfwStatusById(WorkflowId in varchar2,
                                  AfwStatus  in number) is
  begin
    update oa_afw_leave_info t
       set t.n_status = AfwStatus
     where t.c_leave_id = WorkflowId;
  end;
  -- 借款审批单状态
  procedure SetLoanAfwStatusById(WorkflowId    in varchar2,
                                 AfwStatus     in number,
                                 ApprovalOrder number) is
  begin
    -- order=3为财务:费用会计 order=7为财务：出纳
    if ApprovalOrder > 2 and AfwStatus = 3 then
      if ApprovalOrder = 7 then
        -- 财务出纳 ,更新费用会计状态
        update oa_afw_workflow_approval_flow a
           set a.n_approval_status = 0
         where a.c_workflow_id = WorkflowId
           and a.n_approval_order in (3, 7);
      
      else
        -- 财务其他
        update oa_afw_workflow_approval_flow a
           set a.n_approval_status = 0
         where a.c_workflow_id = WorkflowId
           and a.n_approval_order >= 3;
      
      end if;
      -- 财务审批中
      update oa_afw_loan_info t
         set t.n_approval_status = 4
       where t.c_id = WorkflowId;
    else
      update oa_afw_loan_info t
         set t.n_approval_status = AfwStatus
       where t.c_id = WorkflowId;
    end if;
  end;

  -- 数据修改审批单状态
  procedure SetDMDAfwStatusById(WorkflowId in varchar2,
                                AfwStatus  in number) is
  begin
    -- AfwStatus 
    update oa_afw_dmd_apply t
       set t.n_status = AfwStatus
     where t.c_datamodify_apply_id = WorkflowId;
  end;
  -- 延期还款审批单状态
  procedure SetExtensionAfwStatusById(WorkflowId in varchar2,
                                      AfwStatus  in number) is
  begin
    -- AfwStatus 
    update oa_afw_loan_extension t
       set t.n_approval_status = AfwStatus
     where t.c_id = WorkflowId;
  end;

  procedure SetEgressAfwStatusById(WorkflowId in varchar2,
                                   AfwStatus  in number) is
  begin
    update oa_afw_egress_info t
       set t.n_status = AfwStatus
     where t.c_egress_id = WorkflowId;
  end;
  procedure SetPublishAfwStatusById(WorkflowId in varchar2,
                                    AfwStatus  in number) is
  begin
    update oa_msg_publish_info t
       set t.n_status = AfwStatus
     where t.c_news_id = WorkflowId;
  end;
  procedure SetExpensesAfwStatusById(WorkflowId in varchar2,
                                     AfwStatus  in number) is
  begin
    update oa_eps_expenses_info t
       set t.n_status = AfwStatus
     where t.c_expenses_id = WorkflowId;
  end;
  procedure SetPromotionAfwStatusById(WorkflowId in varchar2,
                                      AfwStatus  in number) is
  begin
    update lcoa.oa_afw_promotion_info t
       set t.n_status = AfwStatus
     where t.c_promotion_id = WorkflowId;
  end;
  procedure SetAdjustpostAfwStatusById(WorkflowId in varchar2,
                                       AfwStatus  in number) is
  begin
    update lcoa.oa_afw_adjustpost_info t
       set t.n_status = AfwStatus
     where t.c_adjust_id = WorkflowId;
  end;

  procedure FormAfwResultMessage(ApprovalUserId in varchar2,
                                 AfwStatus      in number,
                                 ApprovalResult out varchar2) is
    v_ApprovalResult   varchar2(100);
    v_ApprovalUserName varchar2(50);
  begin
    select u.v_pet_name
      into v_ApprovalUserName
      from lcbase.t_zip_user u
     where u.c_user_id = ApprovalUserId
       and u.d_enddate > sysdate;
  
    v_ApprovalResult := case
                          when AfwStatus = 1 then
                           v_ApprovalUserName || '已经通过你的'
                          when AfwStatus = 2 then
                           v_ApprovalUserName || '已经延期你的'
                          when AfwStatus = -1 then
                           v_ApprovalUserName || '已驳回你的'
                          when AfwStatus = -2 then
                           v_ApprovalUserName || '已撤回了'
                          else
                           '正在处理你的'
                        end;
    ApprovalResult   := v_ApprovalResult;
  end;

  procedure FormLeaveTodoTitleById(WorkflowId in varchar2,
                                   TodoTitle  out varchar2) is
  begin
    -- 匹配请假申请人名字
    SELECT CONCAT(tu.v_pet_name, '的请假申请')
      INTO TodoTitle
      FROM oa_afw_leave_info t
      LEFT JOIN lcbase.t_zip_user tu
        ON tu.c_user_id = t.c_leave_user_id
     WHERE t.c_leave_id = WorkflowId
       and tu.d_enddate > sysdate;
  end;
  --借款
  procedure FormLoanTodoTitleById(WorkflowId in varchar2,
                                  TodoTitle  out varchar2) is
  begin
    -- 匹配请假申请人名字
    SELECT CONCAT(tu.v_pet_name, '的借款申请')
      INTO TodoTitle
      FROM oa_afw_loan_info t
      LEFT JOIN lcbase.t_zip_user tu
        ON tu.c_user_id = t.c_user_id
     WHERE t.c_id = WorkflowId
       and tu.d_enddate > sysdate;
  end;

  -- 延期还款
  procedure FormExtensionTodoTitleById(WorkflowId in varchar2,
                                       TodoTitle  out varchar2) is
  begin
    -- 匹配请假申请人名字
    SELECT CONCAT(tu.v_pet_name, '的延期还款申请')
      INTO TodoTitle
      FROM oa_afw_loan_extension t
      LEFT JOIN lcbase.t_zip_user tu
        ON tu.c_user_id = t.c_user_id
     WHERE t.c_id = WorkflowId
       and tu.d_enddate > sysdate;
  end;

  procedure FormDMDTodoTitleById(WorkflowId in varchar2,
                                 TodoTitle  out varchar2) is
  begin
    -- 匹配数据修改申请人名字
    SELECT CONCAT(tu.v_pet_name, '的数据修改申请')
      INTO TodoTitle
      FROM LCOA.OA_AFW_DMD_APPLY oaei
      LEFT JOIN LCBASE.T_ZIP_USER tu
        ON oaei.c_input_user_id = tu.C_USER_ID
     WHERE OAEI.C_DATAMODIFY_APPLY_ID = WorkflowId
       and tu.d_enddate > sysdate;
  end;

  procedure FormEgressTodoTitleById(WorkflowId in varchar2,
                                    TodoTitle  out varchar2) is
  begin
    -- 匹配外出申请人名字
    SELECT CONCAT(tu.v_pet_name, '的外出申请')
      INTO TodoTitle
      FROM LCOA.OA_AFW_EGRESS_INFO oaei
      LEFT JOIN LCBASE.T_ZIP_USER tu
        ON oaei.C_EGRESS_USER_ID = tu.C_USER_ID
     WHERE OAEI.C_EGRESS_ID = WorkflowId
       and tu.d_enddate > sysdate;
  end;
  procedure FormPublishTodoTitleById(WorkflowId in varchar2,
                                     TodoTitle  out varchar2) is
  begin
    -- 匹配公告申请人名字
    SELECT CONCAT(tu.v_pet_name, '的公告申请')
      INTO TodoTitle
      FROM LCOA.oa_msg_publish_info oaei
      LEFT JOIN LCBASE.T_ZIP_USER tu
        ON oaei.C_INPUT_USER_ID = tu.C_USER_ID
     WHERE OAEI.C_NEWS_ID = WorkflowId
       and tu.d_enddate > sysdate;
  end;
  procedure FormExpensesTodoTitleById(WorkflowId in varchar2,
                                      TodoTitle  out varchar2) is
  begin
    -- 匹配报销申请人名字
    SELECT CONCAT(tu.v_pet_name, '的报销申请')
      INTO TodoTitle
      FROM LCOA.oa_eps_expenses_info oaei
      LEFT JOIN LCBASE.T_ZIP_USER tu
        ON oaei.C_EXPENSES_USER_ID = tu.C_USER_ID
     WHERE OAEI.C_EXPENSES_ID = WorkflowId
       and tu.d_enddate > sysdate;
  end;
  procedure FormPromotionTodoTitleById(WorkflowId in varchar2,
                                       TodoTitle  out varchar2) is
  begin
    -- 匹配转正申请人名字
    SELECT CONCAT(tu.v_pet_name, '的转正申请')
      INTO TodoTitle
      FROM lcoa.oa_afw_promotion_info t
      LEFT JOIN lcbase.t_zip_user tu
        ON tu.c_user_id = t.c_promotion_user_id
     WHERE t.c_promotion_id = WorkflowId
       and tu.d_enddate > sysdate;
  end;
  procedure CreateLeaveAfwMsgById(WorkflowId     in varchar2,
                                  ApprovalUserId in varchar2,
                                  AfwStatus      in number,
                                  MsgSender_Cur  out sys_refcursor) is
    v_ApprovalResult varchar2(100);
  begin
    FormAfwResultMessage(ApprovalUserId, AfwStatus, v_ApprovalResult);
    insert into oa_msg_message_info
      (c_msg_id,
       n_msg_type,
       n_istop_flag,
       v_msg_title,
       d_msg_time,
       n_read_flag,
       c_msg_user_id,
       c_msg_src,
       v_msg_content,
       v_msg_sender,
       d_update_time,
       n_enable)
      select lower(sys_guid()),
             1,
             0,
             v_ApprovalResult || '请假申请',
             sysdate,
             0,
             t.c_leave_user_id,
             WorkflowId,
             u.v_pet_name || '的' || decode(t.n_leave_type,
                                           1,
                                           '事假',
                                           2,
                                           '病假',
                                           3,
                                           '调休',
                                           4,
                                           '年假',
                                           5,
                                           '产假',
                                           6,
                                           '哺乳假',
                                           7,
                                           '婚假',
                                           8,
                                           '丧假',
                                           9,
                                           '陪产假',
                                           10,
                                           '产检假',
                                           '其它请假') || case
               when t.n_leave_days > 0 then
                t.n_leave_days || '天'
               else
                null
             end || case
               when t.n_leave_hours > 0 then
                t.n_leave_hours || '小时'
               else
                null
             end || '【' ||
             to_char(t.d_leave_start_time, 'yyyy-MM-dd HH24:mi am') || '至' ||
             to_char(t.d_leave_end_time, 'yyyy-MM-dd HH24:mi am') || '】',
             '系统',
             sysdate,
             1
        from oa_afw_leave_info t
        left join lcbase.t_zip_user u
          on u.c_user_id = t.c_leave_user_id
       where t.c_leave_id = WorkflowId
         and u.d_enddate > sysdate;
  
    open MsgSender_Cur for
      select t.c_leave_user_id
        from oa_afw_leave_info t
       where t.c_leave_id = WorkflowId;
  end;
  -- 借款
  procedure CreateLoanAfwMsgById(WorkflowId     in varchar2,
                                 ApprovalUserId in varchar2,
                                 AfwStatus      in number,
                                 ApprovalOrder  in number,
                                 MsgSender_Cur  out sys_refcursor) is
    v_ApprovalResult varchar2(100);
    v_title          varchar2(100);
    v_content        varchar2(400);
  begin
    -- 财务内部驳回，不给申请人发消息
    if ApprovalOrder > 2 and AfwStatus = -1 then
      null;
    
    else
      if ApprovalOrder = 7 then
        -- 出纳通过即支付成功
        v_title := '您的借款已成功支付';
      else
        FormAfwResultMessage(ApprovalUserId, AfwStatus, v_ApprovalResult);
        v_title := v_ApprovalResult || '借款申请';
      end if;
    
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               5,
               0,
               v_title,
               sysdate,
               0,
               t.c_user_id,
               WorkflowId,
               u.v_pet_name || '的借款',
               '系统',
               sysdate,
               1
          from oa_afw_loan_info t
          left join lcbase.t_zip_user u
            on u.c_user_id = t.c_user_id
         where t.c_id = WorkflowId
           and u.d_enddate > sysdate;
    end if;
    open MsgSender_Cur for
      select t.c_leave_user_id
        from oa_afw_leave_info t
       where t.c_leave_id = WorkflowId;
  end;

  -- 数据修改
  procedure CreateDMDAfwMsgById(WorkflowId     in varchar2,
                                ApprovalUserId in varchar2,
                                AfwStatus      in number,
                                MsgSender_Cur  out sys_refcursor) is
    v_ApprovalResult varchar2(100);
  begin
    -- 财务内部驳回，不给申请人发消息
  
    FormAfwResultMessage(ApprovalUserId, AfwStatus, v_ApprovalResult);
    insert into oa_msg_message_info
      (c_msg_id,
       n_msg_type,
       n_istop_flag,
       v_msg_title,
       d_msg_time,
       n_read_flag,
       c_msg_user_id,
       c_msg_src,
       v_msg_content,
       v_msg_sender,
       d_update_time,
       n_enable)
      select lower(sys_guid()),
             16,
             0,
             v_ApprovalResult || '数据修改申请',
             sysdate,
             0,
             t.c_input_user_id,
             WorkflowId,
             u.v_pet_name || '的数据修改',
             '系统',
             sysdate,
             1
        from oa_afw_dmd_apply t
        left join lcbase.t_zip_user u
          on u.c_user_id = t.c_input_user_id
       where t.c_datamodify_apply_id = WorkflowId
         and u.d_enddate > sysdate;
  
    open MsgSender_Cur for
      select t.c_input_user_id
        from oa_afw_dmd_apply t
       where t.c_datamodify_apply_id = WorkflowId;
  end;

  -- 延期还款
  procedure CreateExtensionAfwMsgById(WorkflowId     in varchar2,
                                      ApprovalUserId in varchar2,
                                      AfwStatus      in number,
                                      MsgSender_Cur  out sys_refcursor) is
    v_ApprovalResult varchar2(100);
  begin
    FormAfwResultMessage(ApprovalUserId, AfwStatus, v_ApprovalResult);
    insert into oa_msg_message_info
      (c_msg_id,
       n_msg_type,
       n_istop_flag,
       v_msg_title,
       d_msg_time,
       n_read_flag,
       c_msg_user_id,
       c_msg_src,
       v_msg_content,
       v_msg_sender,
       d_update_time,
       n_enable)
      select lower(sys_guid()),
             7,
             0,
             v_ApprovalResult || '延期还款申请',
             sysdate,
             0,
             t.c_user_id,
             WorkflowId,
             u.v_pet_name || '的延期还款',
             '系统',
             sysdate,
             1
        from oa_afw_loan_extension t
        left join lcbase.t_zip_user u
          on u.c_user_id = t.c_user_id
       where t.c_id = WorkflowId
         and u.d_enddate > sysdate;
  
    open MsgSender_Cur for
      select t.c_user_id
        from oa_afw_loan_extension t
       where t.c_id = WorkflowId;
  end;

  procedure CreateEgressAfwMsgById(WorkflowId     in varchar2,
                                   ApprovalUserId in varchar2,
                                   AfwStatus      in number,
                                   MsgSender_Cur  out sys_refcursor) is
    v_ApprovalResult varchar2(100);
  begin
    FormAfwResultMessage(ApprovalUserId, AfwStatus, v_ApprovalResult);
    insert into oa_msg_message_info
      (c_msg_id,
       n_msg_type,
       n_istop_flag,
       v_msg_title,
       d_msg_time,
       n_read_flag,
       c_msg_user_id,
       c_msg_src,
       v_msg_content,
       v_msg_sender,
       d_update_time,
       n_enable)
      select lower(sys_guid()),
             2,
             0,
             v_ApprovalResult || '外出申请',
             sysdate,
             0,
             t.c_egress_user_id,
             WorkflowId,
             u.v_pet_name || '的' ||
              decode(t.n_egress_type, 1, '市内外出', 2, '出差', '其它外出') || case
                when t.n_egress_days > 0 then
                 t.n_egress_days || '天'
                else
                 null
              end || case
                when t.n_egress_hours > 0 then
                 t.n_egress_hours || '小时'
                else
                 null
              end
             --to_char(t.n_egress_days, '90D90') 
              || '【' ||
              to_char(t.d_egress_start_time, 'yyyy-MM-dd HH24:mi am') || '至' ||
              to_char(t.d_egress_end_time, 'yyyy-MM-dd HH24:mi am') || '】',
             '系统',
             sysdate,
             1
        from oa_afw_egress_info t
        left join lcbase.t_zip_user u
          on u.c_user_id = t.c_egress_user_id
       where t.c_egress_id = WorkflowId
         and u.d_enddate > sysdate;
  
    open MsgSender_Cur for
      select t.c_egress_user_id
        from oa_afw_egress_info t
       where t.c_egress_id = WorkflowId;
  end;
  procedure CreatePublishAfwMsgById(WorkflowId      in varchar2,
                                    ApprovalUserId  in varchar2,
                                    AfwStatus       in number,
                                    MsgRange        in number,
                                    MsgSender_Cur   out sys_refcursor,
                                    IsAll_MsgSender out number) is
    v_ApprovalResult varchar2(100);
    P_RANGE          number(1);
    v_sql            varchar2(2000);
  begin
    FormAfwResultMessage(ApprovalUserId, AfwStatus, v_ApprovalResult);
    IsAll_MsgSender := 0;
    v_sql           := 'select t.c_input_user_id userid from lcoa.oa_msg_publish_info t where t.c_news_id = ''' ||
                       WorkflowId || '''';
    insert into oa_msg_message_info
      (c_msg_id,
       n_msg_type,
       n_istop_flag,
       v_msg_title,
       d_msg_time,
       n_read_flag,
       c_msg_user_id,
       c_msg_src,
       v_msg_content,
       v_msg_sender,
       d_update_time,
       n_enable)
      select lower(sys_guid()),
             3,
             0,
             v_ApprovalResult || '【' || t.v_news_title || '】公告',
             sysdate,
             0,
             t.c_input_user_id,
             WorkflowId,
             t.v_input_user_name || '发布的公告',
             '系统',
             sysdate,
             1
        from lcoa.oa_msg_publish_info t
       where t.c_news_id = WorkflowId;
    IF MsgRange = 2 THEN
      select t.n_news_range
        into P_RANGE
        from lcoa.oa_msg_publish_info t
       where t.c_news_id = WorkflowId;
    
      if P_RANGE = 1 then
        insert into oa_msg_message_info
          (c_msg_id,
           n_msg_type,
           n_istop_flag,
           v_msg_title,
           d_msg_time,
           n_read_flag,
           c_msg_user_id,
           c_msg_src,
           --v_msg_content,
           v_msg_sender,
           d_update_time,
           n_enable)
          select lower(sys_guid()),
                 51,
                 t.n_istop_flag,
                 t.v_news_title,
                 sysdate,
                 0,
                 c_user_id,
                 WorkflowId,
                 --t.v_news_content,
                 t.v_signature_name,
                 sysdate,
                 1
            from (select u.c_user_id
                    from LCBASE.t_zip_User u
                   where u.n_status = 0
                     and u.c_organization_id in
                         (select g.c_organization_id
                            from (SELECT *
                                    FROM LCBASE.T_ZIP_ORGANIZATION
                                   WHERE D_ENDDATE > SYSDATE) g
                          connect by prior g.c_organization_id =
                                      g.c_organization_parent_id
                           start with g.c_organization_id in
                                      (select r.c_target_id
                                         from oa_msg_publish_range r
                                        where r.c_news_id = WorkflowId
                                          and r.n_target_type = 1))
                     and u.d_enddate > sysdate
                  union
                  select 'e6e0d38119eb47bea9be644ac003bd18' from dual) mu
            left join oa_msg_publish_info t
              on t.c_news_id = WorkflowId;
        v_sql := v_sql || ' union ';
        v_sql := v_sql ||
                 'select u.c_user_id userid
                    from LCBASE.t_zip_User u
                   where u.n_status = 0
                   and u.d_enddate > sysdate
                     and u.c_organization_id in
                         (select g.c_organization_id
                            from (SELECT *
                                    FROM LCBASE.T_ZIP_ORGANIZATION
                                   WHERE D_ENDDATE > SYSDATE) g
                          connect by prior g.c_organization_id =
                                      g.c_organization_parent_id
                           start with g.c_organization_id in
                                      (select r.c_target_id
                                         from oa_msg_publish_range r
                                        where r.c_news_id = ''' ||
                 WorkflowId || ''' and r.n_target_type = 1))';
        v_sql := v_sql || ' union ';
        v_sql := v_sql ||
                 'select ''e6e0d38119eb47bea9be644ac003bd18'' from dual ';
      else
        insert into oa_msg_message_info
          (c_msg_id,
           n_msg_type,
           n_istop_flag,
           v_msg_title,
           d_msg_time,
           n_read_flag,
           c_msg_user_id,
           c_msg_src,
           --v_msg_content,
           v_msg_sender,
           d_update_time,
           n_enable)
          select lower(sys_guid()),
                 51,
                 t.n_istop_flag,
                 t.v_news_title,
                 sysdate,
                 0,
                 c_user_id,
                 WorkflowId,
                 --t.v_news_content,
                 t.v_signature_name,
                 sysdate,
                 1
            from (select u.c_user_id
                    from LCBASE.t_zip_user u
                   where u.n_status = 0
                     and u.d_enddate > sysdate
                     and u.c_organization_id in
                         (select g.c_organization_id
                            from (SELECT *
                                    FROM LCBASE.T_ZIP_ORGANIZATION
                                   WHERE D_ENDDATE > SYSDATE) g
                          connect by prior g.c_organization_id =
                                      g.c_organization_parent_id
                           start with g.c_organization_id =
                                      '997c2b49b01d4bdba3c5ea4e0f615617')) mu
            left join oa_msg_publish_info t
              on t.c_news_id = WorkflowId;
        IsAll_MsgSender := 1;
      end if;
    END IF;
    open MsgSender_Cur for v_sql;
  end;
  procedure CreateExpensesAfwMsgById(WorkflowId     in varchar2,
                                     ApprovalUserId in varchar2,
                                     AfwStatus      in number,
                                     MsgSender_Cur  out sys_refcursor) is
    v_ApprovalResult varchar2(100);
  begin
    FormAfwResultMessage(ApprovalUserId, AfwStatus, v_ApprovalResult);
    insert into oa_msg_message_info
      (c_msg_id,
       n_msg_type,
       n_istop_flag,
       v_msg_title,
       d_msg_time,
       n_read_flag,
       c_msg_user_id,
       c_msg_src,
       v_msg_content,
       v_msg_sender,
       d_update_time,
       n_enable)
      select lower(sys_guid()),
             4,
             0,
             v_ApprovalResult || '报销申请',
             sysdate,
             0,
             t.c_expenses_user_id,
             WorkflowId,
             t.v_expenses_user_name || '的报销',
             '系统',
             sysdate,
             1
        from oa_eps_expenses_info t
       where t.c_expenses_id = WorkflowId;
    open MsgSender_Cur for
      select t.c_expenses_user_id
        from oa_eps_expenses_info t
       where t.c_expenses_id = WorkflowId;
  end;
  procedure CreatePromotionAfwMsgById(WorkflowId     in varchar2,
                                      ApprovalUserId in varchar2,
                                      AfwStatus      in number,
                                      MsgSender_Cur  out sys_refcursor) is
    v_ApprovalResult varchar2(100);
  begin
    FormAfwResultMessage(ApprovalUserId, AfwStatus, v_ApprovalResult);
    insert into oa_msg_message_info
      (c_msg_id,
       n_msg_type,
       n_istop_flag,
       v_msg_title,
       d_msg_time,
       n_read_flag,
       c_msg_user_id,
       c_msg_src,
       v_msg_content,
       v_msg_sender,
       d_update_time,
       n_enable)
      select lower(sys_guid()),
             11,
             0,
             v_ApprovalResult || '转正申请',
             sysdate,
             0,
             t.c_promotion_user_id,
             WorkflowId,
             u.v_pet_name || '的转正',
             '系统',
             sysdate,
             1
        from lcoa.oa_afw_promotion_info t
        left join lcbase.t_zip_user u
          on u.c_user_id = t.c_promotion_user_id
       where t.c_promotion_id = WorkflowId
         and u.d_enddate > sysdate;
  
    open MsgSender_Cur for
      select t.c_promotion_user_id
        from oa_afw_promotion_info t
       where t.c_promotion_id = WorkflowId;
  end;
  procedure CreateAdjustpostAfwMsgById(WorkflowId     in varchar2,
                                       ApprovalUserId in varchar2,
                                       AfwStatus      in number,
                                       MsgSender_Cur  out sys_refcursor) is
    v_ApprovalResult varchar2(100);
  begin
    FormAfwResultMessage(ApprovalUserId, AfwStatus, v_ApprovalResult);
    insert into oa_msg_message_info
      (c_msg_id,
       n_msg_type,
       n_istop_flag,
       v_msg_title,
       d_msg_time,
       n_read_flag,
       c_msg_user_id,
       c_msg_src,
       v_msg_content,
       v_msg_sender,
       d_update_time,
       n_enable)
      select lower(sys_guid()),
             12,
             0,
             v_ApprovalResult || '调岗申请',
             sysdate,
             0,
             t.c_adjust_user_id,
             WorkflowId,
             u.v_pet_name || '的调岗',
             '系统',
             sysdate,
             1
        from lcoa.oa_afw_adjustpost_info t
        left join lcbase.t_zip_user u
          on u.c_user_id = t.c_adjust_user_id
       where t.c_adjust_id = WorkflowId
         and u.d_enddate > sysdate;
  
    open MsgSender_Cur for
      select t.c_adjust_user_id
        from oa_afw_adjustpost_info t
       where t.c_adjust_id = WorkflowId;
  end;
  --查询邮件内容
  function get_email_content(EmailList out sys_refcursor,
                             ErrMsg    out varchar2) return number is
  begin
    open EmailList for
      with sttt as
       (SELECT C_ID,
               LISTAGG(V_SENDTOS_ADDR, ',') WITHIN GROUP(ORDER BY V_SENDTOS_ADDR) AS addr
          FROM lcoa.oa_msg_recipient_addr
         GROUP BY C_ID)
      select e.C_ID,
             e.C_DATAID,
             e.N_OPERATION_TYPE,
             e.N_MESSAGE_TYPE,
             e.N_TYPE,
             e.V_FROM_NAME,
             e.V_FROM_ADDR,
             e.V_SUBJECT,
             e.V_CONTENT,
             e.N_DEL_STATUS,
             e.N_SEND_STATUS,
             e.D_SET_SEND_DATE,
             e.D_REAL_SEND_DATE,
             e.N_SEND_ONEBYONE,
             e.N_ALL_USER,
             s.addr as V_SENDTOS_ADDR
        from lcoa.oa_msg_email_info e
        left join sttt s
          on e.c_id = s.c_id
       where to_char(e.d_set_send_date, 'yyyy-mm-dd') =
             to_char(sysdate, 'yyyy-mm-dd')
         and e.n_del_status = 0
         and e.n_send_status = 0;
  
    update lcoa.oa_msg_email_info e
       set e.d_real_send_date = to_date(to_char(sysdate,
                                                'yyyy-mm-dd hh24:mi:ss'),
                                        'yyyy-mm-dd hh24:mi:ss'),
           e.n_send_status    = 1
     where to_char(e.d_set_send_date, 'yyyy-mm-dd') =
           to_char(sysdate, 'yyyy-mm-dd');
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'get_email_content: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise;
      return 1;
  end;
  -- 存储邮件信息
  procedure insert_email_info(WorkflowId     in varchar2,
                              ApprovalUserId in varchar2,
                              ContentFlag    in varchar2,
                              ErrMsg         out varchar2) is
    workflowtype     number(6);
    applyuserid      varchar2(40);
    applyname        varchar2(30);
    applyemail       varchar2(200);
    approvalname     varchar2(30);
    approvalemail    varchar2(200);
    workflowtypename varchar2(30);
    emailtitle       varchar2(2000);
    emailcontent     varchar2(2000);
    titlename        varchar2(300);
    n_result         number(6);
    emailtype        number(6);
    cid              varchar2(40);
    v_approvalorder  number;
  begin
  
    --查询审批类型
    if Contentflag = 1 then
      select f.n_workflow_type, min(f.n_approval_order)
        into workflowtype, v_approvalorder
        from lcoa.oa_afw_workflow_approval_flow f
       where f.c_workflow_id = WorkflowId
         and f.c_approval_user_id = ApprovalUserId
       group by f.n_workflow_type;
    else
      select f.n_workflow_type
        into workflowtype
        from lcoa.oa_afw_workflow_approval_flow f
       where f.c_workflow_id = WorkflowId
       group by f.n_workflow_type;
    end if;
  
    -- 查询审批人姓名和email地址
    select u.v_pet_name, u.v_email
      into approvalname, approvalemail
      from lcbase.t_zip_user u
     where u.c_user_id = ApprovalUserId
       and u.d_enddate > SYSDATE;
  
    -- 查询申请人姓名和邮件地址
    n_result := get_applyuser_nameandemail(WorkflowId,
                                           workflowtype,
                                           applyuserid,
                                           applyname,
                                           applyemail,
                                           ErrMsg);
  
    -- 匹配类型名称
    if workflowtype = 1 then
      workflowtypename := '请假';
    elsif workflowtype = 2 then
      workflowtypename := '外出';
    elsif workflowtype = 3 then
      -- 公告时 查询公告标题
      select p.v_news_title
        into titlename
        from lcoa.oa_msg_publish_info p
       where p.c_news_id = WorkflowId;
      workflowtypename := '公告';
    elsif workflowtype = 4 then
      workflowtypename := '报销';
    elsif workflowtype = 5 then
      workflowtypename := '借款';
    elsif workflowtype = 7 then
      workflowtypename := '借款延期';
    elsif workflowtype = 11 then
      workflowtypename := '转正';
    elsif workflowtype = 12 then
      workflowtypename := '调岗';
    elsif workflowtype = 16 then
      workflowtypename := '数据修改';
    end if;
  
    -- ContentFlag 1待审批 2同意 3拒绝 4撤回 5延期 
    -- 组合待审批发待办时邮件内容
    if ContentFlag = 1 then
      --公告待办
      if workflowtype = 3 then
        emailtitle   := '【公告申请】' || applyname || '的公告申请';
        emailcontent := '您有一个【' || titlename || '】的公告申请待审批，申请人【' ||
                        applyname || '】，请及时登录OA系统在【首页-我的待办】中进行审批';
      else
        if v_approvalorder = 7 then
          emailtitle   := '【' || workflowtypename || '申请】' || applyname || '的' ||
                          workflowtypename || '申请待支付';
          emailcontent := '您有一个【' || workflowtypename || '申请】待支付，申请人【' ||
                          applyname || '】，请及时登录OA系统在【首页-我的待办】中进行支付';
        else
          emailtitle   := '【' || workflowtypename || '申请】' || applyname || '的' ||
                          workflowtypename || '申请';
          emailcontent := '您有一个【' || workflowtypename || '申请】待审批，申请人【' ||
                          applyname || '】，请及时登录OA系统在【首页-我的待办】中进行审批';
        end if;
      end if;
      -- 组合同意发消息时邮件内容
    elsif ContentFlag = 2 then
      --公告同意消息
      if workflowtype = 3 then
        emailtitle   := '【公告申请】' || approvalname || '已同意了你的【' || titlename ||
                        '】的公告申请';
        emailcontent := approvalname || '已同意了你的【' || titlename ||
                        '】的公告申请，可登录OA系统查看';
      else
        emailtitle   := '【' || workflowtypename || '申请】' || approvalname ||
                        '已同意了你的' || workflowtypename || '申请';
        emailcontent := approvalname || '已同意了你的' || workflowtypename ||
                        '申请，可登录OA系统查看';
      end if;
      -- 组合拒绝发消息时邮件内容
    elsif ContentFlag = 3 then
      --公告拒绝消息
      if workflowtype = 3 then
        emailtitle   := '【公告申请】' || approvalname || '已拒绝了你的【' || titlename ||
                        '】的公告申请';
        emailcontent := approvalname || '已拒绝了你的【' || titlename ||
                        '】的公告申请，可登录OA系统查看';
      else
        emailtitle   := '【' || workflowtypename || '申请】' || approvalname ||
                        '已拒绝了你的' || workflowtypename || '申请';
        emailcontent := approvalname || '已拒绝了你的' || workflowtypename ||
                        '申请，可登录OA系统查看';
      end if;
      -- 组合撤回发消息时邮件内容
    elsif ContentFlag = 4 then
    
      --公告撤回消息
      if workflowtype = 3 then
        emailtitle   := '【公告申请】' || approvalname || '已撤回了你的【' || titlename ||
                        '】的公告申请';
        emailcontent := approvalname || '已撤回了【' || titlename ||
                        '】的公告申请，可登录OA系统查看';
      else
        emailtitle   := '【' || workflowtypename || '申请】' || approvalname ||
                        '已撤回了' || workflowtypename || '申请';
        emailcontent := approvalname || '已撤回了' || workflowtypename ||
                        '申请，可登录OA系统查看';
      end if;
      -- 组合延期发消息时邮件内容
    elsif ContentFlag = 5 then
      emailtitle   := '【' || workflowtypename || '申请】' || approvalname ||
                      '已延期了你的' || workflowtypename || '申请';
      emailcontent := approvalname || '已延期了你的' || workflowtypename ||
                      '申请，可登录OA系统查看';
    end if;
  
    -- 1为待审批 邮件为代办邮件
    if ContentFlag = 1 then
      emailtype := 1;
    
    else
      -- 其余为消息邮件
      emailtype := 2;
    end if;
  
    select lower(sys_guid()) into cid from dual;
  
    -- 插入邮件信息表信息
    INSERT INTO LCOA.OA_MSG_EMAIL_INFO
      (C_ID,
       C_DATAID,
       N_OPERATION_TYPE,
       N_MESSAGE_TYPE,
       N_TYPE, --邮件内容类型 1普通 2HTML
       V_FROM_NAME,
       V_FROM_ADDR,
       V_SUBJECT,
       V_CONTENT,
       N_DEL_STATUS,
       N_SEND_STATUS,
       D_SET_SEND_DATE,
       D_REAL_SEND_DATE,
       N_SEND_ONEBYONE, --是否群发 0群发 1单个发
       N_ALL_USER) --是否全员 0全员 1非全员
    VALUES
      (cid,
       WorkflowId,
       workflowtype,
       emailtype,
       1,
       null,
       null,
       emailtitle,
       emailcontent,
       0,
       0,
       sysdate,
       null,
       1,
       1);
    -- 1为待审批 4为撤回  都是给审批人发邮件
    if ContentFlag = 1 then
      INSERT INTO LCOA.OA_MSG_RECIPIENT_ADDR
        (C_ID, V_RECIPIENT, V_SENDTOS_ADDR)
      VALUES
        (cid, approvalname, approvalemail);
    elsif ContentFlag = 4 then
      get_cancel_nameandemail(WorkflowId,
                              approvalname,
                              approvalemail,
                              ErrMsg);
      INSERT INTO LCOA.OA_MSG_RECIPIENT_ADDR
        (C_ID, V_RECIPIENT, V_SENDTOS_ADDR)
      VALUES
        (cid, approvalname, approvalemail);
    else
      -- 其余为给申请人发邮件
      INSERT INTO LCOA.OA_MSG_RECIPIENT_ADDR
        (C_ID, V_RECIPIENT, V_SENDTOS_ADDR)
      VALUES
        (cid, applyname, applyemail);
    end if;
    --commit;
  exception
    when others then
      ErrMsg := 'insert_email_info: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise;
  end;

  function get_applyuser_nameandemail(WorkflowId   IN VARCHAR2,
                                      workflowtype in varchar2,
                                      applyuserid  out VARCHAR2,
                                      applyname    out varchar2,
                                      applyemail   out varchar2,
                                      ErrMsg       out varchar2)
    return number is
  begin
    --请假
    if workflowtype = 1 then
      select l.c_leave_user_id, u.v_email, u.v_pet_name
        into applyuserid, applyemail, applyname
        from lcoa.oa_afw_leave_info l
        left join lcbase.t_zip_user u
          on l.c_leave_user_id = u.c_user_id
       where l.c_leave_id = WorkflowId
         and u.d_enddate > SYSDATE;
      --外出
    elsif workflowtype = 2 then
      select e.c_egress_user_id, u.v_email, u.v_pet_name
        into applyuserid, applyemail, applyname
        from lcoa.oa_afw_egress_info e
        left join lcbase.t_zip_user u
          on e.c_egress_user_id = u.c_user_id
       where e.c_egress_id = WorkflowId
         and u.d_enddate > SYSDATE;
      --公告
    elsif workflowtype = 3 then
      select p.c_input_user_id, u.v_email, u.v_pet_name
        into applyuserid, applyemail, applyname
        from lcoa.oa_msg_publish_info p
        left join lcbase.t_zip_user u
          on p.c_input_user_id = u.c_user_id
       where p.c_news_id = WorkflowId
         and u.d_enddate > SYSDATE;
      --报销
    elsif workflowtype = 4 then
      select l.c_leave_user_id
        into applyuserid
        from lcoa.oa_afw_leave_info l
       where l.c_leave_id = WorkflowId;
      --借款
    elsif workflowtype = 5 then
      select l.c_user_id, u.v_email, u.v_pet_name
        into applyuserid, applyemail, applyname
        from lcoa.oa_afw_loan_info l
        left join lcbase.t_zip_user u
          on l.c_user_id = u.c_user_id
       where l.c_id = WorkflowId
         and u.d_enddate > SYSDATE;
      --借款延期
    elsif workflowtype = 7 then
      select l.c_user_id, u.v_email, u.v_pet_name
        into applyuserid, applyemail, applyname
        from lcoa.oa_afw_loan_extension l
        left join lcbase.t_zip_user u
          on l.c_user_id = u.c_user_id
       where l.c_id = WorkflowId
         and u.d_enddate > SYSDATE;
      --转正
    elsif workflowtype = 11 then
      select p.c_promotion_user_id, u.v_email, u.v_pet_name
        into applyuserid, applyemail, applyname
        from lcoa.oa_afw_promotion_info p
        left join lcbase.t_zip_user u
          on p.c_promotion_user_id = u.c_user_id
       where p.c_promotion_id = WorkflowId
         and u.d_enddate > SYSDATE;
      --调岗
    elsif workflowtype = 12 then
      select a.c_adjust_user_id, u.v_email, u.v_pet_name
        into applyuserid, applyemail, applyname
        from lcoa.oa_afw_adjustpost_info a
        left join lcbase.t_zip_user u
          on a.c_adjust_user_id = u.c_user_id
       where a.c_adjust_id = WorkflowId
         and u.d_enddate > SYSDATE;
      --数据修改
    elsif workflowtype = 16 then
      select a.c_input_user_id, u.v_email, u.v_pet_name
        into applyuserid, applyemail, applyname
        from lcoa.oa_afw_dmd_apply a
        left join lcbase.t_zip_user u
          on a.c_input_user_id = u.c_user_id
       where a.c_datamodify_apply_id = WorkflowId
         and u.d_enddate > SYSDATE;
    
    end if;
    return 0;
  exception
    when others then
      ErrMsg := 'get_applyuser_nameandemail:' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  procedure get_cancel_nameandemail(WorkflowId    IN VARCHAR2,
                                    approvalname  out varchar2,
                                    approvalemail out varchar2,
                                    ErrMsg        out varchar2) is
    countname      number(6);
    approvalstatus number(6);
  begin
    select count(*)
      into countname
      from lcoa.oa_afw_workflow_approval_flow f
     where f.c_workflow_id = WorkflowId;
    if countname = 1 then
      select u.v_pet_name, u.v_email
        into approvalname, approvalemail
        from lcoa.oa_afw_workflow_approval_flow f
        left join lcbase.t_zip_user u
          on f.c_approval_user_id = u.c_user_id
       where f.c_workflow_id = WorkflowId
         and u.d_enddate > SYSDATE;
    elsif countname > 1 then
      select u.v_pet_name, u.v_email
        into approvalname, approvalemail
        from lcoa.oa_afw_workflow_approval_flow f
        left join lcbase.t_zip_user u
          on f.c_approval_user_id = u.c_user_id
       where f.c_workflow_id = WorkflowId
         and u.d_enddate > SYSDATE
         and f.n_approval_status = 0
         and rownum = 1;
    end if;
  
  exception
    when others then
      ErrMsg := 'get_cancel_nameandemail:' || sqlcode || ',' || sqlerrm;
      raise;
  end;

--此块进行变量初始化，可删除
begin
  -- Initialization
  i := 1;
end PKG_INS_AFW_USERAPPLY;
/

