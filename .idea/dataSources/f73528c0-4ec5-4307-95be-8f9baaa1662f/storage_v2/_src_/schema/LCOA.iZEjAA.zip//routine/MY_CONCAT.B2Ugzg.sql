create function      my_concat(tableName varchar2,opType varchar2)
return varchar2 is
  FunctionResult varchar2(1000):='';
  type typ_cursor is ref cursor;
  v_cursor typ_cursor;
  v_temp varchar2(30);
  v_sql varchar2(200);
begin
  v_sql := 'select column_name from user_tab_columns where table_name = ''' || upper(tableName) || ''' order by column_id asc';
  open v_cursor for v_sql;
  loop
    fetch v_cursor into v_temp;
    exit when v_cursor%notfound;
    if opType = 'select' or opType = 'insert' then
      FunctionResult := FunctionResult || ',' || chr(13) || v_temp ;
    elsif opType = 'update' then
      FunctionResult := FunctionResult || ',' || chr(13) || v_temp || ' = ?' ;
    end if;
  end loop;
  return substr(FunctionResult,2);
end my_concat;

/

