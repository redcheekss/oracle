create package body PKG_EXT_DMD_APPLY is

  FUNCTION INSERT_OADMDAPPLY(OADMDAPPLY      IN VARCHAR2,
                             enclosure_LIST  IN arr_longstr,
                             OperationUserID IN VARCHAR2,
                             TodoSender_Cur  out sys_refcursor,
                             ErrMsg          OUT VARCHAR2) RETURN NUMBER is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
  begin
    time_start := systimestamp;
    begin
      n_optype := 2;
      n_result := lcoa.pkg_dmd_apply.INSERT_OADMDAPPLY(OADMDAPPLY,
                                                       enclosure_LIST,
                                                       OperationUserID,
                                                       TodoSender_Cur,
                                                       ErrMsg);
    
    EXCEPTION
      WHEN OTHERS THEN
        --ErrMsg := pkg_common.g_errmsg_common;
        ErrMsg   := SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'INSERT_OADMDAPPLY',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  FUNCTION UPDATE_OADMDAPPLY(datamodify_apply_id IN VARCHAR2,
                             OperationUserID     IN VARCHAR2,
                             ErrMsg              OUT VARCHAR2) RETURN NUMBER is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
  begin
    time_start := systimestamp;
    begin
    
      n_optype := 3;
      n_result := pkg_dmd_apply.UPDATE_OADMDAPPLY(datamodify_apply_id,
                                                  OperationUserID,
                                                  ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'UPDATE_OADMDAPPLY',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  FUNCTION SELECT_OADMDAPPLY(datamodify_apply_id IN VARCHAR2,
                             OperationUserID     IN VARCHAR2,
                             TodoSender_Cur      out sys_refcursor,
                             enclosure           out sys_refcursor,
                             CUR_FLOW            out sys_refcursor,
                             ErrMsg              OUT VARCHAR2) RETURN NUMBER is
    n_optype     number(6); --1查2插3更4删
    n_status     number(6) := 0; --0成功1失败
    resultNumber number(6);
  begin
    n_optype     := 1;
    resultNumber := pkg_dmd_apply.SELECT_OADMDAPPLY(datamodify_apply_id,
                                                    OperationUserID,
                                                    TodoSender_Cur,
                                                    enclosure,
                                                    CUR_FLOW,
                                                    ErrMsg);
    if resultNumber = 1 then
      RETURN 1;
    end IF;
    if resultNumber <> 0 then
      ErrMsg := '暂无数据';
      RETURN - 1;
    end IF;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'SELECT_OADMDAPPLY',
                                  n_optype,
                                  n_status);
    RETURN 0;
  end;

  FUNCTION INSER_OADMDCOMMENT(DataInfo        IN VARCHAR2,
                              OperationUserID IN VARCHAR2,
                              TodoSender_Cur  out VARCHAR2,
                              ErrMsg          OUT VARCHAR2) RETURN NUMBER is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
    CurData    sys_refcursor;
    ROW_FLOW   varchar2(32);
    DATAARR    PKG_COMMON.ARR_LONGSTR;
  begin
    time_start := systimestamp;
    begin
      n_optype := 2;
      DATAARR  := PKG_COMMON.Split(DataInfo, '^');
      n_result := pkg_dmd_apply.INSER_OADMDCOMMENT(DataInfo, --COMMEN
                                                   OperationUserID,
                                                   DATAARR(6), --messageReceiverUserID
                                                   DATAARR(3), --datamodify_comment_id
                                                   DATAARR(4), --datamodify_apply_id
                                                   CurData,
                                                   ErrMsg);
      if CurData is not null and CurData%found then
        fetch CurData
          into ROW_FLOW;
        while CurData%found loop
          TodoSender_Cur := ROW_FLOW;
          fetch CurData
            into ROW_FLOW;
        end loop;
        close CurData;
      end if;
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'INSER_OADMDCOMMENT: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'INSER_OADMDCOMMENT',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  FUNCTION SELETE_OADMDCOMMENT(datamodify_apply_id in VARCHAR2,
                               OperationUserID     IN VARCHAR2,
                               nPageSize           IN NUMBER, --每页显示大小>0
                               nPageCur            IN NUMBER, --当前页码[1-总页数]
                               CUR_DATA            OUT SYS_REFCURSOR, --oracle标准游标
                               nOutRows            OUT number, --输出总记录数
                               nOutPageCount       OUT number, --输出总页数
                               datamodify          out sys_refcursor,
                               ErrMsg              OUT VARCHAR2)
    RETURN NUMBER is
    n_optype     number(6); --1查2插3更4删
    n_status     number(6) := 0; --0成功1失败
    resultNumber number(6);
  begin
    n_optype     := 1;
    resultNumber := pkg_dmd_apply.SELETE_OADMDCOMMENT(datamodify_apply_id,
                                                      OperationUserID,
                                                      nPageSize,
                                                      nPageCur,
                                                      CUR_DATA,
                                                      nOutRows,
                                                      nOutPageCount,
                                                      datamodify,
                                                      ErrMsg);
    if resultNumber <> 0 then
      RETURN - 1;
    end IF;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'SELETE_OADMDCOMMENT',
                                  n_optype,
                                  n_status);
    RETURN 0;
  end;
  FUNCTION distribute_OADMDAPPLY(DataInfo        in VARCHAR2,
                                 OperationUserID IN VARCHAR2,
                                 apply_id        out VARCHAR2,
                                 TodoSender_Cur  out varchar2,
                                 ErrMsg          OUT VARCHAR2) RETURN NUMBER is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
    CurData    sys_refcursor;
    ROW_FLOW   varchar2(32);
    DATAARR    PKG_COMMON.ARR_LONGSTR;
  begin
    time_start := systimestamp;
    begin
      n_optype := 3;
      DATAARR  := PKG_COMMON.Split(DataInfo, '^');
      n_result := pkg_dmd_apply.distribute_OADMDAPPLY(DATAARR(1), --datamodify_apply_id
                                                      OperationUserID,
                                                      DATAARR(15), --distributeUserID
                                                      DATAARR(13), --distributeRemarks
                                                      apply_id,
                                                      CurData,
                                                      ErrMsg);
      if CurData is not null and CurData%found then
        fetch CurData
          into ROW_FLOW;
        while CurData%found loop
          TodoSender_Cur := ROW_FLOW;
          fetch CurData
            into ROW_FLOW;
        end loop;
        close CurData;
      end if;
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'distribute_OADMDAPPLY',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  FUNCTION reject_OADMDAPPLY(DataInfo        in VARCHAR2,
                             OperationUserID IN VARCHAR2,
                             apply_id        out VARCHAR2,
                             
                             ErrMsg OUT VARCHAR2) RETURN NUMBER is
    TodoSender_Cur varchar2(32);
    n_optype       number(6); --1查2插3更4删
    n_status       number(6) := 0; --0成功1失败
    time_start     timestamp;
    time_end       timestamp;
    n_duration     number(10);
    n_result       number(6);
    CurData        sys_refcursor;
    ROW_FLOW       varchar2(32);
    DATAARR        PKG_COMMON.ARR_LONGSTR;
  begin
    time_start := systimestamp;
    begin
      n_optype := 3;
      DATAARR  := PKG_COMMON.Split(DataInfo, '^');
      n_result := pkg_dmd_apply.reject_OADMDAPPLY(DATAARR(1), --datamodify_apply_id
                                                  OperationUserID,
                                                  DATAARR(23), --rejectRemarks
                                                  apply_id,
                                                  ErrMsg);
      if CurData is not null and CurData%found then
        fetch CurData
          into ROW_FLOW;
        while CurData%found loop
          TodoSender_Cur := ROW_FLOW;
          fetch CurData
            into ROW_FLOW;
        end loop;
        close CurData;
      end if;
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'reject_OADMDAPPLY',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  FUNCTION close_OADMDAPPLY(DataInfo        in VARCHAR2,
                            OperationUserID IN VARCHAR2,
                            apply_id        out VARCHAR2,
                            ErrMsg          OUT VARCHAR2) RETURN NUMBER is
    TodoSender_Cur varchar2(32);
    n_optype       number(6); --1查2插3更4删
    n_status       number(6) := 0; --0成功1失败
    time_start     timestamp;
    time_end       timestamp;
    n_duration     number(10);
    n_result       number(6);
    CurData        sys_refcursor;
    ROW_FLOW       varchar2(32);
    DATAARR        PKG_COMMON.ARR_LONGSTR;
  begin
    time_start := systimestamp;
    begin
      n_optype := 3;
      DATAARR  := PKG_COMMON.Split(DataInfo, '^');
      n_result := pkg_dmd_apply.close_OADMDAPPLY(DATAARR(1), --datamodify_apply_id
                                                 OperationUserID,
                                                 DATAARR(16), --closeStatus
                                                 DATAARR(17), --closeRemarks
                                                 apply_id,
                                                 ErrMsg);
      if CurData is not null and CurData%found then
        fetch CurData
          into ROW_FLOW;
        while CurData%found loop
          TodoSender_Cur := ROW_FLOW;
          fetch CurData
            into ROW_FLOW;
        end loop;
        close CurData;
      end if;
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'close_OADMDAPPLY',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
end PKG_EXT_DMD_APPLY;
/

