create package body PKG_TEST is

  FUNCTION Insert_Expenses_Info(Data            in type_expenses_list,
                                DataItem        in type_expenses_item_list, --报销明细表
                                ArrFile         in ARR_LONGSTR,
                                OperationUserId in varchar2,
                                DataId          out varchar2,
                                ErrMsg          out varchar2) return number is
  
    P_ID             char(32);
    deptFullName     varchar2(50);
    expensesUserName varchar2(20);
    DataInfo         TYPE_EXPENSES_INFO;
    DataItemInfo     type_expenses_item;
    n_result         number(1) := 0;
  BEGIN
    P_ID     := LOWER(SYS_GUID());
    DataInfo := Data(1);
    select v_organization_name
      into deptFullName
      from lcbase.t_organization
     where c_organization_id = DataInfo.deptId;
  
    select v_user_name
      into expensesUserName
      from lcbase.t_user
     where c_user_id = DataInfo.expensesUserId;
  
    insert into oa_eps_expenses_info
      (c_expenses_id,
       n_expenses_type,
       c_expenses_user_id,
       v_expenses_user_name,
       v_expenses_user_tel,
       c_dept_id,
       v_dept_name,
       c_top1_dept_id,
       c_top2_dept_id,
       c_top3_dept_id,
       c_top4_dept_id,
       v_dept_full_name,
       c_position_id,
       v_position_name,
       c_lk_corp_id,
       v_expenses_reason,
       c_project_id,
       v_project_name,
       n_borrowed_fee,
       n_total_fee,
       n_payable_fee,
       v_expenses_no,
       v_bar_code,
       n_repay_flag,
       n_repay_type,
       n_repay_amount,
       d_input_time,
       d_reject_time,
       c_reject_user_id,
       v_reject_user_name,
       v_reject_remark,
       d_update_time,
       c_update_user_id,
       n_status,
       n_approval_avoid_flag,
       n_finance_status,
       n_current_level,
       n_paid_fee,
       c_pay_lk_corp_id,
       n_ebank_pay_status,
       v_payment_flow_no,
       v_payment_flow_no_prefix,
       v_bank_flow_no,
       n_payment_fee,
       v_payment_failed_reason,
       v_payment_account_no,
       c_payment_user_id,
       d_payment_date,
       v_payment_purpose,
       n_record_flag,
       d_record_time,
       n_check_flag,
       v_check_remark,
       d_check_time,
       c_check_user_id,
       n_notice_payable_fee,
       n_notice_status,
       v_notice_remark,
       n_disabled_flag,
       c_last_invalid_userid,
       d_last_invalid_date,
       v_last_invalid_memo,
       v_finance_reject_reson,
       d_finance_reject_date,
       c_finance_reject_user_id,
       v_finance_reject_user_name,
       n_invalid_status,
       v_ex_memo)
    values
      (P_ID,
       DataInfo.expensesType,
       OperationUserId,
       expensesUserName,
       DataInfo.expensesUserTel,
       DataInfo.deptId,
       DataInfo.deptName,
       DataInfo.top1DeptId,
       DataInfo.top2DeptId,
       DataInfo.top3DeptId,
       DataInfo.top4DeptId,
       deptFullName,
       DataInfo.positionId,
       DataInfo.positionName,
       DataInfo.lkCorpId,
       DataInfo.expensesReason,
       DataInfo.projectId,
       DataInfo.projectName,
       DataInfo.borrowedFee,
       DataInfo.totalFee,
       DataInfo.payableFee,
       DataInfo.expensesNo,
       DataInfo.barCode,
       DataInfo.repayFlag,
       DataInfo.repayType,
       DataInfo.repayAmount,
       sysdate,
       DataInfo.rejectTime,
       DataInfo.rejectUserId,
       DataInfo.rejectUserName,
       DataInfo.rejectRemark,
       sysdate,
       DataInfo.updateUserId,
       DataInfo.status,
       DataInfo.approvalAvoidFlag,
       DataInfo.financeStatus,
       DataInfo.currentLevel,
       DataInfo.paidFee,
       DataInfo.payLkCorpId,
       DataInfo.ebankPayStatus,
       DataInfo.paymentFlowNo,
       DataInfo.paymentFlowNoPrefix,
       DataInfo.bankFlowNo,
       DataInfo.payableFee,
       DataInfo.paymentFailedReason,
       DataInfo.paymentAccountNo,
       DataInfo.paymentUserId,
       DataInfo.paymentDate,
       '付报销款',
       DataInfo.recordFlag,
       DataInfo.recordTime,
       DataInfo.checkFlag,
       DataInfo.checkRemark,
       DataInfo.checkTime,
       DataInfo.checkUserId,
       DataInfo.noticePayableFee,
       DataInfo.noticeStatus,
       DataInfo.noticeRemark,
       DataInfo.disabledFlag,
       DataInfo.lastInvalidUserid,
       DataInfo.lastInvalidDate,
       DataInfo.lastInvalidMemo,
       DataInfo.financeRejectReson,
       DataInfo.financeRejectDate,
       DataInfo.financeRejectUserId,
       DataInfo.financeRejectUserName,
       DataInfo.invalidStatus,
       DataInfo.exMemo);
  
    DataId := P_ID;
  
    if DataItem is null or DataItem.Count = 0 then
      ErrMsg := '报销明细不能为空';
      return - 1;
    end if;
    for i in DataItem.FIRST .. DataItem.LAST loop
      DataItemInfo := DataItem(i);
    
      n_result := Insert_Expenses_Item(DataInfo   => DataItemInfo,
                                       ExpensesId => DataId,
                                       DataId     => DataId,
                                       ErrMsg     => errmsg);
    
    end loop;
  
    lcoa.pkg_user_schedule.Insert_User_Upload_File(DataId   => DataId,
                                                   FileType => 4,
                                                   ArrFile  => ArrFile);
  
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'Insert_Expenses_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE_APPLICATION_ERROR(-20008, errmsg, false);
  END;

  --插入报销单明细
  function Insert_Expenses_Item(DataInfo   in type_expenses_item,
                                ExpensesId in varchar2,
                                DataId     out varchar2,
                                ErrMsg     out varchar2) return number is
  
    P_ID char(32);
  begin
    P_ID := LOWER(SYS_GUID());
    insert into oa_eps_expenses_item
      (c_expenses_item_id,
       v_expenses_item_type,
       v_expenses_item_subtype,
       c_expenses_id,
       d_start_date,
       d_end_date,
       v_start_place,
       v_end_place,
       v_tool_key,
       v_tool,
       n_person_num,
       n_tickets_way_key,
       v_tickets_way,
       n_fee,
       n_bill_num,
       v_logement,
       n_unit_price,
       n_days,
       n_room,
       v_memo,
       v_cause,
       n_index,
       n_disabled_flag)
    values
      (P_ID,
       DataInfo.expensesItemType,
       DataInfo.expensesItemSubtype,
       ExpensesId,
       to_date(DataInfo.startDate, 'yyyymmddhh24miss'),
       to_date(DataInfo.endDate, 'yyyymmddhh24miss'),
       DataInfo.startPlace,
       DataInfo.endPlace,
       DataInfo.toolKey,
       DataInfo.tool,
       DataInfo.personNum,
       DataInfo.ticketsWayKey,
       DataInfo.ticketsWay,
       DataInfo.fee,
       DataInfo.billNum,
       DataInfo.logement,
       DataInfo.unitPrice,
       DataInfo.days,
       DataInfo.room,
       DataInfo.memo,
       DataInfo.cause,
       DataInfo.nIndex,
       DataInfo.disabledFlag);
  
    DataId := P_ID;
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'Insert_Expenses_Item: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE_APPLICATION_ERROR(-20008, errmsg, false);
  end;

  --申请
  function Apply_Expenses(DataInfo        in type_expenses_list,
                          OperationUserId in varchar2,
                          ErrMsg          out varchar2) return number is
    ROW_DATA LCOA.oa_eps_expenses_info%rowtype;
  
    FirstApprovalUserId char(32);
    TodoTitle           varchar2(30);
  begin
    for i in 1 .. DataInfo.COUNT loop
      --获取报销单详情
      select *
        into ROW_DATA
        from oa_eps_expenses_info
       where C_EXPENSES_ID = DataInfo(i).expensesId;
    
      if (ROW_DATA.N_STATUS <> 0 and ROW_DATA.N_STATUS <> -1 and
         ROW_DATA.N_STATUS <> 5) then
      
        ErrMsg := '报销单非待申请状态！';
        return - 1;
      else
      
        update oa_eps_expenses_info
           set N_STATUS                   = 1,
               V_FINANCE_REJECT_RESON     = '',
               D_FINANCE_REJECT_DATE      = '',
               C_FINANCE_REJECT_USER_ID   = '',
               V_FINANCE_REJECT_USER_NAME = ''
         where C_EXPENSES_ID = DataInfo(i).expensesId;
      
        --报销申请 固化审批信息
        select t.v_user_name || '的报销审批'
          into TodoTitle
          from lcbase.t_user t
         where t.c_user_id = DataInfo(i).expensesUserId;
      
        lcoa.pkg_user_workflow.Create_Approval_By_Id(DataInfo(i).expensesId,
                                                     4);
        lcoa.pkg_user_workflow.Create_Next_Approval_Todo(DataInfo(i)
                                                         .expensesId,
                                                         TodoTitle);
      
      end if;
    
    end loop;
    commit;
    return 0;
  end;

  --撤回
  function Withdrawn_Expenses(DataInfo        in type_expenses_list,
                              OperationUserId in varchar2,
                              ErrMsg          out varchar2) return number is
    ROW_DATA LCOA.oa_eps_expenses_info%rowtype;
  
  begin
    for i in 1 .. DataInfo.COUNT loop
      --获取报销单详情
      select *
        into ROW_DATA
        from oa_eps_expenses_info
       where C_EXPENSES_ID = DataInfo(i).expensesId;
    
      if (ROW_DATA.N_STATUS <> 1) then
      
        ErrMsg := '报销单状态已更新不能撤回！';
        return - 1;
      else
      
        update oa_eps_expenses_info
           set N_STATUS = 0
         where C_EXPENSES_ID = DataInfo(i).expensesId;
      
        --todo  删除已固化审批信息
      
        -- 插入履历撤回操作
        insert into oa_afw_workflow_approval_log
          (c_data_id,
           c_workflow_id,
           n_approval_model,
           C_APPROVAL_USER_ID,
           v_approval_user_name,
           n_approval_status,
           d_approval_time,
           v_approval_remark)
        values
          (LOWER(SYS_GUID()),
           DataInfo(i).expensesId,
           1,
           OperationUserId,
           ROW_DATA.V_EXPENSES_USER_NAME,
           0,
           SYSDATE,
           '撤回');
        return 0;
      end if;
    end loop;
    COMMIT;
  end;

  --删除
  function Delete_Expenses(DataInfo        in type_expenses_list,
                           OperationUserId in varchar2,
                           ErrMsg          out varchar2) return number is
    ROW_DATA LCOA.oa_eps_expenses_info%rowtype;
  begin
    for i in 1 .. DataInfo.COUNT loop
      --获取报销单详情
      select *
        into ROW_DATA
        from oa_eps_expenses_info
       where C_EXPENSES_ID = DataInfo(i).expensesId;
    
      if (ROW_DATA.N_STATUS <> 0 and ROW_DATA.N_STATUS <> -1 and
         ROW_DATA.N_STATUS <> 5) then
      
        ErrMsg := '报销单非待申请状态！不可删除！';
        return - 1;
      else
      
        update oa_eps_expenses_info
           set N_DISABLED_FLAG = 1
         where C_EXPENSES_ID = DataInfo(i).expensesId;
      
      end if;
    
    end loop;
    commit;
    return 0;
  end;

  --获取公司主体集合
  function Get_Lk_Company_List(CUR_DATA OUT SYS_REFCURSOR,
                               ErrMsg   out varchar2) return number is
  begin
    OPEN CUR_DATA FOR
      SELECT * FROM lcbase.t_lk_company_info WHERE N_STATUS = 0;
    return 0;
  exception
    when others then
      ErrMsg := 'Get_Fee_Project_List: ' || SQLCODE || ',' || SQLERRM;
      RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
  end;

  --插入费用项目
  FUNCTION Insert_Fee_Project(DataInfo        in oa_eps_fee_project%rowtype,
                              OperationUserId in varchar2,
                              DataId          out varchar2,
                              ErrMsg          out varchar2) return number IS
    P_ID CHAR(32);
  BEGIN
    P_ID := LOWER(SYS_GUID());
    insert into oa_eps_fee_project
      (c_fee_project_id,
       v_fee_project_no,
       v_fee_project_name,
       d_input,
       d_update,
       c_input_user_id,
       n_enabled)
    values
      (P_ID,
       DataInfo.v_Fee_Project_No,
       DataInfo.v_Fee_Project_Name,
       sysdate,
       sysdate,
       OperationUserId,
       1);
    DataId := P_ID;
    commit;
    RETURN 0;
  exception
    when others then
      ErrMsg := 'Insert_Fee_Project: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE_APPLICATION_ERROR(-20008, errmsg, false);
    
  END;

  --修改费用项目
  FUNCTION Update_Fee_Project(DataInfo        in oa_eps_fee_project%rowtype,
                              OperationUserId in varchar2,
                              ErrMsg          out varchar2) return number is
  begin
    update oa_eps_fee_project
       set c_fee_project_id   = DataInfo.c_Fee_Project_Id,
           v_fee_project_no   = DataInfo.v_Fee_Project_No,
           v_fee_project_name = DataInfo.v_Fee_Project_Name,
           d_update           = sysdate,
           n_enabled          = DataInfo.n_Enabled
     where c_fee_project_id = DataInfo.c_Fee_Project_Id;
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'Update_Fee_Project: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE_APPLICATION_ERROR(-20008, errmsg, false);
  end;

  --获取报销用户默认报销项目
  function Get_Default_Expenses_ProjectId(UserId in varchar2,
                                          ErrMsg out varchar2)
    return varchar2 as
    PROJECT_ID CHAR(32);
  begin
    select T1.C_FEE_PROJECT_ID
      INTO PROJECT_ID
      from oa_eps_user_fee_project T1
      left join oa_eps_fee_project T2
        on T1.C_FEE_PROJECT_ID = T2.C_FEE_PROJECT_ID
     where T2.N_ENABLED = 1
       AND T1.C_USER_ID = UserId
       and rownum = 1;
    RETURN PROJECT_ID;
  exception
    when others then
      ErrMsg := 'Get_Default_Expenses_ProjectId: ' || SQLCODE || ',' ||
                SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE_APPLICATION_ERROR(-20008, errmsg, false);
  end;

  --查询费用项目
  function Get_Fee_Project_By_Id(ProjectId in varchar2,
                                 CUR_DATA  OUT SYS_REFCURSOR,
                                 ErrMsg    out varchar2) return number is
  
  begin
    OPEN CUR_DATA FOR
      SELECT * FROM OA_EPS_FEE_PROJECT where C_FEE_PROJECT_ID = ProjectId;
    return 0;
  exception
    when others then
      ErrMsg := 'Get_Fee_Project_List: ' || SQLCODE || ',' || SQLERRM;
      RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
    
  end;

  --获取费用所属项目
  function Get_Fee_Project_List(CUR_DATA OUT SYS_REFCURSOR,
                                ErrMsg   out varchar2) RETURN NUMBER IS
  BEGIN
    OPEN CUR_DATA FOR
      SELECT * FROM OA_EPS_FEE_PROJECT;
    return 0;
  exception
    when others then
      ErrMsg := 'Get_Fee_Project_List: ' || SQLCODE || ',' || SQLERRM;
      RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
  END;

  --通知作废
  function Invalid_Expenses(ExpensesId      in varchar2,
                            OperationUserId in varchar2,
                            InvalidMemo     in varchar2,
                            ErrMsg          out varchar2) RETURN NUMBER is
  begin
    update oa_eps_expenses_info
       set C_LAST_INVALID_USERID = OperationUserId,
           D_LAST_INVALID_DATE   = sysdate,
           V_LAST_INVALID_MEMO   = InvalidMemo,
           N_INVALID_STATUS      = 1
     WHERE C_EXPENSES_ID = ExpensesId;
    -- 插入履历
    --申请人发送邮件
  
    commit;
    return 0;
  end;

  --作废同意/拒绝操作
  function FeedBackInvalid(ExpensesId in varchar2, OperationType in number)
    return number as
    MESSAGE       VARCHAR2(20);
    INVALIDSTATUS NUMBER(1);
  begin
    IF OperationType = 0 then
      MESSAGE       := '同意作废';
      INVALIDSTATUS := 2;
      UPDATE oa_eps_expenses_info
         SET N_INVALID_STATUS = INVALIDSTATUS, N_STATUS = -1
       WHERE C_EXPENSES_ID = ExpensesId;
    ELSE
      MESSAGE       := '拒绝作废';
      INVALIDSTATUS := -1;
      UPDATE oa_eps_expenses_info
         SET N_INVALID_STATUS = INVALIDSTATUS
       WHERE C_EXPENSES_ID = ExpensesId;
    END IF;
    -- 插入履历
  
    COMMIT;
    RETURN 0;
  
  end;

  --发送通知
  function Send_Expenses_Message(ExpensesId          in varchar2,
                                 OperationUserId     in varchar2,
                                 NoticePayableAmount in number,
                                 Memo                in varchar2,
                                 ErrMsg              out varchar2)
    RETURN NUMBER as
    FINANCE_STATUS NUMBER(1);
  begin
    SELECT N_FINANCE_STATUS
      INTO FINANCE_STATUS
      FROM oa_eps_expenses_info
     WHERE C_EXPENSES_ID = ExpensesId;
  
    IF FINANCE_STATUS = -3 THEN
      ErrMsg := '出纳已驳回,无法通知报销人!';
      RETURN - 1;
      /*   elsif Memo is null then 
        ErrMsg := '通知备注不能为空!';
      RETURN -1;*/
    else
      update oa_eps_expenses_info
         set N_NOTICE_PAYABLE_FEE = NoticePayableAmount,
             V_NOTICE_REMARK      = Memo,
             N_NOTICE_STATUS      = 1,
             N_FINANCE_STATUS     = 2
       WHERE C_EXPENSES_ID = ExpensesId;
      -- 插入履历
      --申请人发送邮件
    end if;
    commit;
    return 0;
  end;

  --通知同意/拒绝操作
  function FeedBackMessage(ExpensesId in varchar2, OperationType in number)
    return number as
    MESSAGE       VARCHAR2(20);
    NOTICESTATUS  NUMBER(1);
    financeStatus number(1);
  begin
    IF OperationType = 0 then
      MESSAGE       := '通知确认';
      NOTICESTATUS  := 2;
      financeStatus := 3;
      UPDATE oa_eps_expenses_info
         SET N_NOTICE_STATUS  = NOTICESTATUS,
             N_FINANCE_STATUS = financeStatus
       WHERE C_EXPENSES_ID = ExpensesId;
    ELSE
      MESSAGE       := '通知拒绝';
      NOTICESTATUS  := -1;
      financeStatus := -1;
      UPDATE oa_eps_expenses_info
         SET N_NOTICE_STATUS  = NOTICESTATUS,
             N_FINANCE_STATUS = financeStatus
       WHERE C_EXPENSES_ID = ExpensesId;
    END IF;
    -- 插入履历
  
    COMMIT;
    RETURN 0;
  END;

  -- 用户重名返回工号
  function getUserWorkNo(UserId in varchar2) RETURN VARCHAR2 AS
    N_COUNT  NUMBER(1);
    cur_data varchar2(50);
  BEGIN
    select count(*)
      into n_count
      from lcbase.t_user tt
     where tt.v_user_name = (select t.v_user_name
                               from lcbase.t_user t
                              where t.c_user_id = UserId);
  
    if n_count > 1 then
      select t.v_user_name ||
             decode(t.n_work_id, null, '', '(' || t.n_work_id || ')')
        into cur_data
        from lcbase.t_user t
       where t.c_user_id = UserId;
    
    else
    
      select t.v_user_name
        into cur_data
        from lcbase.t_user t
       where t.c_user_id = UserId;
    
    end if;
    return cur_data;
  END;
end PKG_TEST;
/

