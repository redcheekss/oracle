create package body PKG_USER_RESTTIME is

  -- Private type declarations
  --type <TypeName> is <Datatype>;

  -- Private constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Private variable declarations
  --<VariableName> <Datatype>;
  i number(1);

  function getHolidayDuration(cUserId    in varchar2,
                              dStartTime in Date,
                              dEndTime   in Date,
                              nDays      out number,
                              nTimes     out number,
                              vErrMsg    out varchar2) return number is
    n_days      number(4) := 0;
    d_firstDay  Date;
    d_lastDay   Date;
    n_restTimes number(4) := 0;
    n_restDays  number(4) := 0;
  begin
    d_firstDay := trunc(dStartTime, 'dd');
    d_lastDay  := trunc(dEndTime, 'dd');
    nDays      := 0;
    nTimes     := 0;
    n_days     := d_lastDay - d_firstDay;

    if (dStartTime > dEndTime) then
      raise pkg_common.EXP_PARAM;
    else
      if n_days = 0 then
        --请假1天以内
        n_restDays  := 0;
        n_restTimes := 0;
        getFirstDayTimes(cUserId       => cUserId,
                         dFirstDayTime => dStartTime,
                         dLastDayTime  => dEndTime,
                         nRestDays     => n_restDays,
                         nRestTimes    => n_restTimes);
        nDays  := n_restDays;
        nTimes := n_restTimes;
        return 0;
      else
        --跨天请假 & 超过2天以上合并处理首日和末日
        n_restDays  := 0;
        n_restTimes := 0;
        getFirstDayTimes(cUserId       => cUserId,
                         dFirstDayTime => dStartTime,
                         dLastDayTime  => dEndTime,
                         nRestDays     => n_restDays,
                         nRestTimes    => n_restTimes);
        nDays  := nDays + n_restDays;
        nTimes := nTimes + n_restTimes;
        getLastDayTimes(cUserId      => cUserId,
                        dLastDayTime => dEndTime,
                        nRestDays    => n_restDays,
                        nRestTimes   => n_restTimes);
        nDays  := nDays + n_restDays;
        nTimes := nTimes + n_restTimes;
        if (n_days >= 2) then
          --超过2天以上请假
          getRestDays(d_firstDay + 1, d_lastDay - 1, n_restDays);
          nDays := n_days - 1 - n_restDays + nDays;
        end if;
        return 0;
      end if;
    end if;
  exception
    when others then
      vErrMsg := 'getHolidayDuration: ' || SQLCODE || ',' || SQLERRM || ',' ||
                 DBMS_UTILITY.format_error_backtrace;
      return - 1;
  end;

  -- Function and procedure implementations
  procedure getTodayOndutyTime(cUserId in varchar2, dOndutyTime out Date) is
    d_ondutyTime Date;
  begin
    select min(uc.usercheckdate)
      into d_ondutyTime
      from lcbase.t_zip_user              u,
           lcoa.t_user_ding_user_rel  ur,
           lcoa.t_user_ding_card_flow uc
     where u.c_user_id = ur.c_user_id
       and ur.c_ding_userid = uc.userid
       and u.c_user_id = cUserId
       and u.d_enddate > sysdate
       and uc.usercheckdate >= trunc(sysdate, 'dd')
       and lower(uc.checktype) = 'onduty';
    dOndutyTime := d_ondutyTime;
  end;

  procedure getRestDays(dStartTime in Date,
                        dEndTime   in Date,
                        nRestDays  out number) is
  begin
    select count(*)
      into nRestDays
      from lcoa.oa_calendar_restday t
     where t.d_rest_day between dStartTime and dEndTime
       and t.n_rest_type = 2;
  end;

  function checkLecarWorkRestDay(dCheckDay in Date) return number is
    n_restType number(1);
  begin
    select t.n_rest_type
      into n_restType
      from lcoa.oa_calendar_restday t
     where trunc(t.d_rest_day, 'dd') = trunc(dCheckDay, 'dd');
    return n_restType; --按数据库中定义返回即可
  exception
    --日期不在定义列表则认为法定工作日，确定为乐卡正常工作日
    WHEN NO_DATA_FOUND THEN
      return 0;
    WHEN OTHERS THEN
      RAISE;
  end;

  procedure getFirstDayTimes(cUserId       in varchar2,
                             dFirstDayTime in Date,
                             dLastDayTime  in Date,
                             nRestDays     out number,
                             nRestTimes    out number) is
    n_restDays      number(4);
    n_restTimes     number(4);
    n_firstDayType  number(1);
    d_startWorkTime Date;
    d_endWorkTime   Date;
    d_endTime       Date;
    d_startTime     Date;
  begin
    n_restDays     := 0;
    n_restTimes    := 0;
    n_firstDayType := checkLecarWorkRestDay(dFirstDayTime);
    d_startTime := trunc(dFirstDayTime, 'dd') +
                     numtodsinterval(9, 'hour');
  
    case
      when n_firstDayType = 2 then
        n_restDays  := 0;
        n_restTimes := 0;
      when n_firstDayType = 1 then
        d_endTime := trunc(dFirstDayTime, 'dd') +
                     numtodsinterval(18, 'hour');
        if dLastDayTime < d_endTime then
          d_endTime := dLastDayTime;
        end if;
        calLecarWorkDayRestTimes(dFirstDayTime, d_endTime, n_restTimes);
        if n_restTimes = 6 then
          n_restDays  := n_restDays + 1;
          n_restTimes := 0;
        end if;
      when n_firstDayType = 0 then
        /*       if (trunc(dFirstDayTime, 'dd') = trunc(dLastDayTime, 'dd')) then
          buildWorkDayWorkTime(cUserId,
                               dLastDayTime,
                               d_startWorkTime,
                               d_endWorkTime);
        else
          buildWorkDayWorkTime(cUserId,
                               dFirstDayTime,
                               d_startWorkTime,
                               d_endWorkTime);
        end if;*/
        
        buildWorkDayWorkTime(cUserId,
                             d_startTime,
                             d_startWorkTime,
                             d_endWorkTime);
        if dLastDayTime < d_endWorkTime then
          d_endWorkTime := dLastDayTime;
        end if;
        calWorkDayRestTimes(d_startWorkTime,
                            d_endWorkTime,
                            dFirstDayTime,
                            d_endWorkTime,
                            n_restTimes);
        if n_restTimes = 7 then
          n_restDays  := 1;
          n_restTimes := 0;
        end if;
    end case;
    nRestDays  := n_restDays;
    nRestTimes := n_restTimes;
  end;
  procedure getLastDayTimes(cUserId      in varchar2,
                            dLastDayTime in Date,
                            nRestDays    out number,
                            nRestTimes   out number) is
    n_restDays      number(4);
    n_restTimes     number(4);
    n_lastDayType   number(1);
    d_startWorkTime Date;
    d_endWorkTime   Date;
  begin
    n_restDays    := 0;
    n_restTimes   := 0;
    n_lastDayType := checkLecarWorkRestDay(dLastDayTime);
    case
      when n_lastDayType = 2 then
        n_restDays  := 0;
        n_restTimes := 0;
      when n_lastDayType = 1 then
        calLecarWorkDayRestTimes(trunc(dLastDayTime, 'dd') +
                                 numtodsinterval(10, 'hour'),
                                 dLastDayTime,
                                 n_restTimes);
        if n_restTimes = 6 then
          n_restDays  := 1;
          n_restTimes := 0;
        end if;
      when n_lastDayType = 0 then
        buildWorkDayWorkTime(cUserId,
                             trunc(dLastDayTime, 'dd') +
                                 numtodsinterval(9, 'hour'),
                             d_startWorkTime,
                             d_endWorkTime);
        if dLastDayTime < d_endWorkTime then
          d_endWorkTime := dLastDayTime;
        end if;
        calWorkDayRestTimes(d_startWorkTime,
                            d_endWorkTime,
                            trunc(dLastDayTime, 'dd') +
                            numtodsinterval(9, 'hour'),
                            d_endWorkTime,
                            n_restTimes);
        if n_restTimes = 7 then
          n_restDays  := 1;
          n_restTimes := 0;
        end if;
    end case;
    nRestDays  := n_restDays;
    nRestTimes := n_restTimes;
  end;
  procedure calLecarWorkDayRestTimes(dStartTime in Date,
                                     dEndTime   in Date,
                                     nRestTimes out number) is
    d_startWorkTime      date; --工作开始时间
    d_startNoonBreakTime date; --午休开始时间
    d_endNoonBreakTime   date; --午休结束时间
    d_endWorkTime        date; --工作结束时间
  begin
    --乐卡周末工作日
    --周末工作日时间固定，不需要判断打卡时间
    d_startWorkTime      := trunc(dStartTime, 'dd') +
                            numtodsinterval(10, 'hour');
    d_startNoonBreakTime := trunc(dStartTime, 'dd') +
                            numtodsinterval(11, 'hour') +
                            numtodsinterval(30, 'minute');
    d_endNoonBreakTime   := trunc(dStartTime, 'dd') +
                            numtodsinterval(14, 'hour') +
                            numtodsinterval(30, 'minute');
    d_endWorkTime        := trunc(dStartTime, 'dd') +
                            numtodsinterval(18, 'hour');

    if (dEndTime <= dStartTime) then
      nRestTimes := 0;
    else

      if (dStartTime <= d_startWorkTime) then

        if (dEndTime between d_startWorkTime and d_startNoonBreakTime) then
          --上午部分休
          nRestTimes := ceil((dEndTime - d_startWorkTime) * 24);
        elsif dEndTime between d_startNoonBreakTime and d_endNoonBreakTime then
          --上午休半天
          nRestTimes := ceil((d_startNoonBreakTime - d_startWorkTime) * 24);
        elsif dEndTime between d_endNoonBreakTime and d_endWorkTime then
          --上午半天+下午部分
          nRestTimes := ceil((d_startNoonBreakTime - d_startWorkTime) * 24) +
                        ceil((dEndTime - d_endNoonBreakTime) * 24);
        elsif dEndTime > d_endWorkTime then
          --全天
          nRestTimes := ceil((d_startNoonBreakTime - d_startWorkTime) * 24) +
                        ceil((d_endWorkTime - d_endNoonBreakTime) * 24);
        else
          nRestTimes := 9;
        end if;
      elsif (dStartTime between d_startWorkTime and d_startNoonBreakTime) then
        --上午部分休
        if (dEndTime between d_startWorkTime and d_startNoonBreakTime) then
          --上午部分休
          nRestTimes := ceil((dEndTime - dStartTime) * 24);
        elsif dEndTime between d_startNoonBreakTime and d_endNoonBreakTime then
          --上午休半天
          nRestTimes := ceil((d_startNoonBreakTime - dStartTime) * 24);
        elsif dEndTime between d_endNoonBreakTime and d_endWorkTime then
          --上午半天+下午部分
          nRestTimes := ceil((d_startNoonBreakTime - dStartTime) * 24) +
                        ceil((dEndTime - d_endNoonBreakTime) * 24);
        elsif dEndTime > d_endWorkTime then
          --全天
          nRestTimes := ceil((d_startNoonBreakTime - dStartTime) * 24) +
                        ceil((d_endWorkTime - d_endNoonBreakTime) * 24);
        else
          nRestTimes := 9;
        end if;
      elsif (dStartTime between d_startNoonBreakTime and d_endNoonBreakTime) then
        --下午开始休
        if (dEndTime between d_startWorkTime and d_startNoonBreakTime) then
          --上午部分休
          nRestTimes := ceil((dEndTime - dStartTime) * 24);
        elsif dEndTime between d_startNoonBreakTime and d_endNoonBreakTime then
          --上午休半天
          nRestTimes := ceil((d_startNoonBreakTime - dStartTime) * 24);
        elsif dEndTime between d_endNoonBreakTime and d_endWorkTime then
          --上午半天+下午部分
          nRestTimes := ceil((d_startNoonBreakTime - dStartTime) * 24) +
                        ceil((dEndTime - d_endNoonBreakTime) * 24);
        elsif dEndTime > d_endWorkTime then
          --全天
          nRestTimes := ceil((d_startNoonBreakTime - dStartTime) * 24) +
                        ceil((d_endWorkTime - d_endNoonBreakTime) * 24);
        else
          nRestTimes := 9;
        end if;
      elsif (dStartTime between d_endNoonBreakTime and d_endWorkTime) then
        --下午部分休
        if dEndTime between d_endNoonBreakTime and d_endWorkTime then
          --上午半天+下午部分
          nRestTimes := ceil((dEndTime - dStartTime) * 24);
        elsif dEndTime > d_endWorkTime then
          --全天
          nRestTimes := ceil((d_endWorkTime - dStartTime) * 24);
        else
          nRestTimes := 9;
        end if;
      end if;
    end if;
  end;
  procedure calWorkDayRestTimes(dStartWorkTime in Date,
                                dEndWorkTime   in Date,
                                dStartTime     in Date,
                                dEndTime       in Date,
                                nRestTimes     out number) is
    d_startWorkTime      date; --工作开始时间
    d_startNoonBreakTime date; --午休开始时间
    d_endNoonBreakTime   date; --午休结束时间
    d_endWorkTime        date; --工作结束时间
  begin
    --乐卡周末工作日
    --周末工作日时间固定，不需要判断打卡时间
    d_startWorkTime      := dStartWorkTime;
    d_startNoonBreakTime := trunc(dStartTime, 'dd') +
                            numtodsinterval(12, 'hour');
    d_endNoonBreakTime   := trunc(dStartTime, 'dd') +
                            numtodsinterval(14, 'hour');
    d_endWorkTime        := dEndWorkTime;
/*
    dbms_output.put_line('d_startWorkTime:' ||
                         to_char(d_startWorkTime, 'yyyy-mm-dd hh24:mi'));
    dbms_output.put_line('d_startNoonBreakTime:' ||
                         to_char(d_startNoonBreakTime,
                                 'yyyy-mm-dd hh24:mi'));
    dbms_output.put_line('d_endNoonBreakTime:' ||
                         to_char(d_endNoonBreakTime, 'yyyy-mm-dd hh24:mi'));
    dbms_output.put_line('d_endWorkTime:' ||
                         to_char(d_endWorkTime, 'yyyy-mm-dd hh24:mi'));
    dbms_output.put_line('dStartTime:' ||
                         to_char(dStartTime, 'yyyy-mm-dd hh24:mi'));
    dbms_output.put_line('dEndTime:' ||
                         to_char(dEndTime, 'yyyy-mm-dd hh24:mi'));
*/
    if (dEndTime <= dStartTime) then
      nRestTimes := 0;
    else
      if (dStartTime < d_startWorkTime) then
        if (dEndTime between d_startWorkTime and d_startNoonBreakTime) then
          --上午部分休
          nRestTimes := ceil((dEndTime - d_startWorkTime) * 24);
        elsif dEndTime between d_startNoonBreakTime and d_endNoonBreakTime then
          --上午休半天
          nRestTimes := ceil((d_startNoonBreakTime - d_startWorkTime) * 24);
        elsif dEndTime between d_endNoonBreakTime and d_endWorkTime then
          --上午半天+下午部分
          nRestTimes := ceil((dEndTime - d_startWorkTime) * 24) - 2; --剔除2小时休息时间
        elsif dEndTime > d_endWorkTime then
          --全天
          nRestTimes := ceil((d_endWorkTime - d_startWorkTime) * 24) - 2;
        else
          nRestTimes := 9;
        end if;
      elsif (dStartTime between d_startWorkTime and d_startNoonBreakTime) then
        --上午部分休
        if (dEndTime < d_startWorkTime) then
          nRestTimes := 0;
        elsif (dEndTime between d_startWorkTime and d_startNoonBreakTime) then
          --上午部分休
          nRestTimes := ceil((dEndTime - dStartTime) * 24);
        elsif dEndTime between d_startNoonBreakTime and d_endNoonBreakTime then
          --上午休半天
          nRestTimes := ceil((d_startNoonBreakTime - dStartTime) * 24);
        elsif dEndTime between d_endNoonBreakTime and d_endWorkTime then
          --上午半天+下午部分
          nRestTimes := ceil((dEndTime - dStartTime) * 24) - 2;
        elsif dEndTime > d_endWorkTime then
          --全天
          nRestTimes := ceil((d_endWorkTime - dStartTime) * 24) - 2;
        else
          nRestTimes := 9;
        end if;
      elsif (dStartTime between d_startNoonBreakTime and d_endNoonBreakTime) then
        --下午开始休
        if dEndTime between d_startNoonBreakTime and d_endNoonBreakTime then
          nRestTimes := 0;
        elsif dEndTime between d_endNoonBreakTime and d_endWorkTime then
          --上午半天+下午部分
          nRestTimes := ceil((dEndTime - d_endNoonBreakTime) * 24);
        elsif dEndTime > d_endWorkTime then
          --全天
          nRestTimes := ceil((d_endWorkTime - d_endNoonBreakTime) * 24);
        else
          nRestTimes := 9;
        end if;
      elsif (dStartTime between d_endNoonBreakTime and d_endWorkTime) then
        --下午部分休
        if dEndTime between d_endNoonBreakTime and d_endWorkTime then
          --上午半天+下午部分
          nRestTimes := ceil((dEndTime - dStartTime) * 24);
        elsif dEndTime > d_endWorkTime then
          --全天
          nRestTimes := ceil((d_endWorkTime - dStartTime) * 24);
        else
          nRestTimes := 9;
        end if;
      end if;
    end if;
  end;

  procedure buildWorkDayWorkTime(cUserId        in varchar2,
                                 dWorkTime      in Date,
                                 dStartWorkTime out Date,
                                 dEndWorkTime   out Date) is
    d_workDay    Date;
    d_workTime   Date;
    d_ondutyTime Date;
  begin
    d_workTime := dWorkTime;
    d_workDay  := trunc(dWorkTime, 'dd');

    --申请日当日
    if (d_workDay = trunc(sysdate, 'dd')) then
      getTodayOndutyTime(cUserId, dOndutyTime => d_ondutyTime);
      if d_ondutyTime is not null then
        d_workTime := d_ondutyTime;
      end if;
    end if;

    if (d_workTime <= d_workDay + numtodsinterval(9, 'hour')) then
      dStartWorkTime := d_workDay + numtodsinterval(9, 'hour');
      dEndWorkTime   := d_workDay + numtodsinterval(18, 'hour');
    elsif (d_workTime > d_workDay + numtodsinterval(10, 'hour')) then
      dStartWorkTime := d_workDay + numtodsinterval(10, 'hour');
      dEndWorkTime   := d_workDay + numtodsinterval(19, 'hour');
    else
      dStartWorkTime := d_workTime;
      dEndWorkTime   := d_workTime + numtodsinterval(9, 'hour');
    end if;
  end;

--此块进行变量初始化，可删除
begin
  -- Initialization
  i := 1;
end PKG_USER_RESTTIME;
/

