create package body pkg_ins_dept_info is

  --更新记录操作
  function HISTORY_TABLE_LOG(OperationDataId       in varchar2, --更新数据ID
                             OperationIdColumnName in varchar2, --更新ID字段名
                             OperationTableName    in varchar2, --更新表名
                             OperationType         in varchar2, --操作类型0新增1更改
                             OperationUserId       IN VARCHAR2,
                             ErrMsg                out varchar2)
    return number is
    DATAARRA     PKG_COMMON.ARR_LONGSTR;
    DATAARRB     PKG_COMMON.ARR_LONGSTR;
    DATAARRC     PKG_COMMON.ARR_LONGSTR;
    DATAARRD     PKG_COMMON.ARR_LONGSTR;
    DATAARRE     PKG_COMMON.ARR_LONGSTR;
    H_ID         CHAR(32);
    D_COUNT      NUMBER(6);
    v_sql_insert varchar2(2000);
    v_sql_one    varchar2(2000);
    v_sql_two    varchar2(2000);
  BEGIN
    BEGIN
      DATAARRA := PKG_COMMON.Split(OperationDataId, '^');
      DATAARRB := PKG_COMMON.Split(OperationIdColumnName, '^');
      DATAARRC := PKG_COMMON.Split(OperationTableName, '^');
      DATAARRD := PKG_COMMON.Split(OperationType, '^');
      H_ID     := LOWER(SYS_GUID());
      --修改表总数量
      D_COUNT := DATAARRB.count;
      --sql_one
      /* select 'v_id,V_OPERATION_ID,V_OPERATION_TYPE,V_OPERATION_TIME,'|| 
      listagg (column_name, ',') WITHIN GROUP (ORDER BY column_name)
      into v_sql_one
      from all_tab_columns 
      where table_name=upper(''|| DATAARRC(i)||'_HISTORY' ||'') and owner='LCBASE';
      */
      for i in 1 .. D_COUNT loop
        DATAARRE:=PKG_COMMON.Split(DATAARRC(i), '.');
        v_sql_two:='v_id,V_OPERATION_ID,V_OPERATION_TYPE,V_OPERATION_TIME,';
        --sql_one
        select listagg(column_name, ',') WITHIN GROUP(ORDER BY column_name)
        into   v_sql_one
        from   all_tab_columns
        where  table_name = upper('' || DATAARRE(2) || '')--t_organization t_zip_organization
        and    owner = 'LCBASE';
        v_sql_insert := 'insert into ' || DATAARRC(i) || '_HISTORY' || '   
        (' ||v_sql_two|| v_sql_one ||
                        ')
        (
         select * from
         (select LOWER(SYS_GUID()),''' ||
                        OperationUserId || ''',' || DATAARRD(i) ||
                        ' , sysdate from dual)
         left join
         (select '||v_sql_one||' from  ' || DATAARRC(i) || '
         where ' || DATAARRB(i) || '=''' ||
                        DATAARRA(i) || '''
         and D_ENDDATE > sysdate )
         on 1=1)';
        execute immediate v_sql_insert;
      end loop;
      return 0;
    end;
  end;

  --新增部门
  function insert_children_organization(DataInfo        in varchar2, --新增的部门名称^父部门ID^LEVEL
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增部门ID
                                        ErrMsg          out varchar2)
    return number is
    DATAARR  PKG_COMMON.ARR_LONGSTR;
    P_ID     CHAR(32);
    P_STEP   NUMBER(2);
    P_OPTYPE NUMBER(1) := 1;
    P_SORT   number(3);
    n_result number(3);
    n_status number(3);
  BEGIN
    BEGIN
      
      P_STEP  := 0;
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      P_ID    := LOWER(SYS_GUID());
      --查看副部们状态
      select t.n_status
      into   n_status
      from   lcbase.t_zip_organization t
      where  t.C_ORGANIZATION_ID = DATAARR(2)
      and t.d_enddate>sysdate;
      if n_status = 0 then
        --排序默认序号
        select (count(*) + 1)
        into   P_SORT
        from   lcbase.t_zip_organization t
        where  t.C_ORGANIZATION_PARENT_ID = DATAARR(2)
        and    t.n_status = 0
        and t.d_enddate>sysdate;
        --新增开始
        INSERT INTO lcbase.t_zip_organization
          (select sysdate,
                  to_date('9999-12-31','yyyy-mm-dd'),
                  P_ID,
                  DATAARR(1), --部门名称
                  DATAARR(2), --副本们ID
                  DATAARR(3), --level
                  DATAARR(4), --type
                  '', --OWNER
                  0, --status
                  DATAARR(1), --简称
                  '', --BP
                  P_SORT, --排序
                  '' --VP
           from   lcbase.t_zip_organization t
           where  t.c_organization_id = DATAARR(2)
           and t.d_enddate > sysdate
           );
        --新增结束
        DataId := P_ID;
        --更改记录日志
        n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(P_ID,
                                                             'C_ORGANIZATION_ID',
                                                             'LCBASE.T_zip_ORGANIZATION',
                                                             '0',
                                                             OperationUserId,
                                                             ErrMsg);
        COMMIT;
        return 0;
      else
        return - 1;
        ErrMsg := '此部门异常,无法添加子部门';
      end if;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '新增/更新组织信息失败';
        ROLLBACK;
        return - 1;
    END;
  END;

  --修改部门名称
  function update_children_organization(DataInfo        in varchar2, --部门名称^部门id^lEvel^type
                                        OperationUserId IN VARCHAR2,
                                        ErrMsg          out varchar2)
    return number is
    DATAARR  PKG_COMMON.ARR_LONGSTR;
    P_ID     CHAR(32);
    P_STEP   NUMBER(2);
    P_OPTYPE NUMBER(1) := 1;
    P_SORT   number(3);
    n_result number(3);
    update_count Date;
    current_time Date;
  begin
    begin
      current_time:= sysdate;
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      --判断是否是当天首次修改
      --查最新数据的起始时间是否是当天
      begin 
        select 
        D_STARTDATE 
        into update_count 
        from lcbase.t_zip_organization
        where C_ORGANIZATION_ID = DATAARR(2)
        and trunc(D_startdate)= trunc(sysdate);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
        update_count := NULL;
      end;
      --判断开始 if起始日期是当天，则不是当天首次修改 直接修改最新记录
      if trunc(update_count) = trunc(current_time) then 
         --修改开始
         UPDATE lcbase.t_zip_organization o
         SET    V_ORGANIZATION_NAME    = DATAARR(1),
                v_organization_abbname = DATAARR(1),
                n_organization_level   = DATAARR(3),
                n_organization_type    = DATAARR(4)
         WHERE  C_ORGANIZATION_ID = DATAARR(2)
         and D_ENDDATE > sysdate;
         --修改结束
      else--起始日期不是当天，则是当天首次修改，先更新有效期，再新增,再修改
         --更新原始数据有效期时间
         UPDATE lcbase.t_zip_organization o
         SET    D_ENDDATE    = current_time
         WHERE  o.c_organization_id= DATAARR(2)
         and    D_ENDDATE > sysdate;
         
         --新增开始
         insert into lcbase.t_zip_organization o
         (
           select sysdate,
                  to_date('9999-12-31','yyyy-mm-dd'),
                  o.c_organization_id,
                  DATAARR(1),
                  o.c_organization_parent_id,
                  DATAARR(3),
                  DATAARR(4),
                  o.c_organization_owner,
                  o.n_status,
                  DATAARR(1),
                  o.c_organization_bp,
                  o.n_order,
                  o.c_organization_po 
           from lcbase.t_zip_organization o
           where C_ORGANIZATION_ID = DATAARR(2)
           and D_ENDDATE= current_time
         );
         
         --更新最新记录
        /* update lcbase.t_zip_organization 
         SET    V_ORGANIZATION_NAME    = DATAARR(1),
                v_organization_abbname = DATAARR(1),
                n_organization_level   = DATAARR(3),
                n_organization_type    = DATAARR(4),
                D_STARTDATE            = sysdate,
                D_ENDDATE              = to_date('9999-12-31','yyyy-mm-dd')
         WHERE  C_ORGANIZATION_ID = DATAARR(2)
         and    D_ENDDATE= current_time
         and    rownum= 1;*/
         
      end if;
      --修改结束
      --更改记录日志
      n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(DATAARR(2),
                                                           'C_ORGANIZATION_ID',
                                                           'LCBASE.T_zip_ORGANIZATION',
                                                           '1',
                                                           OperationUserId,
                                                           ErrMsg);
      COMMIT;
      return 0;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '新增/更新组织信息失败';
        ROLLBACK;
        return - 1;
    END;
  END;

  --修改部门BP,VP
  function update_organization_leader(DataInfo in varchar2, --部门id^负责人id^
                                      --负责人类型1负责人 2 BP 3 VP
                                      OperationUserId IN VARCHAR2,
                                      ErrMsg          out varchar2)
    return number is
    DATAARR  PKG_COMMON.ARR_LONGSTR;
    P_ID     CHAR(32);
    P_STEP   NUMBER(2);
    P_OPTYPE NUMBER(1) := 1;
    P_SORT   number(3);
    n_result number(3) := 0;
    n_level  number(3);
    update_count Date;
    current_time Date;
    v_colunmName varchar2(100);
  begin
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      current_time := sysdate;
      --判断是否是当天首次修改
      --查最新数据的起始时间是否是当天
      begin 
      select 
      D_STARTDATE 
      into update_count 
      from lcbase.t_zip_organization
      where C_ORGANIZATION_ID = DATAARR(1)
      and trunc(D_startdate)= trunc(sysdate);    
      EXCEPTION
      WHEN NO_DATA_FOUND THEN
      update_count := NULL;
      end;
      --查询部门等级
      select o.n_organization_level
      into   n_level
      from   lcbase.t_zip_organization o
      where  o.c_organization_id = DATAARR(1)
      and D_ENDDATE > sysdate;
      --判断开始 if起始日期是当天，则不是当天首次修改 直接修改最新记录
      if trunc(update_count) = trunc(current_time) then 
        --设置部门负责人
        if DATAARR(3) = 1 then
          --修改开始
          UPDATE lcbase.t_zip_organization o
          SET    o.c_organization_owner = DATAARR(2)
          WHERE  C_ORGANIZATION_ID = DATAARR(1)
          and    D_ENDDATE > sysdate;
          --修改结束
          --设置部门BP
        elsif DATAARR(3) = 2 then
          --修改开始
          UPDATE lcbase.t_zip_organization o
          SET    o.c_organization_bp = DATAARR(2)
          WHERE  C_ORGANIZATION_ID = DATAARR(1)
          and D_ENDDATE > sysdate;
          --修改结束
          --设置部门VP
        else
          if n_level = 2 then
            --修改开始
            UPDATE lcbase.t_zip_organization o
            SET    o.c_organization_po = DATAARR(2)
            WHERE  C_ORGANIZATION_ID = DATAARR(1)
            and D_ENDDATE > sysdate;
            --修改结束
          else
            ErrMsg   := '非本部级别的部门不能设置PO~';
            n_result := -1;
          end if;
        end if;
      else--起始日期不是当天，则是当天首次修改，先更新有效期，再新增,再修改
        --修改有效期开始
          UPDATE lcbase.t_zip_organization o
          SET    o.d_enddate= current_time
          WHERE  C_ORGANIZATION_ID = DATAARR(1)
          and    D_ENDDATE > sysdate;
          
          /*insert into lcbase.t_zip_organization o
          (
           select * from lcbase.t_zip_organization o
           where C_ORGANIZATION_ID = DATAARR(1)
           and D_ENDDATE= current_time
          );*/
          insert into lcbase.t_zip_organization o
          (
           select sysdate,
                  to_date('9999-12-31','yyyy-mm-dd'),
                  o.c_organization_id,
                  o.v_organization_name,
                  o.c_organization_parent_id,
                  o.n_organization_level,
                  o.n_organization_type,
                  o.c_organization_owner,
                  o.n_status,
                  o.v_organization_abbname,
                  o.c_organization_bp,
                  o.n_order,
                  o.c_organization_po from lcbase.t_zip_organization o
           where C_ORGANIZATION_ID = DATAARR(1)
           and D_ENDDATE= current_time
          );
        --设置部门负责人
        if DATAARR(3) = 1 then
          --修改开始
          UPDATE lcbase.t_zip_organization o
          SET    o.c_organization_owner= DATAARR(2)
          WHERE  C_ORGANIZATION_ID = DATAARR(1)
          and D_ENDDATE >sysdate;
          /*insert into lcbase.t_zip_organization o
          (
           select sysdate,
                  to_date('9999-12-31','yyyy-mm-dd'),
                  o.c_organization_id,
                  o.v_organization_name,
                  o.c_organization_parent_id,
                  o.n_organization_level,
                  o.n_organization_type,
                  o.c_organization_owner,
                  o.n_status,
                  o.v_organization_abbname,
                  o.c_organization_bp,
                  o.n_order,
                  o.c_organization_po from lcbase.t_zip_organization o
           where C_ORGANIZATION_ID = DATAARR(1)
           and D_ENDDATE= current_time
          );*/
          --修改结束
          --设置部门BP
        elsif DATAARR(3) = 2 then
          --修改开始
          UPDATE lcbase.t_zip_organization o
          SET    o.c_organization_bp= DATAARR(2)
          WHERE  C_ORGANIZATION_ID = DATAARR(1)
          and D_ENDDATE >sysdate;
          --修改结束
          --设置部门VP
        else
          if n_level = 2 then
            --修改开始
            UPDATE lcbase.t_zip_organization o
            SET    o.c_organization_po = DATAARR(2)
            WHERE  C_ORGANIZATION_ID = DATAARR(1)
            and D_ENDDATE >sysdate;
            --修改结束
          else
            ErrMsg   := '非本部级别的部门不能设置PO~';
            n_result := -1;
          end if;
        end if;
      end if;
      if n_result = 0 then
        --更改记录日志
        n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(DATAARR(1),
                                                             'C_ORGANIZATION_ID',
                                                             'LCBASE.T_zip_ORGANIZATION',
                                                             '1',
                                                             OperationUserId,
                                                             ErrMsg);
      end if;
      COMMIT;
      return n_result;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '新增/更新组织信息失败';
    END;
    ROLLBACK;
    return - 1;
  END;

  --删除部门
  function delete_organization(OrganizationId  in varchar2, --部门id
                               OperationUserId IN VARCHAR2,
                               ErrMsg          out varchar2) return number is
    P_OPTYPE    NUMBER(1) := 4;
    n_result    number(3);
    P_c_dept    number(3); --子部门数量
    P_C_emp     number(3); --部门成员数量
    P_PARENT_ID varchar2(32); --副部们ID
    P_SORTNUM   number(3); --排序序号
    v_sql       varchar2(3000);
    --声明游标 排序序号
    v_organizationIds SYS_REFCURSOR; --游标类型
    V_countNumber     lcbase.t_zip_organization.c_organization_id%type;
    current_time Date;
    update_count Date;
  BEGIN
    BEGIN
      current_time :=sysdate;
      update_count :=sysdate;
      --计算部门下子部门数量
      select count(*)
      into   P_c_dept
      from   lcbase.t_zip_organization o
      left   join lcbase.t_zip_organization org
      on     o.c_organization_id = org.c_organization_parent_id
      where  org.c_organization_parent_id = OrganizationId
      and    org.D_ENDDATE > sysdate
      and    org.n_status = 0;
      --计算部门下人员情况
      select count(*)
      into   P_C_emp
      from   lcbase.t_zip_user u
      left join lcbase.t_employees_info info 
      on u.c_user_id=info.c_user_id
      where  u.c_organization_id = OrganizationId
      and    info.n_status=0
      and    u.D_ENDDATE > sysdate;
      n_result := -1;
      --查当前部门的副部们ID
      select org.c_organization_parent_id
      into   P_PARENT_ID
      from   lcbase.t_zip_organization org
      where  org.c_organization_id = OrganizationId
      and    D_ENDDATE > sysdate;
      --查当前排序序号
      select org.n_order
      into   P_SORTNUM
      from   lcbase.t_zip_organization org
      where  org.c_organization_id = OrganizationId
      and    D_ENDDATE > sysdate;
       --查最新数据的起始时间是否是当天
      begin 
        select 
        D_STARTDATE 
        into update_count 
        from lcbase.t_zip_organization
        where C_ORGANIZATION_ID = OrganizationId
        and trunc(D_startdate)= trunc(sysdate);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
        update_count := NULL;
      end;
      --判断开始 if起始日期是当天，则不是当天首次修改 直接修改最新记录
      
      if P_c_dept = 0 and P_C_emp = 0 then
        if trunc(update_count) = trunc(current_time) then 
        UPDATE lcbase.t_zip_organization o
        SET    n_status = 1
        WHERE  c_organization_id = OrganizationId
        and o.D_ENDDATE > sysdate;
        else--当天首次修改
        --更改数据有效期
        UPDATE lcbase.t_zip_organization o
        SET    o.d_enddate= current_time
        WHERE  c_organization_id = OrganizationId
        and    o.D_ENDDATE > sysdate;
        
        --插入数据
        insert into lcbase.t_zip_organization o
        (
           select sysdate,
                  to_date('9999-12-31','yyyy-mm-dd'),
                  o.c_organization_id,
                  o.v_organization_name,
                  o.c_organization_parent_id,
                  o.n_organization_level,
                  o.n_organization_type,
                  o.c_organization_owner,
                  1,
                  o.v_organization_abbname,
                  o.c_organization_bp,
                  o.n_order,
                  o.c_organization_po
           from lcbase.t_zip_organization o
           where C_ORGANIZATION_ID = OrganizationId
           and D_ENDDATE= current_time
         );
         end if;
        --逻辑删除部门开始
        /*UPDATE lcbase.t_zip_organization o
        SET    n_status = 1,

        WHERE  c_organization_id = OrganizationId
        and o.D_ENDDATE= current_time
        and rownum= 1;*/
        --逻辑删除部门结束
        n_result := 0;
        v_sql    := 'select org.c_organization_id
               from LCBASE.T_zip_ORGANIZATION org
               WHERE org.c_organization_parent_id = ''' ||
                    P_PARENT_ID || '''
               and org.N_ORDER > ' || P_SORTNUM || '
               and  org.D_ENDDATE > sysdate';
        --打开游标
        open v_organizationIds for v_sql;
        --提取游标数据
        fetch v_organizationIds
          into V_countNumber;
        while v_organizationIds%found loop
          --大于当前序号的，自动减一
          update LCBASE.T_zip_ORGANIZATION o
          SET    o.n_order = o.N_ORDER - 1
          WHERE  o.c_organization_id = V_countNumber;
          --更改记录日志(修改下游序号操作记录)
          n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(V_countNumber,
                                                               'C_ORGANIZATION_ID',
                                                               'LCBASE.T_zip_ORGANIZATION',
                                                               '2',
                                                               OperationUserId,
                                                               ErrMsg);
          --取出下一条
          fetch v_organizationIds
            into V_countNumber;
        end loop;
        --更改记录日志
        n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(OrganizationId,
                                                             'C_ORGANIZATION_ID',
                                                             'LCBASE.T_zip_ORGANIZATION',
                                                             '2',
                                                             OperationUserId,
                                                             ErrMsg);
        COMMIT;
      
      
      else
        ErrMsg := '请删除此部门下的成员或子部门后，再删除此部门';
      end if;
      if OrganizationId = '997c2b49b01d4bdba3c5ea4e0f615617' then
        ErrMsg := '根部门不允许删除';
      end if;
      RETURN n_result;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '删除组织信息失败';
    END;
    ROLLBACK;
    RETURN 1;
  END;
  
  /*FUNCTION Update_User(PUserInfo         IN VARCHAR2,
                       OperationUserId   IN VARCHAR2,
                       UserId            IN OUT VARCHAR2,
                       V_ORGANIZATION_ID out char,
                       ErrMsg            OUT VARCHAR2) RETURN NUMBER IS
    DATAARR       PKG_COMMON.ARR_LONGSTR;
    P_ID          CHAR(32);
    P_STEP        NUMBER(2);
    n_optype      number(1);
    n_result      number(1) := 0;
    ErrMsg2       varchar2(50);
    row_count     integer;
    v_work_number NUMBER(6, 0);
    rowEmail      number(5);
    email         varchar(30);
    workNum       number(6);
  BEGIN
    BEGIN
      P_STEP  := 0;
      DATAARR := PKG_COMMON.Split(PUserInfo, '^');
      P_ID    := DATAARR(1);
      IF P_ID IS NULL THEN
        P_ID := LOWER(SYS_GUID());
        --判断手机号是否存在
        n_result := pkg_user.is_phones_exists_insert(DATAARR(7), ErrMsg);
        if n_result = -1 then
          return - 1;
        end if;
        --判断手机号是否存在2
        n_result := pkg_user.is_phones_exists2_insert(DATAARR(8), ErrMsg);
        if n_result = -1 then
          return - 1;
        end if;
        /*n_result := pkg_user.is_EMAIL_exists_insert(DATAARR(12), ErrMsg);
        if n_result = -1 then
          return - 1;
        end if;
        *//*
        if DATAARR(21) is null then
          ErrMsg := '用户汉语拼音无值！';
          return - 1;
        end if;
        email := DATAARR(21) || '@lecarlink.com';
        select count(*)
        into   rowEmail
        from   lcbase.t_zip_user tu
        where  tu.v_email = email
        and tu.d_enddate>sysdate;
        if rowEmail > 0 then
          select max(n_work_num) - 1
          into   workNum
          from   lcbase.t_employees_info;
          email := DATAARR(21) || workNum || '@lecarlink.com';
        end if;
        INSERT INTO LCBASE.T_zip_USER
          (d_startdate,
           d_enddate,
           C_USER_ID,
           C_ORGANIZATION_ID,
           V_USER_NAME,
           N_USER_TYPE,
           N_WORK_ID,
           V_PET_NAME,
           N_MOBILE_1,
           N_MOBILE_2,
           V_TEL_1,
           V_TEL_2,
           N_STATUS,
           V_EMAIL,
           C_PASSWORD,
           V_WX_OPEN_ID,
           V_WORK_WX_ACCOUNT,
           N_SEX,
           N_AUTHORITY,
           N_WORK_WX_ACTIVATION,
           V_HEADPIC_ALY,
           N_KINDOFWORK,
           V_FULLNAME_ZH)
        values
          (sysdate,
           to_date('9999-12-31','yyyy-mm-dd'),
           P_ID,
           DATAARR(2),
           DATAARR(3),
           DATAARR(4),
           DATAARR(5),
           DATAARR(3),
           DATAARR(7),
           DATAARR(8),
           DATAARR(9),
           DATAARR(10),
           0, --（用户状态-默认为0 可用）DATAARR(11),
           email,
           lower(md5('lecarlink2020')), --DATAARR(13),
           DATAARR(14),
           DATAARR(15),
           DATAARR(16),
           DATAARR(17),
           DATAARR(18),
           DATAARR(19),
           DATAARR(20),
           DATAARR(21));
        --commit;
        UserId            := P_ID;
        V_ORGANIZATION_ID := DATAARR(2);
        ErrMsg            := '插入成功';
        RETURN 0;
      ELSE
        n_result := pkg_user.is_phones_exists(DATAARR(7), UserId, ErrMsg);
        if n_result = -1 then
          return - 1;
        end if;
        n_result := pkg_user.is_phones_exists2(DATAARR(8), UserId, ErrMsg);
        if n_result = -1 then
          return - 1;
        end if;
        n_result := pkg_user.is_EMAIL_exists(DATAARR(12), UserId, ErrMsg);
        if n_result = -1 then
          return - 1;
        end if;
        if DATAARR(21) is null then
          ErrMsg := '用户汉语拼音无值！';
          return - 1;
        end if;
        UPDATE lcbase.T_USER
        set    C_ORGANIZATION_ID = DATAARR(2),
               V_USER_NAME       = DATAARR(3),
               N_USER_TYPE       = DATAARR(4),
               N_WORK_ID         = DATAARR(5),
               V_PET_NAME        = DATAARR(6),
               N_MOBILE_1        = DATAARR(7),
               N_MOBILE_2        = DATAARR(8),
               V_TEL_1           = DATAARR(9),
               V_TEL_2           = DATAARR(10),
               N_STATUS          = DATAARR(11),
               V_EMAIL           = DATAARR(12), 
               --C_PASSWORD           = lcbase.md5(DATAARR(13)),
               V_WX_OPEN_ID         = DATAARR(14),
               V_WORK_WX_ACCOUNT    = DATAARR(15),
               N_SEX                = DATAARR(16),
               N_AUTHORITY          = DATAARR(17),
               N_WORK_WX_ACTIVATION = DATAARR(18),
               V_HEADPIC_ALY        = DATAARR(19),
               N_KINDOFWORK         = DATAARR(20),
               V_FULLNAME_ZH        = DATAARR(21)
        WHERE  C_USER_ID = UserId;
      END IF;
      --commit;
      ErrMsg := '更新成功';
      RETURN 0;
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        raise_application_error(lcoa.pkg_common.g_errcode_exception, ErrMsg,
                                false);
        ROLLBACK;
        return - 1;
    END;
    return - 1;
  END;
  */
  FUNCTION Delete_User(UserId          IN VARCHAR2,
                       OperationUserId IN VARCHAR2,
                       ErrMsg          OUT VARCHAR2) RETURN NUMBER IS
    n_optype number(1);
    n_result number(1) := 0;
    count_date date;
    current_date date;
  BEGIN
    BEGIN
      current_date:= sysdate;
      n_optype := 4;
      --判断是否是当天首次修改
      --查最新数据的起始时间是否是当天
      begin 
        select 
        D_STARTDATE 
        into count_date  
        from lcbase.t_zip_user u
        where C_USER_ID = UserId
        and trunc(D_startdate)= trunc(sysdate);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
        count_date := NULL;
      end; 
      --判断开始 if起始日期是当天，则不是当天首次修改 直接修改最新记录
      if trunc(count_date) = trunc(current_date) then 
      UPDATE lcbase.T_zip_USER 
      SET N_STATUS = 1 
      WHERE C_USER_ID = UserId
      and d_enddate > sysdate;
      else--首次修改
      --先修改保质期
      UPDATE lcbase.T_zip_USER u
      SET d_enddate = current_date 
      WHERE C_USER_ID = UserId
      and d_enddate > sysdate;
      --新增
      insert into lcbase.T_zip_USER
      (
      select  sysdate,
              to_date('9999-12-31','yyyy-mm-dd'),
              u.c_user_id,
              u.c_organization_id,
              u.v_user_name,
              u.n_user_type,
              u.v_pet_name,
              u.n_mobile_1,
              u.n_mobile_2,
              u.v_tel_1,
              u.v_tel_2,
              1,
              u.v_email,
              u.c_password,
              u.v_wx_open_id,
              u.v_work_wx_account,
              u.n_sex,
              u.n_authority,
              u.n_work_wx_activation,
              u.v_headpic_aly,
              u.n_work_id,
              u.n_kindofwork,
              u.v_fullname_zh,
							u.n_work_status
      from lcbase.T_zip_USER u
      where C_USER_ID = UserId
      and d_enddate = current_date
      );
      --修改数据
          
      end if;
      COMMIT;
      n_result := 1;
      PKG_COMMON.InsertOperationLog(OperationUserId, 'T_USER', n_optype,
                                    n_result);
      RETURN 0;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
        ROLLBACK;
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
        ROLLBACK;
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据' || ',' || DBMS_UTILITY.format_error_backtrace;
        ROLLBACK;
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字' || ',' || DBMS_UTILITY.format_error_backtrace;
        ROLLBACK;
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误' || ',' || DBMS_UTILITY.format_error_backtrace;
        ROLLBACK;
      WHEN OTHERS THEN
        ErrMsg := '删除用户信息失败: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        ROLLBACK;
    END;
    /* PKG_COMMON.InsertOperationLog(OperationUserId,
    'T_USER',
    n_optype,
    n_result);*/
    return - 1;
  END;
  FUNCTION Get_User(UserId          IN VARCHAR2,
                    OperationUserId IN VARCHAR2,
                    --       PUserInfo       OUT VARCHAR2,
                    CUR_DATA OUT SYS_REFCURSOR,
                    ErrMsg   OUT VARCHAR2) RETURN NUMBER IS
    n_result number(1) := 0;
  BEGIN
    BEGIN
      OPEN CUR_DATA FOR
        SELECT * FROM lcbase.t_zip_user 
        WHERE C_USER_ID = UserId
        and d_enddate > sysdate;
      n_result := 1;
      return 0;
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := '查询数据失败: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
    END;
    /* PKG_COMMON.InsertOperationLog(OperationUserId,
    'T_USER',
    1,
    n_result);*/
    RETURN - 1;
  END;

end pkg_ins_dept_info;
/

