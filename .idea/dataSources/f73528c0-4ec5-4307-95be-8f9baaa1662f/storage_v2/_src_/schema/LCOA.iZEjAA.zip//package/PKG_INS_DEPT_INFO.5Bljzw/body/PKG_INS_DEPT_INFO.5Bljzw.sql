create package body pkg_ins_dept_info is
  --更新记录操作
  function HISTORY_TABLE_LOG(OperationDataId       in varchar2, --更新数据ID
                             OperationIdColumnName in varchar2, --更新ID字段名
                             OperationTableName    in varchar2, --更新表名
                             OperationType         in varchar2, --操作类型0新增1更改
                             OperationUserId       IN VARCHAR2,
                             ErrMsg                out varchar2)
    return number is
    DATAARRA     PKG_COMMON.ARR_LONGSTR;
    DATAARRB     PKG_COMMON.ARR_LONGSTR;
    DATAARRC     PKG_COMMON.ARR_LONGSTR;
    DATAARRD     PKG_COMMON.ARR_LONGSTR;
    H_ID         CHAR(32);
    D_COUNT      NUMBER(6);
    v_sql_insert varchar2(2000);
  BEGIN
    BEGIN
      DATAARRA := PKG_COMMON.Split(OperationDataId, '^');
      DATAARRB := PKG_COMMON.Split(OperationIdColumnName, '^');
      DATAARRC := PKG_COMMON.Split(OperationTableName, '^');
      DATAARRD := PKG_COMMON.Split(OperationType, '^');
      H_ID     := LOWER(SYS_GUID());
      --修改表总数量
      D_COUNT := DATAARRB.count;

      for i in 1 .. D_COUNT loop
        v_sql_insert := 'insert into ' || DATAARRC(i) || '_HISTORY' || '(
         select * from
         (select LOWER(SYS_GUID())
         from  dual)
         left join
         (select * from  ' || DATAARRC(i) || '
         left join
         (select ''' || OperationUserId || ''',' ||
                        DATAARRD(i) || ' , sysdate from dual)
         on 1=1
         where ' || DATAARRB(i) || '=''' ||
                        DATAARRA(i) || '''
          )
         on 1=1)';
        execute immediate v_sql_insert;
      end loop;

      return 0;

    end;
  end;

  --新增部门
  function insert_children_organization(DataInfo        in varchar2, --新增的部门名称^父部门ID^LEVEL
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增部门ID
                                        ErrMsg          out varchar2)
    return number is
    DATAARR  PKG_COMMON.ARR_LONGSTR;
    P_ID     CHAR(32);
    P_STEP   NUMBER(2);
    P_OPTYPE NUMBER(1) := 1;
    P_SORT   number(3);
    n_result number(3);
    n_status number(3);
  BEGIN
    BEGIN
      P_STEP  := 0;
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      P_ID    := LOWER(SYS_GUID());

      --查看副部们状态
      select t.n_status into n_status from LCBASE.T_ORGANIZATION t
      where t.C_ORGANIZATION_ID = DATAARR(2);

      if n_status = 0 then
          --排序默认序号
          select (count(*) + 1)
            into P_SORT
            from
            lcbase.t_organization t
           where t.C_ORGANIZATION_PARENT_ID = DATAARR(2)
           and t.n_status=0;
          --新增开始
          INSERT INTO LCBASE.T_ORGANIZATION
            (select P_ID,
                    DATAARR(1), --部门名称
                    DATAARR(2), --副本们ID
                    DATAARR(3), --level
                    DATAARR(4), --type
                    '', --OWNER
                    0, --status
                    DATAARR(1), --简称
                    '', --BP
                    P_SORT, --排序
                    '' --VP
               from LCBASE.T_ORGANIZATION t
              where t.c_organization_id = DATAARR(2));
          --新增结束
          DataId := P_ID;
          --更改记录日志
          n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(P_ID,
                                                      'C_ORGANIZATION_ID',
                                                      'LCBASE.T_ORGANIZATION',
                                                      '0',
                                                      OperationUserId,
                                                      ErrMsg);

      COMMIT;
      return 0;
      else
        return -1;
        ErrMsg := '此部门异常,无法添加子部门';
      end if;



    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '新增/更新组织信息失败';
        ROLLBACK;
        return - 1;

    END;
  END;

  --修改部门名称
  function update_children_organization(DataInfo        in varchar2, --部门名称^部门id^lEvel^type
                                        OperationUserId IN VARCHAR2,
                                        ErrMsg          out varchar2)
    return number is
    DATAARR  PKG_COMMON.ARR_LONGSTR;
    P_ID     CHAR(32);
    P_STEP   NUMBER(2);
    P_OPTYPE NUMBER(1) := 1;
    P_SORT   number(3);
    n_result number(3);
  begin
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      --修改开始
      UPDATE LCBASE.T_ORGANIZATION o
         SET V_ORGANIZATION_NAME    = DATAARR(1),
             v_organization_abbname = DATAARR(1),
             n_organization_level   = DATAARR(3),
             n_organization_type    = DATAARR(4)
       WHERE C_ORGANIZATION_ID = DATAARR(2);
      --修改结束

      --更改记录日志
      n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(DATAARR(2),
                                                      'C_ORGANIZATION_ID',
                                                      'LCBASE.T_ORGANIZATION',
                                                      '1',
                                                      OperationUserId,
                                                      ErrMsg);

      COMMIT;
      return 0;

    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '新增/更新组织信息失败';
        ROLLBACK;
        return - 1;

    END;
  END;
  --修改部门BP,VP
  function update_organization_leader(DataInfo in varchar2, --部门id^负责人id^
                                      --负责人类型1负责人 2 BP 3 VP
                                      OperationUserId IN VARCHAR2,
                                      ErrMsg          out varchar2)
    return number is
    DATAARR  PKG_COMMON.ARR_LONGSTR;
    P_ID     CHAR(32);
    P_STEP   NUMBER(2);
    P_OPTYPE NUMBER(1) := 1;
    P_SORT   number(3);
    n_result number(3):=0;
    n_level  number(3);
  begin
    begin
      DATAARR := PKG_COMMON.Split(DataInfo, '^');
      
      --查询部门等级
      select o.n_organization_level into n_level
      from LCBASE.T_ORGANIZATION o
      where o.c_organization_id=DATAARR(1);
      
      --设置部门负责人
      if DATAARR(3) = 1 then
        --修改开始
        UPDATE LCBASE.T_ORGANIZATION o
           SET o.c_organization_owner = DATAARR(2)
         WHERE C_ORGANIZATION_ID = DATAARR(1);
        --修改结束
        --设置部门BP
      elsif DATAARR(3) = 2 then
        --修改开始
        UPDATE LCBASE.T_ORGANIZATION o
           SET o.c_organization_bp = DATAARR(2)
         WHERE C_ORGANIZATION_ID = DATAARR(1);
        --修改结束
        --设置部门VP
      else
        if n_level=2 then
        --修改开始
        UPDATE LCBASE.T_ORGANIZATION o
           SET o.c_organization_vp = DATAARR(2)
         WHERE C_ORGANIZATION_ID = DATAARR(1);
        --修改结束
        else 
          ErrMsg := '非本部级别的部门不能设置VP~';
          n_result := -1;
        end if;
      end if;
      if n_result=0 then 
        --更改记录日志
        n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(DATAARR(1),
                                                        'C_ORGANIZATION_ID',
                                                        'LCBASE.T_ORGANIZATION',
                                                        '1',
                                                        OperationUserId,
                                                        ErrMsg);
      end if;

      COMMIT;
      return n_result;

    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '新增/更新组织信息失败';
    END;
    ROLLBACK;
    return - 1;

  END;

  --删除部门
   function delete_organization(OrganizationId  in varchar2, --部门id
                               OperationUserId IN VARCHAR2,
                               ErrMsg          out varchar2) return number is
    P_OPTYPE NUMBER(1) := 4;
    n_result number(3);
    P_c_dept number(3);--子部门数量
    P_C_emp  number(3);--部门成员数量
    P_PARENT_ID varchar2(32);--副部们ID
    P_SORTNUM number(3);--排序序号
    v_sql    varchar2(3000);
    --声明游标 排序序号
    v_organizationIds SYS_REFCURSOR;--游标类型
    V_countNumber lcbase.t_organization.c_organization_id%type;
  BEGIN
    BEGIN
      --计算部门下子部门数量
      select count(*) into P_c_dept
      from LCBASE.T_ORGANIZATION o
      left join LCBASE.T_ORGANIZATION org
      on o.c_organization_id  = org.c_organization_parent_id
      where org.c_organization_parent_id =OrganizationId
      and org.n_status=0;
      --计算部门下人员情况
      select count(*) into P_C_emp
      from lcbase.t_user u
      where u.c_organization_id=OrganizationId;

      n_result := -1;
      --查当前部门的副部们ID
      select
      org.c_organization_parent_id into  P_PARENT_ID
      from LCBASE.T_ORGANIZATION org
      where org.c_organization_id=OrganizationId;
      --查当前排序序号
      select
      org.n_order
      into P_SORTNUM
      from LCBASE.T_ORGANIZATION org
      where org.c_organization_id=OrganizationId;
      
      
      if P_c_dept=0 and P_C_emp=0 then
          --逻辑删除部门开始
          UPDATE LCBASE.T_ORGANIZATION
             SET n_status = 1
           WHERE c_organization_id = OrganizationId;
          --逻辑删除部门结束
          n_result:=0;

         v_sql:='select org.c_organization_id
               from LCBASE.T_ORGANIZATION org
               WHERE org.c_organization_parent_id = '''||P_PARENT_ID||'''
               and org.N_ORDER > '||P_SORTNUM||'';
          --打开游标
          open v_organizationIds for v_sql;
          --提取游标数据
          fetch v_organizationIds into V_countNumber;

          while v_organizationIds%found loop
              --大于当前序号的，自动减一
              update LCBASE.T_ORGANIZATION o
              SET o.n_order = o.N_ORDER-1
              WHERE o.c_organization_id = V_countNumber;

              --更改记录日志(修改下游序号操作记录)
              n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(V_countNumber,
                                                            'C_ORGANIZATION_ID',
                                                            'LCBASE.T_ORGANIZATION',
                                                            '2',
                                                            OperationUserId,
                                                            ErrMsg);
              --取出下一条
              fetch v_organizationIds into V_countNumber;
          end loop;




           --更改记录日志
           n_result := lcoa.pkg_ins_dept_info.HISTORY_TABLE_LOG(OrganizationId,
                                                            'C_ORGANIZATION_ID',
                                                            'LCBASE.T_ORGANIZATION',
                                                            '2',
                                                            OperationUserId,
                                                            ErrMsg);

            COMMIT;
       else
         ErrMsg:='请删除此部门下的成员或子部门后，再删除此部门';
       end if;
       
       if OrganizationId='997c2b49b01d4bdba3c5ea4e0f615617' then
         ErrMsg:='根部门不允许删除';
       end if;
      RETURN n_result;
      
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字';
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误';
      WHEN OTHERS THEN
        ErrMsg := '删除组织信息失败';
    END;
    ROLLBACK;
    RETURN 1;
  END;

end pkg_ins_dept_info;

/

