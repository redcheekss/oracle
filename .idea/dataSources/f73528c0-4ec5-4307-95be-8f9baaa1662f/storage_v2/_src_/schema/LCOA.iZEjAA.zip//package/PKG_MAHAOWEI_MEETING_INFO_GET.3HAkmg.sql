create package pkg_mahaowei_meeting_info_get is
  procedure get_meet_message;
  function GET_MEETING_MAJOR(DataId          in varchar2,
                             DataSource      in number,
                             OperationUserId in varchar2,
                             getmeetinginfo  out sys_refcursor,
                             getmeetcontent  out sys_refcursor,
                             gettodolist     out sys_refcursor,
                             getuploadinfo   out sys_refcursor,
                             getattendeelist out sys_refcursor,
                             getschedulenum  out sys_refcursor,
                             getuserschedule out sys_refcursor,
                             countmeetingid  out number,
                             ErrMsg          out varchar2) return number;
  /**
  function GET_MEETING_INFO(DataId          in varchar2,
                            OperationUserId in varchar2,
                            getmeetinginfo  out sys_refcursor,
                            getmeetcontent  out sys_refcursor,
                            gettodolist     out sys_refcursor,
                            getuploadinfo   out sys_refcursor,
                            getattendeelist out sys_refcursor,
                            getschedulenum  out sys_refcursor,
                            ErrMsg          out varchar2) return number;
  **/
  function GET_MEETING_STATUS(DataId          in varchar2,
                              OperationUserId in varchar2,
                              ErrMsg          out varchar2) return number;
  function GET_CLERK_ID(DataId          in varchar2,
                        OperationUserId in varchar2,
                        ErrMsg          out varchar2) return varchar2;
  function GET_SECRET_TYPE(DataId          in varchar2,
                           OperationUserId in varchar2,
                           ErrMsg          out varchar2) return number;
  function CHECK_MEETINGUSER(DataId          in varchar2,
                             DataSource      in number,
                             OperationUserId in varchar2,
                             ErrMsg          out varchar2) return number;
  function GET_MEETINGID_COUNT(DataId          in varchar2,
                               DataSource      in number,
                               OperationUserId in varchar2,
                               ErrMsg          out varchar2) return number;
  function CHECK_USERTEAM(OperationUserId in varchar2, ErrMsg out varchar2)
    return number;
end;
/

