create package PKG_DMD_APPLY is
  --数据处理新增
  FUNCTION INSERT_OADMDAPPLY(OADMDAPPLY      IN VARCHAR2,
                             enclosure_LIST  IN arr_longstr,
                             OperationUserID IN VARCHAR2,
                             TodoSender_Cur  out sys_refcursor,
                             ErrMsg          OUT VARCHAR2) RETURN NUMBER;
  --数据处理撤回
  FUNCTION UPDATE_OADMDAPPLY(datamodify_apply_id IN VARCHAR2,
                             OperationUserID     IN VARCHAR2,
                             ErrMsg              OUT VARCHAR2) RETURN NUMBER;
  --数据处理详情
  FUNCTION SELECT_OADMDAPPLY(datamodify_apply_id IN VARCHAR2,
                             OperationUserID     IN VARCHAR2,
                             TodoSender_Cur      out sys_refcursor,
                             enclosure           out sys_refcursor,
                             CUR_FLOW            out sys_refcursor,
                             ErrMsg              OUT VARCHAR2) RETURN NUMBER;
  --数据处理留言
  FUNCTION INSER_OADMDCOMMENT(COMMEN                IN VARCHAR2,
                              OperationUserID       IN VARCHAR2,
                              messageReceiverUserID in VARCHAR2,
                              datamodify_comment_id in VARCHAR2,
                              datamodify_apply_id   in VARCHAR2,
                              TodoSender_Cur        out sys_refcursor,
                              ErrMsg                OUT VARCHAR2)
    RETURN NUMBER;
  --数据处理留言查询
  FUNCTION SELETE_OADMDCOMMENT(datamodify_apply_id in VARCHAR2,
                               OperationUserID     IN VARCHAR2,
                               nPageSize           IN NUMBER, --每页显示大小>0
                               nPageCur            IN NUMBER, --当前页码[1-总页数]
                               CUR_DATA            OUT SYS_REFCURSOR, --oracle标准游标
                               nOutRows            OUT number, --输出总记录数
                               nOutPageCount       OUT number, --输出总页数
                               datamodify          out sys_refcursor,
                               ErrMsg              OUT VARCHAR2)
    RETURN NUMBER;
  --数据处理分发
  FUNCTION distribute_OADMDAPPLY(datamodify_apply_id in VARCHAR2,
                                 OperationUserID     IN VARCHAR2,
                                 distributeUserID    IN VARCHAR2,
                                 distributeRemarks   IN VARCHAR2,
                                 apply_id            out VARCHAR2,
                                 TodoSender_Cur      out sys_refcursor,
                                 ErrMsg              OUT VARCHAR2)
    RETURN NUMBER;
  --数据处理驳回
  FUNCTION reject_OADMDAPPLY(datamodify_apply_id in VARCHAR2,
                             OperationUserID     IN VARCHAR2,
                             rejectRemarks       IN VARCHAR2,
                             apply_id            out VARCHAR2,
                             
                             ErrMsg OUT VARCHAR2) RETURN NUMBER;
  --数据处理关闭
  FUNCTION close_OADMDAPPLY(datamodify_apply_id in VARCHAR2,
                            OperationUserID     IN VARCHAR2,
                            closeStatus         IN NUMBER,
                            closeRemarks        IN VARCHAR2,
                            apply_id            out VARCHAR2,
                            ErrMsg              OUT VARCHAR2) RETURN NUMBER;
  FUNCTION Create_Approval_Todo(WorkflowId            in varchar2,
                                TodoTitle             in varchar2,
                                messageReceiverUserID in varchar2,
                                WORKFLOW_TYPE         in Number,
                                TodoSender_Cur        out sys_refcursor,
                                ErrMsg                OUT VARCHAR2)
    RETURN NUMBER;
  FUNCTION Create_Approval_MESSAGE(WorkflowId            in varchar2,
                                   TodoTitle             in varchar2,
                                   messageReceiverUserID in varchar2,
                                   WORKFLOW_TYPE         in Number,
                                   TodoSender_Cur        out sys_refcursor,
                                   ErrMsg                OUT VARCHAR2)
    RETURN NUMBER;
end PKG_DMD_APPLY;
/

