create package PKG_EXT_DELAY_INFO is
  function getDelayApproverList(userId       in varchar2, --操作人ID
                                loanInfo     out sys_refcursor, --未还清借款单列表 
                                ApproveUsers out sys_refcursor, --审批人详情
                                ErrMsg       out varchar2) return number;
  --添加借款延期
  function save_delay_info(loanIds   in varchar2,
                           delayInfo in varchar2,
                           userId    IN VARCHAR2,
                           c_cursor  out sys_refcursor,
                           ErrMsg    OUT VARCHAR2) return number;
  function getDelayInfo(delayId         in varchar2, --借款信息ID
                        operationUserId in varchar2, --操作人ID
                        loanInfo        out sys_refcursor, --借款单详情 
                        ApproveUsers    out sys_refcursor, --审批人详情
                        delayInfo       out sys_refcursor, --延期单详情
                        ErrMsg          out varchar2) return number;
end;
/

