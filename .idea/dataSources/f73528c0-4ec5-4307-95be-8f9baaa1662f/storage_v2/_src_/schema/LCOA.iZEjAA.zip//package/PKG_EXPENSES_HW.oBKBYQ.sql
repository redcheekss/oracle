create package PKG_EXPENSES_HW is

    -- Author  : HAOWEI
    -- Created : 2020/4/2 14:52:16
    -- Purpose : PKG_EXPENSES_HW
    --报销--查看 
    function expense_GetExpenseBaseInfo(DataId   in char,
                                        CUR_DATA OUT SYS_REFCURSOR,
                                        CUR_FLOW OUT SYS_REFCURSOR,
                                        CUR_FILE OUT SYS_REFCURSOR,
                                        ErrMsg   OUT VARCHAR2)
        return number;

    --报销--附件查看 
    function expense_GetExpenseUploadInfo(DataId   in char,
                                          CUR_FILE OUT SYS_REFCURSOR,
                                          ErrMsg   OUT VARCHAR2)
        return number;

    --报销--报销进度查看 
    function expense_GetExpenseScheduleInfo(DataId       in char,
                                            CUR_FLOW     OUT SYS_REFCURSOR,
                                            CUR_Schedule OUT SYS_REFCURSOR,
                                            ErrMsg       OUT VARCHAR2)
        return number;

end PKG_EXPENSES_HW;
/

