create function moveleft(a in int,n in int) return int
is

begin
   return a*power(2,n);
end;
/

