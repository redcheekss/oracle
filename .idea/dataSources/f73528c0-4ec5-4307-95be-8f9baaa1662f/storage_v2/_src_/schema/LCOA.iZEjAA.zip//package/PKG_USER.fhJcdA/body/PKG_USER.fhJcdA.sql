create PACKAGE BODY PKG_USER AS

  FUNCTION Update_User(PUserInfo         IN VARCHAR2,
                       OperationUserId   IN VARCHAR2,
                       UserId            IN OUT VARCHAR2,
                       V_ORGANIZATION_ID out char,
                       ErrMsg            OUT VARCHAR2) RETURN NUMBER IS
    DATAARR          PKG_COMMON.ARR_LONGSTR;
    P_ID             CHAR(32);
    P_STEP           NUMBER(2);
    n_optype         number(1);
    n_result         number(1) := 0;
    ErrMsg2          varchar2(50);
    row_count        integer;
    v_work_number    NUMBER(6, 0);
    rowEmail         number(5);
    email            varchar(30);
    workNum          number(6);
    update_count     Date;
    current_time     Date;
    V_ORGANIZATIONid char(32);
    projectId        char(32);
    projectCount     number(3);
  BEGIN
    BEGIN
      P_STEP    := 0;
      DATAARR   := PKG_COMMON.Split(PUserInfo, '^');
      P_ID      := DATAARR(1);
      projectId := DATAARR(22);
      IF P_ID IS NULL THEN
        P_ID := LOWER(SYS_GUID());
        --判断手机号是否存在
        n_result := pkg_user.is_phones_exists_insert(DATAARR(7), ErrMsg);
        if n_result = -1 then
          return - 1;
        end if;
        --判断手机号是否存在2
        n_result := pkg_user.is_phones_exists2_insert(DATAARR(8), ErrMsg);
        if n_result = -1 then
          return - 1;
        end if;
        /*n_result := pkg_user.is_EMAIL_exists_insert(DATAARR(12), ErrMsg);
        if n_result = -1 then
          return - 1;
        end if;
        */
        if DATAARR(21) is null then
          ErrMsg := '用户汉语拼音无值！';
          return - 1;
        end if;
        email := DATAARR(21) || '@lecarlink.com';
        select count(*)
          into rowEmail
          from lcbase.t_Zip_User tu
         where tu.v_email = email
           and D_ENDDATE > sysdate;
        if rowEmail > 0 then
          select max(n_work_num) - 1
            into workNum
            from lcbase.t_employees_info;
          email := DATAARR(21) || workNum || '@lecarlink.com';
        end if;
        INSERT INTO LCBASE.t_Zip_User
          (D_STARTDATE,
           D_ENDDATE,
           C_USER_ID,
           C_ORGANIZATION_ID,
           V_USER_NAME,
           N_USER_TYPE,
           N_WORK_ID,
           V_PET_NAME,
           N_MOBILE_1,
           N_MOBILE_2,
           V_TEL_1,
           V_TEL_2,
           N_STATUS,
           V_EMAIL,
           C_PASSWORD,
           V_WX_OPEN_ID,
           V_WORK_WX_ACCOUNT,
           N_SEX,
           N_AUTHORITY,
           N_WORK_WX_ACTIVATION,
           V_HEADPIC_ALY,
           N_KINDOFWORK,
           V_FULLNAME_ZH)
        values
          (trunc(sysdate, 'dd'),
           TO_DATE('9999-12-31', 'yyyy-mm-dd'),
           P_ID,
           DATAARR(2),
           DATAARR(3),
           DATAARR(4),
           DATAARR(5),
           DATAARR(3),
           DATAARR(7),
           DATAARR(8),
           DATAARR(9),
           DATAARR(10),
           0, --（用户状态-默认为0 可用）DATAARR(11),
           email,
           lower(md5('lecarlink2020')), --DATAARR(13),
           DATAARR(14),
           DATAARR(15),
           DATAARR(16),
           DATAARR(17),
           DATAARR(18),
           DATAARR(19),
           DATAARR(20),
           DATAARR(21));
        if projectId is not null then
          insert into lcbase.t_user_organization
          values
            (P_ID, projectId, 1);
        end if;
        UserId            := P_ID;
        V_ORGANIZATION_ID := DATAARR(2);
        ErrMsg            := '插入成功';
        RETURN 0;
      ELSE
        n_result := pkg_user.is_phones_exists(DATAARR(7), UserId, ErrMsg);
        if n_result = -1 then
          return - 1;
        end if;
        n_result := pkg_user.is_phones_exists2(DATAARR(8), UserId, ErrMsg);
        if n_result = -1 then
          return - 1;
        end if;
        n_result := pkg_user.is_EMAIL_exists(DATAARR(12), UserId, ErrMsg);
        if n_result = -1 then
          return - 1;
        end if;
        if DATAARR(21) is null then
          ErrMsg := '用户汉语拼音无值！';
          return - 1;
        end if;
        current_time := sysdate;
        select count(*)
          into row_count
          from LCBASE.T_ZIP_USER
         where C_USER_ID = P_ID
           and D_ENDDATE > sysdate;
        if row_count <= 0 then
          return - 1;
        end if;
        select D_STARTDATE
          into update_count
          from LCBASE.T_ZIP_USER
         where C_USER_ID = P_ID
           and D_ENDDATE > sysdate;
        --查询当前用户下所属组织
        select C_ORGANIZATION_ID
          into V_ORGANIZATIONid
          from lcbase.T_ZIP_USER T
         where C_USER_ID = P_ID
           and D_ENDDATE > sysdate;
        --判断当前组织与旧组织是否一致，如果一致直接更新，否则拉链表操作
        if trim(V_ORGANIZATIONid) = trim(DATAARR(2)) then
          UPDATE lcbase.t_zip_user
             set --D_STARTDATE       = sysdate,
                 --D_ENDDATE         = to_date('9999-12-31', 'yyyy-mm-dd'),
                   C_ORGANIZATION_ID = DATAARR(2),
                 V_USER_NAME       = DATAARR(3),
                 N_USER_TYPE       = DATAARR(4),
                 N_WORK_ID         = DATAARR(5),
                 V_PET_NAME        = DATAARR(3),
                 N_MOBILE_1        = DATAARR(7),
                 N_MOBILE_2        = DATAARR(8),
                 V_TEL_1           = DATAARR(9),
                 V_TEL_2           = DATAARR(10),
                 N_STATUS          = DATAARR(11),
                 V_EMAIL           = DATAARR(12),
                 --C_PASSWORD           = lcbase.md5(DATAARR(13)),
                 V_WX_OPEN_ID         = DATAARR(14),
                 V_WORK_WX_ACCOUNT    = DATAARR(15),
                 N_SEX                = DATAARR(16),
                 N_AUTHORITY          = DATAARR(17),
                 N_WORK_WX_ACTIVATION = DATAARR(18),
                 V_HEADPIC_ALY        = DATAARR(19),
                 N_KINDOFWORK         = DATAARR(20),
                 V_FULLNAME_ZH        = DATAARR(21)
           WHERE C_USER_ID = P_ID
             and D_ENDDATE > sysdate;
          --组织发生变化-进行拉链操作
        else
          if trunc(update_count, 'dd') = trunc(current_time, 'dd') then
            update LCBASE.T_ZIP_USER
               set --D_STARTDATE       = sysdate,
                   -- D_ENDDATE         = to_date('9999-12-31', 'yyyy-mm-dd'),
                     C_ORGANIZATION_ID = DATAARR(2),
                   V_USER_NAME       = DATAARR(3),
                   N_USER_TYPE       = DATAARR(4),
                   N_WORK_ID         = DATAARR(5),
                   V_PET_NAME        = DATAARR(3),
                   N_MOBILE_1        = DATAARR(7),
                   N_MOBILE_2        = DATAARR(8),
                   V_TEL_1           = DATAARR(9),
                   V_TEL_2           = DATAARR(10),
                   N_STATUS          = DATAARR(11),
                   V_EMAIL           = DATAARR(12),
                   --C_PASSWORD           = lcbase.md5(DATAARR(13)),
                   V_WX_OPEN_ID         = DATAARR(14),
                   V_WORK_WX_ACCOUNT    = DATAARR(15),
                   N_SEX                = DATAARR(16),
                   N_AUTHORITY          = DATAARR(17),
                   N_WORK_WX_ACTIVATION = DATAARR(18),
                   V_HEADPIC_ALY        = DATAARR(19),
                   N_KINDOFWORK         = DATAARR(20),
                   V_FULLNAME_ZH        = DATAARR(21)
             where C_USER_ID = P_ID
               and D_ENDDATE > sysdate;
          else
            --起始日期不是当天-- 则是当天首次修改，先更新有效期，再新增,再修改
            --插入数据
            insert into lcbase.t_zip_user(D_STARTDATE,
																					D_ENDDATE,
																					C_USER_ID,
																					C_ORGANIZATION_ID,
																					V_USER_NAME,
																					N_USER_TYPE,
																					V_PET_NAME,
																					N_MOBILE_1,
																					N_MOBILE_2,
																					V_TEL_1,
																					V_TEL_2,
																					N_STATUS,
																					V_EMAIL,
																					C_PASSWORD,
																					V_WX_OPEN_ID,
																					V_WORK_WX_ACCOUNT,
																					N_SEX,
																					N_AUTHORITY,
																					N_WORK_WX_ACTIVATION,
																					V_HEADPIC_ALY,
																					N_WORK_ID,
																					N_KINDOFWORK,
																					V_FULLNAME_ZH
																					) 
              select T.D_STARTDATE,
                     trunc(sysdate, 'dd'),
                     T.C_USER_ID,
                     T.C_ORGANIZATION_ID,
                     T.V_USER_NAME,
                     T.N_USER_TYPE,
                     T.V_PET_NAME,
                     T.N_MOBILE_1,
                     T.N_MOBILE_2,
                     T.V_TEL_1,
                     T.V_TEL_2,
                     T.N_STATUS,
                     T.V_EMAIL,
                     T.C_PASSWORD,
                     T.V_WX_OPEN_ID,
                     T.V_WORK_WX_ACCOUNT,
                     T.N_SEX,
                     T.N_AUTHORITY,
                     T.N_WORK_WX_ACTIVATION,
                     T.V_HEADPIC_ALY,
                     T.N_WORK_ID,
                     T.N_KINDOFWORK,
                     T.V_FULLNAME_ZH
                from LCBASE.T_ZIP_USER T
               where C_USER_ID = P_ID
                 and D_ENDDATE > sysdate;
            --更新有效期
            --更新数据
            UPDATE lcbase.t_zip_user
               set D_STARTDATE       = trunc(sysdate, 'dd'),
                   C_ORGANIZATION_ID = DATAARR(2),
                   V_USER_NAME       = DATAARR(3),
                   N_USER_TYPE       = DATAARR(4),
                   N_WORK_ID         = DATAARR(5),
                   V_PET_NAME        = DATAARR(3),
                   N_MOBILE_1        = DATAARR(7),
                   N_MOBILE_2        = DATAARR(8),
                   V_TEL_1           = DATAARR(9),
                   V_TEL_2           = DATAARR(10),
                   N_STATUS          = DATAARR(11),
                   V_EMAIL           = DATAARR(12),
                   --C_PASSWORD           = lcbase.md5(DATAARR(13)),
                   V_WX_OPEN_ID         = DATAARR(14),
                   V_WORK_WX_ACCOUNT    = DATAARR(15),
                   N_SEX                = DATAARR(16),
                   N_AUTHORITY          = DATAARR(17),
                   N_WORK_WX_ACTIVATION = DATAARR(18),
                   V_HEADPIC_ALY        = DATAARR(19),
                   N_KINDOFWORK         = DATAARR(20),
                   V_FULLNAME_ZH        = DATAARR(21)
             WHERE C_USER_ID = P_ID
               and D_ENDDATE > sysdate;
          end if;
        end if;
        update lcbase.t_zip_user t
           set t.v_pet_name =
               (select u.v_user_name || '(' || e.n_work_num_old || ')'
                  from lcbase.t_zip_user u, lcbase.t_employees_info e
                 where u.c_user_id = e.c_user_id
                   and u.d_enddate > sysdate
                   and u.c_user_id = t.c_user_id)
         where t.v_user_name in (select t.v_user_name
                                   from lcbase.t_zip_user t
                                  WHERE t.v_user_name = DATAARR(3)
                                    and t.d_enddate > sysdate
                                  group by t.v_user_name
                                 having count(*) > 1)
           and t.d_enddate > sysdate;
        update lcbase.t_zip_user t
           set t.v_pet_name = t.v_user_name
         where t.v_user_name in (select t.v_user_name
                                   from lcbase.t_zip_user t
                                  where t.d_enddate > sysdate
                                  group by t.v_user_name
                                 having count(*) = 1)
           and t.d_enddate > sysdate;
        if projectId is not null then
          select count(*)
            into projectCount
            from lcbase.t_user_organization
           where C_USER_ID = P_ID;
          if projectCount > 0 then
            update lcbase.t_user_organization a
               set a.c_organization_id = projectId
             where a.c_user_id = P_ID;
          else
            insert into lcbase.t_user_organization
            values
              (P_ID, projectId, 1);
          end if;
        else
          select count(*)
            into projectCount
            from lcbase.t_user_organization
           where C_USER_ID = P_ID;
          if projectCount > 0 then
            delete lcbase.t_user_organization a where a.c_user_id = P_ID;
          end if;
        end if;
      END IF;
      V_ORGANIZATION_ID := DATAARR(2);
      ErrMsg            := '更新成功';
      RETURN 0;
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                ErrMsg,
                                false);
        ROLLBACK;
        return - 1;
    END;
    return - 1;
  END;

  FUNCTION Delete_User(UserId          IN VARCHAR2,
                       OperationUserId IN VARCHAR2,
                       ErrMsg          OUT VARCHAR2) RETURN NUMBER IS
    n_optype     number(1);
    n_result     number(1) := 0;
    count_date   date;
    current_date date;
  BEGIN
    BEGIN
      current_date := sysdate;
      n_optype     := 4;
      --判断是否是当天首次修改
      --查最新数据的起始时间是否是当天
      begin
        select D_STARTDATE
          into count_date
          from lcbase.t_zip_user u
         where C_USER_ID = UserId
           and trunc(D_startdate) = trunc(sysdate);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          count_date := NULL;
      end;
      --判断开始 if起始日期是当天，则不是当天首次修改 直接修改最新记录
      if trunc(count_date) = trunc(current_date) then
        UPDATE lcbase.T_zip_USER
           SET N_STATUS = 1
         WHERE C_USER_ID = UserId
           and d_enddate > sysdate;
      else
        --首次修改
        --先修改保质期
        UPDATE lcbase.T_zip_USER u
           SET d_enddate = current_date
         WHERE C_USER_ID = UserId
           and d_enddate > sysdate;
        --新增
        insert into lcbase.T_zip_USER(
											D_STARTDATE,
											D_ENDDATE,
											C_USER_ID,
											C_ORGANIZATION_ID,
											V_USER_NAME,
											N_USER_TYPE,
											V_PET_NAME,
											N_MOBILE_1,
											N_MOBILE_2,
											V_TEL_1,
											V_TEL_2,
											N_STATUS,
											V_EMAIL,
											C_PASSWORD,
											V_WX_OPEN_ID,
											V_WORK_WX_ACCOUNT,
											N_SEX,
											N_AUTHORITY,
											N_WORK_WX_ACTIVATION,
											V_HEADPIC_ALY,
											N_WORK_ID,
											N_KINDOFWORK,
											V_FULLNAME_ZH)
          (select sysdate,
                  to_date('9999-12-31', 'yyyy-mm-dd'),
                  u.c_user_id,
                  u.c_organization_id,
                  u.v_user_name,
                  u.n_user_type,
                  u.v_pet_name,
                  u.n_mobile_1,
                  u.n_mobile_2,
                  u.v_tel_1,
                  u.v_tel_2,
                  1,
                  u.v_email,
                  u.c_password,
                  u.v_wx_open_id,
                  u.v_work_wx_account,
                  u.n_sex,
                  u.n_authority,
                  u.n_work_wx_activation,
                  u.v_headpic_aly,
                  u.n_work_id,
                  u.n_kindofwork,
                  u.v_fullname_zh
             from lcbase.T_zip_USER u
            where C_USER_ID = UserId
              and d_enddate = current_date);
        --修改数据
      end if;
      n_result := 1;
      PKG_COMMON.InsertOperationLog(OperationUserId,
                                    'T_USER',
                                    n_optype,
                                    n_result);
      RETURN 0;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
        ROLLBACK;
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
        ROLLBACK;
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据' || ',' || DBMS_UTILITY.format_error_backtrace;
        ROLLBACK;
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字' || ',' || DBMS_UTILITY.format_error_backtrace;
        ROLLBACK;
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误' || ',' || DBMS_UTILITY.format_error_backtrace;
        ROLLBACK;
      WHEN OTHERS THEN
        ErrMsg := '删除用户信息失败: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
        ROLLBACK;
    END;
    /* PKG_COMMON.InsertOperationLog(OperationUserId,
    'T_USER',
    n_optype,
    n_result);*/
    return - 1;
  END;

  FUNCTION Get_User(UserId          IN VARCHAR2,
                    OperationUserId IN VARCHAR2,
                    --       PUserInfo       OUT VARCHAR2,
                    CUR_DATA OUT SYS_REFCURSOR,
                    ErrMsg   OUT VARCHAR2) RETURN NUMBER IS
    n_result number(1) := 0;
  BEGIN
    BEGIN
      OPEN CUR_DATA FOR
        SELECT *
          FROM lcbase.t_zip_user
         WHERE C_USER_ID = UserId
           and d_enddate > sysdate;
      n_result := 1;
      return 0;
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := '查询数据失败: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;
    END;
    /* PKG_COMMON.InsertOperationLog(OperationUserId,
    'T_USER',
    1,
    n_result);*/
    RETURN - 1;
  END;

  FUNCTION Login_User(UserAccount  VARCHAR2,
                      UserPassword VARCHAR2,
                      LoginType    NUMBER,
                      CUR_DATA     OUT SYS_REFCURSOR,
                      ErrMsg       OUT VARCHAR2) RETURN NUMBER IS
    user_count   NUMBER;
    valid_count  NUMBER;
    ReturnNumber NUMBER;
  BEGIN
    select count(1),
           sum(case
                 when c_password = UserPassword then
                  1
                 else
                  0
               end)
      INTO user_count, valid_count
      from lcbase.t_zip_user t
     where t.n_mobile_1 = UserAccount
       and t.d_enddate > sysdate;
    if user_count = 0 then
      ErrMsg       := '用户账户不存在';
      ReturnNumber := 30002;
    elsif valid_count = 0 then
      ErrMsg       := '密码错误';
      ReturnNumber := 30004;
    else
      open CUR_DATA for
        select *
          from lcbase.t_zip_user a
          left join lcbase.t_user_pic b
            on a.c_user_id = b.c_user_id
           and a.d_enddate > sysdate
           and b.n_pic_type = 5
         where n_mobile_1 = UserAccount
           and c_password = UserPassword;
      ReturnNumber := 0;
    end if;
    return ReturnNumber;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := SQLCODE || ',' || SQLERRM;
      RETURN - 1; --其它错误
  END;

  -- 用户重名，返回工号
  function getUserWorkNo(UserId in varchar2) RETURN VARCHAR2 AS
    N_COUNT  NUMBER(4);
    cur_data varchar2(50);
  BEGIN
    select count(*)
      into n_count
      from lcbase.t_zip_user tt
     where tt.v_user_name = (select t.v_user_name
                               from lcbase.t_zip_user t
                              where t.c_user_id = UserId
                                and t.d_enddate > sysdate)
       and tt.d_enddate > sysdate;
    if n_count > 1 then
      select t.v_user_name ||
             decode(e.n_work_num, null, '', '(' || e.n_work_num || ')')
        into cur_data
        from lcbase.t_zip_user t
        left join lcbase.t_employees_info e
          on e.c_user_id = t.c_user_id
       where t.c_user_id = UserId
         and t.d_enddate > sysdate;
    else
      select t.v_user_name
        into cur_data
        from lcbase.t_zip_user t
       where t.c_user_id = UserId
         and t.d_enddate > sysdate;
    end if;
    return cur_data;
  END;

  FUNCTION OAGetUserMenu(UserID    VARCHAR2,
                         MenuType  NUMBER,
                         RE_CURSOR OUT PKG_COMMON.REF_CURSOR,
                         ErrMsg    OUT VARCHAR) RETURN NUMBER IS
    ErrCode    NUMBER := 0;
    P_ROLE_ID  NUMBER(4);
    P_CORPFLAG NUMBER(2);
    P_CORP_ID  CHAR(32);
  BEGIN
    ErrCode := -3;
    OPEN RE_CURSOR FOR
      select t.c_menu_id,
             t.v_menu_name,
             t.n_delflag,
             t.v_menu_url,
             t.n_level,
             t.v_icon_name,
             t.c_menu_parent_id,
             t.n_order,
             t.n_right,
             t.c_user_id
        from (select TT.*,
                     row_number() over(partition by TT.V_MENU_NAME order by TT.n_right desc) rw
                from (select dic.*, rm.n_right, ur.c_user_id
                        from Oa_Aut_Role_Menu rm
                       INNER join Oa_Aut_Menu_Dic dic
                          on rm.c_menu_id = dic.c_menu_id
                       INNER join Oa_Aut_Role r
                          on rm.c_role_id = r.c_role_id
                       INNER JOIN OA_AUT_USER_ROLE UR
                          ON R.C_ROLE_ID = UR.C_ROLE_ID
                       where ur.c_user_id = UserID
                         and dic.menu_type = MenuType
                         and dic.c_menu_id not in
                             (select dis.c_menu_id
                                from Oa_Aut_User_Menu_Disable dis
                               where dis.n_right >= 2
                                 and dis.c_user_id = UserID)
                         and r.deleted = 0
                      union all
                      select dic.*, um.n_right as n_rights, um.c_user_id
                        from Oa_Aut_Menu_Dic dic
                       INNER join Oa_Aut_User_Menu UM
                          on dic.c_menu_id = um.c_menu_id
                       where um.c_user_id = UserID
                         and dic.menu_type = MenuType
                         and dic.c_menu_id not in
                             (select dis.c_menu_id
                                from Oa_Aut_User_Menu_Disable dis
                               where dis.n_right >= 2
                                 and dis.c_user_id = UserID)
                         ) TT) t
       where t.rw = 1;
    ErrCode := 0;
    RETURN ErrCode;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := SQLCODE || ',' || sqlerrm;
      RETURN ErrCode;
  END;

  /*
    手机号
  */
  function is_phones_exists(N_MOBILE in varchar2,
                            user_id  in char,
                            ErrMsg   out varchar2) RETURN NUMBER is
    V_MOBILE integer;
  begin
    select count(*)
      into V_MOBILE
      from LCBASE.t_Zip_User
     where N_MOBILE_1 = N_MOBILE
       AND c_user_id <> user_id
       and D_ENDDATE > sysdate;
    if V_MOBILE > 0 then
      ErrMsg := '手机号已存在！';
      return - 1;
    else
      return 0;
    end if;
    return 0;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := 'phones: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
  end;

  /*
  */
  function is_phones_exists_insert(N_MOBILE in varchar2,
                                   ErrMsg   out varchar2) RETURN NUMBER is
    V_MOBILE integer;
  begin
    select count(*)
      into V_MOBILE
      from LCBASE.t_Zip_User
     where N_MOBILE_1 = N_MOBILE
       and D_ENDDATE > sysdate;
    if V_MOBILE > 0 then
      ErrMsg := '手机号已存在！';
      return - 1;
    else
      return 0;
    end if;
    return 0;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := 'phones操作异常: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
  end;

  /*
   判断手机号是否存在2
  */
  function is_phones_exists2(N_MOBILE in varchar2,
                             user_id  in char,
                             ErrMsg   out varchar2) RETURN NUMBER is
    V_MOBILE integer;
  begin
    select count(*)
      into V_MOBILE
      from LCBASE.t_Zip_User
     where N_MOBILE_2 = N_MOBILE
       and c_user_id <> user_id
       and D_ENDDATE > sysdate;
    if V_MOBILE > 0 then
      ErrMsg := '备用手机已存在!';
      return - 1;
    else
      return 0;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := 'phones操作异常: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
  end;

  /*
   判断手机号是否存在2_insert
  */
  function is_phones_exists2_insert(N_MOBILE in varchar2,
                                    ErrMsg   out varchar2) RETURN NUMBER is
    V_MOBILE integer;
  begin
    select count(*)
      into V_MOBILE
      from LCBASE.t_Zip_User
     where N_MOBILE_2 = N_MOBILE
       and D_ENDDATE > sysdate;
    if V_MOBILE > 0 then
      ErrMsg := '备用手机已存在!';
      return - 1;
    else
      return 0;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := 'phones操作异常..: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
  end;

  --判断EMAIL 是否存在
  function is_EMAIL_exists(EMAIL   in varchar2,
                           user_id in char,
                           ErrMsg  out varchar2) RETURN NUMBER is
    counts integer;
  begin
    SELECT count(*)
      into counts
      FROM LCBASE.T_ZIP_USER
     WHERE V_EMAIL = EMAIL
       AND C_USER_ID <> user_id
       and D_ENDDATE > Sysdate;
    if counts > 0 then
      ErrMsg := 'EMAIL重复！';
      return - 1;
    else
      return 0;
    end if;
  end;

  --判断EMAIL 是否存在_insert
  function is_EMAIL_exists_insert(email in varchar2, ErrMsg out varchar2)
    RETURN NUMBER is
    counts integer;
  begin
    SELECT count(*)
      into counts
      FROM LCBASE.T_ZIP_USER
     WHERE V_EMAIL = email
       and D_ENDDATE > sysdate;
    if counts > 0 then
      ErrMsg := 'EMAIL重复！';
      return - 1;
    else
      return 0;
    end if;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := 'EMAIL操作异常..: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
  end;
  FUNCTION OASaveRoleMenuRights(RIGHT_ROLE      IN VARCHAR2,
                                MENU_LIST       IN PKG_COMMON.ARR_UID,
                                RIGHT_LIST      IN PKG_COMMON.ARR_UID,
                                OperationUserID IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) RETURN NUMBER IS
    CORP_ID   VARCHAR2(32);
    PARENT_ID VARCHAR2(32);
  BEGIN
    IF MENU_LIST.COUNT <> RIGHT_LIST.COUNT THEN
      ErrMsg := '参数数组长度不匹配';
      RETURN - 1;
    END IF;

    FOR i IN MENU_LIST.FIRST .. MENU_LIST.LAST LOOP
      DELETE FROM Oa_Aut_Role_Menu
       WHERE C_ROLE_ID = RIGHT_ROLE
         AND C_MENU_ID = MENU_LIST(i);
      IF BITAND(RIGHT_LIST(i), 2046) > 0 THEN
        SELECT U.C_MENU_PARENT_ID
          INTO PARENT_ID
          FROM Oa_Aut_Menu_Dic U
         WHERE U.C_MENU_ID = MENU_LIST(i);
        INSERT INTO Oa_Aut_Role_Menu
          (C_ROLE_ID, C_MENU_ID, N_RIGHT)
        VALUES
          (RIGHT_ROLE, MENU_LIST(i), RIGHT_LIST(i));
      END IF;
    END LOOP;

    IF PARENT_ID is not null THEN
      DELETE FROM Oa_Aut_Role_Menu
       WHERE C_ROLE_ID = RIGHT_ROLE
         AND C_MENU_ID = PARENT_ID;
      INSERT INTO Oa_Aut_Role_Menu
        (C_ROLE_ID, C_MENU_ID, N_RIGHT)
      VALUES
        (RIGHT_ROLE, PARENT_ID, '2046');
    END IF;

    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := '保存权限设置失败,' || SQLERRM;
      RETURN - 1;
  END;

END PKG_USER;

/

