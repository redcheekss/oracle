create PACKAGE BODY PKG_USER AS

    FUNCTION Update_User(PUserInfo         IN VARCHAR2,
                         OperationUserId   IN VARCHAR2,
                         UserId            IN OUT VARCHAR2,
                         V_ORGANIZATION_ID out char,
                         ErrMsg            OUT VARCHAR2)
        RETURN NUMBER IS
        DATAARR  PKG_COMMON.ARR_LONGSTR;
        P_ID     CHAR(32);
        P_STEP   NUMBER(2);
        n_optype number(1);
        n_result number(1) := 0;
        ErrMsg2  varchar2(50);
    BEGIN
        BEGIN
            P_STEP  := 0;
            DATAARR := PKG_COMMON.Split(PUserInfo, '^');
            P_ID    := DATAARR(1);
            IF P_ID IS NULL THEN
            
                P_ID := LOWER(SYS_GUID());
                --判断手机号是否存在
                n_result := pkg_user.is_phones_exists_insert(DATAARR(7),
                                                             ErrMsg);
                if n_result = -1 then
                    return - 1;
                end if;
                --判断手机号是否存在2
                n_result := pkg_user.is_phones_exists2_insert(DATAARR(8),
                                                              ErrMsg);
                if n_result = -1 then
                    return - 1;
                end if;
            
                n_result := pkg_user.is_EMAIL_exists_insert(DATAARR(12),
                                                            ErrMsg);
                if n_result = -1 then
                    return - 1;
                end if;
            
                INSERT INTO LCBASE.T_USER
                    (C_USER_ID,
                     C_ORGANIZATION_ID,
                     V_USER_NAME,
                     N_USER_TYPE,
                     N_WORK_ID,
                     V_PET_NAME,
                     N_MOBILE_1,
                     N_MOBILE_2,
                     V_TEL_1,
                     V_TEL_2,
                     N_STATUS,
                     V_EMAIL,
                     C_PASSWORD,
                     V_WX_OPEN_ID,
                     V_WORK_WX_ACCOUNT,
                     N_SEX,
                     N_AUTHORITY,
                     N_WORK_WX_ACTIVATION,
                     V_HEADPIC_ALY)
                values
                    (P_ID,
                     DATAARR(2),
                     DATAARR(3),
                     DATAARR(4),
                     DATAARR(5),
                     DATAARR(3),
                     DATAARR(7),
                     DATAARR(8),
                     DATAARR(9),
                     DATAARR(10),
                     0, --（用户状态-默认为0 可用）DATAARR(11),
                     DATAARR(12),
                     lower(md5('lecarlink2020')), --DATAARR(13),
                     DATAARR(14),
                     DATAARR(15),
                     DATAARR(16),
                     DATAARR(17),
                     DATAARR(18),
                     DATAARR(19)
                     
                     );
                --commit;
                UserId            := P_ID;
                V_ORGANIZATION_ID := DATAARR(2);
                ErrMsg            := '插入成功';
                RETURN 0;
            ELSE
                n_result := pkg_user.is_phones_exists(DATAARR(7),
                                                      UserId,
                                                      ErrMsg);
                if n_result = -1 then
                    return - 1;
                end if;
            
                n_result := pkg_user.is_phones_exists2(DATAARR(8),
                                                       UserId,
                                                       ErrMsg);
                if n_result = -1 then
                    return - 1;
                end if;
            
                n_result := pkg_user.is_EMAIL_exists(DATAARR(12),
                                                     UserId,
                                                     ErrMsg);
                if n_result = -1 then
                    return - 1;
                end if;
                UPDATE lcbase.T_USER
                   set C_ORGANIZATION_ID = DATAARR(2),
                       V_USER_NAME       = DATAARR(3),
                       N_USER_TYPE       = DATAARR(4),
                       N_WORK_ID         = DATAARR(5),
                       V_PET_NAME        = DATAARR(6),
                       N_MOBILE_1        = DATAARR(7),
                       N_MOBILE_2        = DATAARR(8),
                       V_TEL_1           = DATAARR(9),
                       V_TEL_2           = DATAARR(10),
                       N_STATUS          = DATAARR(11),
                       V_EMAIL           = DATAARR(12),
                       --C_PASSWORD           = lcbase.md5(DATAARR(13)),
                       V_WX_OPEN_ID         = DATAARR(14),
                       V_WORK_WX_ACCOUNT    = DATAARR(15),
                       N_SEX                = DATAARR(16),
                       N_AUTHORITY          = DATAARR(17),
                       N_WORK_WX_ACTIVATION = DATAARR(18),
                       V_HEADPIC_ALY        = DATAARR(19)
                 WHERE C_USER_ID = UserId;
            
            END IF;
            --commit;
            ErrMsg := '更新成功';
            RETURN 0;
        
        EXCEPTION
            WHEN OTHERS THEN
                ErrMsg := 'UPDATE_EMPLOYEEINFO: ' ||
                          sqlcode || ',' || sqlerrm;
                raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                        ErrMsg,
                                        false);
                ROLLBACK;
                return - 1;
            
        END;
    
        return - 1;
    END;

    FUNCTION Delete_User(UserId          IN VARCHAR2,
                         OperationUserId IN VARCHAR2,
                         ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
        n_optype number(1);
        n_result number(1) := 0;
    BEGIN
        BEGIN
            n_optype := 4;
            UPDATE lcbase.T_USER
               SET N_STATUS = 1
             WHERE C_USER_ID = UserId;
        
            COMMIT;
            n_result := 1;
            PKG_COMMON.InsertOperationLog(OperationUserId,
                                          'T_USER',
                                          n_optype,
                                          n_result);
            RETURN 0;
        EXCEPTION
            WHEN ACCESS_INTO_NULL THEN
                ErrMsg := '数据不能为空';
                ROLLBACK;
            WHEN CASE_NOT_FOUND THEN
                ErrMsg := '没有找到数据';
                ROLLBACK;
            WHEN NO_DATA_FOUND THEN
                ErrMsg := '没有找到数据' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
                ROLLBACK;
            WHEN INVALID_NUMBER THEN
                ErrMsg := '无效数字' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
                ROLLBACK;
            WHEN VALUE_ERROR THEN
                ErrMsg := '数据错误' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
                ROLLBACK;
            WHEN OTHERS THEN
                ErrMsg := '删除用户信息失败: ' || SQLCODE || ',' ||
                          SQLERRM || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
                ROLLBACK;
        END;
        /* PKG_COMMON.InsertOperationLog(OperationUserId,
        'T_USER',
        n_optype,
        n_result);*/
        return - 1;
    END;

    FUNCTION Get_User(UserId          IN VARCHAR2,
                      OperationUserId IN VARCHAR2,
                      --       PUserInfo       OUT VARCHAR2,
                      CUR_DATA OUT SYS_REFCURSOR,
                      ErrMsg   OUT VARCHAR2) RETURN NUMBER IS
        n_result number(1) := 0;
    BEGIN
        BEGIN
            OPEN CUR_DATA FOR
                SELECT *
                  FROM lcbase.T_USER
                 WHERE C_USER_ID = UserId;
            n_result := 1;
            return 0;
        EXCEPTION
            WHEN OTHERS THEN
                ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                          SQLERRM || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
        END;
        /* PKG_COMMON.InsertOperationLog(OperationUserId,
        'T_USER',
        1,
        n_result);*/
        RETURN - 1;
    END;

    FUNCTION Login_User(UserAccount  VARCHAR2,
                        UserPassword VARCHAR2,
                        LoginType    NUMBER,
                        CUR_DATA     OUT SYS_REFCURSOR,
                        ErrMsg       OUT VARCHAR2)
        RETURN NUMBER IS
        user_count   NUMBER;
        valid_count  NUMBER;
        ReturnNumber NUMBER;
    BEGIN
        select count(1),
               sum(case
                       when c_password = UserPassword then
                        1
                       else
                        0
                   end)
          INTO user_count, valid_count
          from lcbase.t_user t
         where t.n_mobile_1 = UserAccount;
        if user_count = 0 then
            ErrMsg       := '用户账户不存在';
            ReturnNumber := 30002;
        elsif valid_count = 0 then
            ErrMsg       := '密码错误';
            ReturnNumber := 30004;
        else
            open CUR_DATA for
                select *
                  from lcbase.t_user a
                  left join lcbase.t_user_pic b
                    on a.c_user_id = b.c_user_id
                   and b.n_pic_type = 5
                 where n_mobile_1 = UserAccount
                   and c_password = UserPassword;
            ReturnNumber := 0;
        end if;
        return ReturnNumber;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := SQLCODE || ',' || SQLERRM;
            RETURN - 1; --其它错误
    END;

    -- 用户重名，返回工号
    function getUserWorkNo(UserId in varchar2) RETURN VARCHAR2 AS
        N_COUNT  NUMBER(4);
        cur_data varchar2(50);
    BEGIN
        select count(*)
          into n_count
          from lcbase.t_user tt
         where tt.v_user_name =
               (select t.v_user_name
                  from lcbase.t_user t
                 where t.c_user_id = UserId);
    
        if n_count > 1 then
            select t.v_user_name ||
                   decode(e.n_work_num,
                          null,
                          '',
                          '(' || e.n_work_num || ')')
              into cur_data
              from lcbase.t_user t
              left join lcbase.t_employees_info e
                on e.c_user_id = t.c_user_id
             where t.c_user_id = UserId;
        
        else
        
            select t.v_user_name
              into cur_data
              from lcbase.t_user t
             where t.c_user_id = UserId;
        
        end if;
        return cur_data;
    END;
    FUNCTION OAGetUserMenu(UserID    VARCHAR2,
                           MenuType  NUMBER,
                           RE_CURSOR OUT PKG_COMMON.REF_CURSOR,
                           ErrMsg    OUT VARCHAR) RETURN NUMBER IS
        ErrCode    NUMBER := 0;
        P_ROLE_ID  NUMBER(4);
        P_CORPFLAG NUMBER(2);
        P_CORP_ID  CHAR(32);
    BEGIN
        ErrCode := -3;
        OPEN RE_CURSOR FOR
            select t.c_menu_id,
                   t.v_menu_name,
                   t.n_delflag,
                   t.v_menu_url,
                   t.n_level,
                   t.v_icon_name,
                   t.c_menu_parent_id,
                   t.n_order,
                   t.n_right,
                   t.c_user_id
              from (select TT.*,
                           row_number() over(partition by TT.V_MENU_NAME order by TT.n_right desc) rw
                      from (select dic.*,
                                   rm.n_right,
                                   ur.c_user_id
                              from Oa_Aut_Role_Menu rm
                             INNER join Oa_Aut_Menu_Dic dic
                                on rm.c_menu_id =
                                   dic.c_menu_id
                             INNER join Oa_Aut_Role r
                                on rm.c_role_id = r.c_role_id
                             INNER JOIN OA_AUT_USER_ROLE UR
                                ON R.C_ROLE_ID = UR.C_ROLE_ID
                             where ur.c_user_id = UserID
                               and dic.menu_type = MenuType
                            union all
                            select dic.*,
                                   um.n_right as n_rights,
                                   um.c_user_id
                              from Oa_Aut_Menu_Dic dic
                             INNER join Oa_Aut_User_Menu UM
                                on dic.c_menu_id =
                                   um.c_menu_id
                             where um.c_user_id = UserID
                               and dic.menu_type = MenuType) TT) t
             where t.rw = 1;
        ErrCode := 0;
        RETURN ErrCode;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := SQLCODE || ',' || sqlerrm;
            RETURN ErrCode;
    END;

    /*
      手机号
    */
    function is_phones_exists(N_MOBILE in varchar2,
                              user_id  in char,
                              ErrMsg   out varchar2)
        RETURN NUMBER is
    
        V_MOBILE integer;
    begin
    
        select count(*)
          into V_MOBILE
          from LCBASE.T_USER
         where N_MOBILE_1 = N_MOBILE
           AND c_user_id <> user_id;
    
        if V_MOBILE > 0 then
            ErrMsg := '手机号已存在！';
            return - 1;
        
        else
            return 0;
        end if;
    
        return 0;
    
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := 'phones: ' || sqlcode || ',' ||
                      sqlerrm;
            raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                    ErrMsg,
                                    false);
        
            return - 1;
        
    end;

    /*
    */
    function is_phones_exists_insert(N_MOBILE in varchar2,
                                     ErrMsg   out varchar2)
        RETURN NUMBER is
    
        V_MOBILE integer;
    begin
    
        select count(*)
          into V_MOBILE
          from LCBASE.T_USER
         where N_MOBILE_1 = N_MOBILE;
    
        if V_MOBILE > 0 then
            ErrMsg := '手机号已存在！';
            return - 1;
        
        else
            return 0;
        end if;
    
        return 0;
    
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := 'phones操作异常: ' || sqlcode || ',' ||
                      sqlerrm;
            raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                    ErrMsg,
                                    false);
        
            return - 1;
        
    end;

    /*
     判断手机号是否存在2
    */
    function is_phones_exists2(N_MOBILE in varchar2,
                               user_id  in char,
                               ErrMsg   out varchar2)
        RETURN NUMBER is
    
        V_MOBILE integer;
    begin
    
        select count(*)
          into V_MOBILE
          from LCBASE.T_USER
         where N_MOBILE_2 = N_MOBILE
           and c_user_id <> user_id;
        if V_MOBILE > 0 then
            ErrMsg := '备用手机已存在!';
            return - 1;
        
        else
            return 0;
        end if;
    
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := 'phones操作异常: ' || sqlcode || ',' ||
                      sqlerrm;
            raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                    ErrMsg,
                                    false);
        
            return - 1;
        
    end;

    /*
     判断手机号是否存在2_insert
    */
    function is_phones_exists2_insert(N_MOBILE in varchar2,
                                      ErrMsg   out varchar2)
        RETURN NUMBER is
    
        V_MOBILE integer;
    begin
    
        select count(*)
          into V_MOBILE
          from LCBASE.T_USER
         where N_MOBILE_2 = N_MOBILE;
    
        if V_MOBILE > 0 then
            ErrMsg := '备用手机已存在!';
            return - 1;
        
        else
            return 0;
        end if;
    
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := 'phones操作异常..: ' || sqlcode || ',' ||
                      sqlerrm;
            raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                    ErrMsg,
                                    false);
        
            return - 1;
        
    end;

    --判断EMAIL 是否存在
    function is_EMAIL_exists(EMAIL   in varchar2,
                             user_id in char,
                             ErrMsg  out varchar2)
        RETURN NUMBER is
        counts integer;
    begin
        SELECT count(*)
          into counts
          FROM LCBASE.T_USER
         WHERE V_EMAIL = EMAIL
           AND C_USER_ID <> user_id;
        if counts > 0 then
        
            ErrMsg := 'EMAIL重复！';
            return - 1;
        else
            return 0;
        
        end if;
    
    end;

    --判断EMAIL 是否存在_insert
    function is_EMAIL_exists_insert(email  in varchar2,
                                    ErrMsg out varchar2)
        RETURN NUMBER is
        counts integer;
    begin
        SELECT count(*)
          into counts
          FROM LCBASE.T_USER
         WHERE V_EMAIL = email;
        if counts > 0 then
            ErrMsg := 'EMAIL重复！';
            return - 1;
        else
            return 0;
        
        end if;
    
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := 'EMAIL操作异常..: ' || sqlcode || ',' ||
                      sqlerrm;
            raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                    ErrMsg,
                                    false);
        
            return - 1;
    end;

END PKG_USER;
/

