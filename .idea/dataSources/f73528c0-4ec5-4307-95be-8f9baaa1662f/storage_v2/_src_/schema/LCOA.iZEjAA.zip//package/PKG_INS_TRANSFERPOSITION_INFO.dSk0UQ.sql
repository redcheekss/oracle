create package PKG_INS_TRANSFERPOSITION_INFO is

  function get_approval_list(recordvo        in varchar2,
                             pageNum         in number,
                             PageSize        in number,
                             getapprovallist out sys_refcursor,
                             totalPage       out number,
                             totalCount      out number,
                             errmsg          out varchar2) return number;

  function get_apply_list(recordvo     in varchar2,
                          pageNum      in number,
                          PageSize     in number,
                          getapplylist out sys_refcursor,
                          totalPage    out number,
                          totalCount   out number,
                          errmsg       out varchar2) return number;

  function add_leave_list(userid            in varchar2,
                          startdate         in varchar2,
                          enddate           in varchar2,
                          approvalapplytype in number,
                          errmsg            out varchar2) return number;

  function add_egress_list(userid            in varchar2,
                           startdate         in varchar2,
                           enddate           in varchar2,
                           approvalapplytype in number,
                           errmsg            out varchar2) return number;

  function add_news_list(userid            in varchar2,
                         startdate         in varchar2,
                         enddate           in varchar2,
                         approvalapplytype in number,
                         errmsg            out varchar2) return number;

  function add_adjustpost_list(userid            in varchar2,
                               startdate         in varchar2,
                               enddate           in varchar2,
                               approvalapplytype in number,
                               errmsg            out varchar2) return number;

  function add_promotion_list(userid            in varchar2,
                              startdate         in varchar2,
                              enddate           in varchar2,
                              approvalapplytype in number,
                              errmsg            out varchar2) return number;

  function add_loan_list(userid            in varchar2,
                         startdate         in varchar2,
                         enddate           in varchar2,
                         approvalapplytype in number,
                         errmsg            out varchar2) return number;

  function add_repayment_list(userid            in varchar2,
                              startdate         in varchar2,
                              enddate           in varchar2,
                              approvalapplytype in number,
                              errmsg            out varchar2) return number;

  function add_extension_list(userid            in varchar2,
                              startdate         in varchar2,
                              enddate           in varchar2,
                              approvalapplytype in number,
                              errmsg            out varchar2) return number;
  function add_datamodify_list(userid            in varchar2,
                               startdate         in varchar2,
                               enddate           in varchar2,
                               approvalapplytype in number,
                               errmsg            out varchar2) return number;

  --调岗信息添加
  function save_AfwAdjustpost_Info(datainfo        in varchar2,
                                   OperationUserId IN VARCHAR2,
                                   --DataId1         out char,
                                   c_cursor out sys_refcursor,
                                   ErrMsg   OUT VARCHAR2) return number;

  --调岗详情
  function query_AfwAdjustpost_info(Adjust_id            in char,
                                    OperationUserId      IN VARCHAR2,
                                    AdjustPost_Info      out sys_refcursor,
                                    transferApplyForPost out sys_refcursor,
                                    ErrMsg               OUT VARCHAR2)
    return number;

  --更新调岗后的用户职位信息
  function update_UserAndEmployees_info(Adjust_Id in char,
                                        ErrMsg    OUT VARCHAR2) return number;

  --判断是否有bp
  function is_oraganization_exits(newOrgnizationId char,
                                  ErrMsg           OUT VARCHAR2)
    return number;

  --插入组织信息
  function INSERT_T_USER(User_id              in char,
                         v_new_orgnization_id in char,
                         ErrMsg               OUT VARCHAR2) return number;

  --调岗详情-模块更新(user_组织使用拉链表信息)
  --调岗信息添加
  /*function save_AfwAdjustpost_Info2(datainfo        in varchar2,
                                  OperationUserId IN OUT VARCHAR2,
                                  DataId1         out char,
                                  ErrMsg          OUT VARCHAR2)
  return number;*/
  --更新调岗后的用户职位信息-拉链表信息改动)
  /*function update_UserAndEmployees_info2(Adjust_Id in char,
                                       ErrMsg    OUT VARCHAR2)
  return number;*/
  function Get_Message_List(UserID     in varchar2,
                            MsgType    in varchar2,
                            pageNum    in number,
                            PageSize   in number,
                            DataInfo   out sys_refcursor,
                            totalPage  out number,
                            totalCount out number,
                            ErrMsg     out varchar2) return number;

end PKG_INS_TRANSFERPOSITION_INFO;
/

