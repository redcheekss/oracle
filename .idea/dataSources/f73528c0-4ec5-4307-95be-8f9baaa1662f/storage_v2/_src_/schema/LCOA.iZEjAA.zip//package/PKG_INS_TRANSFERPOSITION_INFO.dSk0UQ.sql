create package PKG_INS_TRANSFERPOSITION_INFO is

  function get_approval_list(recordvo        in varchar2,
                             pageNum         in number,
                             PageSize        in number,
                             getapprovallist out sys_refcursor,
                             totalPage       out number,
                             totalCount      out number,
                             errmsg          out varchar2) return number;
  function get_apply_list(recordvo     in varchar2,
                          pageNum      in number,
                          PageSize     in number,
                          getapplylist out sys_refcursor,
                          totalPage    out number,
                          totalCount   out number,
                          errmsg       out varchar2) return number;
  function add_leave_list(userid            in varchar2,
                          startdate         in varchar2,
                          enddate           in varchar2,
                          approvalapplytype in number,
                          errmsg            out varchar2) return number;
  function add_egress_list(userid            in varchar2,
                           startdate         in varchar2,
                           enddate           in varchar2,
                           approvalapplytype in number,
                           errmsg            out varchar2) return number;
  function add_news_list(userid            in varchar2,
                         startdate         in varchar2,
                         enddate           in varchar2,
                         approvalapplytype in number,
                         errmsg            out varchar2) return number;

  function add_adjustpost_list(userid            in varchar2,
                               startdate         in varchar2,
                               enddate           in varchar2,
                               approvalapplytype in number,
                               errmsg            out varchar2) return number;

  function add_promotion_list(userid            in varchar2,
                              startdate         in varchar2,
                              enddate           in varchar2,
                              approvalapplytype in number,
                              errmsg            out varchar2) return number;

  function get_user_todo(userId      in varchar2,
                         pageNum     in number,
                         PageSize    in number,
                         getUserTodo out sys_refcursor,
                         totalPage   out number,
                         totalCount  out number,
                         errmsg      out varchar2) return number;

  function add_usertodo_forward(userid in varchar2, errmsg out varchar2)
    return number;

  function add_usertodo_meetinfo(userid in varchar2, errmsg out varchar2)
    return number;

  function add_usertodo_promotion(userid in varchar2, errmsg out varchar2)
    return number;

  --调岗信息添加
  function save_AfwAdjustpost_Info(datainfo        in varchar2,
                                   OperationUserId IN OUT VARCHAR2,
                                   DataId1         out char,
                                   ErrMsg          OUT VARCHAR2)
    return number;

  --调岗详情
  function query_AfwAdjustpost_info(Adjust_id            in char,
                                    OperationUserId      IN VARCHAR2,
                                    AdjustPost_Info      out sys_refcursor,
                                    transferApplyForPost out sys_refcursor,
                                    
                                    ErrMsg OUT VARCHAR2) return number;

  --更新调岗后的用户职位信息  
  function update_UserAndEmployees_info(Adjust_Id in char,
                                        ErrMsg    OUT VARCHAR2) return number;

  --判断是否有bp    
  function is_oraganization_exits(newOrgnizationId char,
                                  ErrMsg           OUT VARCHAR2)
    return number;

end PKG_INS_TRANSFERPOSITION_INFO;
/

