create package body PKG_INS_employee_info as

    /*
     1
     新增成员
     return 0 成功、-1 失败
     ErrMSg 返回错误信息表示： 当无错误时候返回0
     bp
     owner
     employeesInfo,
     userInfo,
     userPicList,
     OperationUserId
    
    */

    function insert_employeeInfo(bp              IN integer,
                                 owner           IN integer,
                                 vp              IN integer,
                                 employeesInfo   IN VARCHAR2,
                                 userInfo        IN VARCHAR2,
                                 userPicList     IN lcoa.ARR_LONGSTR,
                                 OperationUserId IN VARCHAR2,
                                 ErrMsg          OUT VARCHAR2
                                 
                                 ) return number is
        P_STEP            NUMBER(2);
        n_result          INTEGER := -1;
        v_userPicList     PKG_COMMON.ARR_LONGSTR;
        total             integer;
        v_userInfo        PKG_COMMON.ARR_LONGSTR;
        v_userID          varchar2(32);
        user_ids          varchar2(50);
        ids               varchar2(200);
        V_ORGANIZATION_ID char(32);
    begin
        BEGIN
            P_STEP := 0;
            --add users (userInfo  user_id=null 执行添加,not null update）
            n_result := Pkg_User.Update_User(userInfo,
                                             OperationUserId,
                                             v_userID,
                                             V_ORGANIZATION_ID,
                                             ErrMsg);
            if n_result <> 0 then
                return - 1;
            end if;
            v_userInfo := PKG_COMMON.Split(userInfo, '^');
        
            --是否是组织bp 0/1 （是、否）
            if bp = 1 then
                UPDATE LCBASE.T_ORGANIZATION
                   SET C_ORGANIZATION_BP = v_userID
                 WHERE C_ORGANIZATION_ID = v_userInfo(2);
            end if;
        
            --是否组织vp  0/1 （是、否）
            if owner = 1 then
                UPDATE LCBASE.T_ORGANIZATION
                   SET C_ORGANIZATION_OWNER = v_userID
                 WHERE C_ORGANIZATION_ID = v_userInfo(2);
            
            end if;
        
            --是否组织vp  0/1 （是、否）
            if vp = 1 then
                UPDATE LCBASE.T_ORGANIZATION
                   SET C_ORGANIZATION_VP = v_userID
                 WHERE C_ORGANIZATION_ID = v_userInfo(2);
            
            end if;
            --add employeesInfo
            n_result := Insert_Employee(employeesInfo,
                                        v_userID,
                                        ErrMsg);
            if n_result <> 0 then
                return - 1;
            end if;
        
            --add T_USER_PIC
            total := userPicList.Count;
        
            for i in 1 .. total loop
                v_userPicList := PKG_COMMON.Split(userPicList(i));
                n_result      := PKG_TEMPEMPLOYEE.Update_EmployeePic(v_userID,
                                                                     v_userPicList(2),
                                                                     v_userPicList(3),
                                                                     ErrMsg);
            
                if n_result <> 0 then
                    return - 1;
                end if;
            
            end loop;
        
            --更新日志记录
        
            ids := v_userID || '^' || v_userID || '^' ||
                   v_userID || '^' || V_ORGANIZATION_ID;
        
            n_result := pkg_ins_dept_info.HISTORY_TABLE_LOG(ids,
                                                            'C_USER_ID^C_USER_ID^C_USER_ID^C_ORGANIZATION_ID',
                                                            'LCBASE.T_USER^LCBASE.T_EMPLOYEES_INFO^LCBASE.T_USER_PIC^LCBASE.T_ORGANIZATION',
                                                            '0^0^0^0',
                                                            OperationUserId,
                                                            ErrMsg);
        
            --设置员工角色
            if n_result <> -1 and v_userID is not null then
                n_result := set_user_role(v_userID,
                                          'b27c1f975fcc4310ae04754c7c0b63ec', --默认设置为普通员工
                                          ErrMsg);
            
                update lcbase.t_user t
                   set t.v_pet_name =
                       (select u.v_user_name || '(' ||
                               e.n_work_num_old || ')'
                          from lcbase.t_user           u,
                               lcbase.t_employees_info e
                         where u.c_user_id = e.c_user_id
                           and u.c_user_id = t.c_user_id)
                 where t.v_user_name in
                       (select t.v_user_name
                          from lcbase.t_user t
                         WHERE t.v_user_name = v_userInfo(3)
                         group by t.v_user_name
                        having count(*) > 1);
            
                if n_result <> -1 then
                    ErrMsg   := '成功！';
                    n_result := 0;
                    return n_result;
                end if;
            
            else
                ErrMsg   := '失败！';
                n_result := -1;
                return n_result;
            
            end if;
        
        EXCEPTION
            WHEN OTHERS THEN
                ErrMsg := 'insert_employeeInfo: ' ||
                          sqlcode || ',' || sqlerrm;
                raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                        ErrMsg,
                                        false);
                rollback;
                return - 1;
        END;
        ROLLBACK;
        return - 1;
    end insert_employeeInfo;

    /*
    2
     更新成员
     return 0 成功、-1 失败
     ErrMSg 返回错误信息表示： 当无错误时候返回0
    
    */
    function update_employeeInfo(bp              IN integer,
                                 owner           IN integer,
                                 vp              IN integer,
                                 employeesInfo   IN VARCHAR2,
                                 userInfo        IN VARCHAR2,
                                 userPicList     IN lcoa.ARR_LONGSTR,
                                 OperationUserId IN VARCHAR2,
                                 ErrMsg          OUT VARCHAR2
                                 
                                 ) return number is
        P_STEP        NUMBER(2);
        n_result      INTEGER;
        v_userPicList PKG_COMMON.ARR_LONGSTR;
        total         integer;
        v_userInfo    PKG_COMMON.ARR_LONGSTR;
        user_ids      varchar2(50);
        UserId        varchar2(50);
    
        V_ORGANIZATION_ID char(32);
        ids               varchar2(200);
        v_bp              integer;
        v_owner           integer;
        v_vp              integer;
    
    begin
        BEGIN
            P_STEP     := 0;
            v_userInfo := PKG_COMMON.Split(userInfo, '^');
            --是否是组织bp 0/1 （是、否）
            if bp = 1 then
                UPDATE LCBASE.T_ORGANIZATION
                   SET C_ORGANIZATION_BP = v_userInfo(1)
                 WHERE C_ORGANIZATION_ID = v_userInfo(2);
            else
                UPDATE LCBASE.T_ORGANIZATION
                   SET C_ORGANIZATION_BP = ''
                 WHERE C_ORGANIZATION_ID = v_userInfo(2)
                   and C_ORGANIZATION_BP = v_userInfo(1);
            
            end if;
        
            --是否组织Owner   0/1 （是、否）
            if owner = 1 then
                UPDATE LCBASE.T_ORGANIZATION
                   SET C_ORGANIZATION_OWNER = v_userInfo(1)
                 WHERE C_ORGANIZATION_ID = v_userInfo(2);
            
            else
                UPDATE LCBASE.T_ORGANIZATION
                   SET C_ORGANIZATION_OWNER = ''
                 WHERE C_ORGANIZATION_ID = v_userInfo(2)
                   and C_ORGANIZATION_OWNER = v_userInfo(1);
            
            end if;
        
            --是否组织vp  0/1 （是、否）
            if vp = 1 then
                UPDATE LCBASE.T_ORGANIZATION
                   SET C_ORGANIZATION_VP = v_userInfo(1)
                 WHERE C_ORGANIZATION_ID = v_userInfo(2);
            
            else
                UPDATE LCBASE.T_ORGANIZATION
                   SET C_ORGANIZATION_VP = ''
                 WHERE C_ORGANIZATION_ID = v_userInfo(2)
                   and C_ORGANIZATION_VP = v_userInfo(1);
            
            end if;
        
            --update users（userInfo user_id is null update）
            UserId   := v_userInfo(1);
            n_result := Pkg_User.Update_User(userInfo,
                                             OperationUserId,
                                             UserId,
                                             V_ORGANIZATION_ID,
                                             ErrMsg);
            if n_result <> 0 then
                return - 1;
            end if;
            --update employeesInfo（user_id is null ）
            n_result := PKG_TEMPEMPLOYEE.Update_Employee(employeesInfo,
                                                         ErrMsg);
            if n_result <> 0 then
                return - 1;
            end if;
            --update T_USER_PIC
            total := userPicList.Count;
        
            for i in 1 .. total loop
                v_userPicList := PKG_COMMON.Split(userPicList(i));
                n_result      := PKG_TEMPEMPLOYEE.Update_EmployeePic(UserId,
                                                                     v_userPicList(2),
                                                                     v_userPicList(3),
                                                                     ErrMsg);
            
                if n_result <> 0 then
                    return - 1;
                end if;
            end loop;
        
            --更新日志记录
            ids := UserId || '^' || UserId || '^' || UserId || '^' ||
                   V_ORGANIZATION_ID;
        
            n_result := pkg_ins_dept_info.HISTORY_TABLE_LOG(ids,
                                                            'C_USER_ID^C_USER_ID^C_USER_ID^C_ORGANIZATION_ID',
                                                            'LCBASE.T_USER^LCBASE.T_EMPLOYEES_INFO^LCBASE.T_USER_PIC^LCBASE.T_ORGANIZATION',
                                                            '1^1^1^1',
                                                            OperationUserId,
                                                            ErrMsg);
            update lcbase.t_user t
               set t.v_pet_name =
                   (select u.v_user_name || '(' ||
                           e.n_work_num_old || ')'
                      from lcbase.t_user           u,
                           lcbase.t_employees_info e
                     where u.c_user_id = e.c_user_id
                       and u.c_user_id = t.c_user_id)
             where t.v_user_name in
                   (select t.v_user_name
                      from lcbase.t_user t
                     WHERE t.v_user_name = v_userInfo(3)
                     group by t.v_user_name
                    having count(*) > 1);
        
            update lcbase.t_user t
               set t.v_pet_name = t.v_user_name
             where t.v_user_name in
                   (select t.v_user_name
                      from lcbase.t_user t
                     group by t.v_user_name
                    having count(*) = 1);
        
            if n_result = 0 then
                ErrMsg   := '更新成功！';
                n_result := 0;
                return n_result;
            else
                ErrMsg := '更新日志记录信息异常';
                rollback;
                return - 1;
            end if;
        
        EXCEPTION
            WHEN OTHERS THEN
                ErrMsg := 'update_employeeInfo: ' ||
                          sqlcode || ',' || sqlerrm;
                raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                        ErrMsg,
                                        false);
                rollback;
                return - 1;
        END;
    
        ROLLBACK;
        return - 1;
    
    end update_employeeInfo;

    /*
    3
     设置成员部门
     return 0 成功、-1 失败
     ErrMSg 返回错误信息表示： 当无错误时候返回0
    
    */
    function update_user_organization(userId          IN lcoa.ARR_LONGSTR,
                                      organizationId  IN VARCHAR2,
                                      OperationUserId IN VARCHAR2,
                                      ErrMsg          OUT VARCHAR2
                                      
                                      ) return number is
        P_STEP   NUMBER(2);
        total    integer;
        n_result INTEGER default - 1;
    begin
        BEGIN
            P_STEP := 0;
            total  := userId.count;
        
            for i in 1 .. total loop
                update LCBASE.T_USER
                   set C_ORGANIZATION_ID = organizationId
                 where C_USER_ID = userId(i);
            end loop;
        
            commit;
            n_result := 0;
            return n_result;
        EXCEPTION
            WHEN OTHERS THEN
                ErrMsg := 'update_user_organization: ' ||
                          sqlcode || ',' || sqlerrm;
                raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                        ErrMsg,
                                        false);
                rollback;
                return - 1;
        END;
    
        ROLLBACK;
        return - 1;
    end update_user_organization;

    /*
    4
     更新历史记录
     return 0 成功、-1 失败
     ErrMSg 返回错误信息表示： 当无错误时候返回0
    
    */
    function operation_user_recordinfo(DATAINFO IN lcoa.ARR_LONGSTR,
                                       ErrMsg   OUT VARCHAR2
                                       
                                       ) return number is
        P_STEP NUMBER(2);
    begin
        BEGIN
            P_STEP := 0;
            dbms_output.put_line('-----------------------------------------');
        
        EXCEPTION
            WHEN OTHERS THEN
                ErrMsg := 'operation_user_recordinfo: ' ||
                          sqlcode || ',' || sqlerrm;
                raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                        ErrMsg,
                                        false);
                rollback;
                return - 1;
        END;
    
        ROLLBACK;
        return - 1;
    end operation_user_recordinfo;

    /*
    insert Insert_Employee 信息数据
    */

    FUNCTION Insert_Employee(PEmployeeInfo IN VARCHAR2,
                             v_userID      in varchar2,
                             ErrMsg        OUT VARCHAR2)
        RETURN NUMBER IS
        DATAARR    PKG_COMMON.ARR_LONGSTR;
        P_STEP     NUMBER(2) := 0;
        P_CNT      NUMBER(3) := 0;
        P_OPTYPE   NUMBER(1) := 1;
        P_ID       char(32);
        V_WORK_NUM integer; -- 新工号
        result_n   integer;
        ErrMsg2    varchar2(50);
    BEGIN
        BEGIN
            DATAARR := PKG_COMMON.Split(PEmployeeInfo, '^');
        
            --查询员工count
            SELECT MAX(tei.N_WORK_NUM)
              into V_WORK_NUM
              FROM LCBASE.T_EMPLOYEES_INFO tei;
        
            --判断身份证银行卡是否为空
        
            result_n := Pkg_Tempemployee.IS_ID_CARD_EXISTS_insert(DATAARR(5),
                                                                  ErrMsg);
            if result_n = -1 then
                return - 1;
            end if;
            result_n := Pkg_Tempemployee.IS_BANK_CARD_EXISTS_insert(DATAARR(24),
                                                                    ErrMsg);
            if result_n = -1 then
                return - 1;
            end if;
        
            INSERT INTO LCBASE.T_EMPLOYEES_INFO
                (C_USER_ID,
                 N_WORK_PLACE,
                 N_POSSESSION,
                 V_USER_TITLE,
                 C_ID_CARD_NUMBER,
                 D_HIRE_DATE,
                 N_POLITICAL_APPERAR,
                 V_NATION,
                 N_MARRIAGE,
                 V_ID_CARD_ADDRESS,
                 N_HU_KOU_TYPE,
                 V_PRESENT_ADDRESS,
                 V_URGENCY_LINK_MAN,
                 V_URGENCY_LINK_TEL,
                 V_COLLEGE,
                 V_MAJOR,
                 N_LEARNING,
                 D_ENTRANCE,
                 D_GRADUATION,
                 N_HOBBIES,
                 V_GRADES,
                 D_PROMOTION,
                 N_EDUCATION,
                 V_BANK_CARD_NUMBER,
                 V_ACCUMULATION_FUND_TYPE,
                 V_OPENING_BANK,
                 V_REMARK,
                 N_SOCIAL_SECURITY_TYPE,
                 D_LEAVE,
                 N_WORK_NUM,
                 N_WORK_NUM_OLD,
                 C_LABOR_REF,
                 N_STATUS,
                 C_LK_COMPANY_ID)
            VALUES
                (v_userID, --DATAARR(1),
                 DATAARR(2),
                 DATAARR(3),
                 DATAARR(4),
                 DATAARR(5),
                 to_date(DATAARR(6), 'yyyymmddhh24miss'),
                 DATAARR(7),
                 DATAARR(8),
                 DATAARR(9),
                 DATAARR(10),
                 DATAARR(11),
                 DATAARR(12),
                 DATAARR(13),
                 DATAARR(14),
                 DATAARR(15),
                 DATAARR(16),
                 DATAARR(17),
                 to_date(DATAARR(18), 'yyyymmddhh24miss'),
                 to_date(DATAARR(19), 'yyyymmddhh24miss'),
                 DATAARR(20),
                 DATAARR(21),
                 to_date(DATAARR(22), 'yyyymmddhh24miss'),
                 DATAARR(23),
                 DATAARR(24),
                 DATAARR(25),
                 DATAARR(26),
                 DATAARR(27),
                 DATAARR(28),
                 DATAARR(29),
                 V_WORK_NUM + 1, --DATAARR(30),
                 V_WORK_NUM - 1, -- DATAARR(31),
                 DATAARR(32),
                 DATAARR(33), --默认0 正常,
                 DATAARR(34));
            ErrMsg := '成功';
            RETURN 0;
        EXCEPTION
            WHEN OTHERS THEN
                ErrMsg := 'Insert_Employee: ' || sqlcode || ',' ||
                          sqlerrm;
                raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                        ErrMsg,
                                        false);
                rollback;
                return - 1;
            
        END;
        ROLLBACK;
    
        RETURN - 1;
    END;

    --设置添加用户角色
    function set_user_role(v_userID  in char,
                           v_ROLE_ID in char,
                           ErrMsg    OUT VARCHAR2)
        return NUMBER is
    
    begin
        if v_userID is not null then
            INSERT INTO LCOA.OA_AUT_USER_ROLE
                (C_USER_ID, C_ROLE_ID)
            VALUES
                (v_userID, v_ROLE_ID);
            ErrMsg := '成功！';
            return 0;
        else
            ErrMsg := '设置添加用户角色 is not null！';
            return - 1;
        end if;
    
    exception
        WHEN OTHERS THEN
            ErrMsg := 'set_user_role: ' || sqlcode || ',' ||
                      sqlerrm;
            raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                    ErrMsg,
                                    false);
            ROLLBACK;
            return - 1;
        
    end;

end PKG_INS_employee_info;
/

