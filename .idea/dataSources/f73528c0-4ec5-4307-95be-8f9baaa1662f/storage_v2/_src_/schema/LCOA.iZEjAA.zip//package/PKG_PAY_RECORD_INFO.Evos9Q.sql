create package PKG_PAY_RECORD_INFO is
 function savePayRecordInfo(datainfo        in varchar2,
                          OperationUserId IN VARCHAR2,
                          paymentId       out VARCHAR2,
                          ErrMsg          OUT VARCHAR2) return number;
 function updateLoanStatus(datainfo        in varchar2,
                             OperationUserId IN VARCHAR2,
                             ErrMsg          OUT VARCHAR2) return number;
 

end PKG_PAY_RECORD_INFO;
/

