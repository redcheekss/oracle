create FUNCTION DectoBin(N IN Integer) RETURN VARCHAR2
IS

  vQuotient INTEGER;  --商
  vRemainder INTEGER; --余数
  vRESULT   VARCHAR2(100):='';
BEGIN

  IF N<=1 THEN RETURN to_char(N); END IF;
  IF N IS NULL THEN RETURN NULL;  END IF;

  vQuotient:=floor(N/2);
  vRemainder:=MOD(N,2);
  IF vQuotient=1 THEN
     vRESULT:='1'||to_char(vremainder)||vRESULT;
  ELSE
     vRESULT:=to_char(Dectobin(vQuotient))||to_char(vremainder);
  END IF;
  RETURN vRESULT;
END;
/

