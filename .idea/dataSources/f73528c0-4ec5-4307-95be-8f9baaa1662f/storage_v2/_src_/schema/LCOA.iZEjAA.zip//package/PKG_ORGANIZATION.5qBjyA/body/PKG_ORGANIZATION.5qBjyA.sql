create package body PKG_ORGANIZATION is
    FUNCTION Update_Organization(POrganizationInfo IN VARCHAR2,
                                 OperationUserId   IN VARCHAR2,
                                 Organization_Id   IN OUT VARCHAR2,
                                 ErrMsg            OUT VARCHAR2)
        RETURN NUMBER IS
        DATAARR  PKG_COMMON.ARR_LONGSTR;
        P_ID     CHAR(32);
        P_STEP   NUMBER(2);
        P_CNT    NUMBER(3);
        P_OPTYPE NUMBER(1) := 1;
    BEGIN
        BEGIN
            P_STEP  := 0;
            DATAARR := PKG_COMMON.Split(POrganizationInfo,
                                        '^');
            P_ID    := LOWER(SYS_GUID());
            P_CNT   := my_tabcolscount('lcbase.t_organization');
        
            IF Organization_Id IS NULL THEN
                P_OPTYPE := 2;
            else
                P_OPTYPE := 3;
            end if;
        
            lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                               'lcbase.t_organization',
                                               P_OPTYPE,
                                               0);
            return - 1;
        
            IF Organization_Id IS NULL THEN
                INSERT INTO LCBASE.T_ORGANIZATION
                    (c_organization_id,
                     v_organization_name,
                     c_organization_parent_id,
                     n_organization_level,
                     n_organization_type,
                     c_organization_owner,
                     n_status,
                     v_organization_abbname)
                VALUES
                    (P_ID,
                     DATAARR(2),
                     DATAARR(3),
                     DATAARR(4),
                     DATAARR(5),
                     DATAARR(6),
                     DATAARR(7),
                     DATAARR(8));
                Organization_Id := P_ID;
            ELSE
                UPDATE LCBASE.T_ORGANIZATION
                   SET v_organization_name      = DATAARR(2),
                       c_organization_parent_id = DATAARR(3),
                       n_organization_level     = DATAARR(4),
                       n_organization_type      = DATAARR(5),
                       c_organization_owner     = DATAARR(6)
                       --        ,n_status                              = DATAARR(7)
                      ,
                       v_organization_abbname = DATAARR(8)
                 WHERE c_organization_id = Organization_Id;
            END IF;
            COMMIT;
            lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                               'lcbase.t_organization',
                                               P_OPTYPE,
                                               1);
            RETURN 0;
        EXCEPTION
            WHEN ACCESS_INTO_NULL THEN
                ErrMsg := '数据不能为空';
            WHEN CASE_NOT_FOUND THEN
                ErrMsg := '没有找到数据';
            WHEN NO_DATA_FOUND THEN
                ErrMsg := '没有找到数据' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN INVALID_NUMBER THEN
                ErrMsg := '无效数字' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN VALUE_ERROR THEN
                ErrMsg := '数据错误' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN OTHERS THEN
                ErrMsg := '新增/更新组织信息失败: ' || P_STEP || ',' ||
                          SQLCODE || ',' || SQLERRM || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
        END;
        ROLLBACK;
        lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                           'lcbase.t_organization',
                                           P_OPTYPE,
                                           0);
        return - 1;
    END;

    FUNCTION Delete_Organization(Organization_Id IN VARCHAR2,
                                 OperationUserId IN VARCHAR2,
                                 ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
        P_OPTYPE NUMBER(1) := 4;
    BEGIN
        BEGIN
            UPDATE LCBASE.T_ORGANIZATION
               SET n_status = 1
             WHERE c_organization_id = Organization_Id;
            COMMIT;
        
            lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                               'lcbase.t_organization',
                                               P_OPTYPE,
                                               1);
            RETURN 0;
        EXCEPTION
            WHEN ACCESS_INTO_NULL THEN
                ErrMsg := '数据不能为空';
            WHEN CASE_NOT_FOUND THEN
                ErrMsg := '没有找到数据';
            WHEN NO_DATA_FOUND THEN
                ErrMsg := '没有找到数据' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN INVALID_NUMBER THEN
                ErrMsg := '无效数字' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN VALUE_ERROR THEN
                ErrMsg := '数据错误' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN OTHERS THEN
                ErrMsg := '删除组织信息失败: ' || SQLCODE || ',' ||
                          SQLERRM || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
        END;
        ROLLBACK;
        lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                           'lcbase.t_organization',
                                           P_OPTYPE,
                                           0);
        RETURN - 1;
    END;

    FUNCTION Get_OrganizationAlone(Organization_Id IN VARCHAR2,
                                   OperationUserId IN VARCHAR2,
                                   CUR_DATA        OUT SYS_REFCURSOR,
                                   ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT *
              FROM lcbase.t_organization
             WHERE c_organization_id = Organization_Id;
        lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                           'lcbase.t_organization',
                                           1,
                                           1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                               'lcbase.t_organization',
                                               1,
                                               0);
            RETURN - 1;
    END;

    FUNCTION Get_OrganizationUpward(Organization_Id IN VARCHAR2,
                                    OperationUserId IN VARCHAR2,
                                    CUR_DATA        OUT SYS_REFCURSOR,
                                    ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT *
              FROM lcbase.t_organization t
             start with t.c_organization_id =
                        Organization_Id
            connect by prior t.c_organization_parent_id =
                        t.c_organization_id;
    
        lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                           'lcbase.t_organization',
                                           1,
                                           1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                               'lcbase.t_organization',
                                               1,
                                               0);
            RETURN - 1;
    END;

    FUNCTION Get_OrganizationUpwardTest(Organization_Id IN VARCHAR2,
                                        OperationUserId IN VARCHAR2,
                                        CUR_DATA        OUT SYS_REFCURSOR,
                                        ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT *
              FROM lcbase.t_organization t
             start with t.c_organization_id =
                        Organization_Id
            connect by prior t.c_organization_parent_id =
                        t.c_organization_id;
    
        lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                           'lcbase.t_organization',
                                           1,
                                           1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                               'lcbase.t_organization',
                                               1,
                                               0);
            RAISE_APPLICATION_ERROR(50000,
                                    '查询数据失败: ');
            RETURN - 1;
    END;

    FUNCTION Get_OrganizationDownward(Organization_Id IN VARCHAR2,
                                      OperationUserId IN VARCHAR2,
                                      CUR_DATA        OUT SYS_REFCURSOR,
                                      ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT *
              FROM lcbase.t_organization t
             where t.n_status = 0
             start with t.c_organization_id =
                        Organization_Id
            connect by t.c_organization_parent_id = prior
                       t.c_organization_id
                   and t.n_status = 0;
        lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                           'lcbase.t_organization',
                                           1,
                                           1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            lcoa.pkg_common.InsertOperationLog(OperationUserId,
                                               'lcbase.t_organization',
                                               1,
                                               0);
            RETURN - 1;
    END;

end PKG_ORGANIZATION;
/

