create package body PKG_EXT_SDE_MEETINFO is

  -- Function and procedure implementations
  function GET_MEETING_MAJOR(DataId          in varchar2,
                             DataSource      in number,
                             OperationUserId in varchar2,
                             getmeetinginfo  out sys_refcursor,
                             getmeetcontent  out sys_refcursor,
                             gettodolist     out sys_refcursor,
                             getuploadinfo   out sys_refcursor,
                             getattendeelist out sys_refcursor,
                             getschedulenum  out sys_refcursor,
                             getuserschedule out sys_refcursor,
                             countmeetingid  out number,
                             ErrMsg          out varchar2) return number is
    m_result   number(6);
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_optype   number(1);
    n_status   number(1);
  begin
    time_start := systimestamp;
    begin
      n_optype := 1;
      m_result := lcoa.pkg_ins_meeting_info_get.GET_MEETING_MAJOR(DataId,
                                                 DataSource,
                                                 OperationUserId,
                                                 getmeetinginfo,
                                                 getmeetcontent,
                                                 gettodolist,
                                                 getuploadinfo,
                                                 getattendeelist,
                                                 getschedulenum,
                                                 getuserschedule,
                                                 countmeetingid,
                                                 ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := 'GET_MEETING_MAJOR: ' || SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        m_result := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (m_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'GET_MEETING_MAJOR',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if m_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
    else
      return m_result;
    end if;
  end;

  function add_meetingsummary_info(SDE_MEETING_INFO         IN varchar2,
                                   SDE_ATTENDEE_LIST        IN ARR_LONGSTR,
                                   SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                   OA_SDE_TODO_LIST         IN ARR_LONGSTR,
                                   USER_UPLOAD_INFO         IN ARR_LONGSTR,
                                   operation_id             in varchar2,
                                   ErrMsg                   OUT VARCHAR2,
                                   sys_meeting_id           out varchar2)
    return number is
    m_result   number(6);
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1);
    n_optype   number(1);
  begin
    time_start := systimestamp;
    begin
      n_optype := 3;
      m_result := pkg_meet_info.add_meetingsummary_info(SDE_MEETING_INFO,
                                                        SDE_ATTENDEE_LIST,
                                                        SDE_MEETING_CONTENT_LIST,
                                                        OA_SDE_TODO_LIST,
                                                        USER_UPLOAD_INFO,
                                                        operation_id,
                                                        ErrMsg,
                                                        sys_meeting_id);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := 'ADD_MEETINGSUMMARY_INFO: ' || SQLCODE || ',' ||
                    SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        m_result := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (m_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(operation_id,
                                  'ADD_MEETINGSUMMARY_INFO',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if m_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
    else
      return m_result;
    end if;
  end;

  function MEETING_MSG_RELEASEINFO(SDE_MEETING_INFO         IN varchar2,
                                   SDE_ATTENDEE_LIST        IN ARR_LONGSTR,
                                   SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                   OA_SDE_TODO_LIST         IN ARR_LONGSTR,
                                   USER_UPLOAD_INFO         IN ARR_LONGSTR,
                                   operation_id             in varchar2,
                                   ErrMsg                   OUT VARCHAR2)
    return number is
    m_result   number(6);
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1);
    n_optype   number(1);
  begin
    time_start := systimestamp;
    begin
      n_optype := 2;
      m_result := pkg_meet_info.Meeting_msg_releaseInfo(SDE_MEETING_INFO,
                                                        SDE_ATTENDEE_LIST,
                                                        SDE_MEETING_CONTENT_LIST,
                                                        OA_SDE_TODO_LIST,
                                                        USER_UPLOAD_INFO,
                                                        operation_id,
                                                        ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := 'MEETING_MSG_RELEASEINFO: ' || SQLCODE || ',' ||
                    SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        m_result := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (m_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(operation_id,
                                  'MEETING_MSG_RELEASEINFO',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if m_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
    else
      return m_result;
    end if;
  end;

end PKG_EXT_SDE_MEETINFO;
/

