create package body PKG_INS_USER_INFO is
  FUNCTION OAGetUserInfo(UserID   IN VARCHAR2,
                         User_CUR OUT sys_refcursor,
                         ErrMsg   OUT VARCHAR2) return number is
    ErrCode           NUMBER := 0;
    SuperiorUserId    char(32);
    SuperiorUserName  varchar2(20);
    SuperiorUserTitle varchar2(20);
    VPUserId          char(32);
    VPUserName        varchar2(20);
    VPUserTitle       varchar2(20);
  
  BEGIN
    ErrCode := -1;
  
    GetDirectSuperiorByUserId(UserID,
                              SuperiorUserId,
                              SuperiorUserName,
                              SuperiorUserTitle);
    GetVPByUserId(UserID, VPUserId, VPUserName, VPUserTitle);
  
    OPEN User_CUR FOR
      with all_org as
       (select sys_connect_by_path(t.v_organization_name, '-') orgfullname,
               t.c_organization_id
          from lcbase.T_ORGANIZATION t
         start with t.c_organization_id = '997c2b49b01d4bdba3c5ea4e0f615617'
        connect by t.c_organization_parent_id = prior t.c_organization_id)
      select u.v_user_name username,
             m.n_work_num_old worknum,
             decode(u.n_sex, 0, '未知', 1, '男', 2, '女', '未知') sex,
             m.v_user_title usertitle,
             --             substr(org.orgfullname,length('-北京乐卡车联科技有限公司-')+1) orgname,
             REPLACE(REPLACE(org.orgfullname,
                             '-北京乐卡车联科技有限公司-',
                             ''),
                     '-北京乐卡车联科技有限公司',
                     '北京乐卡车联科技有限公司') orgname,
             decode(SuperiorUserName, null, VPUserName, SuperiorUserName) SuperiorUserName,
             VPUserName VPUserName,
             u.n_mobile_1 mobile,
             u.v_email email,
             to_char(m.d_hire_date, 'yyyy.mm.dd') || '(已入职' ||
             ceil(sysdate - m.d_hire_date) || '天)' hiredate,
             u.v_headpic_aly headPicUrl,
             u.n_user_type userType
        from lcbase.t_user u
        left join lcbase.t_employees_info m
          on u.c_user_id = m.c_user_id
        left join all_org org
          on u.c_organization_id = org.c_organization_id
       where u.c_user_id = UserID;
  
    ErrCode := 0;
    RETURN ErrCode;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := SQLCODE || ',' || sqlerrm;
      raise;
  END;

  /*
  *获取直接上级
  *根据用户所在组织查找组织负责人。
  *返回结果：
  *    1. 有值，正常组织负责人
  *    2. 有值，如负责人是自己，则继续找上一级组织负责人，直至组织级别为2级的部门负责人
  *    3. 空，2级部门负责人，则返回空；该级别上级为部门VP（主管副总）
  *    4. 空，主管副总，则返回空；该级别上级为自己
  *    5. 异常，其他未知异常
  */
  procedure GetDirectSuperiorByUserId(UserId            in varchar2,
                                      SuperiorUserId    out varchar2,
                                      SuperiorUserName  out varchar2,
                                      SuperiorUserTitle out varchar2) is
  begin
    with all_g as
     (select *
        from lcbase.t_organization g
      connect by prior g.c_organization_parent_id = g.c_organization_id
       start with g.c_organization_id =
                  (select u.c_organization_id
                     from lcbase.t_user u
                    where u.c_user_id = UserId))
    select t.c_user_id, t.v_user_name, v_user_title
      into SuperiorUserId, SuperiorUserName, SuperiorUserTitle
      from (select superior.c_user_id,
                   superior.v_user_name,
                   '直接上级' v_user_title
              from all_g g
             inner join lcbase.t_user superior
                on g.c_organization_owner = superior.c_user_id
             where g.n_organization_level >= 2
               and superior.c_user_id <> UserId
             order by g.n_organization_level desc) t
     where rownum = 1;
  exception
    when NO_DATA_FOUND then
      SuperiorUserId := null;
    WHEN OTHERS THEN
      raise;
  end;
  procedure GetDirectSuperiorByOrgId(OrganizationId    in varchar2,
                                     SuperiorUserId    out varchar2,
                                     SuperiorUserName  out varchar2,
                                     SuperiorUserTitle out varchar2) is
  begin
    with all_g as
     (select *
        from lcbase.t_organization g
      connect by prior g.c_organization_parent_id = g.c_organization_id
       start with g.c_organization_id = OrganizationId)
    select t.c_user_id, t.v_user_name, v_user_title
      into SuperiorUserId, SuperiorUserName, SuperiorUserTitle
      from (select superior.c_user_id,
                   superior.v_user_name,
                   '直接上级' v_user_title
              from all_g g
             inner join lcbase.t_user superior
                on g.c_organization_owner = superior.c_user_id
             where g.n_organization_level >= 2
            --and superior.c_user_id <> UserId
             order by g.n_organization_level desc) t
     where rownum = 1;
  exception
    when NO_DATA_FOUND then
      SuperiorUserId := null;
    WHEN OTHERS THEN
      raise;
  end;
  /*
  *获取直接上级
  *根据用户所在组织查找组织负责人。
  *返回结果：
  *    1. 有值，正常组织VP
  *    2. 有值，VP本人
  *    3. 空，CEO不在此范畴，暂不考虑
  *    4. 异常，其他未知异常
  */
  procedure GetVPByUserId(UserId      in varchar2,
                          VPUserId    out varchar2,
                          VPUserName  out varchar2,
                          VPUserTitle out varchar2) is
  begin
    with all_g as
     (select *
        from lcbase.t_organization g
      connect by prior g.c_organization_parent_id = g.c_organization_id
       start with g.c_organization_id =
                  (select u.c_organization_id
                     from lcbase.t_user u
                    where u.c_user_id = UserId))
    select w.c_user_id, w.v_user_name, '主管副总'
      into VPUserId, VPUserName, VPUserTitle
      from all_g g
      left join lcbase.t_user w
        on w.c_user_id = g.c_organization_vp
     where g.n_organization_level = 2;
  exception
    when NO_DATA_FOUND then
      VPUserId    := null;
      VPUserName  := null;
      VPUserTitle := null;
    WHEN OTHERS THEN
      raise;
  end;
  procedure GetBPByOrgId(OrganizationId in varchar2,
                         BPUserId       out varchar2,
                         BPUserName     out varchar2,
                         BPUserTitle    out varchar2) is
  begin
    with all_g as
     (select *
        from lcbase.t_organization g
      connect by prior g.c_organization_parent_id = g.c_organization_id
       start with g.c_organization_id = OrganizationId)
    select w.c_user_id, w.v_user_name, '最近BP'
      into BPUserId, BPUserName, BPUserTitle
      from all_g g
      left join lcbase.t_user w
        on w.c_user_id = g.c_organization_bp
     where g.c_organization_bp is not null
       and rownum = 1
     order by g.n_organization_level desc;
  end;
  /*
  *判断用户是否为VP
  *根据用户ID判断其是否为VP。
  *返回结果：
  *    1. 是VP
  *    0. 不是VP
  */
  function IsVPUserByUserId(UserId      in varchar2,
                            VPUserId    out varchar2,
                            VPUserName  out varchar2,
                            VPUserTitle out varchar2) return number is
    iCnt integer := 0;
  begin
    select count(*)
      into iCnt
      from lcbase.t_organization t
     where t.c_organization_vp = UserId
       and t.n_organization_level = 2;
    if iCnt > 0 then
      select w.c_user_id, w.v_user_name, '主管副总'
        into VPUserId, VPUserName, VPUserTitle
        from lcbase.t_user w
       where w.c_user_id = UserId;
      return 1;
    else
      return 0;
    end if;
  end;
  /*
  *判断用户是否为CEO
  *根据用户ID判断其是否为CEO。
  *返回结果：
  *    1. 是CEO
  *    0. 不是CEO
  */
  function IsCEOByUserId(UserId   in varchar2,
                         CEOId    out varchar2,
                         CEOName  out varchar2,
                         CEOTitle out varchar2) return number is
    iCnt integer := 0;
  begin
    select count(*)
      into iCnt
      from lcoa.oa_afw_workflow_user_type t
     where t.v_approval_user_id = UserId
       and t.n_approval_user_type = 7; --CEO
    if iCnt > 0 then
      select w.c_user_id, w.v_user_name, 'CEO'
        into CEOId, CEOName, CEOTitle
        from lcbase.t_user w
       where w.c_user_id = UserId;
      return 1;
    else
      return 0;
    end if;
  end;
  function IsLv2OwnerByUserId(UserId        in varchar2,
                              Lv2OwnerId    out varchar2,
                              Lv2OwnerName  out varchar2,
                              Lv2OwnerTitle out varchar2) return number is
    iCnt integer := 0;
  begin
    select count(*)
      into iCnt
      from lcbase.t_organization t
     where t.c_organization_owner = UserId
       and t.n_organization_level = 2;
    if iCnt > 0 then
      select w.c_user_id, w.v_user_name, '直接上级'
        into Lv2OwnerId, Lv2OwnerName, Lv2OwnerTitle
        from lcbase.t_user w
       where w.c_user_id = UserId;
      return 1;
    else
      return 0;
    end if;
  end;
end PKG_INS_USER_INFO;
/

