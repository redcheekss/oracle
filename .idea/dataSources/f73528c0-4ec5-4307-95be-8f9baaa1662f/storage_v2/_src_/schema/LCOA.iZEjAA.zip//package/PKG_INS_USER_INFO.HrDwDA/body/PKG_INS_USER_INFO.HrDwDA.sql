create package body PKG_INS_USER_INFO is

  FUNCTION OAGetUserInfo(UserID   IN VARCHAR2,
                         User_CUR OUT sys_refcursor,
                         ErrMsg   OUT VARCHAR2) return number is
    ErrCode           NUMBER := 0;
    SuperiorUserId    char(32);
    SuperiorUserName  varchar2(200);
    SuperiorUserTitle varchar2(20);
    VPUserId          char(32);
    VPUserName        varchar2(200);
    VPUserTitle       varchar2(20);

  BEGIN

    GetDirectSuperiorByUserId(UserID,
                              SuperiorUserId,
                              SuperiorUserName,
                              SuperiorUserTitle);
    GetVPByUserId(UserID, VPUserId, VPUserName, VPUserTitle);

    OPEN User_CUR FOR
      with all_org as
       (select sys_connect_by_path(t.v_organization_name, '-') orgfullname,
               t.c_organization_id
          from (SELECT *
                  FROM LCBASE.T_ZIP_ORGANIZATION
                 WHERE D_ENDDATE > SYSDATE) t
         start with t.c_organization_id = '997c2b49b01d4bdba3c5ea4e0f615617'
        connect by t.c_organization_parent_id = prior t.c_organization_id)
      select u.V_USER_NAME username,
             LPAD(m.n_work_num_old, 4, '0') worknum,
             decode(u.n_sex, 0, '未知', 1, '男', 2, '女', '未知') sex,
             m.v_user_title usertitle,
             --             substr(org.orgfullname,length('-北京乐卡车联科技有限公司-')+1) orgname,
             REPLACE(REPLACE(org.orgfullname,
                             '-北京乐卡车联科技有限公司-',
                             ''),
                     '-北京乐卡车联科技有限公司',
                     '北京乐卡车联科技有限公司') orgname,
             decode(SuperiorUserName, null, VPUserName, SuperiorUserName) SuperiorUserName,
             VPUserName VPUserName,
             u.n_mobile_1 mobile,
             u.v_email email,
             to_char(m.d_hire_date, 'yyyy.mm.dd') || '(已入职' ||
             ceil(sysdate - m.d_hire_date) || '天)' hiredate,
             u.v_headpic_aly headPicUrl,
             u.n_user_type userType
        from lcbase.t_zip_user u
        left join lcbase.t_employees_info m
          on u.c_user_id = m.c_user_id
        left join all_org org
          on u.c_organization_id = org.c_organization_id
       where u.c_user_id = UserID
         and u.d_enddate > sysdate;

    ErrCode := 0;
    RETURN ErrCode;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := SQLCODE || ',' || sqlerrm;
      raise;
  END;

  /*
  *获取直接上级
  *根据用户所在组织查找组织负责人。
  *返回结果：
  *    1. 有值，正常组织负责人
  *    2. 有值，如负责人是自己，则继续找上一级组织负责人，直至组织级别为2级的部门负责人
  *    3. 空，2级部门负责人，则返回空；该级别上级为部门VP（主管副总）
  *    4. 空，主管副总，则返回空；该级别上级为自己
  *    5. 异常，其他未知异常
  */
  procedure GetDirectSuperiorByUserId(UserId            in varchar2,
                                      SuperiorUserId    out varchar2,
                                      SuperiorUserName  out varchar2,
                                      SuperiorUserTitle out varchar2) is
    cSuperiorUserId    char(32);
    vSuperiorUserName  varchar2(20);
    vSuperiorUserTitle varchar2(20);
    nUserOrgType       number(2);
    nRet               number(6);
    nRoleId            number(2);
  begin
    nRet := IsCEOByUserId(UserId,
                          cSuperiorUserId,
                          vSuperiorUserName,
                          vSuperiorUserTitle);
    if nRet = 1 then
      SuperiorUserId    := cSuperiorUserId;
      SuperiorUserName  := vSuperiorUserName;
      SuperiorUserTitle := vSuperiorUserTitle;
      return;
    end if;
    nRet := IsMilitaryCommitteeByUserId(UserId,
                                        cSuperiorUserId,
                                        vSuperiorUserName,
                                        vSuperiorUserTitle);
    if nRet = 1 then
      GetCEO(SuperiorUserId, SuperiorUserName, SuperiorUserTitle);
      return;
    end if;

    nRet := IsTechnicalCommitteeByUserId(UserId,
                                         cSuperiorUserId,
                                         vSuperiorUserName,
                                         vSuperiorUserTitle);
    if nRet = 1 then
      GetCEO(SuperiorUserId, SuperiorUserName, SuperiorUserTitle);
      return;
    end if;

    nRet := IsLv2OwnerByUserId(UserId,
                               nUserOrgType,
                               cSuperiorUserId,
                               vSuperiorUserName,
                               vSuperiorUserTitle);
    if nRet = 1 then
      case
        when nUserOrgType = 8 then
          --组织型
          GetCEO(SuperiorUserId, SuperiorUserName, SuperiorUserTitle);
        when nUserOrgType = 9 then
          --项目型
          GetVPByUserId(UserId,
                        SuperiorUserId,
                        SuperiorUserName,
                        SuperiorUserTitle);
        when nUserOrgType = 10 then
          --兵团
          GetMilitaryCommittee(SuperiorUserId, SuperiorUserName);
        else
          SuperiorUserName := '未知错误{' || nUserOrgType || '|';
      end case;
      return;
    end if;

    nRet := IsSpecialDepartmentByUserId(UserId, nRoleId);
    if nRet = 1 then
      GetSpecialDepartmentOwner(nRoleId, SuperiorUserId, SuperiorUserName);
      return;
    end if;

    with all_g as
     (select *
        from (SELECT *
                FROM LCBASE.T_ZIP_ORGANIZATION
               WHERE D_ENDDATE > SYSDATE) g
      connect by prior g.c_organization_parent_id = g.c_organization_id
       start with g.c_organization_id =
                  (select u.c_organization_id
                     from lcbase.t_zip_user u
                    where u.c_user_id = UserId
                      and u.d_enddate > sysdate))
    select t.c_user_id, t.v_pet_name, v_user_title
      into SuperiorUserId, SuperiorUserName, SuperiorUserTitle
      from (select superior.c_user_id,
                   superior.v_pet_name,
                   '直接上级' v_user_title
              from all_g g
             inner join lcbase.t_zip_user superior
                on g.c_organization_owner = superior.c_user_id
             where g.n_organization_level >= 2
               and superior.c_user_id <> UserId
               and superior.d_enddate > sysdate
             order by g.n_organization_level desc) t
     where rownum = 1;

  exception
    when NO_DATA_FOUND then
      SuperiorUserId := null;
    WHEN OTHERS THEN
      raise;
  end;

  procedure GetDirectSuperiorByOrgId(OrganizationId    in varchar2,
                                     SuperiorUserId    out varchar2,
                                     SuperiorUserName  out varchar2,
                                     SuperiorUserTitle out varchar2) is
    cSuperiorUserId    char(32);
    vSuperiorUserName  varchar2(20);
    vSuperiorUserTitle varchar2(20);
    nUserOrgType       number(2);
    nRet               number(6);
    nRoleId            number(2);
  begin
    nRet := IsSpecialDepartmentByOrgId(OrganizationId, nRoleId);
    if nRet = 1 then
      GetSpecialDepartmentOwner(nRoleId, SuperiorUserId, SuperiorUserName);
      return;
    end if;

    with all_g as
     (select *
        from (SELECT *
                FROM LCBASE.T_ZIP_ORGANIZATION
               WHERE D_ENDDATE > SYSDATE) g
      connect by prior g.c_organization_parent_id = g.c_organization_id
       start with g.c_organization_id = OrganizationId)
    select t.c_user_id, t.v_pet_name, v_user_title
      into SuperiorUserId, SuperiorUserName, SuperiorUserTitle
      from (select superior.c_user_id,
                   superior.v_pet_name,
                   '直接上级' v_user_title
              from all_g g
             inner join lcbase.t_zip_user superior
                on g.c_organization_owner = superior.c_user_id
             where g.n_organization_level >= 2
               and superior.d_enddate > sysdate
             order by g.n_organization_level desc) t
     where rownum = 1;
  exception
    when NO_DATA_FOUND then
      SuperiorUserId := null;
    WHEN OTHERS THEN
      raise;
  end;
  /*
    procedure GetPLByUserId(UserId            in varchar2,
                            UserRecArray    out user_type_array
                            ) is
      cSuperiorUserId    char(32);
      vSuperiorUserName  varchar2(20);
      vSuperiorUserTitle varchar2(20);
      nUserOrgType       number(2);
      nRet               number(6);
      nRoleId            number(2);
    begin
      nRet := IsCEOByUserId(UserId,
                            cSuperiorUserId,
                            vSuperiorUserName,
                            vSuperiorUserTitle);
      if nRet = 1 then
        user_rec.UserId := cSuperiorUserId;
        user_rec.UserName  := vSuperiorUserName;
        user_rec.UserTitle := vSuperiorUserTitle;
        UserRecArray(1) := user_rec;
        return;
      end if;
  /*    nRet := IsMilitaryCommitteeByUserId(UserId,
                                          cSuperiorUserId,
                                          vSuperiorUserName,
                                          vSuperiorUserTitle);
      if nRet = 1 then
        GetCEO(SuperiorUserId, SuperiorUserName, SuperiorUserTitle);
              user_rec.UserId := cSuperiorUserId;
        user_rec.UserName  := vSuperiorUserName;
        user_rec.UserTitle := vSuperiorUserTitle;

        return;
      end if;

      nRet := IsTechnicalCommitteeByUserId(UserId,
                                           cSuperiorUserId,
                                           vSuperiorUserName,
                                           vSuperiorUserTitle);
      if nRet = 1 then
        GetCEO(SuperiorUserId, SuperiorUserName, SuperiorUserTitle);
        return;
      end if;

      nRet := IsLv2OwnerByUserId(UserId,
                                 nUserOrgType,
                                 cSuperiorUserId,
                                 vSuperiorUserName,
                                 vSuperiorUserTitle);
      if nRet = 1 then
        case
          when nUserOrgType = 8 then
            --组织型
            GetCEO(SuperiorUserId, SuperiorUserName, SuperiorUserTitle);
          when nUserOrgType = 9 then
            --项目型
            GetVPByUserId(UserId,
                          SuperiorUserId,
                          SuperiorUserName,
                          SuperiorUserTitle);
          when nUserOrgType = 10 then
            --兵团
            GetMilitaryCommittee(SuperiorUserId, SuperiorUserName);
          else
            SuperiorUserName := '未知错误{' || nUserOrgType || '|';
        end case;
        return;
      end if;

      nRet := IsSpecialDepartmentByUserId(UserId, nRoleId);
      if nRet = 1 then
        GetSpecialDepartmentOwner(nRoleId, SuperiorUserId, SuperiorUserName);
        return;
      end if;

      with all_g as
       (select *
          from (SELECT *
                  FROM LCBASE.T_ZIP_ORGANIZATION
                 WHERE D_ENDDATE > SYSDATE) g
        connect by prior g.c_organization_parent_id = g.c_organization_id
         start with g.c_organization_id =
                    (select u.c_organization_id
                       from lcbase.t_zip_user u
                      where u.c_user_id = UserId
                        and u.d_enddate > sysdate))
      select t.c_user_id, t.v_pet_name, v_user_title
        into SuperiorUserId, SuperiorUserName, SuperiorUserTitle
        from (select superior.c_user_id,
                     superior.v_pet_name,
                     '直接上级' v_user_title
                from all_g g
               inner join lcbase.t_zip_user superior
                  on g.c_organization_owner = superior.c_user_id
               where g.n_organization_level >= 2
                 and superior.c_user_id <> UserId
                 and superior.d_enddate > sysdate
               order by g.n_organization_level desc) t
       where rownum = 1;

    exception
      when NO_DATA_FOUND then
        SuperiorUserId := null;
      WHEN OTHERS THEN
        raise;
    end;*/
  /*
  *获取直接上级
  *根据用户所在组织查找组织负责人。
  *返回结果：
  *    1. 有值，正常组织VP
  *    2. 有值，VP本人
  *    3. 空，CEO不在此范畴，暂不考虑
  *    4. 异常，其他未知异常
  */
  procedure GetVPByUserId(UserId      in varchar2,
                          VPUserId    out varchar2,
                          VPUserName  out varchar2,
                          VPUserTitle out varchar2) is
  begin
    with all_g as
     (select *
        from (SELECT *
                FROM LCBASE.T_ZIP_ORGANIZATION
               WHERE D_ENDDATE > SYSDATE) g
      connect by prior g.c_organization_parent_id = g.c_organization_id
       start with g.c_organization_id =
                  (select u.c_organization_id
                     from lcbase.t_zip_user u
                    where u.c_user_id = UserId
                      and u.d_enddate > sysdate))
    select w.c_user_id, w.v_pet_name, '主管副总'
      into VPUserId, VPUserName, VPUserTitle
      from all_g g
      left join lcbase.t_zip_user w
        on w.c_user_id = g.c_organization_po
     where g.n_organization_level = 2
       and w.d_enddate > sysdate;
  exception
    when NO_DATA_FOUND then
      VPUserId    := null;
      VPUserName  := null;
      VPUserTitle := null;
    WHEN OTHERS THEN
      raise;
  end;

  function GetPLByUserId(UserId in varchar2) return ArrayUsersType is
    SuperiorUserId    char(32);
    SuperiorUserName  varchar2(20);
    SuperiorUserTitle varchar2(20);
    arrUserType       ArrayUsersType;
    nUserOrgType      number(2);
    nRet              number(6);
    nRoleId           number(2);
  begin
    nRet := IsCEOByUserId(UserId,
                          SuperiorUserId,
                          SuperiorUserName,
                          SuperiorUserTitle);
    if nRet = 1 then
      return GetCEO;
    end if;

    nRet := IsMilitaryCommitteeByUserId(UserId,
                                        SuperiorUserId,
                                        SuperiorUserName,
                                        SuperiorUserTitle);
    if nRet = 1 then
      return GetCEO;
    end if;

    nRet := IsTechnicalCommitteeByUserId(UserId,
                                         SuperiorUserId,
                                         SuperiorUserName,
                                         SuperiorUserTitle);
    if nRet = 1 then
      return GetCEO;
    end if;

    nRet := IsLv2OwnerByUserId(UserId,
                               nUserOrgType,
                               SuperiorUserId,
                               SuperiorUserName,
                               SuperiorUserTitle);
    if nRet = 1 then
      case
        when nUserOrgType = 8 then
          --组织型
          return GetCEO;
        when nUserOrgType = 9 then
          --项目型
          return GetPoByUserId(UserId);
        when nUserOrgType = 10 then
          --兵团
          return GetMilitaryCommittee;
        else
          SuperiorUserName := '未知错误{' || nUserOrgType || '|';
      end case;
      return arrUserType;
    end if;

    nRet := IsSpecialDepartmentByUserId(UserId, nRoleId);
    if nRet = 1 then
      return GetSpecialDepartmentOwner(nRoleId);
    end if;

    return GetCommonLeaderByUserId(UserId);
  exception
    when NO_DATA_FOUND then
      return arrUserType;
    WHEN OTHERS THEN
      raise;
  end;
  function GetCommonLeaderByUserId(UserId in varchar2) return ArrayUsersType is
    i            number default 0;
    UserRecArray ArrayUsersType;
  begin
    for ulst in (with all_g as
                    (select *
                      from (SELECT *
                              FROM LCBASE.T_ZIP_ORGANIZATION
                             WHERE D_ENDDATE > SYSDATE) g
                    connect by prior g.c_organization_parent_id =
                                g.c_organization_id
                     start with g.c_organization_id =
                                (select u.c_organization_id
                                   from lcbase.t_zip_user u
                                  where u.c_user_id = UserId
                                    and u.d_enddate > sysdate))
                   select t.c_user_id  user_id,
                          t.v_pet_name user_name,
                          v_user_title user_title
                     from (select superior.c_user_id,
                                  superior.v_pet_name,
                                  '直接上级' v_user_title
                             from all_g g
                            inner join lcbase.t_zip_user superior
                               on g.c_organization_owner = superior.c_user_id
                            where g.n_organization_level >= 2
                              and superior.c_user_id <> UserId
                              and superior.d_enddate > sysdate
                              and superior.n_status = 0
                            order by g.n_organization_level desc) t
                    where rownum = 1) loop
      user_rec.UserId := ulst.user_id;
      user_rec.UserName := ulst.user_name;
      user_rec.UserTitle := ulst.user_title;
      i := i + 1;
      UserRecArray(i) := user_rec;

    end loop;
    return UserRecArray;
  end;

  procedure GetCEO(CEOId    out varchar2,
                   CEOName  out varchar2,
                   CEOTitle out varchar2) is
  begin
    select w.c_user_id, w.v_pet_name, 'CEO'
      into CEOId, CEOName, CEOTitle
      from lcbase.t_zip_user w
     inner join lcoa.oa_afw_workflow_user_type t
        on t.v_approval_user_id = w.c_user_id
     where t.n_approval_user_type = 7
       and w.d_enddate > sysdate;
  end;
  function GetPOByUserId(UserId in varchar2) return ArrayUsersType is
    i            number default 0;
    UserRecArray ArrayUsersType;
  begin
    for ulst in (with all_g as
                    (select *
                      from (SELECT *
                              FROM LCBASE.T_ZIP_ORGANIZATION
                             WHERE D_ENDDATE > SYSDATE) g
                    connect by prior g.c_organization_parent_id =
                                g.c_organization_id
                     start with g.c_organization_id =
                                (select u.c_organization_id
                                   from lcbase.t_zip_user u
                                  where u.c_user_id = UserId
                                    and u.d_enddate > sysdate))
                   select w.c_user_id user_id,
                          w.v_pet_name user_name,
                          '主管副总' user_title
                     from all_g g
                     left join lcbase.t_zip_user w
                       on w.c_user_id = g.c_organization_po
                    where g.n_organization_level = 2
                      and w.d_enddate > sysdate) loop
      user_rec.UserId := ulst.user_id;
      user_rec.UserName := ulst.user_name;
      user_rec.UserTitle := ulst.user_title;
      i := i + 1;
      UserRecArray(i) := user_rec;
    end loop;
    return UserRecArray;
  end;
  function GetCEO return ArrayUsersType is
    i            number default 0;
    UserRecArray ArrayUsersType;
  begin
    for ulst in (select w.c_user_id user_id,
                        w.v_pet_name user_name,
                        'CEO' user_title
                   from lcbase.t_zip_user w
                  inner join lcoa.oa_afw_workflow_user_type t
                     on t.v_approval_user_id = w.c_user_id
                  where t.n_approval_user_type = 7
                    and w.d_enddate > sysdate) loop
      user_rec.UserId := ulst.user_id;
      user_rec.UserName := ulst.user_name;
      user_rec.UserTitle := ulst.user_title;
      i := i + 1;
      UserRecArray(i) := user_rec;

    end loop;
    return UserRecArray;
  end;

  --获取军委常委
  function GetMilitaryCommittee return ArrayUsersType is
    i            number default 0;
    UserRecArray ArrayUsersType;
  begin
    for ulst in (select a.c_user_id user_id,
                        a.v_pet_name user_name,
                        '军委常委' user_title
                   from lcbase.t_zip_user a, OA_AFW_APPROVAL_USER_ROLE b
                  where a.c_user_id = b.C_USER_ID
                    and a.d_enddate > sysdate
                    and b.N_APPROVAL_ROLE_ID = 3) loop
      user_rec.UserId := ulst.user_id;
      user_rec.UserName := ulst.user_name;
      user_rec.UserTitle := ulst.user_title;
      i := i + 1;
      UserRecArray(i) := user_rec;

    end loop;
    return UserRecArray;
  end;
  procedure GetMilitaryCommittee(PUserIds   out varchar2,
                                 PUserNames out varchar2) is
    vUserNames varchar2(100);
  begin
    --added by lihuawei at 2020.6.11经过与产品确认，显示军委常委即可
    --select listagg(a.v_pet_name, ',') within group(order by a.c_user_id)
    select '军委常委',
           listagg(a.v_pet_name, ',') within group(order by a.c_user_id)
      into PUserNames, vUserNames
      from lcbase.t_zip_user a, OA_AFW_APPROVAL_USER_ROLE b
     where a.c_user_id = b.C_USER_ID
       and a.d_enddate > sysdate
       and b.N_APPROVAL_ROLE_ID = 3;
  end;
  --获取技术委员会
  procedure GetTechnicalCommittee(PUserIds   out varchar2,
                                  PUserNames out varchar2) is
  begin
    --added by lihuawei at 2020.6.11经过与产品确认，技术委员会直接显示人
    select listagg(a.c_user_id, '、') within group(order by a.c_user_id),
           listagg(a.v_pet_name, '、') within group(order by a.c_user_id)
    --select '技术委员会'
      into PUSerIds, PUserNames
      from lcbase.t_zip_user a, OA_AFW_APPROVAL_USER_ROLE b
     where a.c_user_id = b.C_USER_ID
       and a.d_enddate > sysdate
       and b.N_APPROVAL_ROLE_ID = 2;
  end;
  --获取特殊部门审批人
  function GetSpecialDepartmentOwner(nRoleId in number) return ArrayUsersType is
    i            number default 0;
    UserRecArray ArrayUsersType;
  begin
    for ulst in (select a.c_user_id user_id,
                        a.v_pet_name user_name,
                        '军委常委' user_title
                   from lcbase.t_zip_user a, OA_AFW_APPROVAL_USER_ROLE b
                  where a.c_user_id = b.C_USER_ID
                    and a.d_enddate > sysdate
                    and b.N_APPROVAL_ROLE_ID = nRoleId) loop
      user_rec.UserId := ulst.user_id;
      user_rec.UserName := ulst.user_name;
      user_rec.UserTitle := ulst.user_title;
      i := i + 1;
      UserRecArray(i) := user_rec;

    end loop;
    return UserRecArray;
  end;
  procedure GetSpecialDepartmentOwner(nRoleId    in number,
                                      PUserIds   out varchar2,
                                      PUserNames out varchar2) is
  begin
    --added by lihuawei at 2020.6.11经过与产品确认，技术委员会直接显示人
    select listagg(a.v_pet_name, '、') within group(order by a.c_user_id)
      into PUserNames
      from lcbase.t_zip_user a, OA_AFW_APPROVAL_USER_ROLE b
     where a.c_user_id = b.C_USER_ID
       and a.d_enddate > sysdate
       and b.N_APPROVAL_ROLE_ID = nRoleId;
  end;

  procedure GetBPByOrgId(OrganizationId in varchar2,
                         BPUserId       out varchar2,
                         BPUserName     out varchar2,
                         BPUserTitle    out varchar2) is
  begin
    with all_g as
     (select *
        from (SELECT *
                FROM LCBASE.T_ZIP_ORGANIZATION
               WHERE D_ENDDATE > SYSDATE) g
      connect by prior g.c_organization_parent_id = g.c_organization_id
       start with g.c_organization_id = OrganizationId)
    select w.c_user_id, w.v_pet_name, '最近BP'
      into BPUserId, BPUserName, BPUserTitle
      from all_g g
      left join lcbase.t_zip_user w
        on w.c_user_id = g.c_organization_bp
     where g.c_organization_bp is not null
       and w.d_enddate > sysdate
       and rownum = 1
     order by g.n_organization_level desc;
  end;
  /*
  *判断用户是否为VP
  *根据用户ID判断其是否为VP。
  *返回结果：
  *    1. 是VP
  *    0. 不是VP
  */
  function IsVPUserByUserId(UserId      in varchar2,
                            VPUserId    out varchar2,
                            VPUserName  out varchar2,
                            VPUserTitle out varchar2) return number is
    iCnt integer := 0;
  begin
    select count(*)
      into iCnt
      from lcbase.t_zip_organization t
     where t.c_organization_po = UserId
       and t.n_organization_level = 2;
    if iCnt > 0 then
      select w.c_user_id, w.v_pet_name, '主管副总'
        into VPUserId, VPUserName, VPUserTitle
        from lcbase.t_zip_user w
       where w.c_user_id = UserId
         and w.d_enddate > sysdate;
      return 1;
    else
      return 0;
    end if;
  end;
  /*
  *判断用户是否为CEO
  *根据用户ID判断其是否为CEO。
  *返回结果：
  *    1. 是CEO
  *    0. 不是CEO
  */
  function IsCEOByUserId(UserId   in varchar2,
                         CEOId    out varchar2,
                         CEOName  out varchar2,
                         CEOTitle out varchar2) return number is
    iCnt integer := 0;
  begin
    select count(*)
      into iCnt
      from lcoa.oa_afw_workflow_user_type t
     where t.v_approval_user_id = UserId
       and t.n_approval_user_type = 7; --CEO
    if iCnt > 0 then
      select w.c_user_id, w.v_pet_name, 'CEO'
        into CEOId, CEOName, CEOTitle
        from lcbase.t_zip_user w
       where w.c_user_id = UserId
         and w.d_enddate > sysdate;
      return 1;
    else
      return 0;
    end if;
  end;
  /*
  *判断用户是否为军委常委
  *根据用户ID判断其是否为军委常委。
  *返回结果：
  *    1. 是军委常委
  *    0. 不是军委常委
  */
  function IsMilitaryCommitteeByUserId(UserId     in varchar2,
                                       PUserId    out varchar2,
                                       PUserName  out varchar2,
                                       PUserTitle out varchar2) return number is
    iCnt integer := 0;
  begin
    select count(*)
      into iCnt
      from LCOA.OA_AFW_APPROVAL_USER_ROLE
     where n_approval_role_id = 4
       and c_user_id = UserId;
    if iCnt > 0 then
      select w.c_user_id, w.v_pet_name, '军委常委'
        into PUserId, PUserName, PUserTitle
        from lcbase.t_zip_user w
       where w.c_user_id = UserId
         and w.d_enddate > sysdate;
      return 1;
    else
      return 0;
    end if;
  end;
  function IsTechnicalCommitteeByUserId(UserId     in varchar2,
                                        PUserId    out varchar2,
                                        PUserName  out varchar2,
                                        PUserTitle out varchar2)
    return number is
    iCnt integer := 0;
  begin
    select count(*)
      into iCnt
      from LCOA.OA_AFW_APPROVAL_USER_ROLE
     where n_approval_role_id = 2
       and c_user_id = UserId;
    if iCnt > 0 then
      select w.c_user_id, w.v_pet_name, '技术委员会'
        into PUserId, PUserName, PUserTitle
        from lcbase.t_zip_user w
       where w.c_user_id = UserId
         and w.d_enddate > sysdate;
      return 1;
    else
      return 0;
    end if;
  end;
  /*
  *判断用户是否为二级部门负责人
  *根据用户ID判断其是否为二级部门负责人。
  *输出
  *   Lv2OrgType: 8 -- 组织型部门 9 --项目型部门 10 -- 兵团
  *返回结果：
  *    1. 是二级部门负责人
  *    0. 不是二级部门负责人
  */
  function IsLv2OwnerByUserId(UserId        in varchar2,
                              Lv2OrgType    out number,
                              Lv2OwnerId    out varchar2,
                              Lv2OwnerName  out varchar2,
                              Lv2OwnerTitle out varchar2) return number is
    iCnt integer := 0;
  begin
    select count(*)
      into iCnt
      from lcbase.t_zip_organization t
     where t.c_organization_owner = UserId
       and t.n_organization_level = 2
       and t.d_enddate > sysdate;
    if iCnt > 0 then
      select org.n_organization_type, w.c_user_id, w.v_pet_name, '直接上级'
        into Lv2OrgType, Lv2OwnerId, Lv2OwnerName, Lv2OwnerTitle
        from lcbase.t_zip_organization org
       inner join lcbase.t_zip_user w
          on org.c_organization_owner = w.c_user_id
         and org.d_enddate > sysdate
         and w.d_enddate > sysdate
       where w.c_user_id = UserId
         and org.n_organization_level = 2
         and w.d_enddate > sysdate;
      return 1;
    else
      return 0;
    end if;
  end;
  --判断是否属于特殊部门，如是，则返回审批人角色
  function IsSpecialDepartmentByUserId(UserId  in varchar2,
                                       nRoleId out number) return number is

  begin
    select c.n_approval_role_id
      into nRoleid
      from OA_AFW_WORKFLOW_ORG_CONFIG c
     where c.c_organization_id =
           (select u.c_organization_id
              from lcbase.t_zip_user u
             where u.d_enddate > sysdate
               and u.c_user_id = UserId)
       and c.n_approval_order = 1;
    return 1;
  exception
    when others then
      nRoleId := -1;
      return 0;
  end;
  function IsSpecialDepartmentByOrgId(OrgId   in varchar2,
                                      nRoleId out number) return number is
  begin
    select c.n_approval_role_id
      into nRoleid
      from OA_AFW_WORKFLOW_ORG_CONFIG c
     where c.c_organization_id = OrgId
       and c.n_approval_order = 1;
    return 1;
  exception
    when others then
      nRoleId := -1;
      return 0;
  end;
  -- 逐级上级至主管副总
  function GetOwnerUntileLv2(WorkflowUserId in varchar2)
    return ArrayUsersType as
    i                number default 1;
    v_organizationid char(32);
    UserRecArray     ArrayUsersType;
  begin

    select t.c_organization_id
      into v_organizationid
      from lcbase.t_zip_user t
     where t.d_enddate > sysdate
       and t.c_user_id = WorkflowUserId;

    for lst in (select w.c_user_id UserId,
                       w.v_pet_name UserName,
                       case
                         when g.n_organization_level = 1 then
                          '主管副总'
                         else
                          '上级'
                       end as UserTitle
                  from (select *
                          from lcbase.t_zip_organization g
                        connect by prior g.c_organization_parent_id =
                                    g.c_organization_id
                         start with g.c_organization_id = v_organizationid) g
                  left join lcbase.t_zip_user w
                    on w.c_user_id = g.c_organization_owner
                 where nvl(g.n_organization_level, 5) > 0
                   and w.d_enddate > sysdate) loop
      user_rec.UserId := lst.UserId;
      user_rec.UserName := lst.UserName;
      user_rec.UserTitle := lst.UserTitle;
      UserRecArray(i) := user_rec;
      i := i + 1;
    end loop;
    return UserRecArray;
  end;

  -- 最近PB
  function GetNearestBP(WorkflowUserId    in varchar2,
                        NewOrganizationId in varchar default '')
    return ArrayUsersType as
    v_organizationid char(32);
    UserRecArray     ArrayUsersType;
  begin
    if NewOrganizationId is null then
      select t.c_organization_id
        into v_organizationid
        from lcbase.t_zip_user t
       where t.d_enddate > sysdate
         and t.c_user_id = WorkflowUserId;
    else
      v_organizationid := NewOrganizationId;
    end if;

    select s.c_user_id UserId, s.v_pet_name UserName, '最近BP' UserTitle
      into user_rec.UserId, user_rec.UserName, user_rec.UserTitle
      from (select *
              from (select *
                      from (select *
                              from lcbase.t_zip_organization g
                             where g.d_enddate > sysdate) g
                    connect by prior g.c_organization_parent_id =
                                g.c_organization_id
                     start with g.c_organization_id = v_organizationid) g
              left join lcbase.t_zip_user w
                on w.c_user_id = g.c_organization_bp
             where g.c_organization_bp is not null
               and w.d_enddate > sysdate
             order by n_organization_level desc) s
     where rownum = 1;

    UserRecArray(1) := user_rec;
    return UserRecArray;
  end;

  -- 获取主管副总
  function GetLv2OwnerByUserId(WorkflowUserId in varchar2)
    return ArrayUsersType as
    /*

      NewOrganizationId 为新部门id
    */
    i            number default 0;
    UserRecArray ArrayUsersType;

    flowusercount        number := 0;
    VPUserId             char(32);
    VPUserName           varchar2(20);
    VPUserTitle          varchar2(20);
    v_kindofwork         number;
    v_roleid             number;
    v_conf_orgid         char(32); -- 配置的用户所在的项目组（如产品部门的人在项目组）
    v_count              number;
    v_level              number;
    v_approval_model     number;
    v_organization_type  number;
    v_organization_owner char(32); -- 部门负责人id
    v_organization_id    char(32); -- 用户当前部门id
  begin

    /*
      如果是调岗，会涉及新旧部门的事
    */
    -- 用户信息（如果新部门id有值，则后面再获取相关信息）
    select u.c_organization_id,
           u.n_kindofwork,
           o.n_organization_type,
           o.c_organization_owner
      into v_organization_id,
           v_kindofwork,
           v_organization_type,
           v_organization_owner
      from lcbase.t_zip_user u
      join lcbase.t_zip_organization o
        on (u.c_organization_id = o.c_organization_id)
     where u.c_user_id = WorkflowUserId
       and u.d_enddate > sysdate
       and o.d_enddate > sysdate;

    --------------------------------

    --------------------------------

    --1 如果是ceo或主管副总，直接返回
    if (IsCEOByUserId(WorkflowUserId, VPUserId, VPUserName, VPUserTitle) = 1) then
      -- 主管副总以上级别的申请直接上级就是本人
      user_rec.UserId := VPUserId;
      user_rec.UserName := VPUserName;
      user_rec.UserTitle := VPUserTitle;
      UserRecArray(1) := user_rec;
      return UserRecArray;
    end if;

    --2 军委常委，由ceo审批
    select count(*)
      into v_count
      from OA_AFW_APPROVAL_USER_ROLE
     where n_approval_role_id = 4
       and c_user_id = WorkflowUserId;
    if v_count = 1 then
      select v_approval_user_id, v_approval_user_name, '主管副总'
        into user_rec.UserId, user_rec.UserName, user_rec.UserTitle
        from OA_AFW_WORKFLOW_USER_TYPE
       where n_approval_user_type = 7;
      UserRecArray(1) := user_rec;
      return UserRecArray;
    end if;

    if v_KINDOFWORK = 4 then
      -- 获取产品人员所在的项目组
      begin
        select uo.c_organization_id
          into v_conf_orgid
          from lcbase.T_USER_ORGANIZATION uo
         where uo.c_user_id = WorkflowUserId
           and N_MAIN_FLAG = 1;
      exception
        when NO_DATA_FOUND then
          -- 不在项目组
          v_conf_orgid := null;
      end;
    end if;
    --3 产品成员在项目组，则找po 不在的按通用规则找
    if v_KINDOFWORK = 4 and v_conf_orgid is not null then
      -- 在项目组
      begin
        select u.c_user_id, u.v_pet_name, '主管副总'
          into user_rec.UserId, user_rec.UserName, user_rec.UserTitle
          from lcbase.t_zip_user u
          join lcbase.t_zip_organization o
            on (o.c_organization_po = u.c_user_id)
         where u.d_enddate > sysdate
           and u.n_status = 0
           and o.d_enddate > sysdate
           and o.c_organization_id =
               (select uo.c_organization_id
                  from lcbase.T_USER_ORGANIZATION uo
                 where uo.c_user_id = WorkflowUserId
                   and N_MAIN_FLAG = 1);
        UserRecArray(1) := user_rec;
        return UserRecArray;
      end;
    end if;

    --4 项目型部门里面的成员（含部门负责人）找PO
    if v_organization_type = 9 then
      begin
        select u.c_user_id UserId,
               u.v_pet_name UserName,
               '主管副总' UserTitle
          into user_rec.UserId, user_rec.UserName, user_rec.UserTitle
          from lcbase.t_zip_user u
          join lcbase.t_zip_organization o
            on (o.c_organization_po = u.c_user_id)
         where u.d_enddate > sysdate
           and u.n_status = 0
           and o.c_organization_id = v_organization_id
           and o.d_enddate > sysdate;
        UserRecArray(1) := user_rec;
        return UserRecArray;
      exception
        when NO_DATA_FOUND then
          raise_application_error(-20000,
                                  '没有找到PO UserId:' || WorkflowUserId);
      end;
    end if;

    --5 特殊部门，OA_AFW_WORKFLOW_ORG_CONFIG
    begin
      select c.n_approval_role_id, c.n_approval_model
        into v_roleid, v_APPROVAL_MODEL
        from OA_AFW_WORKFLOW_ORG_CONFIG c
       where c.c_organization_id = v_organization_id
         and c.n_approval_order = 1;
      i := 1;
      for lst in (select a.c_user_id UserId,
                         a.v_pet_name UserName,
                         '主管副总' UserTitle
                    from lcbase.t_zip_user          a,
                         OA_AFW_APPROVAL_USER_ROLE  b,
                         OA_AFW_WORKFLOW_ORG_CONFIG c
                   where a.c_user_id = b.C_USER_ID
                     and b.n_approval_role_id = c.n_approval_role_id
                     and a.d_enddate > sysdate
                     and b.N_APPROVAL_ROLE_ID = v_roleid) loop

        user_rec.UserId := lst.UserId;
        user_rec.UserName := lst.UserName;
        user_rec.UserTitle := lst.UserTitle;
        UserRecArray(i) := user_rec;
        i := i + 1;
      end loop;
      return UserRecArray;
    exception
      when NO_DATA_FOUND then
        null;
    end;

    --6 小兵团，找谁？军种负责人
    if v_ORGANIZATION_TYPE = 10 then
      begin
        select nvl(t.n_organization_level, 0)
          into v_level
          from lcbase.t_zip_organization t
         where t.c_organization_id = v_organization_id
           and t.d_enddate > sysdate
           and t.n_status = 0;
      exception
        when others then
          v_level := 0;
      end;
      if v_level <= 2 and v_organization_owner is not null then

        -- 小兵团连长、 军种负责人，找军委常委审批人审批
        i := 1;
        for lst in (select a.c_user_id UserId,
                           a.v_pet_name UserName,
                           '主管副总' UserTitle

                      from lcbase.t_zip_user a, OA_AFW_APPROVAL_USER_ROLE b
                     where a.c_user_id = b.C_USER_ID
                       and a.d_enddate > sysdate
                       and b.N_APPROVAL_ROLE_ID =
                           (select ar.n_approval_role_id
                              from OA_AFW_APPROVAL_ROLE ar
                             where ar.v_approval_role_name = '军委审批人')) loop
          user_rec.UserId := lst.UserId;
          user_rec.UserName := lst.UserName;
          user_rec.UserTitle := lst.UserTitle;
          UserRecArray(i) := user_rec;
          i := i + 1;
        end loop;
        return UserRecArray;
      else
        -- 小兵团普通找对应军种负责人审批
        begin
          select u.c_user_id UserId,
                 u.v_pet_name UserName,
                 '主管副总' UserTitle
            into user_rec.UserId, user_rec.UserName, user_rec.UserTitle
            from lcbase.t_zip_user u
            join lcbase.t_zip_organization g
              on (u.c_user_id = g.c_organization_owner)
            join lcoa.OA_AFW_WORKFLOW_ARMY_CONFIG c
              on (c.c_organization_id = g.c_organization_id)
           where c.n_kindofwork = v_KINDOFWORK
             and u.d_enddate > sysdate
             and u.n_status = 0
             and g.d_enddate > sysdate
             and rownum = 1;
          UserRecArray(1) := user_rec;
          return UserRecArray;
        exception
          when NO_DATA_FOUND then
            raise_application_error(-20000,
                                    '没有找到数据 UserId:' || WorkflowUserId);
        end;
      end if;
    end if;

    --7 通用规则，部门负责人
    -- 部门负责人
    select count(*)
      into v_count
      from lcbase.t_zip_organization o
     where o.c_organization_id = v_organization_id
       and o.c_organization_owner = WorkflowUserId
       and o.d_enddate > sysdate
       and o.n_status = 0;
    if v_count = 1 then
      -- 部门负责人,找上一级部门负责人
      begin
        select c_organization_owner UserId,
               owner_name UserName,
               '主管副总' UserTitle
          into user_rec.UserId, user_rec.UserName, user_rec.UserTitle
          from (select g.c_organization_id,
                       v_organization_name,
                       n_organization_level,
                       c_organization_owner,
                       g.n_organization_type,
                       c_organization_po,
                       level as lv,
                       (select u.v_pet_name
                          from lcbase.t_zip_user u
                         where u.c_user_id = g.c_organization_owner
                           and u.d_enddate > sysdate
                           and u.n_status = 0) as owner_name
                  from (select *
                          from lcbase.t_zip_organization g
                         where g.d_enddate > sysdate) g
                 where g.d_enddate > sysdate
                connect by prior
                            g.c_organization_parent_id = g.c_organization_id
                 start with g.c_organization_id = v_organization_id
                 order by level)
         where c_organization_id <> v_organization_id
           and c_organization_owner is not null
           and rownum = 1;
        UserRecArray(1) := user_rec;
        return UserRecArray;
      end;
    else
      -- 通用规则 ，普通员工
      begin
        select c_organization_owner UserId,
               owner_name UserName,
               '主管副总' UserTitle
          into user_rec.UserId, user_rec.UserName, user_rec.UserTitle
          from (select g.c_organization_id,
                       v_organization_name,
                       n_organization_level,
                       c_organization_owner,
                       g.n_organization_type,
                       c_organization_po,
                       (select u.v_pet_name
                          from lcbase.t_zip_user u
                         where u.c_user_id = g.c_organization_owner
                           and u.d_enddate > sysdate
                           and u.n_status = 0) as owner_name
                  from (select *
                          from lcbase.t_zip_organization g
                         where g.d_enddate > sysdate) g
                 where g.d_enddate > sysdate
                connect by prior
                            g.c_organization_parent_id = g.c_organization_id
                 start with g.c_organization_id = v_organization_id)
         where n_organization_level = 2;
        UserRecArray(1) := user_rec;
        return UserRecArray;
      end;

    end if;

    return UserRecArray;
  end;

  procedure workflow_approval_reset(vCallContent out varchar2) as
    vUlist     ArrayUsersType;
    vExisted   number default 0;
    v_neworgid char(32);
  begin

    --遍历“新建”类型的审批流
    for aprvinfo in (select t.c_data_id,
                            flows.bstype,
                            t.n_approval_order, -- 审批环节
                            t.n_approval_model, -- 审批模式
                            con.n_approval_user_type,
                            t.c_approval_user_id,
                            t.v_approval_user_name,
                            t.v_approval_user_title,
                            flows.flowid,
                            flows.userid,
                            u.v_pet_name,
                            u.c_organization_id
                       from lcoa.oa_afw_workflow_approval_flow t
                       left join lcoa.oa_afw_workflow_config con
                         on t.n_workflow_type = con.n_workflow_type
                        and t.n_approval_order = con.n_approval_order
                       left join (select '请假' bstype,
                                        leave.c_leave_id flowid,
                                        leave.c_leave_user_id userid,
                                        leave.n_status status
                                   from lcoa.oa_afw_leave_info leave
                                 union all
                                 select '外出' bstype,
                                        egress.c_egress_id flowid,
                                        egress.c_egress_user_id userid,
                                        egress.n_status status
                                   from lcoa.oa_afw_egress_info egress
                                 union all
                                 select '公告' bstype,
                                        pub.c_news_id flowid,
                                        pub.c_input_user_id userid,
                                        pub.n_status status
                                   from lcoa.oa_msg_publish_info pub
                                 union all
                                 select '转正' bstype,
                                        prm.c_promotion_id flowid,
                                        prm.c_promotion_user_id userid,
                                        prm.n_status status
                                   from lcoa.oa_afw_promotion_info prm
                                 union all
                                 select '调岗' bstype,
                                        adj.c_adjust_id flowid,
                                        adj.c_adjust_user_id userid,
                                        adj.n_status status
                                   from lcoa.oa_afw_adjustpost_info adj) flows
                         on t.c_workflow_id = flows.flowid
                      inner join lcbase.t_zip_user u
                         on flows.userid = u.c_user_id
                        and u.d_enddate > sysdate
                      where t.n_approval_status = 0
                        and flows.status not in (-1, 2, 3)
                        and u.d_enddate > sysdate) loop
      --根据申请人，审批人类型定位新的审批人
      /*
        如果原审批人没有包含在新用户列表中 处理
        新用户列表多人的，取第一个处理
      */
      case
        when aprvinfo.n_approval_user_type = 1 then
          begin
            --根据发起人id找直接上级审批人列表
            vUlist := GetPLByUserId(UserId => aprvinfo.userid);
            for i in 1 .. vUlist.count() loop
              if aprvinfo.c_approval_user_id = vUlist(i).UserId then
                vExisted := 1;
                exit; -- 退出当前循环
              end if;
              vExisted := 0;
            end loop;
            if vExisted = 0 then
              -- 更新审批人，要防止原来是n位审批人，新的是1位审批人 【暂不处理】
              update lcoa.oa_afw_workflow_approval_flow t
                 set t.c_approval_user_id    = vUlist(1).UserId,
                     t.v_approval_user_name  = vUlist(1).UserName,
                     t.v_approval_user_title = vUlist(1).UserTitle
               where t.c_data_id = aprvinfo.c_data_id;
              update lcoa.oa_tdo_todo_info i
                 set i.c_todo_user_id = vUlist(1).UserId
               where i.c_todo_data_id = aprvinfo.c_data_id
                 and i.c_todo_user_id = aprvinfo.c_approval_user_id;
              vCallContent := vCallContent || '业务类型:' || aprvinfo.bstype ||
                              '审批流id:' || aprvinfo.c_data_id || '原审批人:' ||
                              aprvinfo.c_approval_user_id ||
                              aprvinfo.v_approval_user_name || '新审批人' || vUlist(1)
                             .UserId || vUlist(1).UserName;
              -- 更新待办
            end if;
          end;
          -- aprvinfo.userid
        when aprvinfo.n_approval_user_type = 2 then
          --逐级找上级
          begin
            --根据发起人id找直接上级审批人列表
            vUlist := GetOwnerUntileLv2(WorkflowUserId => aprvinfo.userid);
            for i in 1 .. vUlist.count() loop
              if aprvinfo.c_approval_user_id = vUlist(i).UserId then
                vExisted := 1;
                exit; -- 退出当前循环
              end if;
              vExisted := 0;
            end loop;
            if vExisted = 0 then
              vCallContent := vCallContent || '业务类型:' || aprvinfo.bstype ||
                              '审批流id:' || aprvinfo.c_data_id || '原审批人:' ||
                              aprvinfo.c_approval_user_id ||
                              aprvinfo.v_approval_user_name || '新审批人' || vUlist(1)
                             .UserId || vUlist(1).UserName;

              /*              dbms_output.put_line('审批流id:' || aprvinfo.c_data_id ||
              '原审批人:' || aprvinfo.c_approval_user_id ||
              aprvinfo.v_approval_user_name || '新审批人' || vUlist(1)
              .UserId || vUlist(1).UserName);*/
              -- 更新审批人，要防止原来是n位审批人，新的是1位审批人 【暂不处理】
              update lcoa.oa_afw_workflow_approval_flow t
                 set t.c_approval_user_id    = vUlist(1).UserId,
                     t.v_approval_user_name  = vUlist(1).UserName,
                     t.v_approval_user_title = vUlist(1).UserTitle
               where t.c_data_id = aprvinfo.c_data_id;
              update lcoa.oa_tdo_todo_info i
                 set i.c_todo_user_id = vUlist(1).UserId
               where i.c_todo_data_id = aprvinfo.c_data_id
                 and i.c_todo_user_id = aprvinfo.c_approval_user_id;
              -- 更新待办
            end if;
          end;
        when aprvinfo.n_approval_user_type = 3 then
          --找主管副总
          begin
            --根据发起人id找直接上级审批人列表
            vUlist := GetLv2OwnerByUserId(WorkflowUserId => aprvinfo.userid);
            for i in 1 .. vUlist.count() loop
              if aprvinfo.c_approval_user_id = vUlist(i).UserId then
                vExisted := 1;
                exit; -- 退出当前循环
              end if;
              vExisted := 0;
            end loop;
            if vExisted = 0 then
              -- 更新审批人，要防止原来是n位审批人，新的是1位审批人 【暂不处理】
              update lcoa.oa_afw_workflow_approval_flow t
                 set t.c_approval_user_id    = vUlist(1).UserId,
                     t.v_approval_user_name  = vUlist(1).UserName,
                     t.v_approval_user_title = vUlist(1).UserTitle
               where t.c_data_id = aprvinfo.c_data_id;
              update lcoa.oa_tdo_todo_info i
                 set i.c_todo_user_id = vUlist(1).UserId
               where i.c_todo_data_id = aprvinfo.c_data_id
                 and i.c_todo_user_id = aprvinfo.c_approval_user_id;
              -- 更新待办
              vCallContent := vCallContent || '业务类型:' || aprvinfo.bstype ||
                              '审批流id:' || aprvinfo.c_data_id || '原审批人:' ||
                              aprvinfo.c_approval_user_id ||
                              aprvinfo.v_approval_user_name || '新审批人' || vUlist(1)
                             .UserId || vUlist(1).UserName;
              /*
              dbms_output.put_line('审批流id:' || aprvinfo.c_data_id ||
                                   '原审批人:' || aprvinfo.c_approval_user_id ||
                                   aprvinfo.v_approval_user_name || '新审批人' || vUlist(1)
                                   .UserId || vUlist(1).UserName);*/
            end if;
          end;
        when aprvinfo.n_approval_user_type = 4 then
          --找最近BP
          begin
            v_neworgid := null;

            if aprvinfo.bstype = '调岗' and aprvinfo.n_approval_order = 4 then
              -- 获取到新部门id
              select t.c_new_orgnization_id
                into v_neworgid
                from lcoa.oa_afw_adjustpost_info t
               where t.c_adjust_id = aprvinfo.flowid;
            end if;

            vUlist := GetNearestBP(WorkflowUserId    => aprvinfo.userid,
                                   NewOrganizationId => aprvinfo.c_organization_id);
            for i in 1 .. vUlist.count() loop
              if aprvinfo.c_approval_user_id = vUlist(i).UserId then
                vExisted := 1;
                exit; -- 退出当前循环
              end if;
              vExisted := 0;
            end loop;
            if vExisted = 0 then
              vCallContent := vCallContent || '业务类型:' || aprvinfo.bstype ||
                              '审批流id:' || aprvinfo.c_data_id || '原审批人:' ||
                              aprvinfo.c_approval_user_id ||
                              aprvinfo.v_approval_user_name || '新审批人' || vUlist(1)
                             .UserId || vUlist(1).UserName;
              /*
              dbms_output.put_line('审批流id:' || aprvinfo.c_data_id ||
                                   '原审批人:' || aprvinfo.c_approval_user_id ||
                                   aprvinfo.v_approval_user_name || '新审批人' || vUlist(1)
                                   .UserId || vUlist(1).UserName);*/
              -- 更新审批人，要防止原来是n位审批人，新的是1位审批人 【暂不处理】
              update lcoa.oa_afw_workflow_approval_flow t
                 set t.c_approval_user_id    = vUlist(1).UserId,
                     t.v_approval_user_name  = vUlist(1).UserName,
                     t.v_approval_user_title = vUlist(1).UserTitle
               where t.c_data_id = aprvinfo.c_data_id;
              update lcoa.oa_tdo_todo_info i
                 set i.c_todo_user_id = vUlist(1).UserId
               where i.c_todo_data_id = aprvinfo.c_data_id
                 and i.c_todo_user_id = aprvinfo.c_approval_user_id;
              -- 更新待办
            end if;
          end;
        else
          dbms_output.put_line('未实现...');
      end case;

    end loop;

  end;

  function Cansee_Roleorg(OperationUserId IN VARCHAR2,
                          DataInfo        out sys_refcursor,
                          ErrMsg          out varchar2) return number is
    countrole  number(6);
    countadmin number(6);
    n_result   number(6);
  begin
    SELECT count(*)
      into countrole
      FROM lcoa.OA_AUT_ROLE r
      LEFT JOIN lcoa.OA_AUT_USER_ROLE ur
        ON r.C_ROLE_ID = ur.C_ROLE_ID
     WHERE r.ROLE_TYPE = '505'
       and ur.c_user_id = OperationUserId;
    SELECT count(*)
      into countadmin
      FROM lcoa.OA_AUT_ROLE r
      LEFT JOIN lcoa.OA_AUT_USER_ROLE ur
        ON r.C_ROLE_ID = ur.C_ROLE_ID
     WHERE r.ROLE_TYPE = '502'
       and ur.c_user_id = OperationUserId;
    if countadmin > 0 then
      n_result := pkg_organization.get_organizationdownward('997c2b49b01d4bdba3c5ea4e0f615617',
                                                            OperationUserId,
                                                            DataInfo,
                                                            ErrMsg);
    elsif countrole > 0 then
      open DataInfo for
        SELECT DISTINCT *
          FROM (SELECT DISTINCT *
                  FROM (SELECT *
                          FROM LCBASE.T_ZIP_ORGANIZATION
                         WHERE D_ENDDATE > SYSDATE) t
                 start with t.c_organization_id in
                            (select w.c_organization_id
                               from (SELECT *
                                       FROM (SELECT *
                                               FROM lcbase.t_zip_organization
                                              WHERE n_status = 0
                                                AND D_ENDDATE > SYSDATE) t
                                      START WITH t.c_organization_id in
                                                 (SELECT o.C_ORGANIZATION_ID
                                                    FROM (SELECT *
                                                            FROM lcbase.T_ZIP_ORGANIZATION o
                                                           WHERE o.D_ENDDATE >
                                                                 SYSDATE) o
                                                   WHERE o.C_ORGANIZATION_PO =
                                                         OperationUserId)
                                     CONNECT BY t.c_organization_parent_id = PRIOR
                                                t.c_organization_id
                                            AND t.n_status = 0
                                     union
                                     SELECT *
                                       FROM (SELECT *
                                               FROM lcbase.t_zip_organization
                                              WHERE n_status = 0
                                                AND D_ENDDATE > SYSDATE) t
                                      START WITH t.c_organization_id in
                                                 (SELECT o.C_ORGANIZATION_ID
                                                    FROM (SELECT *
                                                            FROM lcbase.T_ZIP_ORGANIZATION o
                                                           WHERE o.D_ENDDATE >
                                                                 SYSDATE) o
                                                   WHERE o.c_organization_owner =
                                                         OperationUserId)
                                     CONNECT BY t.c_organization_parent_id = PRIOR
                                                t.c_organization_id
                                            AND t.n_status = 0) w)
                connect by prior
                            t.c_organization_parent_id = t.c_organization_id
                UNION
                SELECT *
                  FROM (SELECT *
                          FROM lcbase.t_zip_organization
                         WHERE n_status = 0
                           AND D_ENDDATE > SYSDATE) t
                 START WITH t.c_organization_id =
                            'a7260eacce5c5289e050a8c0020125b3'
                CONNECT BY t.c_organization_parent_id = PRIOR
                           t.c_organization_id
                       AND t.n_status = 0) w;
    else
      open DataInfo for
        SELECT DISTINCT *
          FROM (SELECT *
                  FROM LCBASE.T_ZIP_ORGANIZATION
                 WHERE D_ENDDATE > SYSDATE) t
         start with t.c_organization_id in
                    (select w.c_organization_id
                       from (SELECT *
                               FROM (SELECT *
                                       FROM lcbase.t_zip_organization
                                      WHERE n_status = 0
                                        AND D_ENDDATE > SYSDATE) t
                              START WITH t.c_organization_id in
                                         (SELECT o.C_ORGANIZATION_ID
                                            FROM (SELECT *
                                                    FROM lcbase.T_ZIP_ORGANIZATION o
                                                   WHERE o.D_ENDDATE > SYSDATE) o
                                           WHERE o.C_ORGANIZATION_PO =
                                                 OperationUserId)
                             CONNECT BY t.c_organization_parent_id = PRIOR
                                        t.c_organization_id
                                    AND t.n_status = 0
                             union
                             SELECT *
                               FROM (SELECT *
                                       FROM lcbase.t_zip_organization
                                      WHERE n_status = 0
                                        AND D_ENDDATE > SYSDATE) t
                              START WITH t.c_organization_id in
                                         (SELECT o.C_ORGANIZATION_ID
                                            FROM (SELECT *
                                                    FROM lcbase.T_ZIP_ORGANIZATION o
                                                   WHERE o.D_ENDDATE > SYSDATE) o
                                           WHERE o.c_organization_owner =
                                                 OperationUserId)
                             CONNECT BY t.c_organization_parent_id = PRIOR
                                        t.c_organization_id
                                    AND t.n_status = 0) w)
        connect by prior t.c_organization_parent_id = t.c_organization_id;
    end if;
    return 0;
  exception
    when others then
      ErrMsg := 'Cansee_Roleorg: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

end PKG_INS_USER_INFO;

/

