create package PKG_INS_employee_info as

	--拉链表操作1 给组织设置bp,vp,onwer
	function insert_up_zip_t_organization(v_userID          in char,
																				p_organization_id in char,
																				bp_vp_owner_type  in integer,
																				ErrMsg            out varchar2)
		return number;

	--拉链表操作2 取消组织bp，vp，onwer
	function insert_up_zip_t_organization2(v_userID          in char,
																				 p_organization_id in char,
																				 bp_vp_owner_type  in integer,
																				 ErrMsg            out varchar2)
		return number;

	--新增成员
	/*
    function insert_employeeInfo(bp              IN integer,
                                 owner           IN integer,
                                 vp              IN integer,
                                 employeesInfo   IN VARCHAR2,
                                 userInfo        IN VARCHAR2,
                                 userPicList     IN lcoa.arr_longstr,
                                 OperationUserId IN VARCHAR2,
                                 user_teminfo    out sys_refcursor,
                                 ErrMsg          OUT VARCHAR2) return number;
  
    --更新成员
    function update_employeeInfo(bp              IN integer,
                                 owner           IN integer,
                                 vp              IN integer,
                                 employeesInfo   IN VARCHAR2,
                                 userInfo        IN VARCHAR2,
                                 userPicList     IN lcoa.arr_longstr,
                                 OperationUserId IN VARCHAR2,
                                 --UserId          IN OUT VARCHAR2,
                                 ErrMsg OUT VARCHAR2) return number;
  */
	--设置成员部门
	function update_user_organization(userId          IN lcoa.ARR_LONGSTR,
																		organizationId  IN VARCHAR2,
																		OperationUserId IN VARCHAR2,
																		ErrMsg          OUT VARCHAR2)
		return number;

	--操作记录
	function operation_user_recordinfo(DATAINFO IN lcoa.ARR_LONGSTR,
																		 ErrMsg   OUT VARCHAR2) return number;

	function insert_Employee(PEmployeeInfo IN VARCHAR2,
													 v_userID      in varchar2,
													 ErrMsg        OUT VARCHAR2) RETURN NUMBER;

	--设置添加用户角色
	function set_user_role(v_userID  in char,
												 v_ROLE_ID in char,
												 N_TYPE    in number,
												 ErrMsg    OUT VARCHAR2) return NUMBER;

	--插入员工履历表信息
	function Insert_EmployeeResumeInfo(data_value IN varchar2,
																		 ErrMsg     OUT VARCHAR2) return number;

	--根据用户id 查询用户信息
	function GET_EmployeeResumeInfo(user_id   IN varchar2,
																	user_info out sys_refcursor,
																	ErrMsg    OUT VARCHAR2) return number;

	--插入新成员(拉链表实现)
	function insert_employeeInfo(bp              IN integer,
															 owner           IN integer,
															 vp              IN integer,
															 employeesInfo   IN VARCHAR2,
															 userInfo        IN VARCHAR2,
															 userPicList     IN lcoa.arr_longstr,
															 OperationUserId IN VARCHAR2,
															 user_teminfo    out sys_refcursor,
															 ErrMsg          OUT VARCHAR2) return number;

	--更新成员(拉链表实现)
	function update_employeeInfo(bp              IN integer,
															 owner           IN integer,
															 vp              IN integer,
															 employeesInfo   IN VARCHAR2,
															 userInfo        IN VARCHAR2,
															 userPicList     IN lcoa.ARR_LONGSTR,
															 OperationUserId IN VARCHAR2,
															 ErrMsg          OUT VARCHAR2) return number;

	function HISTORY_TABLE_LOG2(OperationDataId       in varchar2, --更新数据ID
															OperationIdColumnName in varchar2, --更新ID字段名
															OperationTableName    in varchar2, --更新表名
															OperationType         in varchar2, --操作类型0新增1更改
															OperationUserId       IN VARCHAR2,
															ErrMsg                out varchar2)
		return number;

end PKG_INS_employee_info;
/

