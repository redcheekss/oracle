create function      uf_timestamp_diff(endtime in TIMESTAMP,starttime in TIMESTAMP)
RETURN INTEGER

AS

  str VARCHAR2(50);

  misecond INTEGER;

  seconds INTEGER;

  minutes INTEGER;

  hours INTEGER;

  days INTEGER;

BEGIN

  str:=to_char(endtime-starttime);

  misecond:=to_number(SUBSTR(str,INSTR(str,' ')+10,3));

  seconds:=to_number(SUBSTR(str,INSTR(str,' ')+7,2));

  minutes:=to_number(SUBSTR(str,INSTR(str,' ')+4,2));

  hours:=to_number(SUBSTR(str,INSTR(str,' ')+1,2));

  days:=to_number(SUBSTR(str,1,INSTR(str,' ')));


  RETURN days*24*60*60*1000+hours*60*60*1000+minutes*60*1000+seconds*1000+misecond;
END;

/

