create package body PKG_ztest_info is


    function is_oraganization_exits(newOrgnizationId char,
                                    ErrMsg           OUT VARCHAR2)
        return number

     is
        v_is_bp_exits            integer;
        V_ORGANIZATION_PARENT_ID varchar2(50);
        v_result                 integer;
    begin
        SELECT CASE
                   WHEN O.C_ORGANIZATION_BP IS null THEN
                    -1
                   ELSE
                    0
               END AS "value",
               C_ORGANIZATION_PARENT_ID
          into v_is_bp_exits, V_ORGANIZATION_PARENT_ID
          from LCBASE.T_ORGANIZATION O
         where O.C_ORGANIZATION_ID = newOrgnizationId;

    end;
end PKG_ztest_info;
/

