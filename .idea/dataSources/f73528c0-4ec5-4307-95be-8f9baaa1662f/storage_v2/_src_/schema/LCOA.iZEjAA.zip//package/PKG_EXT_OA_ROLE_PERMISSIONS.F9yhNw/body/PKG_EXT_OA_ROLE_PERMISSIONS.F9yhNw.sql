create package body pkg_ext_oa_role_permissions is
  --新增角色
  function createrole(datainfo        in varchar2, --新增的角色名称^备注
                      OperationUserId IN VARCHAR2,
                      DataId          out varchar2, --返回新增部门ID
                      ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.pkg_ins_role_permissions.createrole(datainfo, --新增的角色名称^备注
                                                           OperationUserId,
                                                           DataId, --返回新增部门ID
                                                           ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := pkg_common.g_errmsg_common;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'createrole',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  --部门下添加角色
  function create_organization_role(organizationid  in varchar2, --
                                    OperationUserId IN VARCHAR2,
                                    DataInfo        IN VARCHAR2,
                                    ErrMsg          out varchar2)
    return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.pkg_ins_role_permissions.create_organization_role(organizationid, --
                                                                         DataInfo,
                                                                         ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := pkg_common.g_errmsg_common;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'create_organization_role',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  --新增用户角色
  function create_user_role(userid          in varchar2, --新增角色的用户id
                            OperationUserId IN VARCHAR2,
                            DataInfo        IN VARCHAR2, --角色id集合
                            entrytype       in number,
                            ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.pkg_ins_role_permissions.create_user_role(userid, --新增角色的用户id
                                                                 DataInfo, --角色id集合
                                                                 entrytype,
                                                                 ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := pkg_common.g_errmsg_common;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'create_user_role',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  --查询副部们角色信息
  function get_parentorg_role(organizationid  in varchar2, --部门id
                              OperationUserId IN VARCHAR2,
                              roles           out sys_refcursor,
                              ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.pkg_ins_role_permissions.get_parentorg_role(organizationid, --部门id
                                                                   roles,
                                                                   ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := pkg_common.g_errmsg_common;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'get_parentorg_role',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  --修改角色
  function update_role(datainfo        in varchar2, --修改角色名称
                       OperationUserId IN VARCHAR2,
                       DataId          out varchar2, --返回新增角色ID
                       ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.pkg_ins_role_permissions.update_role(datainfo, --修改角色名称
                                                            OperationUserId,
                                                            DataId, --返回新增角色ID
                                                            ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := pkg_common.g_errmsg_common;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'update_role',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
  --停用角色
  function update_delrole(datainfo        in varchar2, --修改角色名称
                          OperationUserId IN VARCHAR2,
                          DataId          out varchar2, --返回新增角色ID
                          ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.pkg_ins_role_permissions.update_delrole(datainfo, --修改角色名称
                                                               OperationUserId,
                                                               DataId, --返回新增角色ID
                                                               ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := pkg_common.g_errmsg_common;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'update_delrole',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function Get_RoleEmployees_List(OrganizationId  in varchar2,
                                  status          in varchar2,
                                  pageNum         in number,
                                  PageSize        in number,
                                  OperationUserId IN VARCHAR2,
                                  DataList        out sys_refcursor,
                                  owner           out varchar2,
                                  BpName          out varchar2,
                                  VpName          out varchar2,
                                  totalPage       out number,
                                  totalCount      out number,
                                  dataCount       out number,
                                  ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      n_result := lcoa.PKG_INS_ROLEUSER_GET.get_roleemployees_list(OrganizationId,
                                                                   status,
                                                                   pageNum,
                                                                   PageSize,
                                                                   OperationUserId,
                                                                   DataList,
                                                                   owner,
                                                                   bpname,
                                                                   vpname,
                                                                   totalPage,
                                                                   totalCount,
                                                                   dataCount,
                                                                   ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(organizationid,
                                  'get_roleemployees_list',
                                  n_optype,
                                  n_status,
                                  n_duration);

    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    elsif n_result = -1 then
      ErrMsg := '本部等级不能设置本部等级的子部门,请重新设置部门';
      return n_result;
    else
      return n_result;
    end if;
  END;

end pkg_ext_oa_role_permissions;

/

