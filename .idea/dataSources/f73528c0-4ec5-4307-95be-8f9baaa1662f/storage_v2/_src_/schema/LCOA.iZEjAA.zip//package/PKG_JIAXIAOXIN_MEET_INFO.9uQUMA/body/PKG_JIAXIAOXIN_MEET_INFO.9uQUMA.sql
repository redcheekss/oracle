create package BODY PKG_jiaxiaoxin_MEET_INFO AS

    ---------------------------------------------------------------------------------------
    /*
       1 业务操作
             Add_OA_SDE_MEETING_INFO  会议纪要信息表
       time
             2020-05-06
       author
             jiaxinxin

    */
    procedure ADD_MEETING_INFO(SDE_MEETING_INFO IN varchar2,
                               meeting_id       OUT varchar2,
                               ErrMsg           OUT VARCHAR2) is

        V_SDE_MEETING_INFO PKG_COMMON.ARR_LONGSTR; -- 接收会议基础信息
        count_rows         integer := 0; --记录插入的行数

    begin
        V_SDE_MEETING_INFO := PKG_COMMON.Split(SDE_MEETING_INFO,
                                               '^'); -- 获取会议信息并使切分数据

        INSERT INTO LCOA.OA_SDE_MEETING_INFO
            (C_MEETING_ID,
             C_SCH_ID,
             N_SECRET_TYPE,
             N_MEETING_TYPE,
             V_MEETING_TITLE,
             V_CLERK_NAME,
             D_MEETING_START_TIME,
             D_MEETING_END_TIME,
             V_MEETING_ROOM,
             N_STATUS)
        VALUES
            (V_SDE_MEETING_INFO(1),
             V_SDE_MEETING_INFO(2),
             V_SDE_MEETING_INFO(3),
             V_SDE_MEETING_INFO(4),
             V_SDE_MEETING_INFO(5),
             V_SDE_MEETING_INFO(6),
             to_date(V_SDE_MEETING_INFO(7),
                     'yyyymmddhh24miss'),
             to_date(V_SDE_MEETING_INFO(8),
                     'yyyymmddhh24miss'),
             V_SDE_MEETING_INFO(9),
             V_SDE_MEETING_INFO(10));

        meeting_id := V_SDE_MEETING_INFO(1);
        count_rows := (count_rows + sql%rowcount);
        dbms_output.put_line('insert 影响的的函数' || count_rows);

    exception
        WHEN OTHERS THEN
            ErrMsg := 'sql 操作: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            ROLLBACK;
            raise;

    end ADD_MEETING_INFO;

    ---------------------------------------------------------------------------------------
    /*
       1 业务操作
             UPDATE_OA_SDE_MEETING_INFO  会议纪要信息表
       time
             2020-05-06
       author
             jiaxinxin

    */
    procedure UPDATE_MEETING_INFO(SDE_MEETING_INFO IN varchar2,
                                  meeting_id       IN CHAR,
                                  ErrMsg           OUT VARCHAR2)

     IS

        V_SDE_MEETING_INFO PKG_COMMON.ARR_LONGSTR; -- 接收会议基础信息
        result_int         number := 0; --记录返回值 1 成功，0为失败。
        count_rows         integer := 0; --记录插入的行数
        v_meeting_title    varchar2(100); --组装会议标题信息

    begin
        V_SDE_MEETING_INFO := PKG_COMMON.Split(SDE_MEETING_INFO,
                                               '^'); -- 获取会议信息并使切分数据
        if meeting_id is not null then
            UPDATE LCOA.OA_SDE_MEETING_INFO
               SET C_SCH_ID             = V_SDE_MEETING_INFO(2),
                   N_SECRET_TYPE        = V_SDE_MEETING_INFO(3),
                   N_MEETING_TYPE       = V_SDE_MEETING_INFO(4),
                   V_MEETING_TITLE      = V_SDE_MEETING_INFO(5),
                   V_CLERK_NAME         = V_SDE_MEETING_INFO(6),
                   D_MEETING_START_TIME = to_date(V_SDE_MEETING_INFO(7),
                                                  'yyyymmddhh24miss'),
                   D_MEETING_END_TIME   = to_date(V_SDE_MEETING_INFO(8),
                                                  'yyyymmddhh24miss'),
                   V_MEETING_ROOM       = V_SDE_MEETING_INFO(9),
                   N_STATUS             = V_SDE_MEETING_INFO(10)

             WHERE C_MEETING_ID = meeting_id;

            result_int := 1;
            ErrMsg     := '更新成功';

            count_rows := sql%rowcount;
            dbms_output.put_line('result_int' ||
                                 result_int || 'ErrMsg' ||
                                 ErrMsg || '影响的行数' ||
                                 count_rows);
        else
            dbms_output.put_line('meeting_id is null');
            raise pkg_common.EXP_PARAM;
        end if;
    exception
        WHEN OTHERS THEN
            ErrMsg := 'sql 操作: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            ROLLBACK;

    end UPDATE_MEETING_INFO;
    ---------------------------------------------------------------------------------------

    /*
     2 业务操作
           ADD_SDE_ATTENDEE_LIST_INFO   是否缺席表
     time
           2020-05-06
     author
           jiaxinxin

    */
    procedure ADD_SDE_ATTENDEE_LIST_INFO(SDE_ATTENDEE_LIST IN ARR_LONGSTR,
                                         ErrMsg            OUT VARCHAR2) is
        V_SDE_ATTENDEE_LIST PKG_COMMON.ARR_LONGSTR; -- 接收会议缺席表

        total integer; --记录传入的记录数

        count_rows   integer := 0; --记录插入的行数
        v_meeting_id varchar2(50);

    begin

        total := SDE_ATTENDEE_LIST.count; --获取总记录数

        for i in 1 .. total loop
            V_SDE_ATTENDEE_LIST := PKG_COMMON.Split(SDE_ATTENDEE_LIST(i),
                                                    '^'); --获取第一条记录
            if V_SDE_ATTENDEE_LIST(1) is not null and
               V_SDE_ATTENDEE_LIST(2) is not null then
                INSERT INTO LCOA.OA_SDE_ATTENDEE_LIST
                    (C_MEETING_ID, --会议ID
                     C_USER_ID, --参会人ID
                     N_ABSENT_FLAG) --是否缺席
                VALUES
                    (v_meeting_id,
                     V_SDE_ATTENDEE_LIST(1),
                     V_SDE_ATTENDEE_LIST(2));

                count_rows := (count_rows + sql%rowcount);
                dbms_output.put_line('插入的行数：' ||
                                     count_rows || '');
            else
                dbms_output.put_line('C_MEETING_ID and C_MEETING_ID is null');
                ErrMsg := 'C_MEETING_ID and C_MEETING_ID is null';
                raise pkg_common.EXP_PARAM;
            end if;
        end loop;

    exception
        WHEN OTHERS THEN
            ErrMsg := 'sql 操作: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            ROLLBACK;

    end ADD_SDE_ATTENDEE_LIST_INFO;

    /*
     2 业务操作
           UPDATE_SDE_ATTENDEE_LIST_INFO   是否缺席表
     time
           2020-05-06
     author
           jiaxinxin

    */
    procedure UPDATE_SDE_ATTENDEE_LIST_INFO(SDE_ATTENDEE_LIST IN ARR_LONGSTR,
                                            metting_id        IN char,
                                            ErrMsg            OUT VARCHAR2) is
    begin
        --根据会议id删除缺席信息
        DELETE FROM LCOA.OA_SDE_ATTENDEE_LIST
         WHERE C_MEETING_ID = metting_id;

        --执行插入操作
        PKG_jiaxiaoxin_MEET_INFO.ADD_SDE_ATTENDEE_LIST_INFO(SDE_ATTENDEE_LIST,
                                                   ErrMsg);
        ErrMsg := '无';
    exception
        WHEN OTHERS THEN
            ErrMsg := 'sql 操作: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            ROLLBACK;
    end UPDATE_SDE_ATTENDEE_LIST_INFO;

    /*
       业务操作
            3 OA_SDE_MEETING_CONTENT_LIST  会议纪要内容列表
       time
             2020-05-06
       author
             jiaxinxin

    */
    procedure ADD_SDE_MEETING_CONTENT_LIST(SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                           metting_id               IN char,
                                           ErrMsg                   OUT VARCHAR2)

     IS
        V_SDE_MEETING_CONTENT_LIST PKG_COMMON.ARR_LONGSTR; -- 会议纪要内容列表

        count_rows integer := 0; --记录插入的行数
        total      integer; --记录会议纪要内容条数
    begin

        total := SDE_MEETING_CONTENT_LIST.count;
        for i in 1 .. total loop
            V_SDE_MEETING_CONTENT_LIST := PKG_COMMON.Split(SDE_MEETING_CONTENT_LIST(i),
                                                           '^');
            INSERT INTO LCOA.OA_SDE_MEETING_CONTENT_LIST
                (C_ID, --数据id
                 C_MEETING_ID, --会议ID
                 V_CONTENT, --内容
                 D_INPUT_TIME, --录入时间
                 N_SEQ --序号
                 )
            VALUES
                (lower(sys_guid()),
                 metting_id,
                 V_SDE_MEETING_CONTENT_LIST(1),
                 sysdate,
                 V_SDE_MEETING_CONTENT_LIST(2));
            count_rows := (count_rows + sql%rowcount);
        end loop;
        ErrMsg := 'ADD_SDE_MEETING_CONTENT_LIST';
        dbms_output.put_line('插入会议纪要内容信息：' || sql%rowcount ||
                             '行数据......');
    exception
        WHEN OTHERS THEN
            ErrMsg := 'sql 操作: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            ROLLBACK;
    end ADD_SDE_MEETING_CONTENT_LIST;

    /*
       业务操作
            3 update_OA_SDE_MEETING_CONTENT_LIST  会议纪要内容列表
       time
             2020-05-06
       author
             jiaxinxin

    */
    procedure UP_SDE_MEETING_CONTENT_LIST(SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                          metting_id               IN char,
                                          ErrMsg                   OUT VARCHAR2)

     IS

    begin
        --删除数据
        delete from LCOA.OA_SDE_MEETING_CONTENT_LIST
         where C_MEETING_ID = metting_id;
        dbms_output.put_line('删除以前的旧数据' || sql%rowcount || '函数');
        --更新操作
        PKG_jiaxiaoxin_MEET_INFO.ADD_SDE_MEETING_CONTENT_LIST(SDE_MEETING_CONTENT_LIST,
                                                     metting_id,
                                                     ErrMsg);
        ErrMsg := 'PKG_jiaxiaoxin_MEET_INFO';

    exception
        WHEN OTHERS THEN
            ErrMsg := 'sql 操作: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            ROLLBACK;

    end UP_SDE_MEETING_CONTENT_LIST;

    /*
       4 业务操作
             会议纪要待办事项  会议纪要待办事项
       time
             2020-05-06
       author
             jiaxinxin

    */

    procedure ADD_SDE_TODO_LIST(OA_SDE_TODO_LIST IN ARR_LONGSTR,
                                meeting_id       in char,
                                ErrMsg           OUT VARCHAR2

                                ) is

        total              integer; --记录执行插入总条数
        V_OA_SDE_TODO_LIST PKG_COMMON.ARR_LONGSTR; -- 会议纪要待办事项
        count_rows         integer := 0; --记录插入的行数

    begin
        dbms_output.put_line('-----------------------------------------');
        total := OA_SDE_TODO_LIST.count;
        for i in 1 .. total loop
            V_OA_SDE_TODO_LIST := PKG_COMMON.Split(OA_SDE_TODO_LIST(i),
                                                   '^');

            INSERT INTO LCOA.OA_SDE_TODO_LIST
                (C_TODO_ID, --数据ID
                 C_MEETING_ID, --会议ID
                 V_TODO_CONTENT, --事项内容*
                 V_TODO_TRACE, --后续跟踪情况
                 D_LIMIT_TIME, --待办截止时间
                 C_ASK_USER_ID, --提出人ID
                 V_ASK_USER_NAME, --提出人名称
                 C_DUTY_USER_ID, --负责人ID
                 V_DUTY_USER_NAME, --负责人名称
                 D_INPUT_TIME, --录入时间
                 N_SEQ --序号
                 )
            VALUES
                (lower(sys_guid()),
                 meeting_id,
                 V_OA_SDE_TODO_LIST(1),
                 V_OA_SDE_TODO_LIST(2),
                 to_date(V_OA_SDE_TODO_LIST(3),
                         'yyyymmddhh24miss'),
                 0, --待办提出人id
                 V_OA_SDE_TODO_LIST(4),
                 0, --负责人ID
                 V_OA_SDE_TODO_LIST(5),
                 sysdate,
                 V_OA_SDE_TODO_LIST(6));

        end loop;
        ErrMsg     := '';
        count_rows := (count_rows + sql%rowcount);

        dbms_output.put_line('更新会议纪要待办事项内容信息：' ||
                             count_rows || '行数据' ||
                             '......................');
    exception
        WHEN OTHERS THEN
            ErrMsg := 'sql 操作: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            ROLLBACK;
    end;

    /*
       4 业务操作
             会议纪要待办事项  会议纪要待办事项
       time
             2020-05-06
       author
             jiaxinxin

    */

    procedure UPDATE_SDE_TODO_LIST(OA_SDE_TODO_LIST IN ARR_LONGSTR,
                                   meeting_id       in char,
                                   ErrMsg           OUT VARCHAR2

                                   ) is
    begin
        --删除数据
        DELETE FROM LCOA.OA_SDE_TODO_LIST
         WHERE C_MEETING_ID = meeting_id;
        --执行添加
        PKG_jiaxiaoxin_MEET_INFO.add_SDE_TODO_LIST(OA_SDE_TODO_LIST,
                                          meeting_id,
                                          ErrMsg);
    exception
        WHEN OTHERS THEN
            ErrMsg := 'sql 操作: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            ROLLBACK;
    end;

    /*
       5 业务操作
             USER_UPLOAD_INFO 附件信息表
       time
             2020-04-15
       author
             jiaxinxin

    */
    PROCEDURE ADD_USER_UPLOAD_INFO(USER_UPLOAD_INFO IN ARR_LONGSTR,

                                   meeting_id in char,
                                   ErrMsg     OUT VARCHAR2

                                   )

     is
        total              integer; --记录执行插入总条数
        V_USER_UPLOAD_INFO PKG_COMMON.ARR_LONGSTR; --附件信息表
        count_rows         integer := 0; --记录插入的行数
    begin

        total := USER_UPLOAD_INFO.count;
        for i in 1 .. total loop
            V_USER_UPLOAD_INFO := PKG_COMMON.Split(USER_UPLOAD_INFO(i),
                                                   '^');

            INSERT INTO LCOA.OA_USER_UPLOAD_INFO
                (C_FILE_ID, -- 文件ID
                 N_FILE_TYPE, --文件类型
                 C_FORIGN_ID, -- 外键
                 V_FILE_NAME, --文件名
                 V_FILE_PATH, --文件路径
                 D_UPLOAD_TIME) --上传时间
            VALUES
                (lower(sys_guid()),
                 50,
                 meeting_id,
                 V_USER_UPLOAD_INFO(1),
                 V_USER_UPLOAD_INFO(2),
                 sysdate);
            count_rows := (count_rows + sql%rowcount);
        end loop;
        ErrMsg := 0;
        dbms_output.put_line('插入：附件信息内容信息：' || count_rows ||
                             '行数据' ||
                             '....................................');

    exception
        WHEN OTHERS THEN
            ErrMsg := 'sql 操作: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            ROLLBACK;

    end add_USER_UPLOAD_INFO;

    /*
          5 业务操作
                USER_UPLOAD_INFO 附件信息表
          time
                2020-04-15
          author
                jiaxinxin

    */
    PROCEDURE UPDATE_USER_UPLOAD_INFO(USER_UPLOAD_INFO IN ARR_LONGSTR,
                                      meeting_id       in char,
                                      ErrMsg           OUT VARCHAR2) IS
    BEGIN
        --删除附件信息表
        DELETE FROM LCOA.OA_USER_UPLOAD_INFO
         WHERE C_FORIGN_ID = meeting_id;
        --执行添加操作
        PKG_jiaxiaoxin_MEET_INFO.ADD_USER_UPLOAD_INFO(USER_UPLOAD_INFO,
                                             meeting_id,
                                             ErrMsg);
    exception
        WHEN OTHERS THEN
            ErrMsg := 'sql 操作: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            ROLLBACK;
    end UPDATE_USER_UPLOAD_INFO;

END PKG_jiaxiaoxin_MEET_INFO;
/

