create view V_ZIP_ORGANIZATION as
select o.c_organization_id,
         o.v_organization_name,
         o.c_organization_parent_id,
         o.n_organization_level,
         o.n_organization_type,
         case o.n_organization_type
         when 0 then
          '集团公司'
         when 1 then
          '子公司'
         when 2 then
          '2分公司-独立核算'
         when 3 then
          '分公司-非独核算'
         when 4 then
          'VIE公司'
         when 5 then
          '控股公司'
         when 6 then
          '参股公司'
         when 7 then
          '虚拟体系'
         when 8 then
          '组织型部门'
         when 9 then
          '项目型部门'
         when 10 then
          '小兵团'
         else
          '其他'
       end as v_organization_type,
         o.c_organization_owner,
         (select u1.v_pet_name from lcbase.t_zip_user u1
         where u1.c_user_id=o.c_organization_owner and u1.d_enddate>sysdate and u1.n_status=0) as owner_name,
         o.c_organization_po,
         (select u1.v_pet_name from lcbase.t_zip_user u1
         where u1.c_user_id=o.c_organization_po and u1.d_enddate>sysdate and u1.n_status=0) as po_name,
         o.c_organization_bp,
         (select u1.v_pet_name from lcbase.t_zip_user u1
         where u1.c_user_id=o.c_organization_bp and u1.d_enddate>sysdate and u1.n_status=0) as bp_name,
         level as lv,
         substr(sys_connect_by_path(o.v_organization_name, '->') ,3) organization_path
    from (select *
                from lcbase.t_zip_organization g
               where g.d_enddate > sysdate) o
   where o.d_enddate > sysdate
     and o.n_status = 0
   start with n_organization_level = 0
  connect by prior o.c_organization_id = o.c_organization_parent_id
/

