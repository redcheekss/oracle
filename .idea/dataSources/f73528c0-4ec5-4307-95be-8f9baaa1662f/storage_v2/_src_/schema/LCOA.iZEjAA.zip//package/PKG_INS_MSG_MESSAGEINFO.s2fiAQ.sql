create package PKG_INS_MSG_MESSAGEINFO is
  function Get_Message_List(UserID     in varchar2,
                            MsgType    in varchar2,
                            pageNum    in number,
                            PageSize   in number,
                            DataInfo   out sys_refcursor,
                            totalPage  out number,
                            totalCount out number,
                            ErrMsg     out varchar2) return number;

  function get_user_todo(userId      in varchar2,
                         skipStatus  in number,
                         pageNum     in number,
                         PageSize    in number,
                         getUserTodo out sys_refcursor,
                         totalPage   out number,
                         totalCount  out number,
                         errmsg      out varchar2) return number;

  function add_usertodo_forward(userid     in varchar2,
                                skipStatus in number,
                                errmsg     out varchar2) return number;

  function add_usertodo_meetinfo(userid in varchar2, errmsg out varchar2)
    return number;

  function add_usertodo_promotion(userid     in varchar2,
                                  skipStatus in number,
                                  errmsg     out varchar2) return number;

  function add_usertodo_loan(userid     in varchar2,
                             skipStatus in number,
                             errmsg     out varchar2) return number;
  function add_usertodo_dataModify(userid     in varchar2,
                                   skipStatus in number,
                                   errmsg     out varchar2) return number;

  function add_usertodo_repayment(userid     in varchar2,
                                  skipStatus in number,
                                  errmsg     out varchar2) return number;

  function add_usertodo_loanpay(userid     in varchar2,
                                skipStatus in number,
                                errmsg     out varchar2) return number;

  function get_payment_usertodo(userid      in varchar2,
                                skipStatus  in number,
                                GetUserTodo out sys_refcursor,
                                errmsg      out varchar2) return number;

end;
/

