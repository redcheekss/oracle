create package body PKG_INS_AFW_WORKFLOW is

  -- Private type declarations
  --type <TypeName> is <Datatype>;

  -- Private constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Private variable declarations
  --<VariableName> <Datatype>;
  i number;

  function Create_Part_Approval_Userlist(ROW_CONF        in oa_afw_workflow_config%rowtype,
                                         WorkflowId      in varchar2,
                                         WorkflowSubtype in number,
                                         WorkflowUserId  in varchar2,
                                         OrganizationId  in varchar2,
                                         LST             out T_FLOW)
    return number is
    cur_org_owner       sys_refcursor;
    flowusercount       number := 0;
    VPUserId            char(32);
    VPUserName          varchar2(20);
    VPUserTitle         varchar2(20);
    v_ORGANIZATION_TYPE number;
    v_KINDOFWORK        number;
    v_roleid            number;
    v_conf_orgid        char(32); -- 配置的用户所在的项目组（如产品部门的人在项目组）
    v_count             number;
    v_level             number;
    v_APPROVAL_MODEL    number;
    v_isOrgOwner        number;
  begin
    begin
      -- 获取组织类型，兵种类型
      select N_ORGANIZATION_TYPE
        into v_ORGANIZATION_TYPE
        from lcbase.t_zip_organization t
       where t.c_organization_id = OrganizationId
         and t.d_enddate > sysdate;
      -- 工种
      select N_KINDOFWORK
        into v_KINDOFWORK
        from lcbase.t_zip_user t
       where t.c_user_id = WorkflowUserId
         and t.d_enddate > sysdate;
      -- 是否部门负责人
      select count(*)
        into v_isOrgOwner
        from lcbase.t_zip_organization o
       where o.c_organization_id = OrganizationId
         and o.c_organization_owner = WorkflowUserId
         and o.d_enddate > sysdate
         and o.n_status = 0;
    end;
    -- 直接上级
    /*
    直接上级有两种方式：
    1根据用户id从配置表（T_USER_ORGANIZATION）找
        优先通过该方式查找
    2是根据组织关系找
        普通用户找部门负责人，本部门没负责人的往上级找负责人
    3CEO和PO发起的，自己审批？

    4项目型的pl，直接找本部门po
    */
    if ROW_CONF.N_APPROVAL_USER_TYPE = 1 then
      if (lcoa.pkg_ins_user_info.IsCEOByUserId(WorkflowUserId,
                                               VPUserId,
                                               VPUserName,
                                               VPUserTitle) = 1) then
        -- 主管副总以上级别的申请直接上级就是本人
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               WorkflowUserId,
               VPUserName,
               '直接上级',
               0,
               null,
               null,
               0,
               1
          into LST(1)
          from dual;
        flowusercount := 1;
        return flowusercount;
      end if;
      -- 军委常委 ceo
      select count(*)
        into v_count
        from OA_AFW_APPROVAL_USER_ROLE
       where n_approval_role_id = 4
         and c_user_id = WorkflowUserId;
      if v_count >= 1 then
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               v_approval_user_id,
               v_approval_user_name,
               '直接上级',
               0,
               null,
               null,
               0,
               1
          into LST(1)
          from OA_AFW_WORKFLOW_USER_TYPE
         where n_approval_user_type = 7;
        flowusercount := 1;
        return flowusercount;

      else
        -- 特殊部门，OA_AFW_WORKFLOW_ORG_CONFIG
        begin
          select c.n_approval_role_id, c.n_approval_model
            into v_roleid, v_APPROVAL_MODEL
            from OA_AFW_WORKFLOW_ORG_CONFIG c
           where c.c_organization_id = OrganizationId
             and c.n_approval_order = 1;
          flowusercount := 0;
          open cur_org_owner for
            select lower(sys_guid()),
                   ROW_CONF.N_WORKFLOW_TYPE,
                   WorkflowId,
                   0,
                   --ROW_CONF.N_APPROVAL_MODEL,
                   v_APPROVAL_MODEL,
                   a.c_user_id,
                   a.v_pet_name,
                   '直接上级',
                   0,
                   null,
                   null,
                   0,
                   1
              from lcbase.t_zip_user a, OA_AFW_APPROVAL_USER_ROLE b
             where a.c_user_id = b.C_USER_ID
               and a.d_enddate > sysdate
               and b.N_APPROVAL_ROLE_ID = v_roleid;

          fetch cur_org_owner
            into LST(0);
          while cur_org_owner%found loop
            flowusercount := flowusercount + 1;
            LST(flowusercount) := LST(0);
            fetch cur_org_owner
              into LST(0);
          end loop;
          close cur_org_owner;

        exception
          when others then
            -- 不是特殊部门
            /*根据组织架构找
            select count(*) into v_count from lcbase.t_zip_organization o
             where o.c_organization_id = OrganizationId
               and o.c_organization_owner = WorkflowUserId
               and o.d_enddate>sysdate and o.n_status=0;*/
            if v_isOrgOwner = 1 then
              if v_ORGANIZATION_TYPE = 9 then
                --项目型部门 项目pl，直接最找本部门po
                select lower(sys_guid()),
                       ROW_CONF.N_WORKFLOW_TYPE,
                       WorkflowId,
                       0,
                       ROW_CONF.N_APPROVAL_MODEL,
                       u.c_user_id,
                       u.v_pet_name,
                       '直接上级',
                       0,
                       null,
                       null,
                       0,
                       1
                  into LST(1)
                  from lcbase.t_zip_user u
                 where u.d_enddate > sysdate
                   and u.n_status = 0
                   and u.c_user_id =
                       (select c_organization_po
                          from lcbase.t_zip_organization o
                         where o.c_organization_id = OrganizationId
                           and o.d_enddate > sysdate);
                flowusercount := 1;
              else
                -- 非项目型部门的负责人
                -- 连长（level=2）和军种负责人（level=2）找军委常委
                select count(*)
                  into v_count
                  from (select g.c_organization_id,
                               v_organization_name,
                               n_organization_level,
                               c_organization_owner,
                               g.n_organization_type,
                               c_organization_po,
                               level as lv,
                               (select u.v_pet_name
                                  from lcbase.t_zip_user u
                                 where u.c_user_id = g.c_organization_owner
                                   and u.d_enddate > sysdate
                                   and u.n_status = 0) as owner_name
                          from lcbase.t_zip_organization g
                         where g.d_enddate > sysdate
                        connect by prior g.c_organization_parent_id =
                                    g.c_organization_id
                         start with g.c_organization_id = OrganizationId
                                and n_organization_level = 2
                         order by level)
                 where v_organization_name like '%军委%';
                if v_count > 0 then
                  open cur_org_owner for
                    select lower(sys_guid()),
                           ROW_CONF.N_WORKFLOW_TYPE,
                           WorkflowId,
                           0,
                           2, -- 军种负责人，连长由军委常委一票通过
                           a.c_user_id,
                           a.v_pet_name,
                           '直接上级',
                           0,
                           null,
                           null,
                           0,
                           1
                      from lcbase.t_zip_user a, OA_AFW_APPROVAL_USER_ROLE b
                     where a.c_user_id = b.C_USER_ID
                       and a.d_enddate > sysdate
                       and b.N_APPROVAL_ROLE_ID =
                           (select ar.n_approval_role_id
                              from OA_AFW_APPROVAL_ROLE ar
                             where ar.v_approval_role_name = '军委审批人');

                  fetch cur_org_owner
                    into LST(0);
                  while cur_org_owner%found loop
                    flowusercount := flowusercount + 1;
                    LST(flowusercount) := LST(0);
                    fetch cur_org_owner
                      into LST(0);
                  end loop;
                  close cur_org_owner;
                else
                  begin
                    select lower(sys_guid()),
                           ROW_CONF.N_WORKFLOW_TYPE,
                           WorkflowId,
                           0,
                           ROW_CONF.N_APPROVAL_MODEL,
                           c_organization_owner c_user_id,
                           owner_name v_pet_name,
                           '直接上级',
                           0,
                           null,
                           null,
                           0,
                           1
                      into LST(1)
                      from (select g.c_organization_id,
                                   v_organization_name,
                                   n_organization_level,
                                   c_organization_owner,
                                   g.n_organization_type,
                                   c_organization_po,
                                   level as lv,
                                   (select u.v_pet_name
                                      from lcbase.t_zip_user u
                                     where u.c_user_id =
                                           g.c_organization_owner
                                       and u.d_enddate > sysdate
                                       and u.n_status = 0) as owner_name
                              from lcbase.t_zip_organization g
                             where g.d_enddate > sysdate
                            connect by prior g.c_organization_parent_id =
                                        g.c_organization_id
                             start with g.c_organization_id = OrganizationId
                             order by level)
                     where c_organization_id <> OrganizationId
                       and c_organization_owner is not null
                       and rownum = 1;
                    flowusercount := 1;
                  end;
                end if;
              end if;
            else
              -- 不是负责人
              open cur_org_owner for
                with all_g as
                 (select *
                    from lcbase.t_zip_organization g
                   where g.d_enddate > sysdate
                  connect by prior g.c_organization_parent_id =
                              g.c_organization_id
                   start with g.c_organization_id = OrganizationId)
                select lower(sys_guid()),
                       ROW_CONF.N_WORKFLOW_TYPE,
                       WorkflowId,
                       0,
                       ROW_CONF.N_APPROVAL_MODEL,
                       c_user_id,
                       v_pet_name,
                       '直接上级',
                       0,
                       null,
                       null,
                       0,
                       1
                  from (select *
                          from (select w.*, g.n_organization_level
                                  from all_g g
                                  join lcbase.t_zip_user w
                                    on w.c_user_id = g.c_organization_owner
                                 where g.n_organization_level >= 2
                                   and g.c_organization_owner <>
                                       WorkflowUserId
                                   and w.d_enddate > sysdate)
                         order by n_organization_level desc)
                 where rownum = 1;
              fetch cur_org_owner
                into LST(0);
              if cur_org_owner%found then
                LST(1) := LST(0);
                flowusercount := 1;
              end if;
              close cur_org_owner;

            end if;
        end;
      end if;
      -- 逐级上级至主管副总
    elsif ROW_CONF.N_APPROVAL_USER_TYPE = 2 then
      -- 项目组的成员找pl和po
      -- 产品人员在项目组的找产品负责人和项目组po【先不考虑产品】
      flowusercount := 0;
      if v_ORGANIZATION_TYPE = 9 then
        --项目型部门 项目pl，直接最找本部门po
        open cur_org_owner for
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               u.c_user_id,
               u.v_pet_name,
               p.user_title,
               0,
               null,
               null,
               0,
               1
          from lcbase.t_zip_user u
          join (select o.c_organization_owner user_id,'部门PL' user_title, 1 sort
                  from lcbase.t_zip_organization o
                 where o.c_organization_id = OrganizationId
                   and o.d_enddate > sysdate
                union
                select c_organization_po user_id,'部门PO' user_title, 2 sort
                  from lcbase.t_zip_organization o
                 where o.c_organization_id = OrganizationId
                   and o.d_enddate > sysdate) p
            on (u.c_user_id = p.user_id)
         where u.c_user_id <> WorkflowUserId
           and u.d_enddate > sysdate
           and u.n_status = 0
           order by p.sort ;
      else
        -- 特殊部门，OA_AFW_WORKFLOW_ORG_CONFIG
        begin
          select c.n_approval_role_id, c.n_approval_model
            into v_roleid, v_APPROVAL_MODEL
            from OA_AFW_WORKFLOW_ORG_CONFIG c
           where c.c_organization_id = OrganizationId
             and c.n_approval_order = 1;
          flowusercount := 0;
          open cur_org_owner for
            select lower(sys_guid()),
                   ROW_CONF.N_WORKFLOW_TYPE,
                   WorkflowId,
                   0,
                   --ROW_CONF.N_APPROVAL_MODEL,
                   v_APPROVAL_MODEL,
                   a.c_user_id,
                   a.v_pet_name,
                   '上级',
                   0,
                   null,
                   null,
                   0,
                   1
              from lcbase.t_zip_user a, OA_AFW_APPROVAL_USER_ROLE b
             where a.c_user_id = b.C_USER_ID
               and a.d_enddate > sysdate
               and b.N_APPROVAL_ROLE_ID = v_roleid;

        exception
          when others then
            -- 不是特殊部门
            open cur_org_owner for
        with all_g as
         (select * from (select *
            from lcbase.t_zip_organization  where d_enddate > sysdate ) g
          connect by prior g.c_organization_parent_id = g.c_organization_id
           start with g.c_organization_id = OrganizationId)
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               w.c_user_id,
               w.v_pet_name,
               case
                 when g.n_organization_level = 1 then
                  '主管副总'
                 else
                  '上级'
               end,
               0,
               null,
               null,
               0,
               1
          from all_g g
          left join lcbase.t_zip_user w
            on w.c_user_id = g.c_organization_owner
         where nvl(g.n_organization_level, 5) > 1
           and w.d_enddate > sysdate
           and w.c_user_id <> WorkflowUserId
           order by g.n_organization_level desc;
          end;


      end if;
      fetch cur_org_owner
        into LST(0);
      while cur_org_owner%found loop
        flowusercount := flowusercount + 1;
        LST(flowusercount) := LST(0);
        fetch cur_org_owner
          into LST(0);
      end loop;
      close cur_org_owner;
      --主管副总
    elsif ROW_CONF.N_APPROVAL_USER_TYPE = 3 then
      /*

      */
      if v_KINDOFWORK = 4 then
        -- 获取产品人员所在的项目组
        begin
          select uo.c_organization_id
            into v_conf_orgid
            from lcbase.T_USER_ORGANIZATION uo
           where uo.c_user_id = WorkflowUserId
             and N_MAIN_FLAG = 1;
        exception
          when others then
            v_conf_orgid := null;
        end;
      end if;
      -- 如果是ceo或主管副总，直接返回
      if (lcoa.pkg_ins_user_info.IsCEOByUserId(WorkflowUserId,
                                               VPUserId,
                                               VPUserName,
                                               VPUserTitle) = 1) then
        -- 主管副总以上级别的申请直接上级就是本人
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               WorkflowUserId,
               VPUserName,
               '主管副总',
               0,
               null,
               null,
               0,
               1
          into LST(1)
          from dual;
        flowusercount := 1;
        return flowusercount;
      end if;
      -- 军委常委 ceo
      select count(*)
        into v_count
        from OA_AFW_APPROVAL_USER_ROLE
       where n_approval_role_id = 4
         and c_user_id = WorkflowUserId;
      if v_count >= 1 then
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               v_approval_user_id,
               v_approval_user_name,
               '直接上级',
               0,
               null,
               null,
               0,
               1
          into LST(1)
          from OA_AFW_WORKFLOW_USER_TYPE
         where n_approval_user_type = 7;
        flowusercount := 1;
        return flowusercount;

        -- 项目型里面的成员（含部门负责人）找PO
      elsif v_ORGANIZATION_TYPE = 9 then
        begin
          select lower(sys_guid()),
                 ROW_CONF.N_WORKFLOW_TYPE,
                 WorkflowId,
                 0,
                 ROW_CONF.N_APPROVAL_MODEL,
                 u.c_user_id,
                 u.v_pet_name,
                 '主管副总',
                 0,
                 null,
                 null,
                 0,
                 1
            into LST(1)
            from lcbase.t_zip_user u
            join lcbase.t_zip_organization o
              on (o.c_organization_po = u.c_user_id)
           where u.d_enddate > sysdate
             and u.n_status = 0
             and o.c_organization_id = OrganizationId
             and o.d_enddate > sysdate;
          flowusercount := 1;
        exception
          when NO_DATA_FOUND then
            return 0;
        end;
      else

        -- 特殊部门，OA_AFW_WORKFLOW_ORG_CONFIG
        begin
          select c.n_approval_role_id, c.n_approval_model
            into v_roleid, v_APPROVAL_MODEL
            from OA_AFW_WORKFLOW_ORG_CONFIG c
           where c.c_organization_id = OrganizationId
             and c.n_approval_order = 1;
          flowusercount := 0;
          open cur_org_owner for
            select lower(sys_guid()),
                   ROW_CONF.N_WORKFLOW_TYPE,
                   WorkflowId,
                   0,
                   --ROW_CONF.N_APPROVAL_MODEL,
                   v_APPROVAL_MODEL,
                   a.c_user_id,
                   a.v_pet_name,
                   '主管副总',
                   0,
                   null,
                   null,
                   0,
                   1
              from lcbase.t_zip_user a, OA_AFW_APPROVAL_USER_ROLE b
             where a.c_user_id = b.C_USER_ID
               and a.d_enddate > sysdate
               and b.N_APPROVAL_ROLE_ID = v_roleid;

          fetch cur_org_owner
            into LST(0);
          while cur_org_owner%found loop
            flowusercount := flowusercount + 1;
            LST(flowusercount) := LST(0);
            fetch cur_org_owner
              into LST(0);
          end loop;
          close cur_org_owner;
          return flowusercount;
        exception
          when others then

            -- 小兵团，找谁？军种负责人
            if v_ORGANIZATION_TYPE = 10 then
              begin
                select nvl(t.n_organization_level, 0)
                  into v_level
                  from lcbase.t_zip_organization t
                 where t.c_organization_id = OrganizationId
                   and t.d_enddate > sysdate
                   and t.n_status = 0;
              exception
                when others then
                  v_level := 0;
              end;
              if v_level <= 2 and v_isOrgOwner = 1 then
                -- 连、 军种负责人
                open cur_org_owner for
                  select lower(sys_guid()),
                         ROW_CONF.N_WORKFLOW_TYPE,
                         WorkflowId,
                         0,
                         2, -- 连长、军种负责人由军委常委一票通过
                         a.c_user_id,
                         a.v_pet_name,
                         '主管副总',
                         0,
                         null,
                         null,
                         0,
                         1
                    from lcbase.t_zip_user a, OA_AFW_APPROVAL_USER_ROLE b
                   where a.c_user_id = b.C_USER_ID
                     and a.d_enddate > sysdate
                     and b.N_APPROVAL_ROLE_ID =
                         (select ar.n_approval_role_id
                            from OA_AFW_APPROVAL_ROLE ar
                           where ar.v_approval_role_name = '军委审批人');

                fetch cur_org_owner
                  into LST(0);
                while cur_org_owner%found loop
                  flowusercount := flowusercount + 1;
                  LST(flowusercount) := LST(0);
                  fetch cur_org_owner
                    into LST(0);
                end loop;
                close cur_org_owner;
                return flowusercount;
              end if;
              begin
                select lower(sys_guid()),
                       ROW_CONF.N_WORKFLOW_TYPE,
                       WorkflowId,
                       0,
                       ROW_CONF.N_APPROVAL_MODEL,
                       u.c_user_id,
                       u.v_pet_name,
                       '主管副总',
                       0,
                       null,
                       null,
                       0,
                       1
                  into LST(1)
                  from lcbase.t_zip_user u
                  join lcbase.t_zip_organization g
                    on (u.c_user_id = g.c_organization_owner)
                  join lcoa.OA_AFW_WORKFLOW_ARMY_CONFIG c
                    on (c.c_organization_id = g.c_organization_id)
                 where c.n_kindofwork = v_KINDOFWORK
                   and u.d_enddate > sysdate
                   and u.n_status = 0
                   and g.d_enddate > sysdate;
                flowusercount := 1;
              exception
                when NO_DATA_FOUND then
                  return 0;
              end;
              -- 产品成员在项目组，则找po
            elsif v_KINDOFWORK = 4 and v_conf_orgid is not null then
              -- 在项目组
              begin
                select lower(sys_guid()),
                       ROW_CONF.N_WORKFLOW_TYPE,
                       WorkflowId,
                       0,
                       ROW_CONF.N_APPROVAL_MODEL,
                       u.c_user_id,
                       u.v_pet_name,
                       '主管副总',
                       0,
                       null,
                       null,
                       0,
                       1
                  into LST(1)
                  from lcbase.t_zip_user u
                  join lcbase.t_zip_organization o
                    on (o.c_organization_po = u.c_user_id)
                 where u.d_enddate > sysdate
                   and u.n_status = 0
                   and o.d_enddate > sysdate
                   and o.c_organization_id =
                       (select uo.c_organization_id
                          from lcbase.T_USER_ORGANIZATION uo
                         where uo.c_user_id = WorkflowUserId
                           and N_MAIN_FLAG = 1);
              exception
                when NO_DATA_FOUND then
                  return 0;
              end;
              -- 部门负责人
            else

              -- 通用规则，找本部门po，如果没有，找level为2的负责人，没有则抛异常

              select count(*)
                into v_count
                from lcbase.t_zip_organization o
               where o.c_organization_id = OrganizationId
                 and o.c_organization_owner = WorkflowUserId
                 and o.d_enddate > sysdate
                 and o.n_status = 0;
              if v_count = 1 then
                -- 部门负责人,找上一级部门负责人
                begin
                  select lower(sys_guid()),
                         ROW_CONF.N_WORKFLOW_TYPE,
                         WorkflowId,
                         0,
                         ROW_CONF.N_APPROVAL_MODEL,
                         c_organization_owner c_user_id,
                         owner_name v_pet_name,
                         '主管副总',
                         0,
                         null,
                         null,
                         0,
                         1
                    into LST(1)
                    from (select g.c_organization_id,
                                 v_organization_name,
                                 n_organization_level,
                                 c_organization_owner,
                                 g.n_organization_type,
                                 c_organization_po,
                                 level as lv,
                                 (select u.v_pet_name
                                    from lcbase.t_zip_user u
                                   where u.c_user_id = g.c_organization_owner
                                     and u.d_enddate > sysdate
                                     and u.n_status = 0) as owner_name
                            from (select *
                                    from lcbase.t_zip_organization g
                                   where g.d_enddate > sysdate) g
                           where g.d_enddate > sysdate
                          connect by prior g.c_organization_parent_id =
                                      g.c_organization_id
                           start with g.c_organization_id = OrganizationId
                           order by level)
                   where c_organization_id <> OrganizationId
                     and c_organization_owner is not null
                     and rownum = 1;
                  flowusercount := 1;
                end;
              else
                begin
                  select lower(sys_guid()),
                         ROW_CONF.N_WORKFLOW_TYPE,
                         WorkflowId,
                         0,
                         ROW_CONF.N_APPROVAL_MODEL,
                         c_organization_owner c_user_id,
                         owner_name v_pet_name,
                         '主管副总',
                         0,
                         null,
                         null,
                         0,
                         1
                    into LST(1)
                    from (select g.c_organization_id,
                                 v_organization_name,
                                 n_organization_level,
                                 c_organization_owner,
                                 g.n_organization_type,
                                 c_organization_po,
                                 (select u.v_pet_name
                                    from lcbase.t_zip_user u
                                   where u.c_user_id = g.c_organization_owner
                                     and u.d_enddate > sysdate
                                     and u.n_status = 0) as owner_name
                            from (select *
                                    from lcbase.t_zip_organization g
                                   where g.d_enddate > sysdate) g
                           where g.d_enddate > sysdate
                          connect by prior g.c_organization_parent_id =
                                      g.c_organization_id
                           start with g.c_organization_id = OrganizationId)
                   where n_organization_level = 2;
                  flowusercount := 1;
                end;
              end if;
            end if;
        end;
      end if;
      flowusercount := 1;
      -- 最近BP
    elsif ROW_CONF.N_APPROVAL_USER_TYPE = 4 then

      open cur_org_owner for
        with all_g as
         (select *
            from (select *
                    from lcbase.t_zip_organization g
                   where g.d_enddate > sysdate) g
          connect by prior g.c_organization_parent_id = g.c_organization_id
           start with g.c_organization_id = OrganizationId)
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               s.c_user_id,
               s.v_pet_name,
               '最近BP',
               0,
               null,
               null,
               0,
               1
          into LST(1)
          from (select *
                  from all_g g
                  left join lcbase.t_zip_user w
                    on w.c_user_id = g.c_organization_bp
                 where g.c_organization_bp is not null
                   and w.d_enddate > sysdate
                 order by n_organization_level desc) s
         where rownum = 1;
      fetch cur_org_owner
        into LST(0);
      if cur_org_owner%found then
        LST(1) := LST(0);
        flowusercount := 1;
      end if;
      close cur_org_owner;

      -- 借款财务审批
    elsif row_conf.n_approval_user_type in (16, 17, 18, 19, 20) then
      -- 根据配置的角色id获取审批人列表

      open cur_org_owner for
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               ROW_CONF.N_APPROVAL_ORDER,
               ROW_CONF.N_APPROVAL_MODEL,
               y.c_user_id,
               y.v_pet_name,
               z.v_approval_user_title,
               0,
               null,
               null,
               0,
                1
          from Oa_Aut_User_Role x,lcbase.t_zip_user y,
            (select b.n_approval_user_type,b.v_approval_user_title,a.c_role_id,trim(b.v_approval_user_id) v_approval_user_id
              from Oa_Aut_Role a ,oa_afw_workflow_user_type b
             where trim(b.v_approval_user_id) = to_char(a.role_type)
               and trim(b.v_approval_user_id) in('6','61','62','64','65')
               and b.n_approval_user_type = row_conf.n_approval_user_type  ) z
           where x.c_user_id = y.c_user_id
             and x.c_role_id = z.c_role_id
             and y.d_enddate > sysdate ;

/*
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               ROW_CONF.N_APPROVAL_ORDER,
               ROW_CONF.N_APPROVAL_MODEL,
               u.c_user_id,
               u.v_pet_name,
               a.v_approval_user_title,
               0,
               null,
               null,
               0
          from lcoa.oa_afw_workflow_user_type a
          join lcoa.oa_afw_approval_user_role b
            on (trim(a.v_approval_user_id) = to_char(b.n_approval_role_id))
          join lcbase.t_zip_user u
            on (b.c_user_id = u.c_user_id and u.d_enddate > sysdate)
         where a.n_approval_user_type = row_conf.n_approval_user_type;
*/
      fetch cur_org_owner
        into LST(0);
      while cur_org_owner%found loop
        flowusercount := flowusercount + 1;
        LST(flowusercount) := LST(0);
        fetch cur_org_owner
          into LST(0);
      end loop;
      close cur_org_owner;
      return flowusercount;
    elsif row_conf.n_approval_user_type= 21 then
      -- 数据修改会签
      if WorkflowSubtype = 3 then
        -- KA  财务+KA负责人
        open cur_org_owner for
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               ROW_CONF.N_APPROVAL_ORDER,
               ROW_CONF.N_APPROVAL_MODEL,
               v_approval_user_id,
               v_approval_user_name,
               '数据修改会签',
               0,
               null,
               null,
               0,
               1
          from (
            select t.v_approval_user_id,t.v_approval_user_name
              from oa_afw_workflow_user_type t
             where t.n_approval_user_type in(11,8)
          );
      elsif WorkflowSubtype in (1,2) then
       open cur_org_owner for
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               ROW_CONF.N_APPROVAL_ORDER,
               ROW_CONF.N_APPROVAL_MODEL,
               v_approval_user_id,
               v_approval_user_name,
               '数据修改会签',
               0,
               null,
               null,
               0,
                1
          from (
            select t.v_approval_user_id,t.v_approval_user_name
              from oa_afw_workflow_user_type t
             where t.n_approval_user_type = 11
             union all
            select a.c_user_id,a.v_pet_name
              from lcbase.t_zip_user a
              join lcbase.t_zip_organization b on(b.c_organization_owner = a.c_user_id)
              join oa_afw_workflow_army_config c on(b.c_organization_id = c.c_organization_id)
             where a.d_enddate > sysdate
               and b.d_enddate > sysdate
               and c.n_kindofwork in(1,2,3)
          );

      end if;
      -- 业务 干线 精拼 WorkflowUserId
      fetch cur_org_owner
        into LST(0);
      while cur_org_owner%found loop
        flowusercount := flowusercount + 1;
        LST(flowusercount) := LST(0);
        fetch cur_org_owner
          into LST(0);
      end loop;
      close cur_org_owner;
      return flowusercount;

    else

      select lower(sys_guid()),
             ROW_CONF.N_WORKFLOW_TYPE,
             WorkflowId,
             0,
             ROW_CONF.N_APPROVAL_MODEL,
             u.v_approval_user_id,
             u.v_approval_user_name,
             u.v_approval_user_title,
             0,
             null,
             null,
             0,
             1
        into LST(1)
        from oa_afw_workflow_user_type u
       where u.n_approval_user_type = ROW_CONF.N_APPROVAL_USER_TYPE;
      flowusercount := 1;

    end if;
    return flowusercount;
  end;

  procedure Create_Approval_By_Id(WorkflowId   in varchar2,
                                  WorkflowType in number) is
    WorkflowUserId     char(32);
    Old_OrganizationId char(32);
    New_OrganizationId char(32);
    DaysCount          number(5, 1);
    RangeType          number;
    v_subtype          number;
  begin
    --首先要清除 该业务Id对应的无效审批流信息？
    delete from oa_afw_workflow_approval_flow t
     where t.c_workflow_id = WorkflowId
       and t.n_approval_status in (0, 9);
    --以下逻辑应该在调用时传入即可，无需单独再获取一次
    case
      when WorkflowType = 1 then
        select t.n_leave_days, t.c_leave_user_id
          into DaysCount, WorkflowUserId
          from oa_afw_leave_info t
         where t.c_leave_id = WorkflowId;
      when WorkflowType = 2 then
        select t.n_egress_days, t.c_egress_user_id
          into DaysCount, WorkflowUserId
          from oa_afw_egress_info t
         where t.c_egress_id = WorkflowId;
      when WorkflowType = 3 then
        select t.c_input_user_id, t.n_news_range
          into WorkflowUserId, RangeType
          from oa_msg_publish_info t
         where t.c_news_id = WorkflowId;

      when WorkflowType = 4 then
        select t.c_expenses_user_id
          into WorkflowUserId
          from oa_eps_expenses_info t
         where t.c_expenses_id = WorkflowId;

      when WorkflowType = 5 then
        select t.c_user_id
          into WorkflowUserId
          from oa_afw_loan_info t
         where t.c_id = WorkflowId;
      when WorkflowType = 7 then
        select t.c_user_id
          into WorkflowUserId
          from oa_afw_loan_extension t
         where t.c_id = WorkflowId;
      when WorkflowType = 11 then
        select t.c_promotion_user_id
          into WorkflowUserId
          from lcoa.oa_afw_promotion_info t
         where t.c_promotion_id = WorkflowId;

      when WorkflowType = 12 then
        select t.c_adjust_user_id, t.c_new_orgnization_id
          into WorkflowUserId, New_OrganizationId
          from lcoa.oa_afw_adjustpost_info t
         where t.c_adjust_id = WorkflowId;

      when WorkflowType = 16 then
        select t.c_input_user_id,t.n_business_type
          into WorkflowUserId,v_subtype
          from lcoa.oa_afw_dmd_apply t
         where t.c_datamodify_apply_id = WorkflowId;
        /*        select 'Old_OrganizationId', 'New_OrganizationId'
        into Old_OrganizationId, New_OrganizationId
        from dual; --待实现*/
      else
        DaysCount := 0;
    end case;
    select c_organization_id
      into Old_OrganizationId
      from lcbase.t_zip_user
     where c_user_id = WorkflowUserId
       and d_enddate > sysdate;
    /*    CreateLeaveFullWorkflow(WorkflowId,
    WorkflowType,
    WorkflowUserId,
    DaysCount);*/
    Create_All_Approval_Userlist(WorkflowId         => WorkflowId,
                                 WorkflowUserId     => WorkflowUserId,
                                 WorkflowType       => WorkflowType,
                                 WorkflowSubtype    => v_subtype,
                                 RangeType          => RangeType,
                                 DaysCount          => DaysCount,
                                 Old_OrganizationId => Old_OrganizationId,
                                 New_OrganizationId => New_OrganizationId);


  end;

  procedure Create_All_Approval_Userlist(WorkflowId         in varchar2,
                                         WorkflowUserId     in varchar2,
                                         WorkflowType       in number,
                                         WorkflowSubtype    in number,
                                         RangeType          in number,
                                         DaysCount          in number,
                                         Old_OrganizationId in varchar2,
                                         New_OrganizationId in varchar2) is
    CUR_CONF sys_refcursor;
    ROW_CONF oa_afw_workflow_config%rowtype;
    P_LST    T_FLOW;
    P_STEP   number;
    P_NUM    number;
    P_ALL    number;
    P_EXIST  number;
    v_amount number;
    v_subtype number;
    v_OrganizationId varchar2(32);
    v_count number;
    v_sort  number;
  begin
    P_ALL  := 0;
    P_STEP := 0;
    GetWorkflowConfByFlowType(
          WorkFlowType => WorkFlowType,
          WorkflowUserId=> WorkflowUserId,
          CUR_CONF => CUR_CONF);


    fetch CUR_CONF
      into ROW_CONF;




    while CUR_CONF%found loop
        v_OrganizationId := case
                           when WorkflowType = 12 and row_conf.n_approval_order in (3, 4) then
                            New_OrganizationId
                           else
                            Old_OrganizationId
                         end;  
    
      P_NUM := Create_Part_Approval_Userlist(ROW_CONF        => ROW_CONF,
                                             WorkflowId      => WorkflowId,
                                             WorkflowSubtype => WorkflowSubtype,
                                             WorkflowUserId  => WorkflowUserId,
                                             OrganizationId  => v_OrganizationId,
                                             LST             => P_LST);

      if P_NUM = 0 then
        raise pkg_common.EXP_NOLEADER;
      end if;
      v_sort :=1;
      for I in 1 .. P_NUM loop

        select count(1)
          into P_EXIST
          from oa_afw_workflow_approval_flow t
         where t.c_workflow_id = WorkflowId
           and t.c_approval_user_id = P_LST(I).c_approval_user_id;

        if WorkflowType = 5 then
          -- 借款流程借款金额小于等于1万，不需要财务vp
          select t.n_amount
            into v_amount
            from oa_afw_loan_info t
           where t.c_id = WorkflowId;
          if v_amount <= 10000 and row_conf.n_approval_order = 6 then
            exit;
          end if;
        end if;

        if P_LST(I).c_approval_user_id is not null then
          if WorkflowType = 5 and ROW_CONF.N_APPROVAL_USER_TYPE in (16, 17, 18, 19, 20) then
           -- 借款 财务的角色不做合并
           P_EXIST := 0;  
          end if;
          if P_EXIST = 0 then
            insert into oa_afw_workflow_approval_flow
              (c_data_id,
               n_workflow_type,
               c_workflow_id,
               n_approval_order,
               n_approval_model,
               c_approval_user_id,
               v_approval_user_name,
               v_approval_user_title,
               n_approval_status,
               n_approval_sort)
            values
              (P_LST(I).c_data_id,
               P_LST(I).n_workflow_type,
               P_LST(I).c_workflow_id,
               row_conf.n_approval_order, --P_ALL + I P_LST(I).n_approval_order
               P_LST(I).n_approval_model,
               P_LST(I).c_approval_user_id,
               P_LST(I).v_approval_user_name,
               P_LST(I).v_approval_user_title,
               P_LST(I).n_approval_status,
               case when P_LST(I).n_approval_model = 1 then v_sort else 1 end);
          else
            update oa_afw_workflow_approval_flow t
               set t.v_approval_user_title = t.v_approval_user_title || ',' || P_LST(I)
                                            .v_approval_user_title
             where t.c_workflow_id = WorkflowId
               and t.c_approval_user_id = P_LST(I).c_approval_user_id;
          end if;

        end if;
        v_sort := v_sort + 1;
      end loop;
      P_STEP := P_STEP + 1;
      P_ALL  := P_ALL + P_NUM;
      if WorkflowType in (1, 2) and DaysCount < 3 and P_ALL > 0 then
        exit;
      end if;
      if WorkflowType = 3 and RangeType <> 2 and P_STEP = 2 and P_ALL > 0 then
        exit;
      end if;

      fetch CUR_CONF
        into ROW_CONF;
    end loop;
    close CUR_CONF;
    --commit;
  end;

  procedure GetWorkflowConfByFlowType(WorkFlowType in number,
                                      WorkflowUserId  varchar2,
                                      CUR_CONF     out sys_refcursor) is
    v_count number;
  begin

    if WorkflowType = 16 then

      -- 战区总以上级别申请：直接走会签。三军种负责人申请：直接走会签，自己也需要签。
      -- 首先他是部门负责人，并且部门level小于或等于1或者部门是三军种）
      select count(*) into v_count
        from lcbase.t_zip_user a
       where exists(
         select '' from (
            -- 他是level小于等于2的部门的负责人
            select t.c_organization_owner c_user_id
              from lcbase.t_zip_organization t
             where t.c_organization_owner = WorkflowUserId
               and t.d_enddate > sysdate
               and t.n_organization_level <= 2
               and t.n_organization_type<>9 -- 不含项目型部门
            union
            -- 他是军委常委
            select c_user_id
              from oa_afw_approval_user_role
             where n_approval_role_id = 4
               and c_user_id=WorkflowUserId
           ) b where a.c_user_id = b.c_user_id
         );
      if v_count > 0 then
        open CUR_CONF for
        select *
          from oa_afw_workflow_config
         where n_workflow_type = WorkflowType
           and n_approval_order = 3;
      else
        open CUR_CONF for
        select *
          from oa_afw_workflow_config
         where n_workflow_type = WorkflowType
         order by n_approval_order;
      end if;
    else
      open CUR_CONF for
        select *
          from oa_afw_workflow_config
         where n_workflow_type = WorkflowType
         order by n_approval_order;
    end if;

  end;
  procedure CreateLeaveFullWorkflow(WorkflowId     in varchar2,
                                    WorkflowType   in number,
                                    WorkflowUserId in varchar2,
                                    DaysCount      in number) is
    CUR_CONF          sys_refcursor;
    ROW_CONF          oa_afw_workflow_config%rowtype;
    ROW_FLOW          oa_afw_workflow_approval_flow%rowtype;
    SuperiorUserId    char(32);
    SuperiorUserName  varchar2(20);
    SuperiorUserTitle varchar2(20);
    VPUserId          char(32);
    VPUserName        varchar2(20);
    VPUserTitle       varchar2(20);
    nApprovalOrder    number(2) := 0;
  begin
    GetWorkflowConfByFlowType(
          WorkFlowType => WorkFlowType,
          WorkflowUserId=> WorkflowUserId,
          CUR_CONF => CUR_CONF);
    fetch CUR_CONF
      into ROW_CONF;
    while CUR_CONF%found loop

      if ROW_CONF.N_APPROVAL_USER_TYPE = 1 then
        --直接上级
        --Added By Lihuawei At 2020.5.3
        --直接上级
        --直接上级或主管副总，该步骤为空

        --判断是否为主管副总申请
        if (lcoa.pkg_ins_user_info.IsVPUserByUserId(WorkflowUserId,
                                                    VPUserId,
                                                    VPUserName,
                                                    VPUserTitle) = 0) then
          lcoa.pkg_ins_user_info.GetDirectSuperiorByUserId(WorkflowUserId,
                                                           SuperiorUserId,
                                                           SuperiorUserName,
                                                           SuperiorUserTitle);
          if SuperiorUserId is not null then
            ROW_FLOW.N_WORKFLOW_TYPE       := WorkFlowType;
            ROW_FLOW.C_WORKFLOW_ID         := WorkflowId;
            nApprovalOrder                 := nApprovalOrder + 1;
            ROW_FLOW.N_APPROVAL_ORDER      := nApprovalOrder;
            ROW_FLOW.N_APPROVAL_MODEL      := ROW_CONF.N_APPROVAL_MODEL;
            ROW_FLOW.C_APPROVAL_USER_ID    := SuperiorUserId;
            ROW_FLOW.V_APPROVAL_USER_NAME  := SuperiorUserName;
            ROW_FLOW.V_APPROVAL_USER_TITLE := SuperiorUserTitle;
            InsertApprovelWorkflow(ROW_FLOW);
          end if;
        end if;
      elsif ROW_CONF.n_Approval_User_Type = 3 then
        --主管副总
        --主管副总
        lcoa.pkg_ins_user_info.GetVPByUserId(WorkflowUserId,
                                             VPUserId,
                                             VPUserName,
                                             VPUserTitle);
        if VPUserId is not null then
          ROW_FLOW.N_WORKFLOW_TYPE       := WorkFlowType;
          ROW_FLOW.C_WORKFLOW_ID         := WorkflowId;
          nApprovalOrder                 := nApprovalOrder + 1;
          ROW_FLOW.N_APPROVAL_ORDER      := nApprovalOrder;
          ROW_FLOW.N_APPROVAL_MODEL      := ROW_CONF.N_APPROVAL_MODEL;
          ROW_FLOW.C_APPROVAL_USER_ID    := VPUserId;
          ROW_FLOW.V_APPROVAL_USER_NAME  := VPUserName;
          ROW_FLOW.V_APPROVAL_USER_TITLE := VPUserTitle;
          InsertApprovelWorkflow(ROW_FLOW);
        end if;
      end if;
      --请假和外出3天以内一级审批即可，否则需要主管副总审批
      --因二级部门负责人直接上级为主管副总，所以该判断逻辑在循环中，以区分一级审批还是二级审批
      if WorkflowType in (1, 2) and DaysCount < 3 and nApprovalOrder > 0 then
        exit;
      end if;

      fetch CUR_CONF
        into ROW_CONF;
    end loop;
  end;
  procedure InsertApprovelWorkflow(ROW_FLOW oa_afw_workflow_approval_flow%rowtype) is
  begin
    insert into oa_afw_workflow_approval_flow
      (c_data_id,
       n_workflow_type,
       c_workflow_id,
       n_approval_order,
       n_approval_model,
       c_approval_user_id,
       v_approval_user_name,
       v_approval_user_title,
       n_approval_status)
    values
      (lower(sys_guid()),
       ROW_FLOW.n_workflow_type,
       ROW_FLOW.c_workflow_id,
       ROW_FLOW.n_Approval_Order,
       ROW_FLOW.n_approval_model,
       ROW_FLOW.c_approval_user_id,
       ROW_FLOW.v_approval_user_name,
       ROW_FLOW.v_approval_user_title,
       0);
  end;

  procedure CreatePreApprovalUserList(WorkflowType    in number,
                                      WorkflowSubtype in number,
                                      WorkflowId      in varchar2,
                                      WorkflowUserId  in varchar2,
                                      OrganizationId  in varchar2,
                                      LST             out T_FLOW) is
    CUR_CONF  sys_refcursor;
    ROW_CONF  oa_afw_workflow_config%rowtype;
    ROW_FLOW  oa_afw_workflow_approval_temp%rowtype;
    P_LST     T_FLOW;
    P_STEP    number;
    P_NUM     number;
    P_ALL     number;
    P_EXIST   number;
    P_RETURN  number;
    DaysCount number(8, 4);
    StartTime Date;
    EndTime   Date;
  begin
    GetWorkflowConfByFlowType(
          WorkFlowType => WorkFlowType,
          WorkflowUserId=> WorkflowUserId,
          CUR_CONF => CUR_CONF);

    fetch CUR_CONF
      into ROW_CONF;
    while CUR_CONF%found loop
      P_NUM := Create_Part_Approval_Userlist(ROW_CONF        => ROW_CONF,
                                             WorkflowId      => WorkflowId,
                                             WorkflowSubtype => WorkflowSubtype,
                                             WorkflowUserId  => WorkflowUserId,
                                             OrganizationId  => OrganizationId,
                                             LST             => P_LST);

      for I in 1 .. P_NUM loop
        select count(1)
          into P_EXIST
          from oa_afw_workflow_approval_temp t
         where t.c_workflow_id = WorkflowId
           and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        if P_EXIST = 0 then
          ROW_FLOW.c_Data_Id             := P_LST(I).c_data_id;
          ROW_FLOW.N_WORKFLOW_TYPE       := P_LST(I).n_workflow_type;
          ROW_FLOW.C_WORKFLOW_ID         := P_LST(I).c_workflow_id;
          ROW_FLOW.N_APPROVAL_ORDER      := P_ALL + I;
          ROW_FLOW.N_APPROVAL_MODEL      := P_LST(I).n_approval_model;
          ROW_FLOW.C_APPROVAL_USER_ID    := P_LST(I).c_approval_user_id;
          ROW_FLOW.V_APPROVAL_USER_NAME  := P_LST(I).v_approval_user_name;
          ROW_FLOW.V_APPROVAL_USER_TITLE := P_LST(I).v_approval_user_title;
          ROW_FLOW.n_Approval_Status     := P_LST(I).n_approval_status;
          InsertApprovelWorkflowTmp(ROW_FLOW => ROW_FLOW);
        else
          update oa_afw_workflow_approval_temp t
             set t.v_approval_user_title = t.v_approval_user_title || ',' || P_LST(I)
                                          .v_approval_user_title
           where t.c_workflow_id = WorkflowId
             and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        end if;
      end loop;
      P_STEP := P_STEP + 1;
      P_ALL  := P_ALL + P_NUM;
      if WorkflowType in (1, 2) and DaysCount < 3 and P_ALL > 0 then
        exit;
      end if;
      if WorkflowType = 3 and WorkflowSubtype <> 2 and P_STEP = 2 and
         P_ALL > 0 then
        exit;
      end if;
      fetch CUR_CONF
        into ROW_CONF;
    end loop;
    close CUR_CONF;
    commit;
  end;
  procedure InsertApprovelWorkflowTmp(ROW_FLOW oa_afw_workflow_approval_temp%rowtype) is
  begin
    insert into oa_afw_workflow_approval_temp
      (c_data_id,
       n_workflow_type,
       c_workflow_id,
       n_approval_order,
       n_approval_model,
       c_approval_user_id,
       v_approval_user_name,
       v_approval_user_title,
       n_approval_status)
    values
      (ROW_FLOW.c_Data_Id,
       ROW_FLOW.n_workflow_type,
       ROW_FLOW.c_workflow_id,
       ROW_FLOW.n_Approval_Order,
       ROW_FLOW.n_approval_model,
       ROW_FLOW.c_approval_user_id,
       ROW_FLOW.v_approval_user_name,
       ROW_FLOW.v_approval_user_title,
       0);
  end;

  function Get_Pre_Approval_Userlist(WorkflowUserId     in varchar2,
                                     WorkflowType       in number,
                                     WorkflowSubtype    in number,
                                     DStartTime         in varchar2,
                                     DEndTime           in varchar2,
                                     New_OrganizationId in varchar2,
                                     Days               out number,
                                     Hours              out number,
                                     CUR_DATA           out sys_refcursor,
                                     ErrMsg             out varchar2)
    return number is
    CUR_CONF       sys_refcursor;
    ROW_CONF       oa_afw_workflow_config%rowtype;
    P_LST          T_FLOW;
    WorkflowId     char(32);
    OrganizationId char(32);
    P_STEP         number;
    P_NUM          number;
    P_ALL          number;
    P_EXIST        number;
    P_RETURN       number;
    DaysCount      number(8, 4);
    StartTime      Date;
    EndTime        Date;
    v_OrganizationId varchar2(32);
    v_count   number;
    v_sort    number;
  begin
    P_ALL      := 0;
    P_STEP     := 0;
    WorkflowId := lower(sys_guid());
    select u.c_organization_id
      into OrganizationId
      from lcbase.t_zip_user u
     where u.c_user_id = WorkflowUserId
       and u.d_enddate > sysdate;

    if WorkflowType in (1, 2) then
      StartTime := to_date(DStartTime, 'yyyymmddhh24miss');
      EndTime   := to_date(DEndTime, 'yyyymmddhh24miss');
      if WorkflowType = 1 and WorkflowSubtype in (1, 2, 3) then
        P_RETURN := lcoa.PKG_USER_RESTTIME.getHolidayDuration(WorkflowUserId,
                                                              StartTime,
                                                              EndTime,
                                                              Days,
                                                              Hours,
                                                              ErrMsg);
        if P_RETURN <> 0 then
          return P_RETURN;
        end if;
        DaysCount := Days + Hours / 7; --added by lihuawei at 2020/5/8 此处应该统一为7小时为1个工作日；不考虑周六工时少的情况。
      elsif WorkflowType = 2 and WorkflowSubtype = 1 then
        --GetTotalDays(StartTime, EndTime, Days, Hours);
        Hours     := round((trunc(EndTime, 'hh24') -
                           trunc(StartTime, 'hh24')) * 24,
                           0);
        Days      := 0;
        DaysCount := 1;
      else
        Days      := trunc(EndTime, 'dd') - trunc(StartTime, 'dd') + 1;
        Hours     := 0;
        DaysCount := Days;
      end if;
    end if;

    GetWorkflowConfByFlowType(
          WorkFlowType => WorkFlowType,
          WorkflowUserId=> WorkflowUserId,
          CUR_CONF => CUR_CONF);

    fetch CUR_CONF
      into ROW_CONF;




    while CUR_CONF%found loop
      v_OrganizationId := case
                           when WorkflowType = 12 and row_conf.n_approval_order in (3, 4) then
                            New_OrganizationId
                           else
                            OrganizationId
                         end;      
    
      P_NUM := Create_Part_Approval_Userlist(ROW_CONF        => ROW_CONF,
                                             WorkflowId      => WorkflowId,
                                             WorkflowSubtype => WorkflowSubtype,
                                             WorkflowUserId  => WorkflowUserId,
                                             OrganizationId  => v_OrganizationId,
                                             LST             => P_LST);


      if P_NUM = 0 then
        raise pkg_common.EXP_NOLEADER;
      end if;
      v_sort := 1;
      for I in 1 .. P_NUM loop

        select count(1)
          into P_EXIST
          from oa_afw_workflow_approval_temp t
         where t.c_workflow_id = WorkflowId
           and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        if WorkflowType = 5 and ROW_CONF.N_APPROVAL_USER_TYPE in (16, 17, 18, 19, 20) then
           -- 借款 财务的角色不做合并
           P_EXIST := 0;  
        end if;
        if P_EXIST = 0  then
          insert into oa_afw_workflow_approval_temp
            (c_data_id,
             n_workflow_type,
             c_workflow_id,
             n_approval_order,
             n_approval_model,
             c_approval_user_id,
             v_approval_user_name,
             v_approval_user_title,
             n_approval_status,
             n_approval_sort)
          values
            (P_LST(I).c_data_id,
             P_LST(I).n_workflow_type,
             P_LST(I).c_workflow_id,
             row_conf.n_approval_order, --P_ALL + I P_LST(I).n_approval_order
             P_LST(I).n_approval_model,
             P_LST(I).c_approval_user_id,
             P_LST(I).v_approval_user_name,
             P_LST(I).v_approval_user_title,
             P_LST(I).n_approval_status,
             case when P_LST(I).n_approval_model = 1 then v_sort else 1 end);
        else

          update oa_afw_workflow_approval_temp t
             set t.v_approval_user_title = t.v_approval_user_title || ',' || P_LST(I)
                                          .v_approval_user_title
           where t.c_workflow_id = WorkflowId
             and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        end if;
        v_sort := v_sort + 1;
      end loop;
      P_STEP := P_STEP + 1;
      P_ALL  := P_ALL + P_NUM;
      if WorkflowType in (1, 2) and DaysCount < 3 and P_ALL > 0 then
        exit;
      end if;
      if WorkflowType = 3 and WorkflowSubtype <> 2 and P_STEP = 2 and
         P_ALL > 0 then
        exit;
      end if;
      fetch CUR_CONF
        into ROW_CONF;
    end loop;
    close CUR_CONF;
    commit;
    open CUR_DATA for
      select f.c_data_id,
             f.n_workflow_type,
             f.c_workflow_id,
             f.n_approval_order,
             f.n_approval_model,
             f.c_approval_user_id,
             f.v_approval_user_name,
             f.v_approval_user_title,
             f.n_approval_status,
             f.n_approval_sort,
             f.d_approval_time,
             f.v_approval_remark,
             tu.v_headpic_aly
        from oa_afw_workflow_approval_temp f
        LEFT JOIN LCBASE.t_zip_user tu
          ON f.C_APPROVAL_USER_ID = tu.C_USER_ID
       where f.c_workflow_id = WorkflowId
         and tu.d_enddate > sysdate
       order by f.n_approval_order;
    return 0;
  end;

  /**
  功能：申请人撤回申请

  处理事项：
  1.判断当前申请是否可以撤回，如果可以则撤回;
  2.发送消息给申请人
  **/
  function Approval_Target_Delay(WorkflowId     in varchar2,
                                 WorkflowType   in number,
                                 WorkflowUserId in varchar2,
                                 ApprovalRemark in varchar2,
                                 ErrMsg         out varchar2) return number as
    StartTime date;
    CurStatus number;
  begin

    if WorkflowType = 11 then
      update lcoa.oa_afw_promotion_info t
         set t.n_status = 4
       where t.c_promotion_id = WorkflowId
         and t.c_promotion_user_id = WorkflowUserId;
    end if;
    if SQL%ROWCOUNT = 1 then
      delete from oa_tdo_todo_info t
       where t.n_status = 0
         and t.c_todo_data_id in
             (select f.c_data_id
                from lcoa.oa_afw_workflow_approval_flow f
               where f.c_workflow_id = WorkflowId);
      Send_Workflow_Approval_Message(WorkflowId,
                                     WorkflowUserId,
                                     WorkflowType,
                                     2);
      commit;
      return 0;
    else
      RAISE_APPLICATION_ERROR(-20001, '转正延期失败', false);
    end if;
  exception
    when PKG_COMMON.EXP_CHECK then
      return pkg_common.g_errcode_afw_overlap;
    when NO_DATA_FOUND then
      ErrMsg := pkg_common.g_errmsg_afw_nodata;
      return pkg_common.g_errcode_afw_nodata;
    when others then
      ErrMsg := 'Approval_Target_Cancel: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;
  procedure Send_Workflow_Approval_Message(WorkflowId     in varchar2,
                                           ApprovalUserId in varchar2,
                                           WorkflowType   in number,
                                           ApprovalResult in number) is
    errmsg           varchar2(2000);
    P_ApprovalResult varchar2(40);
    approvalusername varchar2(20);
    P_RANGE          number;
    v_message        varchar2(400);
  begin
    select u.v_pet_name
      into approvalusername
      from lcbase.t_zip_user u
     where u.c_user_id = ApprovalUserId
       and u.d_enddate > sysdate;
    P_ApprovalResult := case
                          when ApprovalResult in (1, 2) then
                           approvalusername || '已经通过你的'
                          when ApprovalResult = -1 then
                           approvalusername || '已驳回你的'
                          when ApprovalResult = -2 then
                           approvalusername || '已撤回了'
                          else
                           '正在处理你的审批申请'
                        end;
    if WorkflowType = 1 then
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult || '请假申请',
               sysdate,
               0,
               t.c_leave_user_id,
               WorkflowId,
               u.v_pet_name || '的' || decode(t.n_leave_type,
                                             1,
                                             '事假',
                                             2,
                                             '病假',
                                             3,
                                             '调休',
                                             4,
                                             '年假',
                                             5,
                                             '产假',
                                             6,
                                             '哺乳假',
                                             7,
                                             '婚假',
                                             8,
                                             '丧假',
                                             9,
                                             '陪产假',
                                             10,
                                             '产检假',
                                             '其它请假') || case
                 when t.n_leave_days > 0 then
                  t.n_leave_days || '天'
                 else
                  null
               end || case
                 when t.n_leave_hours > 0 then
                  t.n_leave_hours || '小时'
                 else
                  null
               end || '【' ||
               to_char(t.d_leave_start_time, 'yyyy-MM-dd HH24:mi am') || '至' ||
               to_char(t.d_leave_end_time, 'yyyy-MM-dd HH24:mi am') || '】',
               '系统',
               sysdate,
               1
          from oa_afw_leave_info t
          left join lcbase.t_zip_user u
            on u.c_user_id = t.c_leave_user_id
         where t.c_leave_id = WorkflowId
           AND (TO_CHAR(t.d_input_date, 'yyyy-mm-dd') >=
               TO_CHAR(u.D_STARTDATE, 'yyyy-mm-dd') AND
               TO_CHAR(t.d_input_date, 'yyyy-mm-dd') <=
               TO_CHAR(u.D_ENDDATE, 'yyyy-mm-dd'));

    elsif WorkflowType = 2 then
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult || '外出申请',
               sysdate,
               0,
               t.c_egress_user_id,
               WorkflowId,
               u.v_pet_name || '的' ||
                decode(t.n_egress_type, 1, '市内外出', 2, '出差', '其它外出') || case
                  when t.n_egress_days > 0 then
                   t.n_egress_days || '天'
                  else
                   null
                end || case
                  when t.n_egress_hours > 0 then
                   t.n_egress_hours || '小时'
                  else
                   null
                end
               --to_char(t.n_egress_days, '90D90')
                || '【' ||
                to_char(t.d_egress_start_time, 'yyyy-MM-dd HH24:mi am') || '至' ||
                to_char(t.d_egress_end_time, 'yyyy-MM-dd HH24:mi am') || '】',
               '系统',
               sysdate,
               1
          from oa_afw_egress_info t
          left join lcbase.t_zip_user u
            on u.c_user_id = t.c_egress_user_id
         where t.c_egress_id = WorkflowId
           AND (TO_CHAR(t.d_input_date, 'yyyy-mm-dd') >=
               TO_CHAR(u.D_STARTDATE, 'yyyy-mm-dd') AND
               TO_CHAR(t.d_input_date, 'yyyy-mm-dd') <=
               TO_CHAR(u.D_ENDDATE, 'yyyy-mm-dd'));
    elsif WorkflowType = 3 then

      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult || '【' || t.v_news_title || '】公告',
               sysdate,
               0,
               t.c_input_user_id,
               WorkflowId,
               t.v_input_user_name || '发布的公告',
               '系统',
               sysdate,
               1
          from lcoa.oa_msg_publish_info t
         where t.c_news_id = WorkflowId;
      IF ApprovalResult = 2 THEN
        select t.n_news_range
          into P_RANGE
          from lcoa.oa_msg_publish_info t
         where t.c_news_id = WorkflowId;

        if P_RANGE = 1 then
          insert into oa_msg_message_info
            (c_msg_id,
             n_msg_type,
             n_istop_flag,
             v_msg_title,
             d_msg_time,
             n_read_flag,
             c_msg_user_id,
             c_msg_src,
             --v_msg_content,
             v_msg_sender,
             d_update_time,
             n_enable)
            select lower(sys_guid()),
                   51,
                   t.n_istop_flag,
                   t.v_news_title,
                   sysdate,
                   0,
                   c_user_id,
                   WorkflowId,
                   --t.v_news_content,
                   t.v_signature_name,
                   sysdate,
                   1
              from (select u.c_user_id
                      from LCBASE.t_zip_user u
                     where u.n_status = 0
                       and u.d_enddate > sysdate
                       and u.c_organization_id in
                           (select g.c_organization_id
                              from LCBASE.t_zip_organization g
                             where g.d_enddate > sysdate
                            connect by prior g.c_organization_id =
                                        g.c_organization_parent_id
                             start with g.c_organization_id in
                                        (select r.c_target_id
                                           from oa_msg_publish_range r
                                          where r.c_news_id = WorkflowId
                                            and r.n_target_type = 1))
                    union
                    select 'e6e0d38119eb47bea9be644ac003bd18' from dual) mu
              left join oa_msg_publish_info t
                on t.c_news_id = WorkflowId;
        else
          insert into oa_msg_message_info
            (c_msg_id,
             n_msg_type,
             n_istop_flag,
             v_msg_title,
             d_msg_time,
             n_read_flag,
             c_msg_user_id,
             c_msg_src,
             --v_msg_content,
             v_msg_sender,
             d_update_time,
             n_enable)
            select lower(sys_guid()),
                   51,
                   t.n_istop_flag,
                   t.v_news_title,
                   sysdate,
                   0,
                   c_user_id,
                   WorkflowId,
                   --t.v_news_content,
                   t.v_signature_name,
                   sysdate,
                   1
              from (select u.c_user_id
                      from LCBASE.t_zip_user u
                     where u.n_status = 0
                       and u.d_enddate > sysdate
                       and u.c_organization_id in
                           (select g.c_organization_id
                              from LCBASE.t_zip_organization g
                             where g.d_enddate > sysdate
                            connect by prior g.c_organization_id =
                                        g.c_organization_parent_id
                             start with g.c_organization_id =
                                        '997c2b49b01d4bdba3c5ea4e0f615617')) mu
              left join oa_msg_publish_info t
                on t.c_news_id = WorkflowId;
        end if;
      END IF;
    elsif WorkflowType = 4 then
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult || '报销申请',
               sysdate,
               0,
               t.c_expenses_user_id,
               WorkflowId,
               t.v_expenses_user_name || '的报销',
               '系统',
               sysdate,
               1
          from oa_eps_expenses_info t
         where t.c_expenses_id = WorkflowId;
    elsif WorkflowType = 11 then
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult || '转正申请',
               sysdate,
               0,
               t.c_promotion_user_id,
               WorkflowId,
               u.v_pet_name || '的转正',
               '系统',
               sysdate,
               1
          from lcoa.oa_afw_promotion_info t
          left join lcbase.t_zip_user u
            on u.c_user_id = t.c_promotion_user_id
         where t.c_promotion_id = WorkflowId
           AND (TO_CHAR(t.d_input_date, 'yyyy-mm-dd') >=
               TO_CHAR(u.D_STARTDATE, 'yyyy-mm-dd') AND
               TO_CHAR(t.d_input_date, 'yyyy-mm-dd') <=
               TO_CHAR(u.D_ENDDATE, 'yyyy-mm-dd'));
    elsif WorkflowType = 16 then
      -- 确认还款通知消息
      -- 借款人消息
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               '还款确认',
               sysdate,
               0,
               t.c_user_id,
               WorkflowId,
               u.v_pet_name || ',您单号为'||t.v_flow_number||'的还款已被财务确认，请登陆OA查阅相关记录。',
               '系统',
               sysdate,
               1
          from oa_afw_repayment_info t
          join lcbase.t_zip_user u on(t.c_user_id = u.c_user_id and u.d_enddate>sysdate)
         where t.c_id = WorkflowId;
 /*
         for loan in(
           select a.c_loan_id,b.v_flow_number,c.v_pet_name,a.c_replayment_amount
           from oa_afw_loan_repayment a,oa_afw_loan_info b,lcbase.t_zip_user c
          where a.c_loan_id = b.c_id
            and b.c_user_id = c.c_user_id
            and c.d_enddate > sysdate
            and a.c_replayment_id = WorkflowId

           ) loop
           -- 审批人信息 每个借款单都发
           insert into oa_msg_message_info
                (c_msg_id,
                 n_msg_type,
                 n_istop_flag,
                 v_msg_title,
                 d_msg_time,
                 n_read_flag,
                 c_msg_user_id,
                 c_msg_src,
                 v_msg_content,
                 v_msg_sender,
                 d_update_time,
                 n_enable)
          select lower(sys_guid()),
                 WorkflowType,
                 0,
                 '还款确认',
                 sysdate,
                 0,
                 f.c_approval_user_id,
                 WorkflowId,
                 loan.v_pet_name ||'已成功归还'||to_char(loan.c_replayment_amount)||'元借款。借款单号:'||loan.v_flow_number ,
                 '系统',
                 sysdate,
                 1
            from oa_afw_repayment_info t
            join oa_afw_workflow_approval_flow f
             on(t.c_id = f.c_workflow_id)
            join lcbase.t_zip_user u
            on(f.c_approval_user_id = u.c_user_id and u.d_enddate > sysdate)
           where t.c_id = WorkflowId;
         end loop;
 */
    end if;
  exception
    when others then
      errmsg := 'Send_New_Message: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE;
  end;
  procedure Create_Next_Approval_Todo(WorkflowId     in varchar2,
                                      TodoTitle      in varchar2,
                                      TodoSender_Cur out sys_refcursor) is
    CUR_FLOW         sys_refcursor;
    ROW_FLOW         oa_afw_workflow_approval_flow%rowtype;
    FLG_MODE         number;
    v_sql            varchar2(32767);
    ErrMsg           varchar2(100);
    v_approval_order number;
    v_workflow_type  number;
    v_todotype       number;
    v_title          varchar2(120);
  begin
    v_title := TodoTitle;
    FLG_MODE := -1;
    v_sql    := 'select null as userid from dual where 1<>1 ';

    select min(n_approval_order), f.n_workflow_type
      into v_approval_order, v_workflow_type
      from oa_afw_workflow_approval_flow f
     where c_workflow_id = WorkflowId
       and n_approval_status = 0
     group by n_workflow_type;
    if v_workflow_type <> 12 then
      /*
        借款支付待办类型为57
      */
      open CUR_FLOW for
        select *
          from oa_afw_workflow_approval_flow t
         where t.c_workflow_id = WorkflowId
           and t.n_approval_status = 0
           and n_approval_order = v_approval_order
           order by t.n_approval_sort;
      fetch CUR_FLOW
        into ROW_FLOW;
      while CUR_FLOW%found loop
        v_todotype := ROW_FLOW.N_WORKFLOW_TYPE;
        if ROW_FLOW.N_WORKFLOW_TYPE = 5 and v_approval_order = 7 then
          -- 借款流程给出纳的待办
          v_todotype := 57;
          select b.v_pet_name || '的借款待支付！'
            into v_title
            from oa_afw_loan_info a,lcbase.t_zip_user b
           where a.c_user_id = b.c_user_id
             and a.c_id = WorkflowId
             and b.d_enddate>sysdate;
              
        end if;
        -- 存储代办邮件内容
        lcoa.PKG_INS_AFW_USERAPPLY.insert_email_info(WorkflowId,
                                                     ROW_FLOW.C_APPROVAL_USER_ID,
                                                     1,
                                                     ErrMsg);
        insert into oa_tdo_todo_info
          (c_todo_id,
           c_todo_user_id,
           d_todo_time,
           n_todo_type,
           v_todo_title,
           d_input_time,
           n_status,
           c_todo_data_id)
        values
          (lower(sys_guid()),
           ROW_FLOW.C_APPROVAL_USER_ID,
           sysdate,
           v_todotype,
           v_title,
           sysdate,
           0,
           ROW_FLOW.C_DATA_ID);

        FLG_MODE := ROW_FLOW.N_APPROVAL_MODEL;
        v_sql    := v_sql || ' union select ''' ||
                    ROW_FLOW.C_APPROVAL_USER_ID || ''' as userid from dual';
        if ROW_FLOW.N_APPROVAL_MODEL = 1 then
          -- 逐级审批
          exit;
        end if;
        fetch CUR_FLOW
          into ROW_FLOW;
      end loop;
      open TodoSender_Cur for v_sql;
      close CUR_FLOW;
    else
      -- 调岗
      open CUR_FLOW for
        select *
          from oa_afw_workflow_approval_flow t
         where t.c_workflow_id = WorkflowId
           and t.n_approval_status = 0;
      fetch CUR_FLOW
        into ROW_FLOW;
      while CUR_FLOW%found loop

        -- 存储代办邮件内容
        lcoa.PKG_INS_AFW_USERAPPLY.insert_email_info(WorkflowId,
                                                     ROW_FLOW.C_APPROVAL_USER_ID,
                                                     1,
                                                     ErrMsg);
        insert into oa_tdo_todo_info
          (c_todo_id,
           c_todo_user_id,
           d_todo_time,
           n_todo_type,
           v_todo_title,
           d_input_time,
           n_status,
           c_todo_data_id)
        values
          (lower(sys_guid()),
           ROW_FLOW.C_APPROVAL_USER_ID,
           sysdate,
           ROW_FLOW.N_WORKFLOW_TYPE,
           v_title,
           sysdate,
           0,
           ROW_FLOW.C_DATA_ID);
        FLG_MODE := ROW_FLOW.N_APPROVAL_MODEL;
        v_sql    := v_sql || ' union select ''' ||
                    ROW_FLOW.C_APPROVAL_USER_ID || ''' as userid from dual';

        fetch CUR_FLOW
          into ROW_FLOW;
      end loop;
      open TodoSender_Cur for v_sql;
      close CUR_FLOW;
    end if;
  end;
  --
  procedure CreateOthersTodo(p_userid in varchar2,
                               p_title  in varchar2,
                               p_type   in number,
                               p_dataid in varchar2,
                               p_time   in varchar2) is

  begin

    insert into oa_tdo_todo_info
      (c_todo_id,
       c_todo_user_id,
       d_todo_time,
       n_todo_type,
       v_todo_title,
       d_input_time,
       n_status,
       c_todo_data_id)
    values
      (lower(sys_guid()),
       p_userid,
       to_date(p_time,'yyyy-mm-dd hh24:mi:ss'),
       p_type,
       p_title,
       sysdate,
       0,
       p_dataid);

  end;


  -- 存储邮件信息
  procedure InsertEmailInfo(p_WorkflowId     in varchar2,
                              p_workflowtype   in number,
                              p_emailtype      in number,
                              p_subject        in varchar2,
                              p_content        in varchar2,
                              p_recipid        in varchar2,
                              p_recipname      in varchar2) is

    cid              varchar2(40);
  begin


    select lower(sys_guid()) into cid from dual;

    -- 插入邮件信息表信息
    INSERT INTO LCOA.OA_MSG_EMAIL_INFO
      (C_ID,
       C_DATAID,
       N_OPERATION_TYPE,
       N_MESSAGE_TYPE,
       N_TYPE, --邮件内容类型 1普通 2HTML
       V_FROM_NAME,
       V_FROM_ADDR,
       V_SUBJECT,
       V_CONTENT,
       N_DEL_STATUS,
       N_SEND_STATUS,
       D_SET_SEND_DATE,
       D_REAL_SEND_DATE,
       N_SEND_ONEBYONE, --是否群发 0群发 1单个发
       N_ALL_USER) --是否全员 0全员 1非全员
    VALUES
      (cid,
       p_WorkflowId,
       p_workflowtype,
       p_emailtype,
       1,
       null,
       null,
       p_subject,
       p_content,
       0,
       0,
       sysdate,
       null,
       1,
       1);


      INSERT INTO LCOA.OA_MSG_RECIPIENT_ADDR
        (C_ID, V_RECIPIENT, V_SENDTOS_ADDR)
       values(cid,p_recipid,p_recipname);


  end;


  --设置审批流状态
  procedure SetApprovalFlowStatus(WorkflowId     in varchar2,
                                  ApprovalUserId in varchar2,
                                  ApprovalRemark in varchar2,
                                  ApprovalStatus in number,
                                  ApprovalOrder in number) is
  begin

    update oa_afw_workflow_approval_flow t
       set t.n_approval_status = ApprovalStatus,
           t.d_approval_time   = sysdate,
           t.v_approval_remark = ApprovalRemark
     where t.c_workflow_id = WorkflowId
       and t.c_approval_user_id = ApprovalUserId
       and t.n_approval_order = ApprovalOrder
       and t.n_approval_status = 0;
    if SQL%ROWCOUNT <> 1 then
      raise PKG_COMMON.EXP_EXECUTE;
    end if;
  end;
  --一次设置所有审批流状态
  procedure SetAllApprovalFlowStatus(WorkflowId     in varchar2,
                                     ApprovalRemark in varchar2,
                                     ApprovalStatus number) is
  begin
    update oa_afw_workflow_approval_flow t
       set t.n_approval_status = ApprovalStatus,
           t.d_approval_time   = sysdate,
           t.v_approval_remark = ApprovalRemark
     where t.c_workflow_id = WorkflowId
       and t.n_approval_status = 0;
    if SQL%ROWCOUNT = 0 then
      raise PKG_COMMON.EXP_EXECUTE;
    end if;
  end;
  --设置待办状态
  procedure SetToDoStatus(WorkflowId     in varchar2,
                          ApprovalUserId in varchar2) is
  begin
    update oa_tdo_todo_info t
       set t.n_status = 1, t.d_done_time = sysdate
     where t.c_todo_user_id = ApprovalUserId
       and t.c_todo_data_id in
           (select f.c_data_id
              from lcoa.oa_afw_workflow_approval_flow f
             where f.c_workflow_id = WorkflowId);
  end;
  procedure RemoveInvalidToDoInfo(WorkflowId in varchar2) is
  begin
    delete from oa_tdo_todo_info t
     where t.n_status = 0
       and t.c_todo_data_id in
           (select f.c_data_id
              from lcoa.oa_afw_workflow_approval_flow f
             where f.c_workflow_id = WorkflowId);
  end;
  procedure CountersignPass(WorkflowId     in varchar2,
                            ApprovalOrder in number,
                            ApprovalModel  in number,
                            ApprovalUserId in varchar2,
                            IsCompleted    out number) is
    /*
    会签 一票通过
    修改本环节非当前审批人的待办状态为1
    把本环节非当前审批人的审批列表一走
    */

    v_count          number;
  begin
    IsCompleted := 0;


    if ApprovalModel = 0 then
      -- 全员通过
      -- 本次审批的状态已经修改过了
      select count(*)
        into v_count
        from oa_afw_workflow_approval_flow w
       where w.c_workflow_id = WorkflowId
         and w.n_approval_order = ApprovalOrder
         and w.n_approval_status = 0;
      if v_count = 0 then
        IsCompleted := 1;
      end if;
    elsif ApprovalModel = 1 then
      IsCompleted := 1;
    elsif ApprovalModel = 2 then
      -- 一票通过
      IsCompleted := 1;
      -- 处理待办
      update oa_tdo_todo_info ot
         set ot.n_status = 1, ot.d_done_time = sysdate
       where ot.c_todo_data_id in
             (select aa.c_data_id
                from oa_afw_workflow_approval_flow aa
               where c_workflow_id = WorkflowId
                 and n_approval_model = ApprovalModel
                 and n_approval_order = ApprovalOrder
                 and c_approval_user_id <> ApprovalUserId);
      -- 处理审批列表
      insert into oa_afw_countsign_approval_flow
        (c_data_id,
         n_workflow_type,
         c_workflow_id,
         n_approval_order,
         n_approval_model,
         c_approval_user_id,
         v_approval_user_name,
         v_approval_user_title,
         n_approval_status,
         d_approval_time,
         v_approval_remark,
         n_skip_flag,
         n_approval_sort)
        select c_data_id,
               n_workflow_type,
               c_workflow_id,
               n_approval_order,
               n_approval_model,
               c_approval_user_id,
               v_approval_user_name,
               v_approval_user_title,
               n_approval_status,
               d_approval_time,
               nvl(v_approval_remark, '') ||
               to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'),
               n_skip_flag,
               n_approval_sort
          from oa_afw_workflow_approval_flow
         where c_workflow_id = WorkflowId
           and n_approval_model = ApprovalModel
           and n_approval_order = ApprovalOrder
           and c_approval_user_id <> ApprovalUserId;
      delete from oa_afw_workflow_approval_flow
       where c_workflow_id = WorkflowId
         and n_approval_model = ApprovalModel
         and n_approval_order = ApprovalOrder
         and c_approval_user_id <> ApprovalUserId;
    end if;
  end;

  procedure CountersignReject(WorkflowId     in varchar2,
                              WorkflowType   in number,
                              ApprovalOrder  in number,
                              ApprovalModel  in number,
                              ApprovalUserId in varchar2,
                              IsCompleted    out number) is
    /*
    会签 一票否决
    修改本环节非当前审批人的待办状态为1
    把本环节非当前审批人的审批列表一走
    */
    v_count          number;
  begin
    IsCompleted := 1;
    
    -- 本次审批的状态已经修改过了
    if ApprovalModel in(0,2) then
      -- 一票否决
      -- 处理待办
      update oa_tdo_todo_info ot
         set ot.n_status = 1, ot.d_done_time = sysdate
       where ot.n_status = 0
         and ot.c_todo_data_id in
             (select aa.c_data_id
                from oa_afw_workflow_approval_flow aa
               where c_workflow_id = WorkflowId
                 and n_approval_model = ApprovalModel
                 and n_approval_order = ApprovalOrder
                 and c_approval_user_id <> ApprovalUserId
                 and n_approval_status = 0);
      if WorkflowType = 5 and ApprovalOrder = 7 then
        -- 借款出纳驳回时，不删除别的出纳的记录
        return;
      end if;
      -- 处理审批列表
      insert into oa_afw_countsign_approval_flow
        (c_data_id,
         n_workflow_type,
         c_workflow_id,
         n_approval_order,
         n_approval_model,
         c_approval_user_id,
         v_approval_user_name,
         v_approval_user_title,
         n_approval_status,
         d_approval_time,
         v_approval_remark,
         n_skip_flag,
         n_approval_sort)
        select c_data_id,
               n_workflow_type,
               c_workflow_id,
               n_approval_order,
               n_approval_model,
               c_approval_user_id,
               v_approval_user_name,
               v_approval_user_title,
               n_approval_status,
               d_approval_time,
               nvl(v_approval_remark, '') ||
               to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'),
               n_skip_flag,
               n_approval_sort
          from oa_afw_workflow_approval_flow
         where c_workflow_id = WorkflowId
           and n_approval_model = ApprovalModel
           and n_approval_order = ApprovalOrder
           and c_approval_user_id <> ApprovalUserId;
      delete from oa_afw_workflow_approval_flow
       where c_workflow_id = WorkflowId
         and n_approval_model = ApprovalModel
         and n_approval_order = ApprovalOrder
         and c_approval_user_id <> ApprovalUserId
         and n_approval_status = 0;
    end if;
  end;
  --获取未完结审批流数量
  procedure GetUnDoneApprovalCount(WorkflowId in varchar2,
                                   UnDoneCnt  out number) is
  begin
    select sum(case
                 when t.n_approval_status in (1, 2) then --added by lihuawei 转正延期2也算是审批完结
                  0
                 else
                  1
               end)
      into UnDoneCnt
      from oa_afw_workflow_approval_flow t
     where t.c_workflow_id = WorkflowId;
  end;
  /**
  功能：当前审批人审批通过

  处理事项：
  1.修改当前审批人的审批状态;
  2.修改待办处理结果;
  3.检查工作流状态，如果审批完成，修改总状态为审批完成并发消息给申请人；否则，给下一个审批人生成待办。
  **/
  function Approval_Target_Pass(WorkflowId      in varchar2,
                                WorkflowType    in number,
                                ApprovalUserId  in varchar2,
                                ApprovalRemark  in varchar2,
                                MsgSender_Cur   out sys_refcursor,
                                TodoSender_Cur  out sys_refcursor,
                                IsAll_MsgSender out number, --0是否，1是全部
                                ErrMsg          out varchar2) return number as
    UnDone_Cnt       number;
    TodoTitle        varchar2(400);
    WFStatus         number;
    errcode          number(6) := 0;
    v_approval_model number;
    v_approval_order number;
    v_iscompleted    number;
    v_count          number;
    resultNum number(1);
    v_username      varchar2(32);
  begin

    

    IsAll_MsgSender := 0;
    if WorkflowType = 1 then
      pkg_ins_afw_userapply.GetLeaveAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 2 then
      pkg_ins_afw_userapply.GetEgressAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 3 then
      pkg_ins_afw_userapply.GetPublishAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 4 then
      pkg_ins_afw_userapply.GetEgressAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 5 then
      -- 借款
      pkg_ins_afw_userapply.GetLoanAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 7 then
      -- 延期还款
      pkg_ins_afw_userapply.GetExtensionAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 11 then
      pkg_ins_afw_userapply.GetPromotionAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 12 then
      pkg_ins_afw_userapply.GetAdjustpostAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 16 then
      pkg_ins_afw_userapply.GetDMDAfwStatusById(WorkflowId, WFStatus,0);
    end if;


    if WFStatus <> 0 then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      raise PKG_COMMON.EXP_CHECK;
    end if;
    select n_approval_order, n_approval_model
    into v_approval_order, v_approval_model
     from (    
    select n_approval_order, n_approval_model    
    from oa_afw_workflow_approval_flow a
   where c_workflow_id = WorkflowId
     and c_approval_user_id = ApprovalUserId
     and a.n_approval_status = 0
     order by n_approval_order
     ) where rownum = 1;


    --修改审批流对应记录状态 审批通过 0-->1
    SetApprovalFlowStatus(WorkflowId, ApprovalUserId, ApprovalRemark, 1, v_approval_order);
  -----------------
   if WorkflowType = 16 and ApprovalRemark is not null then
     -- 数据修改，审批意见写入评论
      resultNum := PKG_DMD_APPLY.INSER_OADMDCOMMENT(COMMEN      =>  ApprovalRemark||'^0',
                                  OperationUserID =>  ApprovalUserId,
                                  messageReceiverUserID => '',
                                  datamodify_comment_id => '',
                                  datamodify_apply_id => WorkflowId,
                                  TodoSender_Cur  => TodoSender_Cur,
                                  ErrMsg => ErrMsg);
    end if;
  ------------------


    -- n_approval_model 2 汇签时，一票通过
    CountersignPass(WorkflowId     => WorkflowId ,
                    ApprovalOrder  => v_approval_order,
                    AppRovalModel  => v_approval_model,
                    ApprovalUserId => ApprovalUserId,
                    IsCompleted    => v_iscompleted);

    --待办完成
    SetToDoStatus(WorkflowId, ApprovalUserId);
    --获取审批流未完结数量
    GetUnDoneApprovalCount(WorkflowId, UnDone_Cnt);
    if (UnDone_Cnt = 0) then
      if WorkflowType = 5 then
        WFStatus := 5; -- 支付完成
      else
        WFStatus := 2; --审批完成
      end if;
    else

      if WorkflowType = 5 then
        -- 部门审批完就应该修改状态未财务审批中
        -- 财务经理/VP审批之后状态修改为待支付（7）
        if v_approval_order = 1 then
          select count(*) into v_count
            from oa_afw_workflow_approval_flow t
           where t.c_workflow_id = WorkflowId
             and t.n_workflow_type=5
             and t.n_approval_order = 2;
          if v_count = 0 then
            -- 直接上级和主管副总为同一级
            WFStatus := 4; -- 财务审批中
          else
             WFStatus := 1;
          end if;
        elsif v_approval_order >=2 then
          -- 如果是出纳驳回到费用会计再通过，应该就到待支付
          WFStatus := 4; -- 财务审批中
          if v_approval_order = 3 then
            select count(*) into v_count
              from oa_afw_workflow_approval_flow t
             where t.c_workflow_id = WorkflowId
               and t.n_workflow_type=5
               and n_approval_order in(4,5,6)
               and t.n_approval_status = 0;
            if v_count = 0 then
              WFStatus := 7;
            end if;
          elsif v_approval_order = 6 then
            -- 财务vp审批完待支付
            WFStatus := 7;
          elsif v_approval_order = 5 then
            -- 财务经理审批
            select count(*) into v_count
              from oa_afw_workflow_approval_flow t
             where t.c_workflow_id = WorkflowId
               and t.n_workflow_type=5
               and n_approval_order = 6
               and t.n_approval_status = 0;
             if v_count = 0 then
               WFStatus := 7;
             end if;
          end if;
        end if;

      else
        WFStatus := 1; --审批中
      end if;
    end if;

    -- 存储同意邮件内容
    lcoa.PKG_INS_AFW_USERAPPLY.insert_email_info(WorkflowId,
                                                 ApprovalUserId,
                                                 2,
                                                 ErrMsg);
 
    if WorkflowType = 1 then
      lcoa.pkg_ins_afw_userapply.SetLeaveAfwStatusById(WorkflowId,
                                                       WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateLeaveAfwMsgById(WorkflowId,
                                                       ApprovalUserId,
                                                       1,
                                                       MsgSender_Cur);

      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormLeaveTodoTitleById(WorkflowId,
                                                          TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;

    elsif WorkflowType = 2 then
      lcoa.pkg_ins_afw_userapply.SetEgressAfwStatusById(WorkflowId,
                                                        WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateEgressAfwMsgById(WorkflowId,
                                                        ApprovalUserId,
                                                        1,
                                                        MsgSender_Cur);

      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormEgressTodoTitleById(WorkflowId,
                                                           TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;

    elsif WorkflowType = 3 then
      lcoa.pkg_ins_afw_userapply.SetPublishAfwStatusById(WorkflowId,
                                                         WFStatus);
      lcoa.pkg_ins_afw_userapply.CreatePublishAfwMsgById(WorkflowId,
                                                         ApprovalUserId,
                                                         1,
                                                         case when
                                                         UnDone_Cnt = 0 then 2 else 1 end,
                                                         MsgSender_Cur,
                                                         IsAll_MsgSender);

      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormPublishTodoTitleById(WorkflowId,
                                                            TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;

    elsif WorkflowType = 4 then
      lcoa.pkg_ins_afw_userapply.SetExpensesAfwStatusById(WorkflowId,
                                                          WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateExpensesAfwMsgById(WorkflowId,
                                                          ApprovalUserId,
                                                          1,
                                                          MsgSender_Cur);

      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormExpensesTodoTitleById(WorkflowId,
                                                             TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;

    elsif WorkflowType = 5 then
      -- 借款流程
      lcoa.pkg_ins_afw_userapply.SetLoanAfwStatusById(WorkflowId, WFStatus,0);
      lcoa.pkg_ins_afw_userapply.CreateLoanAfwMsgById(WorkflowId,
                                                      ApprovalUserId,
                                                      1,
                                                      v_approval_order,--approvalOrder
                                                      MsgSender_Cur);

      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormLoanTodoTitleById(WorkflowId,
                                                         TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;

    elsif WorkflowType = 7 then
      -- 延期还款流程
      lcoa.pkg_ins_afw_userapply.SetExtensionAfwStatusById(WorkflowId, WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateExtensionAfwMsgById(WorkflowId,
                                                      ApprovalUserId,
                                                      1,
                                                      MsgSender_Cur);

      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormExtensionTodoTitleById(WorkflowId,TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      elsif UnDone_Cnt = 0 then
        -- 审批完成更新借款记录表中的延期还款日期（应该还款日期）
        update oa_afw_loan_info t
           set t.n_extension_times = nvl(t.n_extension_times ,0)+1,
               t.d_extension_date  = (
                select e.d_extension_date
                  from oa_afw_loan_extension e
                 where e.c_loan_id = t.c_id and e.c_id = WorkflowId
               )
          where t.c_id = (
            select x.c_loan_id
              from oa_afw_loan_extension x
             where x.c_id = WorkflowId
             );
      end if;

    elsif WorkflowType = 11 then
      lcoa.pkg_ins_afw_userapply.SetPromotionAfwStatusById(WorkflowId,
                                                           WFStatus);
      lcoa.pkg_ins_afw_userapply.CreatePromotionAfwMsgById(WorkflowId,
                                                           ApprovalUserId,
                                                           1,
                                                           MsgSender_Cur);

      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormPromotionTodoTitleById(WorkflowId,
                                                              TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;
      if UnDone_Cnt = 0 then
        errcode := lcoa.pkg_ins_promotion_info.update_user_Promotion_info(WorkFlowID,
                                                                          ErrMsg);
      end if;
    elsif WorkflowType = 12 then
      lcoa.pkg_ins_afw_userapply.SetAdjustpostAfwStatusById(WorkflowId,
                                                            WfStatus);
      lcoa.pkg_ins_afw_userapply.CreateAdjustpostAfwMsgById(WorkflowId,
                                                            ApprovalUserId,
                                                            1,
                                                            MsgSender_Cur);

      --调岗是会签不分先后顺序，一次性生成，审批过程中无需发待办
      --当全部完成审批时，修改岗位及部门信息
      --此处如有调岗其他相关数据操作，由对应业务包在此函数中补充完善
      if UnDone_Cnt = 0 then
        errcode := lcoa.pkg_ins_transferposition_info.update_UserAndEmployees_info(WorkflowId,
                                                                                   ErrMsg);
      end if;
    elsif WorkflowType = 16 then
      lcoa.pkg_ins_afw_userapply.SetDMDAfwStatusById(WorkflowId,
                                                          WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateDMDAfwMsgById(WorkflowId,
                                                          ApprovalUserId,
                                                          1,
                                                          MsgSender_Cur);

      if WFStatus = 2 then
        -- 给数据维护发待办
        select t.v_pet_name
          into v_username
          from lcbase.t_zip_user t
         where t.d_enddate > sysdate and c_user_id =(
          select c_user_id from oa_afw_dmd_apply a
           where a.c_input_user_id = t.c_user_id
             and a.c_datamodify_apply_id = WorkflowId
        );
        for lst in(select b.c_user_id, b.v_pet_name
            from oa_aut_user_role a, lcbase.t_zip_user b
           where a.c_user_id = b.c_user_id
             and b.d_enddate > sysdate
             and a.c_role_id =
                 (select c_role_id from OA_AUT_ROLE t where role_type=216)
          ) loop
            -- 审批完成，给数据分发的人发待办 54:数据修改分发 XXX的数据修改申请待处理
            CreateOthersTodo(p_userid => lst.c_user_id,
                             p_title  => v_username||'的数据修改申请待处理',
                             p_type   => 54,
                             p_dataid => WorkflowId,
                             p_time   => to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')) ;


            InsertEmailInfo(p_WorkflowId => WorkflowId,
                              p_workflowtype  => 16,
                              p_emailtype     => 1,
                              p_subject       => v_username||'的数据修改申请待处理',
                              p_content       => lst.v_pet_name||',您好!'||chr(10)||'    '||v_username||'的数据修改申请需要您处理，请登录OA查看，谢谢！',
                              p_recipid       => lst.c_user_id,
                              p_recipname     => lst.v_pet_name);
          end loop;

      end if;

      /*-------------------------------
      会签
      -----------------------------------*/
      if UnDone_Cnt > 0 and v_iscompleted = 1 then
        lcoa.pkg_ins_afw_userapply.FormDMDTodoTitleById(WorkflowId,
                                                             TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;

    end if;
    return errcode;
  exception
    when PKG_COMMON.EXP_CHECK then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      return pkg_common.g_errcode_afw_overlap;
    when PKG_COMMON.EXP_EXECUTE then
      ErrMsg := pkg_common.g_errmsg_afw_upt_nodata;
      return pkg_common.g_errcode_afw_upt_nodata;
    when others then
      ErrMsg := 'Approval_Target_Pass: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE;
  end;
  /**
  功能：当前审批人审批驳回

  处理事项：
  1.修改当前审批人的审批状态;
  2.修改待办处理结果;
  3.总状态改为已驳回;
  4.发送消息给申请人
  **/
  function Approval_Target_Reject(WorkflowId      in varchar2,
                                  WorkflowType    in number,
                                  ApprovalUserId  in varchar2,
                                  ApprovalRemark  in varchar2,
                                  MsgSender_Cur   out sys_refcursor,
                                  TodoSender_Cur  out sys_refcursor,
                                  IsAll_MsgSender out number, --0是否，1是全部
                                  ErrMsg          out varchar2) return number as
    UnDone_Cnt number(2);
    WFStatus   number;
    errcode    number(6) := 0;
    v_approval_order  number;
    v_approval_model  number;
    v_iscompleted number;
    resultNum  number;
  begin
    IsAll_MsgSender := 0;
    if WorkflowType = 1 then
      pkg_ins_afw_userapply.GetLeaveAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 2 then
      pkg_ins_afw_userapply.GetEgressAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 3 then
      pkg_ins_afw_userapply.GetPublishAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 4 then
      pkg_ins_afw_userapply.GetEgressAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 5 then
      pkg_ins_afw_userapply.GetLoanAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 7 then
      pkg_ins_afw_userapply.GetExtensionAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 11 then
      pkg_ins_afw_userapply.GetPromotionAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 12 then
      pkg_ins_afw_userapply.GetAdjustpostAfwStatusById(WorkflowId,WFStatus);
    elsif WorkflowType = 16 then
      pkg_ins_afw_userapply.GetDMDAfwStatusById(WorkflowId,WFStatus,0);
    end if;

    if WFStatus <> 0 then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      raise PKG_COMMON.EXP_CHECK;
    end if;
    /*-----------------------------------------------
    借款流程
    如果是财务环节驳回，则流程回到财务第一个环节就是费用会计
    如果是出纳驳回的，那么费用会计审批后，直接到出纳
    如果不是出纳驳回的，那么按正常流程逐级审批

    -------------------------------------------------*/
    -- 需要获取到当前节点id,按目前的配置，order=3为财务:费用会计 order=7为财务：出纳
    select n_approval_order, n_approval_model
    into v_approval_order, v_approval_model
     from (    
    select n_approval_order, n_approval_model    
    from oa_afw_workflow_approval_flow a
   where c_workflow_id = WorkflowId
     and c_approval_user_id = ApprovalUserId
     and a.n_approval_status = 0
     order by n_approval_order
     ) where rownum = 1;

    -- n_approval_model 0 汇签时，一票否决
    CountersignReject(WorkflowId     => WorkflowId ,
                      WorkflowType   => WorkflowType,
                      ApprovalOrder  => v_approval_order,
                      ApprovalModel  => v_approval_model,
                      ApprovalUserId => ApprovalUserId,
                      IsCompleted    => v_iscompleted);

   if WorkflowType = 16  and ApprovalRemark is not null then

      resultNum := PKG_DMD_APPLY.INSER_OADMDCOMMENT(COMMEN      =>  ApprovalRemark||'^0',
                                  OperationUserID =>  ApprovalUserId,
                                  messageReceiverUserID => '',
                                  datamodify_comment_id => '',
                                  datamodify_apply_id => WorkflowId,
                                  TodoSender_Cur  => TodoSender_Cur,
                                  ErrMsg => ErrMsg);

   end if;
    --修改审批流对应记录状态 审批拒绝 0-->-1
    SetApprovalFlowStatus(WorkflowId, ApprovalUserId, ApprovalRemark, -1, v_approval_order);
    --经过与产品确认，无需修改其他人审批状态
    --SetAllApprovalFlowStatus(WorkflowId, '已有会签人拒绝,其他未会签默认拒绝', -1);
    --待办完成
    SetToDoStatus(WorkflowId, ApprovalUserId);
    --获取审批流未完结数量
    GetUnDoneApprovalCount(WorkflowId, UnDone_Cnt);

    WFStatus := 3; --已拒绝
    if WorkflowType = 5 and v_approval_order >=2 then
      null;
    else
      -- 存储拒绝邮件内容
      lcoa.PKG_INS_AFW_USERAPPLY.insert_email_info(WorkflowId,
                                                 ApprovalUserId,
                                                 3,
                                                 ErrMsg);
    end if;
    if WorkflowType = 1 then
      lcoa.pkg_ins_afw_userapply.SetLeaveAfwStatusById(WorkflowId,
                                                       WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateLeaveAfwMsgById(WorkflowId,
                                                       ApprovalUserId,
                                                       -1,
                                                       MsgSender_Cur);
    elsif WorkflowType = 2 then
      lcoa.pkg_ins_afw_userapply.SetEgressAfwStatusById(WorkflowId,
                                                        WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateEgressAfwMsgById(WorkflowId,
                                                        ApprovalUserId,
                                                        -1,
                                                        MsgSender_Cur);
    elsif WorkflowType = 3 then
      lcoa.pkg_ins_afw_userapply.SetPublishAfwStatusById(WorkflowId,
                                                         WFStatus);
      lcoa.pkg_ins_afw_userapply.CreatePublishAfwMsgById(WorkflowId,
                                                         ApprovalUserId,
                                                         -1,
                                                         1,
                                                         MsgSender_Cur,
                                                         IsAll_MsgSender);
    elsif WorkflowType = 4 then
      lcoa.pkg_ins_afw_userapply.SetExpensesAfwStatusById(WorkflowId,
                                                          WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateExpensesAfwMsgById(WorkflowId,
                                                          ApprovalUserId,
                                                          -1,
                                                          MsgSender_Cur);
    elsif WorkflowType = 5 then
        -- 设置状态
        lcoa.pkg_ins_afw_userapply.SetLoanAfwStatusById(WorkflowId,
                                                        WFStatus,
                                                        v_approval_order);
        -- 给申请人发消息
        lcoa.pkg_ins_afw_userapply.CreateLoanAfwMsgById(WorkflowId,
                                                        ApprovalUserId,
                                                        -1,
                                                        v_approval_order,
                                                        MsgSender_Cur);
        -- 设置新的待办 让财务：费用会计收到新的待办
        if v_approval_order > 2 then
          Create_Next_Approval_Todo(WorkflowId     => WorkflowId,
                                    TodoTitle      => '流程驳回',
                                    TodoSender_Cur => TodoSender_Cur);
        end if;
    elsif WorkflowType = 7 then

      lcoa.pkg_ins_afw_userapply.SetExtensionAfwStatusById(WorkflowId,
                                                          WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateExtensionAfwMsgById(WorkflowId,
                                                          ApprovalUserId,
                                                          -1,
                                                          MsgSender_Cur);

    elsif WorkflowType = 11 then
      lcoa.pkg_ins_afw_userapply.SetPromotionAfwStatusById(WorkflowId,
                                                           WFStatus);
      lcoa.pkg_ins_afw_userapply.CreatePromotionAfwMsgById(WorkflowId,
                                                           ApprovalUserId,
                                                           -1,
                                                           MsgSender_Cur);
    elsif WorkflowType = 12 then
      lcoa.pkg_ins_afw_userapply.SetAdjustpostAfwStatusById(WorkflowId,
                                                            WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateAdjustpostAfwMsgById(WorkflowId,
                                                            ApprovalUserId,
                                                            -1,
                                                            MsgSender_Cur);
      --驳回后，清除其他未审批人的待办记录
      RemoveInvalidToDoInfo(WorkflowId);

    elsif WorkflowType = 16 then
      lcoa.pkg_ins_afw_userapply.SetDMDAfwStatusById(WorkflowId,
                                                            WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateDMDAfwMsgById(WorkflowId,
                                                            ApprovalUserId,
                                                            -1,
                                                            MsgSender_Cur);
      --驳回后，清除其他未审批人的待办记录
      RemoveInvalidToDoInfo(WorkflowId);

    end if;
    return 0;
  exception
    when PKG_COMMON.EXP_CHECK then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      return pkg_common.g_errcode_afw_overlap;
    when PKG_COMMON.EXP_EXECUTE then
      ErrMsg := pkg_common.g_errmsg_afw_upt_nodata;
      return pkg_common.g_errcode_afw_upt_nodata;
    when others then
      ErrMsg := 'Approval_Target_Reject: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;

  /**
  功能：申请人撤回申请

  处理事项：
  1.判断当前申请是否可以撤回，如果可以则撤回;
  2.发送消息给申请人
  **/
  function Approval_Target_Cancel(WorkflowId      in varchar2,
                                  WorkflowType    in number,
                                  WorkflowUserId  in varchar2,
                                  ApprovalRemark  in varchar2,
                                  MsgSender_Cur   out sys_refcursor,
                                  TodoSender_Cur  out sys_refcursor,
                                  IsAll_MsgSender out number, --0是否，1是全部
                                  ErrMsg          out varchar2) return number as
    StartTime date;
    CurStatus number;
    WFStatus  number;
    n_status  number := 0;
    l_approval_status number;
  begin

    if WorkflowType = 1 then
      begin
        lcoa.pkg_ins_afw_userapply.GetLeaveAfwStatusById(WorkflowId,
                                                         WFStatus,
                                                         1);
      exception
        when PKG_COMMON.EXP_PARAM then
          n_status := 1;
      end;
      lcoa.pkg_ins_afw_userapply.SetLeaveAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreateLeaveAfwMsgById(WorkflowId,
                                                       WorkflowUserId,
                                                       -2,
                                                       MsgSender_Cur);
    elsif WorkflowType = 2 then
      begin
        lcoa.pkg_ins_afw_userapply.GetEgressAfwStatusById(WorkflowId,
                                                          WFStatus,
                                                          1);
      exception
        when PKG_COMMON.EXP_PARAM then
          n_status := 1;
      end;
      lcoa.pkg_ins_afw_userapply.SetEgressAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreateEgressAfwMsgById(WorkflowId,
                                                        WorkflowUserId,
                                                        -2,
                                                        MsgSender_Cur);
    elsif WorkflowType = 3 then
      begin
        lcoa.pkg_ins_afw_userapply.GetPublishAfwStatusById(WorkflowId,
                                                           WFStatus,
                                                           1);
      exception
        when PKG_COMMON.EXP_PARAM then
          n_status := 1;
      end;
      delete from oa_msg_message_info where c_msg_src = WorkflowId; --颠倒一下顺序，为了下面判断 added by lihuawei at 2020-4-23
      lcoa.pkg_ins_afw_userapply.SetPublishAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreatePublishAfwMsgById(WorkflowId,
                                                         WorkflowUserId,
                                                         -2,
                                                         1,
                                                         MsgSender_Cur,
                                                         IsAll_MsgSender);
    elsif WorkflowType = 4 then

      lcoa.pkg_ins_afw_userapply.GetExpensesAfwStatusById(WorkflowId,
                                                          WFStatus,
                                                          1);
      lcoa.pkg_ins_afw_userapply.SetExpensesAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreateExpensesAfwMsgById(WorkflowId,
                                                          WorkflowUserId,
                                                          -2,
                                                          MsgSender_Cur);

    elsif WorkflowType = 5 then
      -- 已支付 不允许撤回

      lcoa.pkg_ins_afw_userapply.GetLoanAfwStatusById(WorkflowId,
                                                          WFStatus,
                                                          1);
      if WFStatus = 5 or WFStatus = -1 then
        raise PKG_COMMON.EXP_EXIT;
      end if;
      lcoa.pkg_ins_afw_userapply.SetLoanAfwStatusById(WorkflowId, -1,0);
      /*
      lcoa.pkg_ins_afw_userapply.CreateLoanAfwMsgById(WorkflowId,
                                                          WorkflowUserId,
                                                          -2,
                                                          0,
                                                          MsgSender_Cur);
                                                          */


    elsif WorkflowType = 7 then
      lcoa.pkg_ins_afw_userapply.GetExtensionAfwStatusById(WorkflowId,
                                                           WFStatus,
                                                           1);
      lcoa.pkg_ins_afw_userapply.SetExtensionAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreateExtensionAfwMsgById(WorkflowId,
                                                           WorkflowUserId,
                                                           -2,
                                                           MsgSender_Cur);
    elsif WorkflowType = 11 then
      lcoa.pkg_ins_afw_userapply.GetPromotionAfwStatusById(WorkflowId,
                                                           WFStatus,
                                                           1);
      lcoa.pkg_ins_afw_userapply.SetPromotionAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreatePromotionAfwMsgById(WorkflowId,
                                                           WorkflowUserId,
                                                           -2,
                                                           MsgSender_Cur);
    elsif WorkflowType = 12 then
      lcoa.pkg_ins_afw_userapply.GetAdjustpostAfwStatusById(WorkflowId,
                                                            WFStatus,
                                                            1);
      lcoa.pkg_ins_afw_userapply.SetAdjustpostAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreateAdjustpostAfwMsgById(WorkflowId,
                                                            WorkflowUserId,
                                                            -2,
                                                            MsgSender_Cur);
    elsif WorkflowType = 16 then
      lcoa.pkg_ins_afw_userapply.GetDMDAfwStatusById(WorkflowId,
                                                            WFStatus,
                                                            1);
      lcoa.pkg_ins_afw_userapply.SetDMDAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreateDMDAfwMsgById(WorkflowId,
                                                            WorkflowUserId,
                                                            -2,
                                                            MsgSender_Cur);

    end if;
    if n_status <> 1 and WorkflowType <> 5 then

      -- 存储撤回邮件内容
      lcoa.PKG_INS_AFW_USERAPPLY.insert_email_info(WorkflowId,
                                                   WorkflowUserId,
                                                   4,
                                                   ErrMsg);
    end if;
    RemoveInvalidToDoInfo(WorkflowId);
    /*update oa_afw_workflow_approval_flow x 
      set x.n_approval_status = -2
      where x.n_workflow_type = WorkflowType
      and x.c_workflow_id = WorkflowId
      and x.n_approval_status = 0;*/
      
    return 0;
  exception
    when PKG_COMMON.EXP_CHECK then
      return pkg_common.g_errcode_afw_overlap;
    when NO_DATA_FOUND then
      ErrMsg := pkg_common.g_errmsg_afw_nodata;
      return pkg_common.g_errcode_afw_nodata;
    when PKG_COMMON.EXP_EXIT then
      RAISE_APPLICATION_ERROR('-20001', '已支付，不可撤销！', false);
    when others then
      ErrMsg := 'Approval_Target_Cancel: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;
  /**
  功能：当前审批人审批通过

  处理事项：
  1.修改当前审批人的审批状态;
  2.修改待办处理结果;
  3.检查工作流状态，如果审批完成，修改总状态为审批完成并发消息给申请人；否则，给下一个审批人生成待办。
  **/
  function Approval_Target_Delay(WorkflowId      in varchar2,
                                 WorkflowType    in number,
                                 ApprovalUserId  in varchar2,
                                 ApprovalRemark  in varchar2,
                                 MsgSender_Cur   out sys_refcursor,
                                 TodoSender_Cur  out sys_refcursor,
                                 IsAll_MsgSender out number, --0是否，1是全部
                                 ErrMsg          out varchar2) return number as
    UnDone_Cnt number(2);
    TodoTitle  varchar2(20);
    WFStatus   number;
    errcode    number(6) := 0;
    v_approval_model number;
    v_approval_order number;
  begin
    IsAll_MsgSender := 0;
    select n_approval_order, n_approval_model
      into v_approval_order, v_approval_model
      from oa_afw_workflow_approval_flow
     where c_workflow_id = WorkflowId
       and c_approval_user_id = ApprovalUserId;
    if WorkflowType = 11 then
      pkg_ins_afw_userapply.GetPromotionAfwStatusById(WorkflowId, WFStatus);
    else
      --只有转正类型有延期功能
      raise Pkg_Common.EXP_PARAM;
    end if;

    if WFStatus <> 0 then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      raise PKG_COMMON.EXP_CHECK;
    end if;
    --修改审批流对应记录状态 审批延期 0-->2
    SetApprovalFlowStatus(WorkflowId, ApprovalUserId, ApprovalRemark, 2, v_approval_order);
    --待办完成
    SetToDoStatus(WorkflowId, ApprovalUserId);
    --获取审批流未完结数量
    GetUnDoneApprovalCount(WorkflowId, UnDone_Cnt);
    if (UnDone_Cnt = 0) then
      WFStatus := 4; --最后一个延期为准
    else
      WFStatus := 1; --审批中
    end if;
    if WorkflowType = 11 then
      lcoa.pkg_ins_afw_userapply.SetPromotionAfwStatusById(WorkflowId,
                                                           WFStatus);
      lcoa.pkg_ins_afw_userapply.CreatePromotionAfwMsgById(WorkflowId,
                                                           ApprovalUserId,
                                                           2,
                                                           MsgSender_Cur);
      -- 存储延期邮件内容
      lcoa.PKG_INS_AFW_USERAPPLY.insert_email_info(WorkflowId,
                                                   ApprovalUserId,
                                                   5,
                                                   ErrMsg);
      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormPromotionTodoTitleById(WorkflowId,
                                                              TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;
    end if;
    return errcode;
  exception
    when PKG_COMMON.EXP_CHECK then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      return pkg_common.g_errcode_afw_overlap;
    when PKG_COMMON.EXP_EXECUTE then
      ErrMsg := pkg_common.g_errmsg_afw_upt_nodata;
      return pkg_common.g_errcode_afw_upt_nodata;
    when others then
      ErrMsg := 'Approval_Target_Pass: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE;
  end;
  function Approval_Target_Skip(WorkflowId     in varchar2,
                                WorkflowType   in number,
                                ApprovalUserId in varchar2,
                                ApprovalRemark in varchar2,
                                ErrMsg         out varchar2) return number is
  begin
    update oa_afw_workflow_approval_flow t
       set t.n_skip_flag = 1
     where t.c_workflow_id = WorkflowId
       and t.c_approval_user_id = ApprovalUserId
       and t.n_approval_status = 0;
    if SQL%ROWCOUNT = 0 then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      raise PKG_COMMON.EXP_CHECK;
    end if;
    commit;
    return 0;
  exception
    when PKG_COMMON.EXP_CHECK then
      return pkg_common.g_errcode_afw_overlap;
    when others then
      ErrMsg := 'Approval_Target_Skip: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;

  function Approval_Target_ResetSkip(ApprovalUserId in varchar2,
                                     ErrMsg         out varchar2)
    return number is
  begin
    update oa_afw_workflow_approval_flow t
       set t.n_skip_flag = 0
     where t.c_approval_user_id = ApprovalUserId
          --and t.n_approval_status = 0
       and t.n_skip_flag = 1;
    --    if SQL%ROWCOUNT = 0 then
    --      ErrMsg := pkg_common.g_errmsg_afw_overlap;
    --      raise PKG_COMMON.EXP_CHECK;
    --    end if;
    commit;
    return 0;
  exception
    when PKG_COMMON.EXP_CHECK then
      return pkg_common.g_errcode_afw_overlap;
    when others then
      ErrMsg := 'Approval_Target_Skip: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;
  --此块进行变量初始化，可删除
begin
  -- Initialization
  i := 1;
end PKG_INS_AFW_WORKFLOW;

/

