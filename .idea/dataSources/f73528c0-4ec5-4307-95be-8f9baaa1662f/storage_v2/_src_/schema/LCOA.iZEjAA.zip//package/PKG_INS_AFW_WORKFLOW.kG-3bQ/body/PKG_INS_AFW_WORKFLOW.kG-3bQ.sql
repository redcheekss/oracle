create package body PKG_INS_AFW_WORKFLOW is

  -- Private type declarations
  --type <TypeName> is <Datatype>;

  -- Private constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Private variable declarations
  --<VariableName> <Datatype>;
  i number(1);

  function Create_Part_Approval_Userlist(ROW_CONF       in oa_afw_workflow_config%rowtype,
                                         WorkflowId     in varchar2,
                                         WorkflowUserId in varchar2,
                                         OrganizationId in varchar2,
                                         LST            out T_FLOW)
    return number is
    cur_org_owner     sys_refcursor;
    flowusercount     number(1) := 0;
    SuperiorUserId    char(32);
    SuperiorUserName  varchar2(20);
    SuperiorUserTitle varchar2(20);
    VPUserId          char(32);
    VPUserName        varchar2(20);
    VPUserTitle       varchar2(20);
    nApprovalOrder    number(2) := 0;
  begin
    if ROW_CONF.N_APPROVAL_USER_TYPE = 1 then
      --直接上级
      --Added By Lihuawei At 2020.5.3
      --直接上级
      --判断是否为主管副总或CEO申请
      if (lcoa.pkg_ins_user_info.IsCEOByUserId(WorkflowUserId,
                                               VPUserId,
                                               VPUserName,
                                               VPUserTitle) = 1) or
         (lcoa.pkg_ins_user_info.IsVPUserByUserId(WorkflowUserId,
                                                  VPUserId,
                                                  VPUserName,
                                                  VPUserTitle) = 1) then
        open cur_org_owner for
          select lower(sys_guid()),
                 ROW_CONF.N_WORKFLOW_TYPE,
                 WorkflowId,
                 0,
                 ROW_CONF.N_APPROVAL_MODEL,
                 VPUserId,
                 VPUserName,
                 VPUserTitle,
                 0,
                 null,
                 null,
                 0
            from dual;
        fetch cur_org_owner
          into LST(0);
        if cur_org_owner%found then
          LST(1) := LST(0);
          flowusercount := 1;
        end if;
        close cur_org_owner;
        --二级部门负责人找VP
      elsif (lcoa.pkg_ins_user_info.IsLv2OwnerByUserId(WorkflowUserId,
                                                       SuperiorUserId,
                                                       SuperiorUserName,
                                                       SuperiorUserTitle) = 1) then
        with all_g as
         (select *
            from lcbase.t_organization g
          connect by prior g.c_organization_parent_id = g.c_organization_id
           start with g.c_organization_id = OrganizationId)
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               w.c_user_id,
               w.v_user_name,
               '主管副总',
               0,
               null,
               null,
               0
          into LST(1)
          from all_g g
          left join lcbase.t_user w
            on w.c_user_id = g.c_organization_vp
         where g.n_organization_level = 2;
        flowusercount := 1;
      else
        open cur_org_owner for
          with all_g as
           (select *
              from lcbase.t_organization g
            connect by prior g.c_organization_parent_id = g.c_organization_id
             start with g.c_organization_id = OrganizationId)
          select lower(sys_guid()),
                 ROW_CONF.N_WORKFLOW_TYPE,
                 WorkflowId,
                 0,
                 ROW_CONF.N_APPROVAL_MODEL,
                 w.c_user_id,
                 w.v_user_name,
                 '直接上级',
                 0,
                 null,
                 null,
                 0
            from all_g g
            left join lcbase.t_user w
              on w.c_user_id = g.c_organization_owner
           where g.n_organization_level >= 2
             and g.c_organization_owner <> WorkflowUserId
             and rownum = 1;
        fetch cur_org_owner
          into LST(0);
        if cur_org_owner%found then
          LST(1) := LST(0);
          flowusercount := 1;
        end if;
        close cur_org_owner;
      end if;
    elsif ROW_CONF.N_APPROVAL_USER_TYPE = 2 then
      flowusercount := 0;
      open cur_org_owner for
        with all_g as
         (select *
            from lcbase.t_organization g
          connect by prior g.c_organization_parent_id = g.c_organization_id
           start with g.c_organization_id = OrganizationId)
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               w.c_user_id,
               w.v_user_name,
               case
                 when g.n_organization_level = 1 then
                  '主管副总'
                 else
                  '上级'
               end,
               0,
               null,
               null,
               0
          from all_g g
          left join lcbase.t_user w
            on w.c_user_id = g.c_organization_owner
         where nvl(g.n_organization_level, 5) > 0;
      fetch cur_org_owner
        into LST(0);
      while cur_org_owner%found loop
        flowusercount := flowusercount + 1;
        LST(flowusercount) := LST(0);
        fetch cur_org_owner
          into LST(0);
      end loop;
      close cur_org_owner;
    
    elsif ROW_CONF.N_APPROVAL_USER_TYPE = 3 then
      if (lcoa.pkg_ins_user_info.IsCEOByUserId(WorkflowUserId,
                                               VPUserId,
                                               VPUserName,
                                               VPUserTitle) = 0) then
        with all_g as
         (select *
            from lcbase.t_organization g
          connect by prior g.c_organization_parent_id = g.c_organization_id
           start with g.c_organization_id = OrganizationId)
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               w.c_user_id,
               w.v_user_name,
               '主管副总',
               0,
               null,
               null,
               0
          into LST(1)
          from all_g g
          left join lcbase.t_user w
            on w.c_user_id = g.c_organization_vp
         where g.n_organization_level = 2;else
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               VPUserId,
               VPUserName,
               VPUserTitle,
               0,
               null,
               null,
               0
          into LST(1)
          from dual;
      end if;
      flowusercount := 1;
    elsif ROW_CONF.N_APPROVAL_USER_TYPE = 4 then
      open cur_org_owner for
        with all_g as
         (select *
            from lcbase.t_organization g
          connect by prior g.c_organization_parent_id = g.c_organization_id
           start with g.c_organization_id = OrganizationId)
        select lower(sys_guid()),
               ROW_CONF.N_WORKFLOW_TYPE,
               WorkflowId,
               0,
               ROW_CONF.N_APPROVAL_MODEL,
               w.c_user_id,
               w.v_user_name,
               '最近BP',
               0,
               null,
               null,
               0
          into LST(1)
          from all_g g
          left join lcbase.t_user w
            on w.c_user_id = g.c_organization_bp
         where g.c_organization_bp is not null;
      fetch cur_org_owner
        into LST(0);
      if cur_org_owner%found then
        LST(1) := LST(0);
        flowusercount := 1;
      end if;
      close cur_org_owner;
    else
      select lower(sys_guid()),
             ROW_CONF.N_WORKFLOW_TYPE,
             WorkflowId,
             0,
             ROW_CONF.N_APPROVAL_MODEL,
             u.v_approval_user_id,
             u.v_approval_user_name,
             u.v_approval_user_title,
             0,
             null,
             null,
             0
        into LST(1)
        from oa_afw_workflow_user_type u
       where u.n_approval_user_type = ROW_CONF.N_APPROVAL_USER_TYPE;
      flowusercount := 1;
    
    end if;
    return flowusercount;
  end;

  procedure Create_Approval_By_Id(WorkflowId   in varchar2,
                                  WorkflowType in number) is
    WorkflowUserId     char(32);
    Old_OrganizationId char(32);
    New_OrganizationId char(32);
    DaysCount          number(5, 1);
    RangeType          number(1);
  begin
    --首先要清除 该业务Id对应的无效审批流信息？
    delete from oa_afw_workflow_approval_flow t
     where t.c_workflow_id = WorkflowId
       and t.n_approval_status in (0, 9);
    --以下逻辑应该在调用时传入即可，无需单独再获取一次   
    case
      when WorkflowType = 1 then
        select t.n_leave_days, t.c_leave_user_id
          into DaysCount, WorkflowUserId
          from oa_afw_leave_info t
         where t.c_leave_id = WorkflowId;
      when WorkflowType = 2 then
        select t.n_egress_days, t.c_egress_user_id
          into DaysCount, WorkflowUserId
          from oa_afw_egress_info t
         where t.c_egress_id = WorkflowId;
      when WorkflowType = 3 then
        select t.c_input_user_id, t.n_news_range
          into WorkflowUserId, RangeType
          from oa_msg_publish_info t
         where t.c_news_id = WorkflowId;
      
      when WorkflowType = 4 then
        select t.c_expenses_user_id
          into WorkflowUserId
          from oa_eps_expenses_info t
         where t.c_expenses_id = WorkflowId;
      when WorkflowType = 11 then
        select t.c_promotion_user_id
          into WorkflowUserId
          from lcoa.oa_afw_promotion_info t
         where t.c_promotion_id = WorkflowId;
      
      when WorkflowType = 12 then
        select t.c_adjust_user_id, t.c_new_orgnization_id
          into WorkflowUserId, New_OrganizationId
          from lcoa.oa_afw_adjustpost_info t
         where t.c_adjust_id = WorkflowId;
        /*        select 'Old_OrganizationId', 'New_OrganizationId'
        into Old_OrganizationId, New_OrganizationId
        from dual; --待实现*/
      else
        DaysCount := 0;
    end case;
    select c_organization_id
      into Old_OrganizationId
      from lcbase.t_user
     where c_user_id = WorkflowUserId;
    /*    CreateLeaveFullWorkflow(WorkflowId,
    WorkflowType,
    WorkflowUserId,
    DaysCount);*/
    Create_All_Approval_Userlist(WorkflowId,
                                 WorkflowUserId,
                                 WorkflowType,
                                 RangeType,
                                 DaysCount,
                                 Old_OrganizationId,
                                 New_OrganizationId);
  end;

  procedure Create_All_Approval_Userlist(WorkflowId         in varchar2,
                                         WorkflowUserId     in varchar2,
                                         WorkflowType       in number,
                                         RangeType          in number,
                                         DaysCount          in number,
                                         Old_OrganizationId in varchar2,
                                         New_OrganizationId in varchar2) is
    CUR_CONF sys_refcursor;
    ROW_CONF oa_afw_workflow_config%rowtype;
    P_LST    T_FLOW;
    P_STEP   number(1);
    P_NUM    number(1);
    P_ALL    number(1);
    P_EXIST  number(1);
  begin
    P_ALL  := 0;
    P_STEP := 0;
    open CUR_CONF for
      select *
        from oa_afw_workflow_config
       where n_workflow_type = WorkflowType
       order by n_approval_order;
    fetch CUR_CONF
      into ROW_CONF;
    while CUR_CONF%found loop
      P_NUM := Create_Part_Approval_Userlist(ROW_CONF,
                                             WorkflowId,
                                             WorkflowUserId,
                                             case
                                               when WorkflowType = 12 and P_ALL >= 2 then
                                                New_OrganizationId
                                               else
                                                Old_OrganizationId
                                             end,
                                             P_LST);
      if P_NUM = 0 then
        raise pkg_common.EXP_NOLEADER;
      end if;
      for I in 1 .. P_NUM loop
        select count(1)
          into P_EXIST
          from oa_afw_workflow_approval_flow t
         where t.c_workflow_id = WorkflowId
           and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        if P_EXIST = 0 then
          insert into oa_afw_workflow_approval_flow
            (c_data_id,
             n_workflow_type,
             c_workflow_id,
             n_approval_order,
             n_approval_model,
             c_approval_user_id,
             v_approval_user_name,
             v_approval_user_title,
             n_approval_status)
          values
            (P_LST(I).c_data_id,
             P_LST(I).n_workflow_type,
             P_LST(I).c_workflow_id,
             P_ALL + I, --P_LST(I).n_approval_order,
             P_LST(I).n_approval_model,
             P_LST(I).c_approval_user_id,
             P_LST(I).v_approval_user_name,
             P_LST(I).v_approval_user_title,
             P_LST(I).n_approval_status);
        else
          update oa_afw_workflow_approval_flow t
             set t.v_approval_user_title = t.v_approval_user_title || ',' || P_LST(I)
                                          .v_approval_user_title
           where t.c_workflow_id = WorkflowId
             and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        end if;
      end loop;
      P_STEP := P_STEP + 1;
      P_ALL  := P_ALL + P_NUM;
      if WorkflowType in (1, 2) and DaysCount < 3 and P_ALL > 0 then
        exit;
      end if;
      if WorkflowType = 3 and RangeType <> 2 and P_STEP = 2 and P_ALL > 0 then
        exit;
      end if;
      fetch CUR_CONF
        into ROW_CONF;
    end loop;
    close CUR_CONF;
    commit;
  end;

  procedure GetWorkflowConfByFlowType(WorkFlowType in number,
                                      CUR_CONF     out sys_refcursor) is
  begin
    open CUR_CONF for
      select *
        from lcoa.oa_afw_workflow_config
       where n_workflow_type = WorkflowType
       order by n_approval_order;
  end;
  procedure CreateLeaveFullWorkflow(WorkflowId     in varchar2,
                                    WorkflowType   in number,
                                    WorkflowUserId in varchar2,
                                    DaysCount      in number) is
    CUR_CONF          sys_refcursor;
    ROW_CONF          oa_afw_workflow_config%rowtype;
    ROW_FLOW          oa_afw_workflow_approval_flow%rowtype;
    SuperiorUserId    char(32);
    SuperiorUserName  varchar2(20);
    SuperiorUserTitle varchar2(20);
    VPUserId          char(32);
    VPUserName        varchar2(20);
    VPUserTitle       varchar2(20);
    nApprovalOrder    number(2) := 0;
  begin
    GetWorkflowConfByFlowType(WorkFlowType, CUR_CONF);
    fetch CUR_CONF
      into ROW_CONF;
    while CUR_CONF%found loop
    
      if ROW_CONF.N_APPROVAL_USER_TYPE = 1 then
        --直接上级
        --Added By Lihuawei At 2020.5.3
        --直接上级
        --直接上级或主管副总，该步骤为空
      
        --判断是否为主管副总申请
        if (lcoa.pkg_ins_user_info.IsVPUserByUserId(WorkflowUserId,
                                                    VPUserId,
                                                    VPUserName,
                                                    VPUserTitle) = 0) then
          lcoa.pkg_ins_user_info.GetDirectSuperiorByUserId(WorkflowUserId,
                                                           SuperiorUserId,
                                                           SuperiorUserName,
                                                           SuperiorUserTitle);
          if SuperiorUserId is not null then
            ROW_FLOW.N_WORKFLOW_TYPE       := WorkFlowType;
            ROW_FLOW.C_WORKFLOW_ID         := WorkflowId;
            nApprovalOrder                 := nApprovalOrder + 1;
            ROW_FLOW.N_APPROVAL_ORDER      := nApprovalOrder;
            ROW_FLOW.N_APPROVAL_MODEL      := ROW_CONF.N_APPROVAL_MODEL;
            ROW_FLOW.C_APPROVAL_USER_ID    := SuperiorUserId;
            ROW_FLOW.V_APPROVAL_USER_NAME  := SuperiorUserName;
            ROW_FLOW.V_APPROVAL_USER_TITLE := SuperiorUserTitle;
            InsertApprovelWorkflow(ROW_FLOW);
          end if;
        end if;
      elsif ROW_CONF.n_Approval_User_Type = 3 then
        --主管副总
        --主管副总
        lcoa.pkg_ins_user_info.GetVPByUserId(WorkflowUserId,
                                             VPUserId,
                                             VPUserName,
                                             VPUserTitle);
        if VPUserId is not null then
          ROW_FLOW.N_WORKFLOW_TYPE       := WorkFlowType;
          ROW_FLOW.C_WORKFLOW_ID         := WorkflowId;
          nApprovalOrder                 := nApprovalOrder + 1;
          ROW_FLOW.N_APPROVAL_ORDER      := nApprovalOrder;
          ROW_FLOW.N_APPROVAL_MODEL      := ROW_CONF.N_APPROVAL_MODEL;
          ROW_FLOW.C_APPROVAL_USER_ID    := VPUserId;
          ROW_FLOW.V_APPROVAL_USER_NAME  := VPUserName;
          ROW_FLOW.V_APPROVAL_USER_TITLE := VPUserTitle;
          InsertApprovelWorkflow(ROW_FLOW);
        end if;
      end if;
      --请假和外出3天以内一级审批即可，否则需要主管副总审批
      --因二级部门负责人直接上级为主管副总，所以该判断逻辑在循环中，以区分一级审批还是二级审批
      if WorkflowType in (1, 2) and DaysCount < 3 and nApprovalOrder > 0 then
        exit;
      end if;
    
      fetch CUR_CONF
        into ROW_CONF;
    end loop;
  end;
  procedure InsertApprovelWorkflow(ROW_FLOW oa_afw_workflow_approval_flow%rowtype) is
  begin
    insert into oa_afw_workflow_approval_flow
      (c_data_id,
       n_workflow_type,
       c_workflow_id,
       n_approval_order,
       n_approval_model,
       c_approval_user_id,
       v_approval_user_name,
       v_approval_user_title,
       n_approval_status)
    values
      (lower(sys_guid()),
       ROW_FLOW.n_workflow_type,
       ROW_FLOW.c_workflow_id,
       ROW_FLOW.n_Approval_Order,
       ROW_FLOW.n_approval_model,
       ROW_FLOW.c_approval_user_id,
       ROW_FLOW.v_approval_user_name,
       ROW_FLOW.v_approval_user_title,
       0);
  end;

  procedure CreatePreApprovalUserList(WorkflowType    in number,
                                      WorkflowSubtype in number,
                                      WorkflowId      in varchar2,
                                      WorkflowUserId  in varchar2,
                                      OrganizationId  in varchar2,
                                      LST             out T_FLOW) is
    CUR_CONF  sys_refcursor;
    ROW_CONF  oa_afw_workflow_config%rowtype;
    ROW_FLOW  oa_afw_workflow_approval_temp%rowtype;
    P_LST     T_FLOW;
    P_STEP    number(1);
    P_NUM     number(1);
    P_ALL     number(1);
    P_EXIST   number(1);
    P_RETURN  number(1);
    DaysCount number(8, 4);
    StartTime Date;
    EndTime   Date;
  begin
    GetWorkflowConfByFlowType(WorkFlowType, CUR_CONF);
    fetch CUR_CONF
      into ROW_CONF;
    while CUR_CONF%found loop
      P_NUM := Create_Part_Approval_Userlist(ROW_CONF,
                                             WorkflowId,
                                             WorkflowUserId,
                                             OrganizationId,
                                             P_LST);
      for I in 1 .. P_NUM loop
        select count(1)
          into P_EXIST
          from oa_afw_workflow_approval_temp t
         where t.c_workflow_id = WorkflowId
           and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        if P_EXIST = 0 then
          ROW_FLOW.c_Data_Id             := P_LST(I).c_data_id;
          ROW_FLOW.N_WORKFLOW_TYPE       := P_LST(I).n_workflow_type;
          ROW_FLOW.C_WORKFLOW_ID         := P_LST(I).c_workflow_id;
          ROW_FLOW.N_APPROVAL_ORDER      := P_ALL + I;
          ROW_FLOW.N_APPROVAL_MODEL      := P_LST(I).n_approval_model;
          ROW_FLOW.C_APPROVAL_USER_ID    := P_LST(I).c_approval_user_id;
          ROW_FLOW.V_APPROVAL_USER_NAME  := P_LST(I).v_approval_user_name;
          ROW_FLOW.V_APPROVAL_USER_TITLE := P_LST(I).v_approval_user_title;
          ROW_FLOW.n_Approval_Status     := P_LST(I).n_approval_status;
          InsertApprovelWorkflowTmp(ROW_FLOW => ROW_FLOW);
        else
          update oa_afw_workflow_approval_temp t
             set t.v_approval_user_title = t.v_approval_user_title || ',' || P_LST(I)
                                          .v_approval_user_title
           where t.c_workflow_id = WorkflowId
             and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        end if;
      end loop;
      P_STEP := P_STEP + 1;
      P_ALL  := P_ALL + P_NUM;
      if WorkflowType in (1, 2) and DaysCount < 3 and P_ALL > 0 then
        exit;
      end if;
      if WorkflowType = 3 and WorkflowSubtype <> 2 and P_STEP = 2 and
         P_ALL > 0 then
        exit;
      end if;
      fetch CUR_CONF
        into ROW_CONF;
    end loop;
    close CUR_CONF;
    commit;
  end;
  procedure InsertApprovelWorkflowTmp(ROW_FLOW oa_afw_workflow_approval_temp%rowtype) is
  begin
    insert into oa_afw_workflow_approval_temp
      (c_data_id,
       n_workflow_type,
       c_workflow_id,
       n_approval_order,
       n_approval_model,
       c_approval_user_id,
       v_approval_user_name,
       v_approval_user_title,
       n_approval_status)
    values
      (ROW_FLOW.c_Data_Id,
       ROW_FLOW.n_workflow_type,
       ROW_FLOW.c_workflow_id,
       ROW_FLOW.n_Approval_Order,
       ROW_FLOW.n_approval_model,
       ROW_FLOW.c_approval_user_id,
       ROW_FLOW.v_approval_user_name,
       ROW_FLOW.v_approval_user_title,
       0);
  end;

  function Get_Pre_Approval_Userlist(WorkflowUserId     in varchar2,
                                     WorkflowType       in number,
                                     WorkflowSubtype    in number,
                                     DStartTime         in varchar2,
                                     DEndTime           in varchar2,
                                     New_OrganizationId in varchar2,
                                     Days               out number,
                                     Hours              out number,
                                     CUR_DATA           out sys_refcursor,
                                     ErrMsg             out varchar2)
    return number is
    CUR_CONF       sys_refcursor;
    ROW_CONF       oa_afw_workflow_config%rowtype;
    P_LST          T_FLOW;
    WorkflowId     char(32);
    OrganizationId char(32);
    P_STEP         number(1);
    P_NUM          number(1);
    P_ALL          number(1);
    P_EXIST        number(1);
    P_RETURN       number(1);
    DaysCount      number(8, 4);
    StartTime      Date;
    EndTime        Date;
  begin
    P_ALL      := 0;
    P_STEP     := 0;
    WorkflowId := lower(sys_guid());
    select u.c_organization_id
      into OrganizationId
      from lcbase.t_user u
     where u.c_user_id = WorkflowUserId;
  
    if WorkflowType in (1, 2) then
      StartTime := to_date(DStartTime, 'yyyymmddhh24miss');
      EndTime   := to_date(DEndTime, 'yyyymmddhh24miss');
      if WorkflowType = 1 and WorkflowSubtype in (1, 2, 3) then
        P_RETURN := lcoa.PKG_USER_RESTTIME.getHolidayDuration(WorkflowUserId,
                                                              StartTime,
                                                              EndTime,
                                                              Days,
                                                              Hours,
                                                              ErrMsg);
        if P_RETURN <> 0 then
          return P_RETURN;
        end if;
        DaysCount := Days + Hours / 7; --added by lihuawei at 2020/5/8 此处应该统一为7小时为1个工作日；不考虑周六工时少的情况。
      elsif WorkflowType = 2 and WorkflowSubtype = 1 then
        --GetTotalDays(StartTime, EndTime, Days, Hours);
        Hours     := round((trunc(EndTime, 'hh24') -
                           trunc(StartTime, 'hh24')) * 24,
                           0);
        Days      := 0;
        DaysCount := 1;
      else
        Days      := trunc(EndTime, 'dd') - trunc(StartTime, 'dd') + 1;
        Hours     := 0;
        DaysCount := Days;
      end if;
    end if;
  
    open CUR_CONF for
      select *
        from oa_afw_workflow_config
       where n_workflow_type = WorkflowType
       order by n_approval_order;
    fetch CUR_CONF
      into ROW_CONF;
    while CUR_CONF%found loop
      P_NUM := Create_Part_Approval_Userlist(ROW_CONF,
                                             WorkflowId,
                                             WorkflowUserId,
                                             case
                                               when WorkflowType = 12 and P_ALL >= 2 then
                                                New_OrganizationId
                                               else
                                                OrganizationId
                                             end,
                                             P_LST);
      if P_NUM = 0 then
        raise pkg_common.EXP_NOLEADER;
      end if;
      for I in 1 .. P_NUM loop
        select count(1)
          into P_EXIST
          from oa_afw_workflow_approval_temp t
         where t.c_workflow_id = WorkflowId
           and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        if P_EXIST = 0 then
          insert into oa_afw_workflow_approval_temp
            (c_data_id,
             n_workflow_type,
             c_workflow_id,
             n_approval_order,
             n_approval_model,
             c_approval_user_id,
             v_approval_user_name,
             v_approval_user_title,
             n_approval_status)
          values
            (P_LST(I).c_data_id,
             P_LST(I).n_workflow_type,
             P_LST(I).c_workflow_id,
             P_ALL + I, --P_LST(I).n_approval_order,
             P_LST(I).n_approval_model,
             P_LST(I).c_approval_user_id,
             P_LST(I).v_approval_user_name,
             P_LST(I).v_approval_user_title,
             P_LST(I).n_approval_status);
        else
          update oa_afw_workflow_approval_temp t
             set t.v_approval_user_title = t.v_approval_user_title || ',' || P_LST(I)
                                          .v_approval_user_title
           where t.c_workflow_id = WorkflowId
             and t.c_approval_user_id = P_LST(I).c_approval_user_id;
        end if;
      end loop;
      P_STEP := P_STEP + 1;
      P_ALL  := P_ALL + P_NUM;
      if WorkflowType in (1, 2) and DaysCount < 3 and P_ALL > 0 then
        exit;
      end if;
      if WorkflowType = 3 and WorkflowSubtype <> 2 and P_STEP = 2 and
         P_ALL > 0 then
        exit;
      end if;
      fetch CUR_CONF
        into ROW_CONF;
    end loop;
    close CUR_CONF;
    commit;
    open CUR_DATA for
      select f.c_data_id,
             f.n_workflow_type,
             f.c_workflow_id,
             f.n_approval_order,
             f.n_approval_model,
             f.c_approval_user_id,
             f.v_approval_user_name,
             f.v_approval_user_title,
             f.n_approval_status,
             f.d_approval_time,
             f.v_approval_remark,
             tu.v_headpic_aly
        from oa_afw_workflow_approval_temp f
        LEFT JOIN LCBASE.T_USER tu
          ON f.C_APPROVAL_USER_ID = tu.C_USER_ID
       where f.c_workflow_id = WorkflowId
       order by f.n_approval_order;
    return 0;
  end;

  /**
  功能：申请人撤回申请
  
  处理事项：  
  1.判断当前申请是否可以撤回，如果可以则撤回;
  2.发送消息给申请人
  **/
  function Approval_Target_Delay(WorkflowId     in varchar2,
                                 WorkflowType   in number,
                                 WorkflowUserId in varchar2,
                                 ApprovalRemark in varchar2,
                                 ErrMsg         out varchar2) return number as
    StartTime date;
    CurStatus number;
  begin
  
    if WorkflowType = 11 then
      update lcoa.oa_afw_promotion_info t
         set t.n_status = 4
       where t.c_promotion_id = WorkflowId
         and t.c_promotion_user_id = WorkflowUserId;
    end if;
    if SQL%ROWCOUNT = 1 then
      delete from oa_tdo_todo_info t
       where t.n_status = 0
         and t.c_todo_data_id in
             (select f.c_data_id
                from lcoa.oa_afw_workflow_approval_flow f
               where f.c_workflow_id = WorkflowId);
      Send_Workflow_Approval_Message(WorkflowId,
                                     WorkflowUserId,
                                     WorkflowType,
                                     2);
      commit;
      return 0;
    else
      RAISE_APPLICATION_ERROR(-20001, '转正延期失败', false);
    end if;
  exception
    when PKG_COMMON.EXP_CHECK then
      return pkg_common.g_errcode_afw_overlap;
    when NO_DATA_FOUND then
      ErrMsg := pkg_common.g_errmsg_afw_nodata;
      return pkg_common.g_errcode_afw_nodata;
    when others then
      ErrMsg := 'Approval_Target_Cancel: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;
  procedure Send_Workflow_Approval_Message(WorkflowId     in varchar2,
                                           ApprovalUserId in varchar2,
                                           WorkflowType   in number,
                                           ApprovalResult in number) is
    errmsg           varchar2(2000);
    P_ApprovalResult varchar2(40);
    approvalusername varchar2(20);
    P_RANGE          number(1);
  begin
    select u.v_user_name
      into approvalusername
      from lcbase.t_user u
     where u.c_user_id = ApprovalUserId;
    P_ApprovalResult := case
                          when ApprovalResult in (1, 2) then
                           approvalusername || '已经通过你的'
                          when ApprovalResult = -1 then
                           approvalusername || '已驳回你的'
                          when ApprovalResult = -2 then
                           approvalusername || '已撤回了'
                          else
                           '正在处理你的审批申请'
                        end;
    if WorkflowType = 1 then
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult || '请假申请',
               sysdate,
               0,
               t.c_leave_user_id,
               WorkflowId,
               u.v_user_name || '的' ||
               decode(t.n_leave_type,
                      1,
                      '事假',
                      2,
                      '病假',
                      3,
                      '调休',
                      4,
                      '年假',
                      5,
                      '产假',
                      6,
                      '哺乳假',
                      7,
                      '婚假',
                      8,
                      '丧假',
                      9,
                      '陪产假',
                      10,
                      '产检假',
                      '其它请假') || case
                 when t.n_leave_days > 0 then
                  t.n_leave_days || '天'
                 else
                  null
               end || case
                 when t.n_leave_hours > 0 then
                  t.n_leave_hours || '小时'
                 else
                  null
               end || '【' ||
               to_char(t.d_leave_start_time, 'yyyy-MM-dd HH24:mi am') || '至' ||
               to_char(t.d_leave_end_time, 'yyyy-MM-dd HH24:mi am') || '】',
               '系统',
               sysdate,
               1
          from oa_afw_leave_info t
          left join lcbase.t_user u
            on u.c_user_id = t.c_leave_user_id
         where t.c_leave_id = WorkflowId;
    
    elsif WorkflowType = 2 then
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult || '外出申请',
               sysdate,
               0,
               t.c_egress_user_id,
               WorkflowId,
               u.v_user_name || '的' ||
                decode(t.n_egress_type, 1, '市内外出', 2, '出差', '其它外出') || case
                  when t.n_egress_days > 0 then
                   t.n_egress_days || '天'
                  else
                   null
                end || case
                  when t.n_egress_hours > 0 then
                   t.n_egress_hours || '小时'
                  else
                   null
                end
               --to_char(t.n_egress_days, '90D90') 
                || '【' ||
                to_char(t.d_egress_start_time, 'yyyy-MM-dd HH24:mi am') || '至' ||
                to_char(t.d_egress_end_time, 'yyyy-MM-dd HH24:mi am') || '】',
               '系统',
               sysdate,
               1
          from oa_afw_egress_info t
          left join lcbase.t_user u
            on u.c_user_id = t.c_egress_user_id
         where t.c_egress_id = WorkflowId;
    elsif WorkflowType = 3 then
    
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult || '【' || t.v_news_title || '】公告',
               sysdate,
               0,
               t.c_input_user_id,
               WorkflowId,
               t.v_input_user_name || '发布的公告',
               '系统',
               sysdate,
               1
          from lcoa.oa_msg_publish_info t
         where t.c_news_id = WorkflowId;
      IF ApprovalResult = 2 THEN
        select t.n_news_range
          into P_RANGE
          from lcoa.oa_msg_publish_info t
         where t.c_news_id = WorkflowId;
      
        if P_RANGE = 1 then
          insert into oa_msg_message_info
            (c_msg_id,
             n_msg_type,
             n_istop_flag,
             v_msg_title,
             d_msg_time,
             n_read_flag,
             c_msg_user_id,
             c_msg_src,
             --v_msg_content,
             v_msg_sender,
             d_update_time,
             n_enable)
            select lower(sys_guid()),
                   51,
                   t.n_istop_flag,
                   t.v_news_title,
                   sysdate,
                   0,
                   c_user_id,
                   WorkflowId,
                   --t.v_news_content,
                   t.v_signature_name,
                   sysdate,
                   1
              from (select u.c_user_id
                      from LCBASE.t_User u
                     where u.n_status = 0
                       and u.c_organization_id in
                           (select g.c_organization_id
                              from LCBASE.t_organization g
                            connect by prior g.c_organization_id =
                                        g.c_organization_parent_id
                             start with g.c_organization_id in
                                        (select r.c_target_id
                                           from oa_msg_publish_range r
                                          where r.c_news_id = WorkflowId
                                            and r.n_target_type = 1))
                    union
                    select 'e6e0d38119eb47bea9be644ac003bd18'
                      from dual) mu
              left join oa_msg_publish_info t
                on t.c_news_id = WorkflowId;
        else
          insert into oa_msg_message_info
            (c_msg_id,
             n_msg_type,
             n_istop_flag,
             v_msg_title,
             d_msg_time,
             n_read_flag,
             c_msg_user_id,
             c_msg_src,
             --v_msg_content,
             v_msg_sender,
             d_update_time,
             n_enable)
            select lower(sys_guid()),
                   51,
                   t.n_istop_flag,
                   t.v_news_title,
                   sysdate,
                   0,
                   c_user_id,
                   WorkflowId,
                   --t.v_news_content,
                   t.v_signature_name,
                   sysdate,
                   1
              from (select u.c_user_id
                      from LCBASE.t_user u
                     where u.n_status = 0
                       and u.c_organization_id in
                           (select g.c_organization_id
                              from LCBASE.t_organization g
                            connect by prior g.c_organization_id =
                                        g.c_organization_parent_id
                             start with g.c_organization_id =
                                        '997c2b49b01d4bdba3c5ea4e0f615617')) mu
              left join oa_msg_publish_info t
                on t.c_news_id = WorkflowId;
        end if;
      END IF;
    elsif WorkflowType = 4 then
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult || '报销申请',
               sysdate,
               0,
               t.c_expenses_user_id,
               WorkflowId,
               t.v_expenses_user_name || '的报销',
               '系统',
               sysdate,
               1
          from oa_eps_expenses_info t
         where t.c_expenses_id = WorkflowId;
    elsif WorkflowType = 11 then
      insert into oa_msg_message_info
        (c_msg_id,
         n_msg_type,
         n_istop_flag,
         v_msg_title,
         d_msg_time,
         n_read_flag,
         c_msg_user_id,
         c_msg_src,
         v_msg_content,
         v_msg_sender,
         d_update_time,
         n_enable)
        select lower(sys_guid()),
               WorkflowType,
               0,
               P_ApprovalResult || '转正申请',
               sysdate,
               0,
               t.c_promotion_user_id,
               WorkflowId,
               u.v_pet_name || '的转正',
               '系统',
               sysdate,
               1
          from lcoa.oa_afw_promotion_info t
          left join lcbase.t_user u
            on u.c_user_id = t.c_promotion_user_id
         where t.c_promotion_id = WorkflowId;
    end if;
  exception
    when others then
      errmsg := 'Send_New_Message: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE;
  end;
  procedure Create_Next_Approval_Todo(WorkflowId     in varchar2,
                                      TodoTitle      in varchar2,
                                      TodoSender_Cur out sys_refcursor) is
    CUR_FLOW sys_refcursor;
    ROW_FLOW oa_afw_workflow_approval_flow%rowtype;
    FLG_MODE number(1);
    v_sql    varchar2(1000);
  begin
    FLG_MODE := -1;
    v_sql    := 'select null as userid from dual where 1<>1 ';
    open CUR_FLOW for
      select *
        from oa_afw_workflow_approval_flow t
       where t.c_workflow_id = WorkflowId
         and t.n_approval_status = 0
       order by t.n_approval_order;
    fetch CUR_FLOW
      into ROW_FLOW;
    while CUR_FLOW%found loop
      if (FLG_MODE = -1) or
         (FLG_MODE = 0 and ROW_FLOW.N_APPROVAL_MODEL = 0) then
        insert into oa_tdo_todo_info
          (c_todo_id,
           c_todo_user_id,
           d_todo_time,
           n_todo_type,
           v_todo_title,
           d_input_time,
           n_status,
           c_todo_data_id)
        values
          (lower(sys_guid()),
           ROW_FLOW.C_APPROVAL_USER_ID,
           sysdate,
           ROW_FLOW.N_WORKFLOW_TYPE,
           TodoTitle,
           sysdate,
           0,
           ROW_FLOW.C_DATA_ID);
        FLG_MODE := ROW_FLOW.N_APPROVAL_MODEL;
        v_sql    := v_sql || ' union select ''' ||
                    ROW_FLOW.C_APPROVAL_USER_ID || ''' as userid from dual';
      else
        exit;
      end if;
      fetch CUR_FLOW
        into ROW_FLOW;
    end loop;
    open TodoSender_Cur for v_sql;
    close CUR_FLOW;
  end;
  --设置审批流状态
  procedure SetApprovalFlowStatus(WorkflowId     in varchar2,
                                  ApprovalUserId in varchar2,
                                  ApprovalRemark in varchar2,
                                  ApprovalStatus number) is
  begin
    update oa_afw_workflow_approval_flow t
       set t.n_approval_status = ApprovalStatus,
           t.d_approval_time   = sysdate,
           t.v_approval_remark = ApprovalRemark
     where t.c_workflow_id = WorkflowId
       and t.c_approval_user_id = ApprovalUserId
       and t.n_approval_status = 0;
    if SQL%ROWCOUNT <> 1 then
      raise PKG_COMMON.EXP_EXECUTE;
    end if;
  end;
  --一次设置所有审批流状态  
  procedure SetAllApprovalFlowStatus(WorkflowId     in varchar2,
                                     ApprovalRemark in varchar2,
                                     ApprovalStatus number) is
  begin
    update oa_afw_workflow_approval_flow t
       set t.n_approval_status = ApprovalStatus,
           t.d_approval_time   = sysdate,
           t.v_approval_remark = ApprovalRemark
     where t.c_workflow_id = WorkflowId
       and t.n_approval_status = 0;
    if SQL%ROWCOUNT = 0 then
      raise PKG_COMMON.EXP_EXECUTE;
    end if;
  end;
  --设置待办状态
  procedure SetToDoStatus(WorkflowId     in varchar2,
                          ApprovalUserId in varchar2) is
  begin
    update oa_tdo_todo_info t
       set t.n_status = 1, t.d_done_time = sysdate
     where t.c_todo_user_id = ApprovalUserId
       and t.c_todo_data_id in
           (select f.c_data_id
              from lcoa.oa_afw_workflow_approval_flow f
             where f.c_workflow_id = WorkflowId);
  end;
  procedure RemoveInvalidToDoInfo(WorkflowId in varchar2) is
  begin
    delete from oa_tdo_todo_info t
     where t.n_status = 0
       and t.c_todo_data_id in
           (select f.c_data_id
              from lcoa.oa_afw_workflow_approval_flow f
             where f.c_workflow_id = WorkflowId);
  end;
  --获取未完结审批流数量
  procedure GetUnDoneApprovalCount(WorkflowId in varchar2,
                                   UnDoneCnt  out number) is
  begin
    select sum(case
                 when t.n_approval_status in (1, 2) then --added by lihuawei 转正延期2也算是审批完结
                  0
                 else
                  1
               end)
      into UnDoneCnt
      from oa_afw_workflow_approval_flow t
     where t.c_workflow_id = WorkflowId;
  end;
  /**
  功能：当前审批人审批通过
  
  处理事项：  
  1.修改当前审批人的审批状态; 
  2.修改待办处理结果; 
  3.检查工作流状态，如果审批完成，修改总状态为审批完成并发消息给申请人；否则，给下一个审批人生成待办。
  **/
  function Approval_Target_Pass(WorkflowId      in varchar2,
                                WorkflowType    in number,
                                ApprovalUserId  in varchar2,
                                ApprovalRemark  in varchar2,
                                MsgSender_Cur   out sys_refcursor,
                                TodoSender_Cur  out sys_refcursor,
                                IsAll_MsgSender out number, --0是否，1是全部
                                ErrMsg          out varchar2) return number as
    UnDone_Cnt number(2);
    TodoTitle  varchar2(20);
    WFStatus   number(1);
    errcode    number(6) := 0;
  begin
    IsAll_MsgSender := 0;
    if WorkflowType = 1 then
      pkg_ins_afw_userapply.GetLeaveAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 2 then
      pkg_ins_afw_userapply.GetEgressAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 3 then
      pkg_ins_afw_userapply.GetPublishAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 4 then
      pkg_ins_afw_userapply.GetEgressAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 11 then
      pkg_ins_afw_userapply.GetPromotionAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 12 then
      pkg_ins_afw_userapply.GetAdjustpostAfwStatusById(WorkflowId,
                                                       WFStatus);
    end if;
  
    if WFStatus <> 0 then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      raise PKG_COMMON.EXP_CHECK;
    end if;
    --修改审批流对应记录状态 审批通过 0-->1
    SetApprovalFlowStatus(WorkflowId, ApprovalUserId, ApprovalRemark, 1);
    --待办完成
    SetToDoStatus(WorkflowId, ApprovalUserId);
    --获取审批流未完结数量
    GetUnDoneApprovalCount(WorkflowId, UnDone_Cnt);
    if (UnDone_Cnt = 0) then
      WFStatus := 2; --审批完成
    else
      WFStatus := 1; --审批中
    end if;
    if WorkflowType = 1 then
      lcoa.pkg_ins_afw_userapply.SetLeaveAfwStatusById(WorkflowId,
                                                       WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateLeaveAfwMsgById(WorkflowId,
                                                       ApprovalUserId,
                                                       1,
                                                       MsgSender_Cur);
    
      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormLeaveTodoTitleById(WorkflowId,
                                                          TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;
    
    elsif WorkflowType = 2 then
      lcoa.pkg_ins_afw_userapply.SetEgressAfwStatusById(WorkflowId,
                                                        WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateEgressAfwMsgById(WorkflowId,
                                                        ApprovalUserId,
                                                        1,
                                                        MsgSender_Cur);
      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormEgressTodoTitleById(WorkflowId,
                                                           TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;
    
    elsif WorkflowType = 3 then
      lcoa.pkg_ins_afw_userapply.SetPublishAfwStatusById(WorkflowId,
                                                         WFStatus);
      lcoa.pkg_ins_afw_userapply.CreatePublishAfwMsgById(WorkflowId,
                                                         ApprovalUserId,
                                                         1,
                                                         case when UnDone_Cnt = 0 then 2 else 1 end,
                                                         MsgSender_Cur,
                                                         IsAll_MsgSender);
      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormPublishTodoTitleById(WorkflowId,
                                                            TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;
    
    elsif WorkflowType = 4 then
      lcoa.pkg_ins_afw_userapply.SetExpensesAfwStatusById(WorkflowId,
                                                          WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateExpensesAfwMsgById(WorkflowId,
                                                          ApprovalUserId,
                                                          1,
                                                          MsgSender_Cur);
      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormExpensesTodoTitleById(WorkflowId,
                                                             TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;
    elsif WorkflowType = 11 then
      lcoa.pkg_ins_afw_userapply.SetPromotionAfwStatusById(WorkflowId,
                                                           WFStatus);
      lcoa.pkg_ins_afw_userapply.CreatePromotionAfwMsgById(WorkflowId,
                                                           ApprovalUserId,
                                                           1,
                                                           MsgSender_Cur);
      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormPromotionTodoTitleById(WorkflowId,
                                                              TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;
      if UnDone_Cnt = 0 then
        errcode := lcoa.pkg_ins_promotion_info.update_user_Promotion_info(WorkFlowID,
                                                                          ErrMsg);
      end if;
    elsif WorkflowType = 12 then
      lcoa.pkg_ins_afw_userapply.SetAdjustpostAfwStatusById(WorkflowId,
                                                            WfStatus);
      lcoa.pkg_ins_afw_userapply.CreateAdjustpostAfwMsgById(WorkflowId,
                                                            ApprovalUserId,
                                                            1,
                                                            MsgSender_Cur);
      --调岗是会签不分先后顺序，一次性生成，审批过程中无需发待办    
      --当全部完成审批时，修改岗位及部门信息
      --此处如有调岗其他相关数据操作，由对应业务包在此函数中补充完善        
      if UnDone_Cnt = 0 then
        errcode := lcoa.pkg_ins_transferposition_info.update_UserAndEmployees_info(WorkflowId,
                                                                                   ErrMsg);
      end if;
    end if;
    return errcode;
  exception
    when PKG_COMMON.EXP_CHECK then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      return pkg_common.g_errcode_afw_overlap;
    when PKG_COMMON.EXP_EXECUTE then
      ErrMsg := pkg_common.g_errmsg_afw_upt_nodata;
      return pkg_common.g_errcode_afw_upt_nodata;
    when others then
      ErrMsg := 'Approval_Target_Pass: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE;
  end;
  /**
  功能：当前审批人审批驳回
  
  处理事项：  
  1.修改当前审批人的审批状态; 
  2.修改待办处理结果; 
  3.总状态改为已驳回;
  4.发送消息给申请人
  **/
  function Approval_Target_Reject(WorkflowId      in varchar2,
                                  WorkflowType    in number,
                                  ApprovalUserId  in varchar2,
                                  ApprovalRemark  in varchar2,
                                  MsgSender_Cur   out sys_refcursor,
                                  TodoSender_Cur  out sys_refcursor,
                                  IsAll_MsgSender out number, --0是否，1是全部
                                  ErrMsg          out varchar2) return number as
    UnDone_Cnt number(2);
    WFStatus   number(1);
    errcode    number(6) := 0;
  begin
    IsAll_MsgSender := 0;
    if WorkflowType = 1 then
      pkg_ins_afw_userapply.GetLeaveAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 2 then
      pkg_ins_afw_userapply.GetEgressAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 3 then
      pkg_ins_afw_userapply.GetPublishAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 4 then
      pkg_ins_afw_userapply.GetEgressAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 11 then
      pkg_ins_afw_userapply.GetPromotionAfwStatusById(WorkflowId, WFStatus);
    elsif WorkflowType = 12 then
      pkg_ins_afw_userapply.GetAdjustpostAfwStatusById(WorkflowId,
                                                       WFStatus);
    end if;
  
    if WFStatus <> 0 then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      raise PKG_COMMON.EXP_CHECK;
    end if;
    --修改审批流对应记录状态 审批拒绝 0-->-1
    SetApprovalFlowStatus(WorkflowId, ApprovalUserId, ApprovalRemark, -1);
    --经过与产品确认，无需修改其他人审批状态
    --SetAllApprovalFlowStatus(WorkflowId, '已有会签人拒绝,其他未会签默认拒绝', -1);
    --待办完成
    SetToDoStatus(WorkflowId, ApprovalUserId);
    --获取审批流未完结数量
    GetUnDoneApprovalCount(WorkflowId, UnDone_Cnt);
  
    WFStatus := 3; --已拒绝
  
    if WorkflowType = 1 then
      lcoa.pkg_ins_afw_userapply.SetLeaveAfwStatusById(WorkflowId,
                                                       WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateLeaveAfwMsgById(WorkflowId,
                                                       ApprovalUserId,
                                                       -1,
                                                       MsgSender_Cur);
    elsif WorkflowType = 2 then
      lcoa.pkg_ins_afw_userapply.SetEgressAfwStatusById(WorkflowId,
                                                        WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateEgressAfwMsgById(WorkflowId,
                                                        ApprovalUserId,
                                                        -1,
                                                        MsgSender_Cur);
    elsif WorkflowType = 3 then
      lcoa.pkg_ins_afw_userapply.SetPublishAfwStatusById(WorkflowId,
                                                         WFStatus);
      lcoa.pkg_ins_afw_userapply.CreatePublishAfwMsgById(WorkflowId,
                                                         ApprovalUserId,
                                                         -1,
                                                         1,
                                                         MsgSender_Cur,
                                                         IsAll_MsgSender);
    elsif WorkflowType = 4 then
      lcoa.pkg_ins_afw_userapply.SetExpensesAfwStatusById(WorkflowId,
                                                          WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateExpensesAfwMsgById(WorkflowId,
                                                          ApprovalUserId,
                                                          -1,
                                                          MsgSender_Cur);
    elsif WorkflowType = 11 then
      lcoa.pkg_ins_afw_userapply.SetPromotionAfwStatusById(WorkflowId,
                                                           WFStatus);
      lcoa.pkg_ins_afw_userapply.CreatePromotionAfwMsgById(WorkflowId,
                                                           ApprovalUserId,
                                                           -1,
                                                           MsgSender_Cur);
    elsif WorkflowType = 12 then
      lcoa.pkg_ins_afw_userapply.SetAdjustpostAfwStatusById(WorkflowId,
                                                            WFStatus);
      lcoa.pkg_ins_afw_userapply.CreateAdjustpostAfwMsgById(WorkflowId,
                                                            ApprovalUserId,
                                                            -1,
                                                            MsgSender_Cur);
      --驳回后，清除其他未审批人的待办记录
      RemoveInvalidToDoInfo(WorkflowId);
    end if;
    return 0;
  exception
    when PKG_COMMON.EXP_CHECK then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      return pkg_common.g_errcode_afw_overlap;
    when PKG_COMMON.EXP_EXECUTE then
      ErrMsg := pkg_common.g_errmsg_afw_upt_nodata;
      return pkg_common.g_errcode_afw_upt_nodata;
    when others then
      ErrMsg := 'Approval_Target_Reject: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;

  /**
  功能：申请人撤回申请
  
  处理事项：  
  1.判断当前申请是否可以撤回，如果可以则撤回;
  2.发送消息给申请人
  **/
  function Approval_Target_Cancel(WorkflowId      in varchar2,
                                  WorkflowType    in number,
                                  WorkflowUserId  in varchar2,
                                  ApprovalRemark  in varchar2,
                                  MsgSender_Cur   out sys_refcursor,
                                  TodoSender_Cur  out sys_refcursor,
                                  IsAll_MsgSender out number, --0是否，1是全部
                                  ErrMsg          out varchar2) return number as
    StartTime date;
    CurStatus number;
    WFStatus  number(1);
  begin
  
    if WorkflowType = 1 then
      lcoa.pkg_ins_afw_userapply.GetLeaveAfwStatusById(WorkflowId,
                                                       WFStatus,
                                                       1);
      lcoa.pkg_ins_afw_userapply.SetLeaveAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreateLeaveAfwMsgById(WorkflowId,
                                                       WorkflowUserId,
                                                       -2,
                                                       MsgSender_Cur);
    elsif WorkflowType = 2 then
      lcoa.pkg_ins_afw_userapply.GetEgressAfwStatusById(WorkflowId,
                                                        WFStatus,
                                                        1);
      lcoa.pkg_ins_afw_userapply.SetEgressAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreateEgressAfwMsgById(WorkflowId,
                                                        WorkflowUserId,
                                                        -2,
                                                        MsgSender_Cur);
    elsif WorkflowType = 3 then
      lcoa.pkg_ins_afw_userapply.GetPublishAfwStatusById(WorkflowId,
                                                         WFStatus,
                                                         1);
      delete from oa_msg_message_info where c_msg_src = WorkflowId; --颠倒一下顺序，为了下面判断 added by lihuawei at 2020-4-23
      lcoa.pkg_ins_afw_userapply.SetPublishAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreatePublishAfwMsgById(WorkflowId,
                                                         WorkflowUserId,
                                                         -2,
                                                         1,
                                                         MsgSender_Cur,
                                                         IsAll_MsgSender);
    elsif WorkflowType = 4 then
      lcoa.pkg_ins_afw_userapply.GetExpensesAfwStatusById(WorkflowId,
                                                          WFStatus,
                                                          1);
      lcoa.pkg_ins_afw_userapply.SetExpensesAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreateExpensesAfwMsgById(WorkflowId,
                                                          WorkflowUserId,
                                                          -2,
                                                          MsgSender_Cur);
    elsif WorkflowType = 11 then
      lcoa.pkg_ins_afw_userapply.GetPromotionAfwStatusById(WorkflowId,
                                                           WFStatus,
                                                           1);
      lcoa.pkg_ins_afw_userapply.SetPromotionAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreatePromotionAfwMsgById(WorkflowId,
                                                           WorkflowUserId,
                                                           -2,
                                                           MsgSender_Cur);
    elsif WorkflowType = 12 then
      lcoa.pkg_ins_afw_userapply.GetAdjustpostAfwStatusById(WorkflowId,
                                                            WFStatus,
                                                            1);
      lcoa.pkg_ins_afw_userapply.SetAdjustpostAfwStatusById(WorkflowId, -1);
      lcoa.pkg_ins_afw_userapply.CreateAdjustpostAfwMsgById(WorkflowId,
                                                            WorkflowUserId,
                                                            -2,
                                                            MsgSender_Cur);
    end if;
  
    RemoveInvalidToDoInfo(WorkflowId);
  
    return 0;
  exception
    when PKG_COMMON.EXP_CHECK then
      return pkg_common.g_errcode_afw_overlap;
    when NO_DATA_FOUND then
      ErrMsg := pkg_common.g_errmsg_afw_nodata;
      return pkg_common.g_errcode_afw_nodata;
    when others then
      ErrMsg := 'Approval_Target_Cancel: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
  end;
  /**
  功能：当前审批人审批通过
  
  处理事项：  
  1.修改当前审批人的审批状态; 
  2.修改待办处理结果; 
  3.检查工作流状态，如果审批完成，修改总状态为审批完成并发消息给申请人；否则，给下一个审批人生成待办。
  **/
  function Approval_Target_Delay(WorkflowId      in varchar2,
                                 WorkflowType    in number,
                                 ApprovalUserId  in varchar2,
                                 ApprovalRemark  in varchar2,
                                 MsgSender_Cur   out sys_refcursor,
                                 TodoSender_Cur  out sys_refcursor,
                                 IsAll_MsgSender out number, --0是否，1是全部
                                 ErrMsg          out varchar2) return number as
    UnDone_Cnt number(2);
    TodoTitle  varchar2(20);
    WFStatus   number(1);
    errcode    number(6) := 0;
  begin
    IsAll_MsgSender := 0;
    if WorkflowType = 11 then
      pkg_ins_afw_userapply.GetPromotionAfwStatusById(WorkflowId, WFStatus);
    else
      --只有转正类型有延期功能
      raise Pkg_Common.EXP_PARAM;
    end if;
  
    if WFStatus <> 0 then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      raise PKG_COMMON.EXP_CHECK;
    end if;
    --修改审批流对应记录状态 审批延期 0-->2
    SetApprovalFlowStatus(WorkflowId, ApprovalUserId, ApprovalRemark, 2);
    --待办完成
    SetToDoStatus(WorkflowId, ApprovalUserId);
    --获取审批流未完结数量
    GetUnDoneApprovalCount(WorkflowId, UnDone_Cnt);
    if (UnDone_Cnt = 0) then
      WFStatus := 4; --最后一个延期为准
    else
      WFStatus := 1; --审批中
    end if;
    if WorkflowType = 11 then
      lcoa.pkg_ins_afw_userapply.SetPromotionAfwStatusById(WorkflowId,
                                                           WFStatus);
      lcoa.pkg_ins_afw_userapply.CreatePromotionAfwMsgById(WorkflowId,
                                                           ApprovalUserId,
                                                           2,
                                                           MsgSender_Cur);
      if UnDone_Cnt > 0 then
        lcoa.pkg_ins_afw_userapply.FormPromotionTodoTitleById(WorkflowId,
                                                              TodoTitle);
        Create_Next_Approval_Todo(WorkflowId, TodoTitle, TodoSender_Cur);
      end if;
    end if;
    return errcode;
  exception
    when PKG_COMMON.EXP_CHECK then
      ErrMsg := pkg_common.g_errmsg_afw_overlap;
      return pkg_common.g_errcode_afw_overlap;
    when PKG_COMMON.EXP_EXECUTE then
      ErrMsg := pkg_common.g_errmsg_afw_upt_nodata;
      return pkg_common.g_errcode_afw_upt_nodata;
    when others then
      ErrMsg := 'Approval_Target_Pass: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      RAISE;
  end;
  --此块进行变量初始化，可删除
begin
  -- Initialization
  i := 1;
end PKG_INS_AFW_WORKFLOW;
/

