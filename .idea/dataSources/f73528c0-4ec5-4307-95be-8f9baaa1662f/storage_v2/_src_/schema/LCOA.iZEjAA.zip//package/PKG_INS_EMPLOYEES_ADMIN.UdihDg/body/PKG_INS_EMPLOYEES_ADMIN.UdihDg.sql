create package body pkg_ins_employees_admin is

  /**
  部门上移下移
  **/
  function move_order(DataInfo        in varchar2,
                      OperationUserId IN VARCHAR2,
                      ErrMsg          out varchar2) return number is
    dataarr        pkg_common.arr_longstr;
    OrganizationId varchar2(40);
    movetype       number(4);
    countorder     number(4);
    norder         number(4);
    uorder         number(4);
    dorder         number(4);
    parentid       varchar2(40);
    nresult        number(4);
  begin
    dataarr        := pkg_common.split(datainfo, '^');
    OrganizationId := dataarr(1);
    movetype       := dataarr(2); --上移下移标识 1为上移 2为下移
    --获取当前部门等级下部门总数
    countorder := lcoa.pkg_ins_employees_admin.count_order(OrganizationId,
                                                           ErrMsg);
    if countorder = 0 then
      return 0;
    end if;
    --查询操作部门排序序号以及部门父id
    select o.n_order, o.c_organization_parent_id
      into norder, parentid
      from lcbase.t_zip_organization o
     where o.c_organization_id = OrganizationId
       and o.d_enddate > SYSDATE;
  
    uorder := norder - 1;
    dorder := norder + 1;
    --判断上移还是下移
    if movetype = 1 then
      --首位不能上移
      if norder = 1 then
        return - 1;
      else
        --给上位赋予被操作位的order
        nresult := lcoa.pkg_ins_employees_admin.update_uorder(norder,
                                                              uorder,
                                                              parentid,
                                                              ErrMsg);
        --被操作位order - 1
        nresult := lcoa.pkg_ins_employees_admin.update_dorder(uorder,
                                                              OrganizationId,
                                                              ErrMsg);
      end if;
    elsif movetype = 2 then
      --末尾不能下移
      if norder = countorder then
        return - 2;
      else
        --给下位赋予被操作位的order
        nresult := lcoa.pkg_ins_employees_admin.update_uorder(norder,
                                                              dorder,
                                                              parentid,
                                                              ErrMsg);
        --被操作位order + 1
        nresult := lcoa.pkg_ins_employees_admin.update_dorder(dorder,
                                                              OrganizationId,
                                                              ErrMsg);
      end if;
    end if;
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'move_order: ' || sqlcode || ',' || sqlerrm;
      raise;
      rollback;
      return 1;
  end;
  /**
  用户部门模糊查询
  **/
  function get_organization_userlist(OperationUserId    IN VARCHAR2,
                                     UserOrOrganization in varchar2,
                                     OrganizationList   out sys_refcursor,
                                     UserInfoList       out sys_refcursor,
                                     ErrMsg             out varchar2)
    return number is
  begin
    open OrganizationList for
      select c_organization_id,
             v_organization_name,
             c_organization_parent_id,
             n_organization_level,
             n_organization_type,
             c_organization_owner,
             n_status,
             v_organization_abbname,
             c_organization_bp,
             n_order,
             c_organization_po
        from lcbase.t_zip_organization
       where n_status = 0
         and d_enddate > SYSDATE
         and v_organization_name like '%' || UserOrOrganization || '%';
    open UserInfoList for
      select u.c_user_id            as cUserId,
             u.c_organization_id    as cOrganizationId,
             u.v_pet_name           as vUserName,
             u.n_user_type          as nUserType,
             u.n_work_id            as nWorkId,
             u.v_pet_name           as vPetName,
             u.n_mobile_1           as nMobile1,
             u.n_mobile_2           as nMobile2,
             u.v_tel_1              as vTel1,
             u.v_tel_2              as vTel2,
             u.n_status             as nStatus,
             u.v_email              as vEmail,
             u.c_password,
             u.v_wx_open_id         as vWxOpenId,
             u.v_work_wx_account    as vWorkWxAccount,
             u.n_sex                as nSex,
             u.n_authority          as nAuthority,
             u.n_work_wx_activation as nWorkWxActivation,
             u.v_headpic_aly        as headpicAly,
             o.v_organization_name  as organizationName
        from lcbase.t_zip_user u
        left join lcbase.t_zip_organization o
          on u.c_organization_id = o.c_organization_id
       where u.v_user_name like '%' || UserOrOrganization || '%'
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE;
    return 0;
  exception
    when others then
      ErrMsg := 'get_organization_userlist: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  /**
  获取成员列表
  **/
  function get_employees_list(OrganizationId  in varchar2,
                              status          in varchar2,
                              pageNum         in number,
                              PageSize        in number,
                              OperationUserId IN VARCHAR2,
                              DataList        out sys_refcursor,
                              owner           out varchar2,
                              BpName          out varchar2,
                              VpName          out varchar2,
                              totalPage       out number,
                              totalCount      out number,
                              dataCount       out number,
                              ErrMsg          out varchar2) return number is
    n_result        number(3);
    vSql            varchar2(4000);
    nOrganizationId varchar2(32);
    countrole       number(6);
  begin
    countrole := count_roleuserid(OperationUserId, ErrMsg);
    --判断status状态值是否传入，是则增加条件，否则只用部门id作为where条件
    if OrganizationId is null then
      nOrganizationId := '997c2b49b01d4bdba3c5ea4e0f615617';
      n_result        := pkg_ins_employees_admin.get_employees_oldlist(nOrganizationId,
                                                                       countrole,
                                                                       status,
                                                                       pageNum,
                                                                       PageSize,
                                                                       OperationUserId,
                                                                       DataList,
                                                                       owner,
                                                                       BpName,
                                                                       VpName,
                                                                       totalPage,
                                                                       totalCount,
                                                                       dataCount,
                                                                       ErrMsg);
    elsif OrganizationId = '997c2b49b01d4bdba3c5ea4e0f615617' then
      nOrganizationId := OrganizationId;
      n_result        := pkg_ins_employees_admin.get_employees_oldlist(nOrganizationId,
                                                                       countrole,
                                                                       status,
                                                                       pageNum,
                                                                       PageSize,
                                                                       OperationUserId,
                                                                       DataList,
                                                                       owner,
                                                                       BpName,
                                                                       VpName,
                                                                       totalPage,
                                                                       totalCount,
                                                                       dataCount,
                                                                       ErrMsg);
    else
      nOrganizationId := OrganizationId;
      n_result        := pkg_ins_employees_admin.get_employees_newlist(nOrganizationId,
                                                                       countrole,
                                                                       status,
                                                                       pageNum,
                                                                       PageSize,
                                                                       OperationUserId,
                                                                       DataList,
                                                                       owner,
                                                                       BpName,
                                                                       VpName,
                                                                       totalPage,
                                                                       totalCount,
                                                                       dataCount,
                                                                       ErrMsg);
    end if;
  
    return n_result;
  exception
    when others then
      ErrMsg := 'get_employees_list: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function get_employees_oldlist(nOrganizationId in varchar2,
                                 countrole       in number,
                                 status          in varchar2,
                                 pageNum         in number,
                                 PageSize        in number,
                                 OperationUserId IN VARCHAR2,
                                 DataList        out sys_refcursor,
                                 owner           out varchar2,
                                 BpName          out varchar2,
                                 VpName          out varchar2,
                                 totalPage       out number,
                                 totalCount      out number,
                                 dataCount       out number,
                                 ErrMsg          out varchar2) return number is
    n_result number(3);
    vSql     varchar2(4000);
    --nOrganizationId varchar2(32);
    countoId number(6);
    o        varchar(32) := '997c2b49b01d4bdba3c5ea4e0f615617';
    char1    varchar(40) := '-';
    char2    varchar(40) := '-北京乐卡车联科技有限公司-';
    char3    varchar(40) := '';
    char4    varchar(40) := '-北京乐卡车联科技有限公司';
    char5    varchar(40) := '北京乐卡车联科技有限公司';
    char6    varchar(40) := '0';
  begin
  
    dataCount := pkg_ins_employees_admin.get_dataCount(nOrganizationId,
                                                       ErrMsg);
  
    countoId := pkg_ins_employees_admin.count_organizationid(nOrganizationId,
                                                             status,
                                                             ErrMsg);
    if countoId = 0 then
      return 0;
    end if;
    vSql := 'select * from (SELECT
                u.v_pet_name AS userName,
                u.V_EMAIL AS email,
                u.C_ORGANIZATION_ID AS organizationId,
                o.V_ORGANIZATION_NAME AS organizationName,
                u.c_user_id AS cUserId,
                e.n_work_place AS nWorkPlace,
                e.n_possession AS nPossession,
                e.v_user_title AS vUserTitle,
                e.c_id_card_number AS cIdCardNumber,
                e.d_hire_date AS dHireDate,
                e.n_political_apperar AS nPoliticalApperar,
                e.v_nation AS vNation,
                e.n_marriage AS nMarriage,
                e.v_id_card_address AS vIdCardAddress,
                e.n_hu_kou_type AS nHuKouType,
                e.v_present_address AS vPresentAddress,
                e.v_urgency_link_man AS vUrgencyLinkMan,
                e.v_urgency_link_tel AS vUrgencyLinkTel,
                e.v_college AS vCollege,
                e.v_major AS vMajor,
                e.n_learning AS nLearning,
                e.d_entrance AS dEntrance,
                e.d_graduation AS dGraduation,
                e.n_hobbies AS nHobbies,
                e.v_grades AS vGrades,
                e.d_promotion AS dPromotion,
                e.n_education AS nEducation,
                e.v_bank_card_number AS vBankCardNumber,
                e.v_accumulation_fund_type AS vAccumulationFundType,
                e.v_opening_bank AS vOpeningBank,
                e.v_remark AS vRemark,
                e.n_social_security_type AS nSocialSecurityType,
                e.d_leave AS dLeave,
                LPAD(e.n_work_num,4,' || '''' || char6 || '''' ||
            ') AS nWorkNum,
                LPAD(e.N_WORK_NUM_OLD,4,' || '''' || char6 || '''' ||
            ') AS nWorkNumOld,
                e.c_labor_ref AS cLaborRef,
                e.n_status AS nStatus,
                e.c_lk_company_id AS lkCompanyId,
                u.N_MOBILE_1 as tel,
                CASE
                    WHEN e.N_WORK_NUM_OLD IS NULL THEN -1
                    ELSE e.N_WORK_NUM_OLD
                END AS nWorkNumOldOrder,
                u.V_PET_NAME as petName,
                REPLACE(REPLACE(o1.v_organization_name,
                             ' || '''' || char2 || '''' || ',
                             ' || '''' || char3 || '''' || '),
                     ' || '''' || char4 || '''' || ',
                     ' || '''' || char5 || '''' ||
            ') as organizationNameAll,
               ' || countrole ||
            ' as isWhoRole 
              FROM
                lcbase.t_zip_user u 
              LEFT JOIN lcbase.t_employees_info e ON 
                u.c_user_id = e.c_user_id 
              LEFT JOIN LCBASE.T_ZIP_ORGANIZATION o ON 
                u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID 
              LEFT JOIN (SELECT t.c_organization_id c_organization_id,
                          SYS_CONNECT_BY_PATH(t.v_organization_name, ' || '''' ||
            char1 || '''' || ') v_organization_name
                     FROM (SELECT * FROM LCBASE.T_ZIP_ORGANIZATION 
                     WHERE D_ENDDATE > SYSDATE) t 
                    START WITH t.c_organization_id =
                               LOWER(' || '''' || o || '''' || ')
                   CONNECT BY PRIOR t.c_organization_id =
                               t.c_organization_parent_id) o1
          ON u.C_ORGANIZATION_ID = o1.c_organization_id
       where e.n_work_place is not null and o.n_status = 0
       and u.d_enddate > SYSDATE
       AND o.D_STARTDATE <= u.D_STARTDATE AND o.D_ENDDATE > u.D_STARTDATE ';
  
    /*vSql := vSql || 'START WITH t.c_organization_id = ' || '''' ||
    nOrganizationId || '''' ||
    ' CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id) ';*/
  
    if status is not null then
      vSql := vSql || ' and e.n_status = ' || status || ' ';
    end if;
    vSql := vSql || ') o order by o.nWorkNumOldOrder desc';
    /*for i in 1 .. 5 loop
      dbms_output.put_line(substr(vSql, 1900 * (i - 1) + 1, 1900));
    end loop;*/
    n_result := lcoa.pkg_common.GetPagingInfo(vSql,
                                              PageSize,
                                              pageNum,
                                              DataList,
                                              totalCount,
                                              totalPage);
    if nOrganizationId is not null then
      n_result := pkg_ins_employees_admin.get_obvnames(nOrganizationId,
                                                       owner,
                                                       BpName,
                                                       VpName,
                                                       ErrMsg);
    end if;
    return n_result;
  exception
    when others then
      ErrMsg := 'get_employees_oldlist: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function get_employees_newlist(nOrganizationId in varchar2,
                                 countrole       in number,
                                 status          in varchar2,
                                 pageNum         in number,
                                 PageSize        in number,
                                 OperationUserId IN VARCHAR2,
                                 DataList        out sys_refcursor,
                                 owner           out varchar2,
                                 BpName          out varchar2,
                                 VpName          out varchar2,
                                 totalPage       out number,
                                 totalCount      out number,
                                 dataCount       out number,
                                 ErrMsg          out varchar2) return number is
    n_result number(3);
    vSql     varchar2(4000);
    --nOrganizationId varchar2(32);
    countoId number(6);
    o        varchar(32) := '997c2b49b01d4bdba3c5ea4e0f615617';
    char1    varchar(40) := '-';
    char2    varchar(40) := '-北京乐卡车联科技有限公司-';
    char3    varchar(40) := '';
    char4    varchar(40) := '-北京乐卡车联科技有限公司';
    char5    varchar(40) := '北京乐卡车联科技有限公司';
    char6    varchar(40) := '0';
  begin
  
    dataCount := pkg_ins_employees_admin.get_dataCount(nOrganizationId,
                                                       ErrMsg);
  
    countoId := pkg_ins_employees_admin.count_organizationid(nOrganizationId,
                                                             status,
                                                             ErrMsg);
    if countoId = 0 then
      return 0;
    end if;
    vSql := 'select * from (SELECT
                u.v_pet_name AS userName,
                u.V_EMAIL AS email,
                u.C_ORGANIZATION_ID AS organizationId,
                o.V_ORGANIZATION_NAME AS organizationName,
                u.c_user_id AS cUserId,
                e.n_work_place AS nWorkPlace,
                e.n_possession AS nPossession,
                e.v_user_title AS vUserTitle,
                e.c_id_card_number AS cIdCardNumber,
                e.d_hire_date AS dHireDate,
                e.n_political_apperar AS nPoliticalApperar,
                e.v_nation AS vNation,
                e.n_marriage AS nMarriage,
                e.v_id_card_address AS vIdCardAddress,
                e.n_hu_kou_type AS nHuKouType,
                e.v_present_address AS vPresentAddress,
                e.v_urgency_link_man AS vUrgencyLinkMan,
                e.v_urgency_link_tel AS vUrgencyLinkTel,
                e.v_college AS vCollege,
                e.v_major AS vMajor,
                e.n_learning AS nLearning,
                e.d_entrance AS dEntrance,
                e.d_graduation AS dGraduation,
                e.n_hobbies AS nHobbies,
                e.v_grades AS vGrades,
                e.d_promotion AS dPromotion,
                e.n_education AS nEducation,
                e.v_bank_card_number AS vBankCardNumber,
                e.v_accumulation_fund_type AS vAccumulationFundType,
                e.v_opening_bank AS vOpeningBank,
                e.v_remark AS vRemark,
                e.n_social_security_type AS nSocialSecurityType,
                e.d_leave AS dLeave,
                LPAD(e.n_work_num,4,' || '''' || char6 || '''' ||
            ') AS nWorkNum,
                LPAD(e.N_WORK_NUM_OLD,4,' || '''' || char6 || '''' ||
            ') AS nWorkNumOld,
                e.c_labor_ref AS cLaborRef,
                e.n_status AS nStatus,
                e.c_lk_company_id AS lkCompanyId,
                u.N_MOBILE_1 as tel,
                CASE
                    WHEN e.N_WORK_NUM_OLD IS NULL THEN -1
                    ELSE e.N_WORK_NUM_OLD
                END AS nWorkNumOldOrder,
                u.V_PET_NAME as petName,
                REPLACE(REPLACE(o1.v_organization_name,
                             ' || '''' || char2 || '''' || ',
                             ' || '''' || char3 || '''' || '),
                     ' || '''' || char4 || '''' || ',
                     ' || '''' || char5 || '''' ||
            ') as organizationNameAll,
               ' || countrole ||
            ' as isWhoRole  
              FROM
                lcbase.t_zip_user u 
              LEFT JOIN lcbase.t_employees_info e ON 
                u.c_user_id = e.c_user_id 
              LEFT JOIN (SELECT * FROM LCBASE.T_ZIP_ORGANIZATION
                   WHERE D_ENDDATE > SYSDATE) o ON 
                u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID 
              LEFT JOIN (SELECT t.c_organization_id c_organization_id,
                          SYS_CONNECT_BY_PATH(t.v_organization_name, ' || '''' ||
            char1 || '''' || ') v_organization_name
                     FROM (SELECT * FROM LCBASE.T_ZIP_ORGANIZATION 
                     WHERE D_ENDDATE > SYSDATE) t 
                    START WITH t.c_organization_id =
                               LOWER(' || '''' || o || '''' || ')
                   CONNECT BY PRIOR t.c_organization_id =
                               t.c_organization_parent_id) o1
          ON u.C_ORGANIZATION_ID = o1.c_organization_id
       where e.n_work_place is not null and o.n_status = 0
       and u.d_enddate > SYSDATE
       and u.c_organization_id IN (SELECT t.C_ORGANIZATION_ID FROM (SELECT * FROM LCBASE.T_ZIP_ORGANIZATION WHERE D_ENDDATE > SYSDATE) t 
       START WITH t.c_organization_id = ' || '''' ||
            nOrganizationId || '''' ||
            ' CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id) ';
  
    /*vSql := vSql || 'START WITH t.c_organization_id = ' || '''' ||
    nOrganizationId || '''' ||
    ' CONNECT BY t.c_organization_parent_id = PRIOR t.c_organization_id) ';*/
  
    if status is not null then
      vSql := vSql || ' and e.n_status = ' || status || ' ';
    end if;
    vSql := vSql || ') o order by o.nWorkNumOldOrder desc';
    /*for i in 1 .. 5 loop
      dbms_output.put_line(substr(vSql, 1900 * (i - 1) + 1, 1900));
    end loop;*/
    n_result := lcoa.pkg_common.GetPagingInfo(vSql,
                                              PageSize,
                                              pageNum,
                                              DataList,
                                              totalCount,
                                              totalPage);
    if nOrganizationId is not null then
      n_result := pkg_ins_employees_admin.get_obvnames(nOrganizationId,
                                                       owner,
                                                       BpName,
                                                       VpName,
                                                       ErrMsg);
    end if;
    return n_result;
  exception
    when others then
      ErrMsg := 'get_employees_newlist: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  /**
  获取成员详情
  **/
  function query_employeeinfo(OperationUserId IN VARCHAR2,
                              UserId          in varchar2,
                              DataSource      in number, --1userid是身份证 2userid是userid
                              owner           out number,
                              bp              out number,
                              vp              out number,
                              EmployeesInfo   out sys_refcursor,
                              UserInfo        out sys_refcursor,
                              UserpicList     out sys_refcursor,
                              ErrMsg          out varchar2) return number is
    bpid            varchar(40);
    ownerid         varchar(40);
    vpid            varchar(40);
    str             varchar2(10) := 'string';
    vpname          varchar(20);
    n_result        number(6) := 0;
    nOrganizationId varchar(40);
    eUserId         varchar2(40);
    countid         number(6);
  begin
    eUserId := UserId;
    if DataSource = 1 then
      select count(*)
        into countid
        from lcbase.t_employees_info e
       where e.c_id_card_number = eUserId;
      if countid < 1 then
        ErrMsg := '该员工为第一次入职，无该用户信息';
        return 20001;
      elsif countid > 1 then
        ErrMsg := '身份证号多人重复，请联系管理员！';
        return 1;
      end if;
      select e.c_user_id
        into eUserId
        from lcbase.t_employees_info e
       where e.c_id_card_number = eUserId;
    end if;
    select u.c_organization_id
      into nOrganizationId
      from lcbase.t_zip_user u
     where u.c_user_id = eUserId
       and u.d_enddate > SYSDATE;
    --获取部门负责人id以及bpid
    n_result := pkg_ins_employees_admin.get_vpname(nOrganizationId,
                                                   VpName,
                                                   vpid,
                                                   ErrMsg);
  
    select count(*)
      into countid
      from lcbase.t_zip_user u
     where u.c_user_id = eUserId
       and u.c_organization_id in
           (SELECT o.C_ORGANIZATION_ID
              FROM lcbase.T_ZIP_ORGANIZATION o
             WHERE o.D_ENDDATE > SYSDATE);
    if countid = 0 then
      select o.c_organization_owner, o.c_organization_bp
        into ownerid, bpid
        from lcbase.t_zip_user u
        left join lcbase.t_zip_organization o
          on u.c_organization_id = o.c_organization_id
       where u.c_user_id = eUserId
         AND o.D_STARTDATE <= u.D_STARTDATE
         AND o.D_ENDDATE > u.D_STARTDATE;
    else
      select o.c_organization_owner, o.c_organization_bp
        into ownerid, bpid
        from lcbase.t_zip_user u
        left join lcbase.t_zip_organization o
          on u.c_organization_id = o.c_organization_id
       where u.c_user_id = eUserId
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE;
    end if;
    --判断当前UserId是否为负责人id和bpid
    if ownerid = eUserId then
      owner := 1;
    else
      owner := 0;
    end if;
    if bpid = eUserId then
      bp := 1;
    else
      bp := 0;
    end if;
    if vpid = eUserId then
      vp := 1;
    else
      vp := 0;
    end if;
    open EmployeesInfo for
      SELECT e.c_user_id AS cUserId,
             e.n_work_place AS nWorkPlace,
             (SELECT t.V_CNAME
                FROM LCBASE.T_SYS_AD_CODE t
               WHERE t.n_ad_code = SUBSTR(e.n_work_place, 1, 2) || '0000') || '-' ||
             (SELECT t.V_CNAME
                FROM LCBASE.T_SYS_AD_CODE t
               WHERE t.n_ad_code = SUBSTR(e.n_work_place, 1, 4) || '00') ||
             (SELECT CASE
                       WHEN e.n_work_place =
                            SUBSTR(e.n_work_place, 1, 4) || '00' THEN
                        ''
                       ELSE
                        '-' || t.V_CNAME
                     END
                FROM LCBASE.T_SYS_AD_CODE t
               WHERE t.n_ad_code = e.n_work_place) AS workPlaceName,
             e.n_possession AS nPossession,
             e.v_user_title AS vUserTitle,
             e.c_id_card_number AS cIdCardNumber,
             e.d_hire_date AS dHireDate,
             e.n_political_apperar AS nPoliticalApperar,
             e.v_nation AS vNation,
             n.v_nation_name AS nationName,
             e.n_marriage AS nMarriage,
             e.v_id_card_address AS vIdCardAddress,
             e.n_hu_kou_type AS nHuKouType,
             e.v_present_address AS vPresentAddress,
             e.v_urgency_link_man AS vUrgencyLinkMan,
             e.v_urgency_link_tel AS vUrgencyLinkTel,
             e.v_college AS vCollege,
             e.v_major AS vMajor,
             e.n_learning AS nLearning,
             e.d_entrance AS dEntrance,
             e.d_graduation AS dGraduation,
             e.n_hobbies AS nHobbies,
             e.v_grades AS vGrades,
             e.d_promotion AS dPromotion,
             e.n_education AS nEducation,
             e.v_bank_card_number AS vBankCardNumber,
             e.v_accumulation_fund_type AS vAccumulationFundType,
             e.v_opening_bank AS vOpeningBank,
             e.v_remark AS vRemark,
             e.n_social_security_type AS nSocialSecurityType,
             e.d_leave AS dLeave,
             LPAD(e.n_work_num, 4, '0') AS nWorkNum,
             LPAD(e.n_work_num_old, 4, '0') AS nWorkNumOld,
             e.c_labor_ref AS cLaborRef,
             e.n_status AS nStatus,
             e.c_lk_company_id AS lkCompanyId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.T_SYS_NATION n
          ON e.V_NATION = n.N_NATION_ID
       WHERE e.V_NATION <> 'string'
         AND e.c_user_id = eUserId
         and u.d_enddate > SYSDATE;
    open UserInfo for
      SELECT u.c_user_id AS cUserId,
             u.c_organization_id AS cOrganizationId,
             u.v_user_name AS vUserName,
             u.n_user_type AS nUserType,
             u.n_work_id AS nWorkId,
             u.v_pet_name AS vPetName,
             u.n_mobile_1 AS nMobile1,
             u.n_mobile_2 AS nMobile2,
             u.v_tel_1 AS vTel1,
             u.v_tel_2 AS vTel2,
             u.n_status AS nStatus,
             u.v_email AS vEmail,
             u.c_password,
             u.v_wx_open_id AS vWxOpenId,
             u.v_work_wx_account AS vWorkWxAccount,
             u.n_sex AS nSex,
             u.n_authority AS nAuthority,
             u.n_work_wx_activation AS nWorkWxActivation,
             u.v_headpic_aly AS headpicAly,
             REPLACE(REPLACE(o.v_organization_name,
                             '-北京乐卡车联科技有限公司-',
                             ''),
                     '-北京乐卡车联科技有限公司',
                     '北京乐卡车联科技有限公司') AS organizationName,
             u.v_fullname_zh AS spell,
             u.n_kindofwork AS kindofwork,
             uo.c_organization_id AS projectId,
             zo.v_organization_name AS projectName
        FROM LCBASE.t_zip_user u
        LEFT JOIN (SELECT t.c_organization_id c_organization_id,
                          SYS_CONNECT_BY_PATH(t.v_organization_name, '-') v_organization_name
                     FROM (SELECT *
                             FROM LCBASE.T_ZIP_ORGANIZATION
                            WHERE D_ENDDATE > SYSDATE) t
                    START WITH t.c_organization_id =
                               LOWER('997c2b49b01d4bdba3c5ea4e0f615617')
                   CONNECT BY PRIOR t.c_organization_id =
                               t.c_organization_parent_id) o
          ON u.C_ORGANIZATION_ID = o.c_organization_id
        LEFT JOIN lcbase.t_user_organization uo
          ON u.c_user_id = uo.c_user_id
        LEFT JOIN (SELECT *
                     FROM lcbase.t_zip_organization
                    WHERE D_ENDDATE > SYSDATE) zo
          ON uo.c_organization_id = zo.c_organization_id
       WHERE u.c_user_id = eUserId
         AND u.d_enddate > SYSDATE;
    open UserpicList for
      select p.c_user_id  as userId,
             p.n_pic_type as picType,
             p.c_pic_addr as picAddr
        from lcbase.t_user_pic p
       where p.c_user_id = eUserId;
    return n_result;
  exception
    when others then
      ErrMsg := 'query_employeeinfo: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function update_uorder(uorder   in number,
                         dorder   in number,
                         parentid in out varchar,
                         ErrMsg   out varchar2) return number is
  begin
    update lcbase.t_zip_organization o
       set o.n_order = uorder
     where o.n_order = dorder
       and o.c_organization_parent_id = parentid
       and o.d_enddate > SYSDATE;
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'update_uorder: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function update_dorder(uorder         in number,
                         OrganizationId in out varchar,
                         ErrMsg         out varchar2) return number is
  begin
    update lcbase.t_zip_organization o
       set o.n_order = uorder
     where o.c_organization_id = OrganizationId
       and o.d_enddate > SYSDATE;
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'update_dorder: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function count_order(OrganizationId in out varchar, ErrMsg out varchar2)
    return number is
    countorder number(4);
  begin
    select count(*)
      into countorder
      from lcbase.t_zip_organization o
     where o.n_status = 0
       and o.c_organization_parent_id in
           (select o.c_organization_parent_id
              from lcbase.t_zip_organization o
             where o.c_organization_id = OrganizationId)
       and o.d_enddate > SYSDATE;
    return countorder;
  exception
    when others then
      ErrMsg := 'update_dorder: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function insert_rest_days(DataInfo        in ARR_LONGSTR,
                            OperationUserId IN VARCHAR2,
                            ErrMsg          out varchar2) return number is
    countday   number(6);
    dataarr    pkg_common.arr_longstr;
    v_dataInfo PKG_COMMON.ARR_LONGSTR;
  begin
    dataarr  := pkg_common.split(DataInfo(1), '^');
    countday := DataInfo.Count;
    delete from lcoa.oa_calendar_restday r
     where to_char(r.d_rest_day, 'yyyyMM') = substr(dataarr(1), 0, 6);
    for i in 1 .. countday loop
      v_dataInfo := PKG_COMMON.Split(DataInfo(i));
      insert into lcoa.oa_calendar_restday
      values
        (to_date(v_dataInfo(1), 'yyyy-mm-dd hh24:mi:ss'), v_dataInfo(2));
    end loop;
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'insert_rest_days: ' || sqlcode || ',' || sqlerrm;
      raise;
      rollback;
      return 1;
  end;

  function get_obvnames(nOrganizationId in varchar2,
                        owner           out VARCHAR2,
                        BpName          out VARCHAR2,
                        VpName          out VARCHAR2,
                        ErrMsg          out varchar2) return number is
    n_reuslt   number(6) := 0;
    vpid       varchar2(32);
    countowner number(6);
    countbp    number(6);
  begin
    n_reuslt := pkg_ins_employees_admin.get_vpname(nOrganizationId,
                                                   VpName,
                                                   vpid,
                                                   ErrMsg);
    select count(*)
      into countowner
      from lcbase.t_zip_organization o
      LEFT JOIN LCBASE.t_zip_user owner
        ON o.C_ORGANIZATION_OWNER = owner.C_USER_ID
     where o.c_organization_id = nOrganizationId
       and o.d_enddate > SYSDATE
       and owner.d_enddate > SYSDATE;
    select count(*)
      into countbp
      from lcbase.t_zip_organization o
      LEFT JOIN LCBASE.t_zip_user bp
        ON o.c_organization_bp = bp.C_USER_ID
     where o.c_organization_id = nOrganizationId
       and o.d_enddate > SYSDATE
       and bp.d_enddate > SYSDATE;
    if countowner > 0 then
      select owner.v_pet_name
        into owner
        from lcbase.t_zip_organization o
        LEFT JOIN LCBASE.t_zip_user owner
          ON o.C_ORGANIZATION_OWNER = owner.C_USER_ID
       where o.c_organization_id = nOrganizationId
         and o.d_enddate > SYSDATE
         and owner.d_enddate > SYSDATE;
    end if;
  
    if countbp > 0 then
      select bp.v_pet_name
        into BpName
        from lcbase.t_zip_organization o
        LEFT JOIN LCBASE.t_zip_user bp
          ON o.c_organization_bp = bp.C_USER_ID
       where o.c_organization_id = nOrganizationId
         and o.d_enddate > SYSDATE
         and bp.d_enddate > SYSDATE;
    end if;
  
    return n_reuslt;
  exception
    when others then
      ErrMsg := 'get_obvnames: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function count_organizationid(nOrganizationId in varchar2,
                                status          in VARCHAR2,
                                ErrMsg          out varchar2) return number is
    countoId   number(6);
    dataarr    pkg_common.arr_longstr;
    v_dataInfo PKG_COMMON.ARR_LONGSTR;
  begin
    if nOrganizationId = '997c2b49b01d4bdba3c5ea4e0f615617' and
       status is not null then
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       WHERE o.n_status = 0
         and e.n_status = status
         and u.d_enddate > SYSDATE
         AND o.D_STARTDATE <= u.D_STARTDATE
         AND o.D_ENDDATE > u.D_STARTDATE;
    elsif nOrganizationId = '997c2b49b01d4bdba3c5ea4e0f615617' and
          status is null then
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       WHERE o.n_status = 0
         and u.d_enddate > SYSDATE
         AND o.D_STARTDATE <= u.D_STARTDATE
         AND o.D_ENDDATE > u.D_STARTDATE;
    elsif status is null then
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       WHERE o.n_status = 0
         and u.d_enddate > SYSDATE
         AND u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id = nOrganizationId
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id);
    else
      SELECT count(*)
        into countoId
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where o.n_status = 0
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id = nOrganizationId
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id)
         and e.n_status = status;
    end if;
    return countoId;
  exception
    when others then
      ErrMsg := 'count_organizationid: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function get_vpname(nOrganizationId in varchar2,
                      VpName          out VARCHAR2,
                      VpId            out VARCHAR2,
                      ErrMsg          out varchar2) return number is
    countname number(6);
  begin
    with all_g as
     (SELECT *
        FROM (select *
                from lcbase.t_zip_organization
               where d_enddate > SYSDATE) g
      connect by prior g.c_organization_parent_id = g.c_organization_id
       start with g.c_organization_id = norganizationid)
    select count(*)
      into countname
      from all_g g
      left join lcbase.t_zip_user w
        on w.c_user_id = g.c_organization_po
     where g.n_organization_level = 2
       and g.d_enddate > SYSDATE
       and w.d_enddate > SYSDATE;
  
    /*if nOrganizationId = '997c2b49b01d4bdba3c5ea4e0f615617' then
    select u.v_pet_name, u.c_user_id
      into VpName, VpId
      from lcbase.t_zip_organization o
      LEFT JOIN lcbase.t_zip_user u
        ON u.c_user_id = o.c_organization_po
     where o.c_organization_id = nOrganizationId
       and u.d_enddate > SYSDATE;*/
    if countname = 0 then
      return 0;
    elsif countname > 1 then
      ErrMsg := '数据错误';
      raise pkg_common.exp_param;
    else
      WITH all_g AS
       (SELECT *
          FROM (select *
                  from lcbase.t_zip_organization
                 where d_enddate > SYSDATE) g
        connect by prior g.c_organization_parent_id = g.c_organization_id
         start with g.c_organization_id = nOrganizationId)
      SELECT w.v_pet_name, w.c_user_id
        into VpName, VpId
        FROM all_g g
        LEFT JOIN lcbase.t_zip_user w
          ON w.c_user_id = g.c_organization_po
       WHERE g.n_organization_level = 2
         and g.d_enddate > SYSDATE
         and w.d_enddate > SYSDATE;
    end if;
  
    return 0;
  exception
    when pkg_common.exp_param then
      return - 1;
    when others then
      ErrMsg := 'get_vpname: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function get_dataCount(nOrganizationId in varchar2, ErrMsg out varchar2)
    return number is
    dataCount number(6);
  begin
    if nOrganizationId = '997c2b49b01d4bdba3c5ea4e0f615617' then
      SELECT count(*)
        into dataCount
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where e.n_work_place is not null
         and u.d_enddate > SYSDATE
         and o.n_status = 0
         AND o.D_STARTDATE <= u.D_STARTDATE
         AND o.D_ENDDATE > u.D_STARTDATE;
    else
      SELECT count(*)
        into dataCount
        FROM lcbase.t_zip_user u
        LEFT JOIN lcbase.t_employees_info e
          ON u.c_user_id = e.c_user_id
        LEFT JOIN LCBASE.t_zip_organization o
          ON u.C_ORGANIZATION_ID = o.C_ORGANIZATION_ID
       where e.n_work_place is not null
         and o.d_enddate > SYSDATE
         and u.d_enddate > SYSDATE
         and o.n_status = 0
         AND u.c_organization_id IN
             (SELECT t.C_ORGANIZATION_ID
                FROM (SELECT *
                        FROM LCBASE.T_ZIP_ORGANIZATION
                       WHERE D_ENDDATE > SYSDATE) t
               START WITH t.c_organization_id = nOrganizationId
              CONNECT BY t.c_organization_parent_id = PRIOR
                         t.c_organization_id);
    end if;
    return dataCount;
  exception
    when others then
      ErrMsg := 'get_dataCount: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function get_organizationName(nOrganizationId  in varchar2,
                                organizationName out varchar2,
                                ErrMsg           out varchar2) return number is
  begin
    SELECT REPLACE(REPLACE(o.v_organization_name,
                           '-北京乐卡车联科技有限公司-',
                           ''),
                   '-北京乐卡车联科技有限公司',
                   '北京乐卡车联科技有限公司')
      into organizationName
      FROM (SELECT t.c_organization_id c_organization_id,
                   SYS_CONNECT_BY_PATH(t.v_organization_name, '-') v_organization_name
              FROM (SELECT *
                      FROM LCBASE.T_ZIP_ORGANIZATION
                     WHERE D_ENDDATE > SYSDATE) t
             START WITH t.c_organization_id =
                        LOWER('997c2b49b01d4bdba3c5ea4e0f615617')
            CONNECT BY PRIOR t.c_organization_id = t.c_organization_parent_id) o
     where o.c_organization_id = nOrganizationId;
    return 0;
  exception
    when others then
      ErrMsg := 'get_organizationName: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

  function count_roleuserid(OperationUserId IN VARCHAR2,
                            ErrMsg          out varchar2) return number is
    countrole number(6);
  begin
    SELECT count(*)
      into countrole
      FROM lcoa.OA_AUT_ROLE r
      LEFT JOIN lcoa.OA_AUT_USER_ROLE ur
        ON r.C_ROLE_ID = ur.C_ROLE_ID
     WHERE r.ROLE_TYPE IN ('11', '502', '503', '504', '505', '506')
       AND ur.c_user_id = OperationUserId;
    if countrole > 0 then
      countrole := 1;
    end if;
    return countrole;
  exception
    when others then
      ErrMsg := 'count_roleuserid: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

end pkg_ins_employees_admin;
/

