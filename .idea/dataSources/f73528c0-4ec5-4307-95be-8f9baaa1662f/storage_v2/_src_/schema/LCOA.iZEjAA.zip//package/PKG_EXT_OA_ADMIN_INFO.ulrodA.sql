create package PKG_EXT_OA_ADMIN_INFO is

  -- Author  : JIAXIAOXIN
  -- Created : 2020/5/12 12:02:43
  -- Purpose : 

  -- Public type declarations

  --新增部门
  function insert_children_organization(DataInfo        in varchar2, --新增的部门名称^父部门ID
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增部门ID
                                        ErrMsg          out varchar2)
    return number;
  --修改部门名称
  function update_children_organization(DataInfo        in varchar2, --部门id^部门名称
                                        OperationUserId IN VARCHAR2,
                                        ErrMsg          out varchar2)
    return number;
  --修改部门BP,VP
  function update_organization_leader(DataInfo        in varchar2, --部门id^负责人id^负责人类型1负责人 2 BP 3 VP
                                      OperationUserId IN VARCHAR2,
                                      ErrMsg          out varchar2)
    return number;
  --删除部门
  function delete_organization(OrganizationId  in varchar2, --部门id
                               OperationUserId IN VARCHAR2,
                               ErrMsg          out varchar2) return number;

  function move_order(DataInfo        in varchar2,
                      OperationUserId IN VARCHAR2,
                      ErrMsg          out varchar2) return number;

  function get_organization_userlist(OperationUserId    IN VARCHAR2,
                                     UserOrOrganization in varchar2,
                                     OrganizationList   out sys_refcursor,
                                     UserInfoList       out sys_refcursor,
                                     ErrMsg             out varchar2)
    return number;

  function get_employees_list(OrganizationId  in varchar2,
                              status          in varchar2,
                              pageNum         in number,
                              PageSize        in number,
                              OperationUserId IN VARCHAR2,
                              DataList        out sys_refcursor,
                              owner           out varchar2,
                              BpName          out varchar2,
                              VpName          out varchar2,
                              totalPage       out number,
                              totalCount      out number,
                              dataCount       out number,
                              ErrMsg          out varchar2) return number;

  function query_employeeinfo(OperationUserId IN VARCHAR2,
                              UserId          in varchar2,
                              owner           out number,
                              bp              out number,
                              vp              out number,
                              EmployeesInfo   out sys_refcursor,
                              UserInfo        out sys_refcursor,
                              UserpicList     out sys_refcursor,
                              ErrMsg          out varchar2) return number;

  --新增成员
  function insert_employeeInfo(bp              IN integer,
                               owner           IN integer,
                               vp              IN integer,
                               employeesInfo   IN VARCHAR2,
                               userInfo        IN VARCHAR2,
                               userPicList     IN ARR_LONGSTR,
                               OperationUserId IN VARCHAR2,
                               --UserId          IN OUT VARCHAR2,
                               ErrMsg OUT VARCHAR2
                               
                               ) return number;
  --更新成员
  function update_employeeInfo(bp              IN integer,
                               owner           IN integer,
                               vp              IN integer,
                               employeesInfo   IN VARCHAR2,
                               userInfo        IN VARCHAR2,
                               userPicList     IN ARR_LONGSTR,
                               OperationUserId IN VARCHAR2,
                               --UserId          IN OUT VARCHAR2,
                               ErrMsg OUT VARCHAR2
                               
                               ) return number;
  --设置成员部门
  function update_user_organization(userId          IN lcoa.ARR_LONGSTR,
                                    organizationId  IN VARCHAR2,
                                    OperationUserId IN VARCHAR2,
                                    ErrMsg          OUT VARCHAR2)
    return number;

  --操作记录
  function operation_user_recordinfo(DATAINFO IN ARR_LONGSTR,
                                     ErrMsg   OUT VARCHAR2
                                     
                                     ) return number;

  function insert_rest_days(DataInfo        in arr_longstr,
                            OperationUserId IN VARCHAR2,
                            ErrMsg          out varchar2) return number;

end PKG_EXT_OA_ADMIN_INFO;
/

