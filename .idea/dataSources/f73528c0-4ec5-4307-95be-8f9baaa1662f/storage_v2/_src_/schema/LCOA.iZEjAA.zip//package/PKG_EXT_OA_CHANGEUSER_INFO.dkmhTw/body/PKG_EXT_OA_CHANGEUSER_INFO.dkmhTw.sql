create package body PKG_EXT_OA_CHANGEUSER_INFO is

  function ApprovalForList(RecordVo        in varchar2,
                           PageNum         in number,
                           PageSize        in number,
                           OperationUserId in varchar2,
                           GetApprovalList out sys_refcursor,
                           TotalPage       out number,
                           TotalCount      out number,
                           ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.PKG_INS_TRANSFERPOSITION_INFO.get_approval_list(RecordVo,
                                                                       PageNum,
                                                                       PageSize,
                                                                       GetApprovalList,
                                                                       TotalPage,
                                                                       TotalCount,
                                                                       ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'approvalForList',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function ApplyForList(RecordVo        in varchar2,
                        PageNum         in number,
                        PageSize        in number,
                        OperationUserId in varchar2,
                        GetApplyList    out sys_refcursor,
                        TotalPage       out number,
                        TotalCount      out number,
                        ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.PKG_INS_TRANSFERPOSITION_INFO.get_apply_list(RecordVo,
                                                                    PageNum,
                                                                    PageSize,
                                                                    GetApplyList,
                                                                    TotalPage,
                                                                    TotalCount,
                                                                    ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'applyForList',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function GetUserToDo(UserId          in varchar2,
                       PageNum         in number,
                       PageSize        in number,
                       OperationUserId out varchar2,
                       GetUserTodo     out sys_refcursor,
                       TotalPage       out number,
                       TotalCount      out number,
                       Errmsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.PKG_INS_TRANSFERPOSITION_INFO.get_user_todo(UserId,
                                                                   PageNum,
                                                                   PageSize,
                                                                   GetUserTodo,
                                                                   TotalPage,
                                                                   TotalCount,
                                                                   ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'GetUserToDo',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function QueryHireDate(UserId              in varchar2, --用户ID
                         OperationUserId     IN VARCHAR2,
                         HtHireDate          out Date, --入职时间
                         HtPromotionDate     out Date, --转正时间
                         GetApprovalUserList out sys_refcursor,
                         ErrMsg              out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.pkg_ins_Promotion_info.QueryHireDate(UserId,
                                                            HtHireDate,
                                                            HtPromotionDate,
                                                            GetApprovalUserList,
                                                            ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'QueryHireDate',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function QueryAfwPromotion(PromotionId         in varchar2, --转正信息ID
                             OperationUserId     IN VARCHAR2,
                             CUR_DATA_HIRE       out sys_refcursor, --转正信息 
                             CUR_DATA_APPRO_LIST out sys_refcursor,
                             ErrMsg              out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.pkg_ins_Promotion_info.QueryAfwPromotion(PromotionId,
                                                                CUR_DATA_HIRE,
                                                                CUR_DATA_APPRO_LIST,
                                                                ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'QueryAfwPromotion',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function SaveAfwPromotion(DataInfo        in varchar2,
                            OperationUserId IN VARCHAR2,
                            NextApproUserID out varchar2,
                            ErrMsg          out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 2;
      n_result := lcoa.pkg_ins_Promotion_info.SaveAfwPromotion(DataInfo,
                                                               OperationUserId,
                                                               NextApproUserID,
                                                               ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'SaveAfwPromotion',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  /*  function queryPostAndOrganization(User_id         in char,
                                    Post_info       out sys_refcursor,
                                    OperationUserId IN OUT VARCHAR2,
                                    ErrMsg          OUT VARCHAR2)
    return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 1;
      n_result := lcoa.PKG_INS_TRANSFERPOSITION_INFO.query_PostAndOrganization_info(User_id,
                                                                                Post_info,
                                                                                OperationUserId,
                                                                                ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'queryPostAndOrganization',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;*/

  function save_AfwAdjustpost_Info(DataInfo        in varchar2,
                                   OperationUserId IN OUT VARCHAR2,
                                   DataID1         out varchar2,
                                   ErrMsg          OUT VARCHAR2)
    return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 2;
      n_result := lcoa.PKG_INS_TRANSFERPOSITION_INFO.save_AfwAdjustpost_Info(DataInfo,
                                                                             OperationUserId,
                                                                             DataID1,
                                                                             ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'saveAfwAdjustpostInfo',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function query_AfwAdjustpost_info(Adjust_id            in char,
                                    OperationUserId      IN VARCHAR2,
                                    AdjustPost_Info      out sys_refcursor,
                                    transferApplyForPost out sys_refcursor,
                                    ErrMsg               OUT VARCHAR2)
    return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 2;
      n_result := lcoa.PKG_INS_TRANSFERPOSITION_INFO.query_AfwAdjustpost_info(Adjust_id,
                                                                              OperationUserId,
                                                                              AdjustPost_Info,
                                                                              transferApplyForPost,
                                                                              ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'queryAfwAdjustpost',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function Create_ToDo_info(UserId_List out sys_refcursor,
                            ErrMsg      out varchar2) return number is
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 2;
      n_result := lcoa.pkg_ins_Promotion_info.Create_ToDo_info(UserId_List,
                                                               ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg := pkg_common.g_errmsg_common;
        --ErrMsg   := 'get_organization_userlist: ' || SQLCODE || ',' ||
        --SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog('todo_crontab',
                                  'Create_ToDo_info',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

end PKG_EXT_OA_CHANGEUSER_INFO;
/

