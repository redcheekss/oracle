create package body PKG_JXX_repayment_info is
  ---测试函数的支持
  function add_test_afw_loan_info(data_values      in ARR_LONGSTR,
                                  out_v_c_id       out varchar2,
                                  out_V_FLOWNUMBER out varchar2,
                                  ErrMsg           OUT VARCHAR2)
    return number is
    v_date_value PKG_COMMON.ARR_LONGSTR;
    row_count    integer;
    V_FLOWNUMBER char(32);
    v_c_id       char(32);
    tempOut_c_id varchar2(2000);
  begin

    row_count := data_values.count;
    for i in 1 .. row_count loop
      v_date_value := PKG_COMMON.Split(data_values(i), '^');
      V_FLOWNUMBER := pkg_common.GetFlowNumber('JK', 4); --生成借款单号
      v_c_id       := lower(sys_guid());
      if i < row_count then
        tempOut_c_id := (tempOut_c_id || v_c_id || ',');
      else
        tempOut_c_id := (tempOut_c_id || v_c_id);
      end if;
      INSERT INTO LCOA.OA_AFW_LOAN_INFO
        (C_ID, --借款id
         V_FLOW_NUMBER, --借款单号
         C_USER_ID, --用户id
         N_AMOUNT, --借款金额
         V_CAUSE, --申请理由
         N_LOAN_TYPE, --借款类型（备用金、个人）
         D_PLAN_REPAYMENT_DATE, --申请借款时填写的还款日期
         D_EXTENSION_DATE, --延期还款日期（应该还款日期，插入时该日期等于D_PLAN_REPAYMENT_DATE）
         N_EXTENSION_TIMES, --延期次数
         N_REPAID_AMOUNT, --已还款金额
         N_STATUS, --状态 0为作废
         N_APPROVAL_STATUS, --模拟时，默认为5 审批完成。
         N_PAYOFF_STATUS, --0未还清 1已还清
         D_APPLY_TIME, --申请时间
         C_PAYMENT_ID, --对应支付记录表(oa_afw_payment_record)主键id
         N_PAYMENT_TYPE, --1线下支付（线下支付时，支付id为空） 2线上支付
         C_USER_CORP_ID, --所属主体
         C_PAYMENT_CORP_ID, --支付主体
         N_UNCONFIRMED_AMOUNT, --待确认还款金额
         D_PAYOFF_TIME --借款还清时间

         )
      VALUES
        (v_c_id,
         V_FLOWNUMBER,
         v_date_value(3), --贾晓新
         v_date_value(4),
         v_date_value(5),
         v_date_value(6),
         to_date(v_date_value(7), 'yyyymmddhh24miss'), --还款日期
         to_date(v_date_value(8), 'yyyymmddhh24miss'),
         v_date_value(9),
         v_date_value(10), --初次借款   已还款金额为0
         v_date_value(11),
         v_date_value(12),
         v_date_value(13),
         to_date(v_date_value(14), 'yyyymmddhh24miss'), --申请时间
         null,
         1,
         '0144429b172f4cd8a4112cdea01e7c3f',
         null,
         0, --初次借款，待确认金额为 0
         null);
    end loop;
    out_v_c_id       := tempOut_c_id;
    out_V_FLOWNUMBER := V_FLOWNUMBER;
    ErrMsg           := '成功！';
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'test' || '新增借款款测试单: ' || sqlcode || ',' || sqlerrm;
      rollback;
      return - 1;
  end add_test_afw_loan_info;

  

end PKG_JXX_repayment_info;
/

