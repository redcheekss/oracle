create package PKG_ZL_TEST is
 procedure TestInsertORG(datainfo in varchar2,
                          org_id out varchar2,
                          msg out   varchar2); 

end PKG_ZL_TEST;
/

