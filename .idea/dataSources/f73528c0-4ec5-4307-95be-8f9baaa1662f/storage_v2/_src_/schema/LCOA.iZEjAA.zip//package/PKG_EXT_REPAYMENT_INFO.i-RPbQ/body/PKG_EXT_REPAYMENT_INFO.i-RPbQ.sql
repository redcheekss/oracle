create package body pkg_ext_repayment_info is

  --1 新增还款确认单
  --list<loanId,amount,picAddress>
  function add_installRepayment(data_value   IN ARR_LONGSTR,
                                data_images  in ARR_LONGSTR,
                                operation_id in char,
                                c_cursor     out sys_refcursor,
                                ErrMsg       OUT VARCHAR2) RETURN NUMBER
  
   is
    n_optype   number(1);
    n_result   integer;
    time_start timestamp;
    time_end   timestamp;
    n_status   number(1) := 0;
    n_duration number(10);
  begin
    time_start := systimestamp; --构建开始时间
    n_optype   := 2; --插入操作
    begin
      n_result := pkg_ins_repayment_info.add_installRepayment(data_value,
                                                              data_images,
                                                              operation_id,
                                                              c_cursor,
                                                              ErrMsg);
      if n_result = 0 then
        commit;
      else
        rollback;
      end if;
    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception; --返回错误码  -20998;
        ErrMsg   := pkg_common.g_errmsg_common; --异常提示    --数据异常
        rollback; --回滚
    end;
  
    --构建结束时间   
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := -1;
    end if;
    PKG_COMMON.InsertOperationLog(operation_id,
                                  '.add_installRepayment',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  
  end add_installRepayment;

  --2报销还款-生成还款单 《报销生成还款单》
  --list<loanId,amount：报销id，还款总金额>
  function add_installRepayment2(data_value   IN varchar2,
                                 operation_id in char,
                                 c_cursor     out sys_refcursor,
                                 ErrMsg       OUT VARCHAR2) RETURN NUMBER
  
   is
    n_optype   number(1);
    n_result   integer;
    time_start timestamp;
    time_end   timestamp;
    n_status   number(1) := 0;
    n_duration number(10);
  begin
    time_start := systimestamp; --构建开始时间
    n_optype   := 2; --插入操作
    begin
      n_result := pkg_ins_repayment_info.add_installRepayment2(data_value,
                                                               operation_id,
                                                               c_cursor,
                                                               ErrMsg);
      if n_result = 0 then
        commit;
      else
        rollback;
      end if;
    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception; --返回错误码  -20998;
        ErrMsg   := pkg_common.g_errmsg_common; --异常提示    --数据异常
        rollback; --回滚
    end;
  
    --构建结束时间   
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := -1;
    end if;
    PKG_COMMON.InsertOperationLog(operation_id,
                                  '.add_installRepayment2',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  
  end add_installRepayment2;

  --3 确认还款单详情
  function getRepaymentInfo(dataId                   in varchar2,
                            operationId              in char,
                            OaAfwRepaymentInfoEntity OUT SYS_REFCURSOR,
                            loanList                 OUT SYS_REFCURSOR,
                            files                    OUT SYS_REFCURSOR,
                            ErrMsg                   OUT VARCHAR2)
    RETURN NUMBER is
    n_optype   number(1);
    n_result   integer;
    time_start timestamp;
    time_end   timestamp;
    n_status   number(1) := 0;
    n_duration number(10);
  begin
    time_start := systimestamp; --构建开始时间
    n_optype   := 2; --插入操作
    begin
      n_result := pkg_ins_repayment_info.getRepaymentInfo(dataId,
                                                          operationId,
                                                          OaAfwRepaymentInfoEntity,
                                                          loanList,
                                                          files,
                                                          ErrMsg);
      if n_result = 0 then
        ErrMsg := '查询成功！';
      else
        rollback;
      end if;
    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception; --返回错误码  -20998;
        ErrMsg   := pkg_common.g_errmsg_common; --异常提示    --数据异常
        rollback; --回滚
    end;
  
    --构建结束时间   
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := -1;
    end if;
    PKG_COMMON.InsertOperationLog(operationId,
                                  'getRepaymentInfo',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  
  end getRepaymentInfo;

  --4 确认还款确认单
  /*
   参数
   list<借款单id，,时间:arrivalTime>
   逻辑：
     - 关系表中更新入账时间
     - 借款单中更新已还金额 是否还清
     - 确认收款后，申请人会收到一条还款成功的通知
     - 确认收款后，我的记录中该条数据的状态同步更新为“已还款”
   return 回款是否成。
  */

  function passRepayment(Repayment   IN ARR_LONGSTR,
	                       v_id        in char,
                         operationId in char,
                         c_cursor    out sys_refcursor,
                         ErrMsg      OUT VARCHAR2)
  
   RETURN NUMBER is
    n_optype   number(1);
    n_result   integer;
    time_start timestamp;
    time_end   timestamp;
    n_status   number(1) := 0;
    n_duration number(10);
  begin
    time_start := systimestamp; --构建开始时间
    n_optype   := 3; --更新操作
    begin
      n_result := pkg_ins_repayment_info.passRepayment(Repayment,
			                                                 v_id,
                                                       operationId,
                                                       c_cursor,
                                                       ErrMsg);
      if n_result = 0 then
        commit;
      else
        rollback;
        n_result := pkg_common.g_errcode_exception;
      end if;
    
    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception; --返回错误码  -20998;
        ErrMsg   := pkg_common.g_errmsg_common; --异常提示    --数据异常
        rollback;
    end;
    --构建结束时间   
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := -1;
    end if;
    PKG_COMMON.InsertOperationLog(operationId,
                                  'passRepayment',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  end passRepayment;

  --5 确认还款确认单(报销)
  /*
   参数list<报销id                                                                                                                                                                                                                          ,arrivalTime>
   逻辑：
     - 关系表中更新入账时间
     - 借款单中更新已还金额 是否还清
  
   return 回款是否成。 还款单号，
  */

  function passRepayment2(Repayment   IN varchar2,
                          operationId in char,
                          ErrMsg      OUT VARCHAR2)
  
   RETURN NUMBER is
    n_optype   number(1);
    n_result   integer;
    time_start timestamp;
    time_end   timestamp;
    n_status   number(1) := 0;
    n_duration number(10);
  begin
    time_start := systimestamp; --构建开始时间
    n_optype   := 2; --插入操作
    begin
      n_result := pkg_ins_repayment_info.passRepayment2(Repayment,
                                                        operationId,
                                                        ErrMsg);
      if n_result = 0 then
        commit;
      else
        rollback;
        n_result := pkg_common.g_result_status;
      end if;
    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception; --返回错误码  -20998;
        ErrMsg   := pkg_common.g_errmsg_common; --异常提示    --数据异常
        rollback; --回滚
    end;
    --构建日期
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := -1;
    end if;
    PKG_COMMON.InsertOperationLog(operationId,
                                  '.add_installRepayment',
                                  n_optype,
                                  n_status,
                                  n_duration);
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  end passRepayment2;

  --6 收款列表
  function get_Payment_list(data_value   in varchar2,
                            pageNum      in number,
                            PageSize     in number,
                            operationId  in char,
                            getapplylist out sys_refcursor,
                            totalPage    out number,
                            totalCount   out number,
                            errmsg       out varchar2)
  
   RETURN NUMBER is
    n_optype   number(1);
    n_result   integer;
    time_start timestamp;
    time_end   timestamp;
    n_status   number(1) := 0;
    n_duration number(10);
  
  begin
    time_start := systimestamp; --构建开始时间
    n_optype   := 2; --插入操作
    begin
      n_result := pkg_ins_repayment_info.get_Payment_list(data_value,
                                                          pageNum,
                                                          PageSize,
                                                          operationId,
                                                          getapplylist,
                                                          totalPage,
                                                          totalCount,
                                                          errmsg);
    
      if n_result = 0 then
        commit;
      else
        rollback;
        n_result := pkg_common.g_result_status;
      end if;
    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception; --返回错误码  -20998;
        ErrMsg   := pkg_common.g_errmsg_common; --异常提示    --数据异常
        rollback;
    end;
    --构建结束时间  
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := -1;
    end if;
    PKG_COMMON.InsertOperationLog(operationId,
                                  'get_Payment_list',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  
  end get_Payment_list;

  --重置 
  function ResetSkip(ApprovalUserId in varchar2, ErrMsg out varchar2)
    return number is
    n_optype   number(1);
    n_result   integer;
    time_start timestamp;
    time_end   timestamp;
    n_status   number(1) := 0;
    n_duration number(10);
  begin
    time_start := systimestamp; --构建开始时间
    n_optype   := 3; --更新操作
    begin
      n_result := pkg_ins_repayment_info.ResetSkip(ApprovalUserId, ErrMsg);
      if n_result = 0 then
        commit;
      else
        rollback;
        n_result := pkg_common.g_result_status;
      end if;
    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception; --返回错误码  -20998;
        ErrMsg   := pkg_common.g_errmsg_common; --异常提示    --数据异常
        rollback;
    end;
    --构建结束时间  
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := -1;
    end if;
    PKG_COMMON.InsertOperationLog(ApprovalUserId,
                                  'ResetSkip',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  end ResetSkip;

  --跳过
  function Target_Skip(repay_id     in varchar2,
                       operation_id in char,
                       ErrMsg       out varchar2) return number is
    n_optype   number(1);
    n_result   integer;
    time_start timestamp;
    time_end   timestamp;
    n_status   number(1) := 0;
    n_duration number(10);
  begin
    time_start := systimestamp; --构建开始时间
    n_optype   := 3; --更新操作
    begin
      n_result := pkg_ins_repayment_info.Target_Skip(repay_id,
                                                     operation_id,
                                                     ErrMsg);
      if n_result = 0 then
        commit;
      else
        rollback;
        n_result := pkg_common.g_result_status;
      end if;
    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception; --返回错误码  -20998;
        ErrMsg   := pkg_common.g_errmsg_common; --异常提示    --数据异常
        rollback;
    end;
    --构建结束时间  
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := -1;
    end if;
    PKG_COMMON.InsertOperationLog(operation_id,
                                  'Target_Skip',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  end Target_Skip;

  function no_loanList(OperationUserId in varchar2,
                       loanList        OUT SYS_REFCURSOR,
                       loanFiles       OUT SYS_REFCURSOR,
                       ErrMsg          OUT VARCHAR2) RETURN NUMBER is
    n_optype   number(1);
    n_result   integer;
    time_start timestamp;
    time_end   timestamp;
    n_status   number(1) := 0;
    n_duration number(10);
  
  begin
    time_start := systimestamp; --构建开始时间
    n_optype   := 1; --插入操作
    begin
      n_result := pkg_ins_repayment_info.no_loanList(OperationUserId,
                                                     loanList,
                                                     loanFiles,
                                                     errmsg);
    
    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception; --返回错误码  -20998;
        ErrMsg   := pkg_common.g_errmsg_common; --异常提示    --数据异常
        rollback;
    end;
    --构建结束时间   
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := -1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'no_loanList',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  
  end;
	
	
	--clear 内容
	function  clear_content_info(V_CLAIM_FORMID in char, operation_id in char,ErrMsg out varchar2) 
	return number 
	is 
	  n_optype   number(1);
    n_result   integer;
    time_start timestamp;
    time_end   timestamp;
    n_status   number(1) := 0;
    n_duration number(10);
	begin
    time_start := systimestamp; --构建开始时间
    n_optype   := 1; --插入操作
    begin
        n_result := pkg_ins_repayment_info.clear_content_info(V_CLAIM_FORMID,operation_id,ErrMsg);
       if n_result = 0 then
           commit;
      else
           rollback;
        n_result := pkg_common.g_errcode_exception;
      end if;
    exception
      WHEN OTHERS THEN
        n_result := pkg_common.g_errcode_exception; --返回错误码  -20998;
        ErrMsg   := pkg_common.g_errmsg_common; --异常提示    --数据异常
        rollback;
    end;
    --构建结束时间   
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
  
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := -1;
    end if;
    PKG_COMMON.InsertOperationLog(operation_id,
                                  'clear_content_info',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
    else
      return n_result;
    end if;
  
  end;
end pkg_ext_repayment_info;
/

