create package PKG_EXT_USER_INFO is
  FUNCTION OAGetUserInfo(UserID   IN VARCHAR2,
                         User_CUR OUT sys_refcursor,
                         ErrMsg   OUT VARCHAR2) return number;

end PKG_EXT_USER_INFO;
/

