create package PKG_jiaxiaoxin_MEET_INFO as

    /*
       1 业务操作
             Add_OA_SDE_MEETING_INFO  会议纪要信息表
       time
             2020-05-06
       author
             jiaxinxin

    */

    procedure ADD_MEETING_INFO(SDE_MEETING_INFO IN varchar2,
                               meeting_id       OUT varchar2,
                               ErrMsg           OUT VARCHAR2);

    /*
       1 业务操作
             UPDATE_OA_SDE_MEETING_INFO  会议纪要信息表
       time
             2020-05-06
       author
             jiaxinxin

    */
    procedure UPDATE_MEETING_INFO(SDE_MEETING_INFO IN varchar2,
                                  meeting_id       IN CHAR,
                                  ErrMsg           OUT VARCHAR2);

    /*
     2 业务操作
           ADD_SDE_ATTENDEE_LIST_INFO   是否缺席表
     time
           2020-05-06
     author
           jiaxinxin

    */
    procedure ADD_SDE_ATTENDEE_LIST_INFO(SDE_ATTENDEE_LIST IN ARR_LONGSTR,
                                         ErrMsg            OUT VARCHAR2);

    /*
     2 业务操作
           UPDATE_SDE_ATTENDEE_LIST_INFO   是否缺席表
     time
           2020-05-06
     author
           jiaxinxin

    */
    procedure UPDATE_SDE_ATTENDEE_LIST_INFO(SDE_ATTENDEE_LIST IN ARR_LONGSTR,
                                            metting_id        IN char,
                                            ErrMsg            OUT VARCHAR2);

    /*
       业务操作
            3 OA_SDE_MEETING_CONTENT_LIST  会议纪要内容列表
       time
             2020-05-06
       author
             jiaxinxin

    */
    procedure ADD_SDE_MEETING_CONTENT_LIST(SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                           metting_id               IN char,
                                           ErrMsg                   OUT VARCHAR2);

    /*
       业务操作
            3 update_OA_SDE_MEETING_CONTENT_LIST  会议纪要内容列表
       time
             2020-05-06
       author
             jiaxinxin

    */
    procedure UP_SDE_MEETING_CONTENT_LIST(SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                          metting_id               IN char,
                                          ErrMsg                   OUT VARCHAR2);

    /*
       4 业务操作
             会议纪要待办事项  会议纪要待办事项
       time
             2020-05-06
       author
             jiaxinxin

    */

    procedure ADD_SDE_TODO_LIST(OA_SDE_TODO_LIST IN ARR_LONGSTR,
                                meeting_id       in char,
                                ErrMsg           OUT VARCHAR2

                                );

    /*
       4 业务操作
             会议纪要待办事项  会议纪要待办事项
       time
             2020-05-06
       author
             jiaxinxin

    */

    procedure UPDATE_SDE_TODO_LIST(OA_SDE_TODO_LIST IN ARR_LONGSTR,
                                   meeting_id       in char,
                                   ErrMsg           OUT VARCHAR2

                                   );

    /*
       5 业务操作
             USER_UPLOAD_INFO 附件信息表
       time
             2020-04-15
       author
             jiaxinxin

    */
    PROCEDURE ADD_USER_UPLOAD_INFO(USER_UPLOAD_INFO IN ARR_LONGSTR,
                                   meeting_id       in char,
                                   ErrMsg           OUT VARCHAR2

                                   );

    /*
       5 业务操作
             USER_UPLOAD_INFO 附件信息表
       time
             2020-04-15
       author
             jiaxinxin

    */
    PROCEDURE UPDATE_USER_UPLOAD_INFO(USER_UPLOAD_INFO IN ARR_LONGSTR,
                                      meeting_id       in char,
                                      ErrMsg           OUT VARCHAR2

                                      );

end PKG_jiaxiaoxin_MEET_INFO;
/

