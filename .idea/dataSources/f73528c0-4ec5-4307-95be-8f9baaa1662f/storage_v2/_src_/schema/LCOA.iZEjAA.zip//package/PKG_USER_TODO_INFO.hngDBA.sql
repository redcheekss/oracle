create package PKG_USER_TODO_INFO as
   function Get_UserToDoInfo (UserId IN VARCHAR2,OperationUserId IN VARCHAR2,PageSize IN NUMBER,PageCur IN NUMBER,CUR_DATA OUT SYS_REFCURSOR,OutRows OUT number,OutPageCount OUT number) return NUMBER;
end PKG_USER_TODO_INFO;

/

