create package      pkg_zhaochao_test is

  -- Author  : ROCK
  -- Created : 2020/4/2 14:35:27
  -- Purpose : 

  procedure Insert_Approval_Flow(ApprovalId          in varchar2,
                                 UserId              in varchar2,
                                 ApprovalType        in number,
                                 FirstApprovalUserId out varchar2);
                                 
  procedure Insert_Approval_Next_Todo_Info(ApprovalId in varchar2,
                                           PreFlowId  in varchar2,
                                           TodoTitle  in varchar2);

end pkg_zhaochao_test;
/

