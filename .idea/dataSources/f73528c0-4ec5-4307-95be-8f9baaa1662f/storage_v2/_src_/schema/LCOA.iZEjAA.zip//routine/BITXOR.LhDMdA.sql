create FUNCTION BITXOR(nExpression1 number, nExpression2 number)
RETURN number
IS

BEGIN
   RETURN BITOR(nExpression1,nExpression2) - BITAND(nExpression1,nExpression2);
END BITXOR;
/

