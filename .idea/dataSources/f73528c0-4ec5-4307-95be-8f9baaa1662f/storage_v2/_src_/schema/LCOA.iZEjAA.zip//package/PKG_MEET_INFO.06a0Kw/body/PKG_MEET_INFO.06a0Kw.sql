create package body PKG_MEET_info as

    /*
       业务操作
             --获取会议基础信息
       time
             2020-04-05
       author
             jiaxinxin
    
    */
    procedure meetingmanager_GetMeetBaseInfo(operationUserId in char,
                                             rooms_result    out SYS_REFCURSOR) is
    begin
        open rooms_result for
            select T.V_MROOM_NAME
              from LCOA.OA_SDE_MEETINGROOM_INFO T --会议室基础信息表
              left join LCOA.OA_SDE_SCHEDULE_INFO S --用户日程信息表
                on T.C_MROOM_NO = S.c_Mroom_No
            
              left join LCBASE.t_zip_User U --用户基础信息表
                on S.C_SCH_USER_ID = U.c_User_Id and u.d_enddate > sysdate
             where U.C_USER_ID = operationUserId;
        --异常处理
    exception
        when NO_DATA_FOUND THEN
            dbms_output.put_line('没有查询到任何数据');
        
    end meetingmanager_GetMeetBaseInfo;

    /*
       业务操作
             --获取会议类型
       time
             2020-04-05
       author
             jiaxinxin
    
    */
    procedure meetingmanager_GetMeetTypeInfo(operationUserId in char,
                                             N_MEETING_TYPE  out SYS_REFCURSOR) is
    begin
        open N_MEETING_TYPE for
            select case T.N_MEETING_TYPE
                       when 1 then
                        '线上会议'
                       when 2 then
                        '线下会议'
                   end
              from LCOA.OA_SDE_SCHEDULE_INFO T
              left join LCBASE.t_zip_User U
                on T.C_SCH_USER_ID = U.C_USER_ID and u.d_enddate >sysdate
             where U.C_USER_ID = operationUserId;
        --异常处理
    exception
        when NO_DATA_FOUND THEN
            dbms_output.put_line('没有查询到任何数据');
        
    end meetingmanager_GetMeetTypeInfo;

    /*
       业务操作
             获取参会人
       time
             2020-04-05
       author
             jiaxinxin
    
    */
    procedure meetingmanager_GetPeopleInfo(operationUserId in char,
                                           c_meting_id     in char,
                                           V_USER_NAMES    out SYS_REFCURSOR) is
    begin
        open V_USER_NAMES for
            select T.V_USER_NAME -- 参会用户
              from LCOA.OA_SDE_ATTENDEE_LIST TM
              left join LCBASE.t_zip_User T
                on TM.C_USER_ID = T.c_User_Id and t.d_enddate > sysdate
             where T.c_User_Id = operationUserId
               and TM.C_MEETING_ID = c_meting_id;
        --异常处理
    exception
        when NO_DATA_FOUND THEN
            dbms_output.put_line('没有查询到任何数据');
    end meetingmanager_GetPeopleInfo;

    /*
       业务操作
             --test 测试
       time
             2020-04-05
       author
             jiaxinxin
    
    */
    function test(name in varchar2) RETURN NUMBER IS
    
        V_MEETING_CLERK_ID varchar2(50);
    
    BEGIN
        dbms_output.put_line('查询到数据' || name);
    
        select C_MEETING_CLERK_ID
          into V_MEETING_CLERK_ID
          from LCOA.oa_sde_schedule_info
         where C_SCH_ID =
               '4e0129f582334c4fbf8801c2cf7e6f6d'
           and rownum = 1;
    
        dbms_output.put_line('dddd------------------------------------');
    
        if V_MEETING_CLERK_ID is not null then
            -- 判断会议记录人是否为空
            dbms_output.put_line('-----------------------------------------------------');
        
        else
        
            dbms_output.put_line('----------------------------------------OA_TDO_TODO_INFO 信息表C_MEETING_CLERK_ID is not null------------------------');
        
        end if;
    
        return 1;
    end test;

    /*
       业务操作
             Add_OA_SDE_MEETING_INFO  会议纪要信息表
    
       return 0 失败  1 为插入成功，2 为更新成功。
    
       time
             2020-04-15
       author
             jiaxinxin
    
    
    
    */

    function add_meeting_info(SDE_MEETING_INFO     IN varchar2,
                              is_exists_meeting_id out varchar2,
                              meeting_id           out varchar2,
                              meeting_title        out varchar2,
                              V_SCH_ID             out varchar2,
                              ErrMsg               OUT VARCHAR2)
        return number is
    
        V_SDE_MEETING_INFO PKG_COMMON.ARR_LONGSTR; -- 接收会议基础新
        result_int         number := 0; --记录返回值 1 成功，0为失败。
        v_meeting_id       varchar2(50); --记录会议id
        count_rows         integer := 0; --记录插入的行数
        v_meeting_title    varchar2(100);
        C_SCH_ID           varchar2(50); --存储SCH_id
    begin
        V_SDE_MEETING_INFO := PKG_COMMON.Split(SDE_MEETING_INFO,
                                               '^'); -- 获取会议信息并使切分数据
        --加入判断
        v_meeting_id := V_SDE_MEETING_INFO(1);
        SELECT count(*)
          into count_rows
          FROM LCOA.OA_SDE_MEETING_INFO
         where C_MEETING_ID = v_meeting_id;
    
        if count_rows > 0 then
            --更新
            UPDATE LCOA.OA_SDE_MEETING_INFO
               SET C_SCH_ID             = V_SDE_MEETING_INFO(2),
                   N_SECRET_TYPE        = V_SDE_MEETING_INFO(3),
                   N_MEETING_TYPE       = V_SDE_MEETING_INFO(4),
                   V_MEETING_TITLE      = V_SDE_MEETING_INFO(5),
                   V_CLERK_NAME         = V_SDE_MEETING_INFO(6),
                   D_MEETING_START_TIME = to_date(V_SDE_MEETING_INFO(7),
                                                  'yyyymmddhh24miss'),
                   D_MEETING_END_TIME   = to_date(V_SDE_MEETING_INFO(8),
                                                  'yyyymmddhh24miss'),
                   V_MEETING_ROOM       = V_SDE_MEETING_INFO(9),
                   N_STATUS             = V_SDE_MEETING_INFO(10)
            
             WHERE C_MEETING_ID = v_meeting_id;
        
            is_exists_meeting_id := v_meeting_id; --记录更新会议id
            result_int           := 2;
            ErrMsg               := '更新成功';
            count_rows           := sql%rowcount;
            dbms_output.put_line('result_int' ||
                                 result_int || 'ErrMsg' ||
                                 ErrMsg || '影响的行数' ||
                                 count_rows);
        
            return result_int;
        
        else
            -- 1.插入会议纪要信息表
            INSERT INTO LCOA.OA_SDE_MEETING_INFO
                (C_MEETING_ID,
                 C_SCH_ID,
                 N_SECRET_TYPE,
                 N_MEETING_TYPE,
                 V_MEETING_TITLE,
                 V_CLERK_NAME,
                 D_MEETING_START_TIME,
                 D_MEETING_END_TIME,
                 V_MEETING_ROOM,
                 N_STATUS)
            VALUES
                (V_SDE_MEETING_INFO(1),
                 V_SDE_MEETING_INFO(2),
                 V_SDE_MEETING_INFO(3),
                 V_SDE_MEETING_INFO(4),
                 V_SDE_MEETING_INFO(5),
                 V_SDE_MEETING_INFO(6),
                 to_date(V_SDE_MEETING_INFO(7),
                         'yyyymmddhh24miss'),
                 to_date(V_SDE_MEETING_INFO(8),
                         'yyyymmddhh24miss'),
                 V_SDE_MEETING_INFO(9),
                 V_SDE_MEETING_INFO(10));
            --is_exists_meeting_id := ''; --记录更新会议id
            meeting_id := V_SDE_MEETING_INFO(1);
        
            --更新代办
            UPDATE OA_TDO_TODO_INFO s
               SET s.V_TODO_TITLE = '【' ||
                                    V_SDE_MEETING_INFO(5) ||
                                    '】会议纪要'
             WHERE C_TODO_DATA_ID = V_SDE_MEETING_INFO(1);
        
            UPDATE lcoa.OA_SDE_SCHEDULE_INFO
               SET V_SCH_TITLE = V_SDE_MEETING_INFO(5)
             WHERE C_SCH_ID =
                   (SELECT OSSF.C_SCH_ID
                      FROM lcoa.OA_SDE_SCHEDULING_FLOW OSSF
                     WHERE OSSF.C_FLOW_ID =
                           V_SDE_MEETING_INFO(1));
        
            --commit;
            result_int    := 1;
            meeting_title := v_meeting_title;
            return result_int;
        end if;
    
    end add_meeting_info;

    /*
       2 业务操作
            OA_SDE_ATTENDEE_LIST  是否缺席表
       time
             2020-04-15
       author
             jiaxinxin
    
    */
    function ADD_SDE_ATTENDEE_LIST(SDE_ATTENDEE_LIST    IN ARR_LONGSTR,
                                   is_exists_meeting_id in varchar2,
                                   metting_id           IN char,
                                   ErrMsg               OUT VARCHAR2)
        return number
    
     is
    
        V_SDE_ATTENDEE_LIST PKG_COMMON.ARR_LONGSTR; -- 接收会议缺席表
        total               integer; --记录执行插入总条数
        count_rows          integer := 0; --记录插入的行数
        result_int          number := 0;
        v_meeting_id        varchar2(50);
    begin
    
        if is_exists_meeting_id is not null then
        
            dbms_output.put_line('--------会议id 存在，执行删除再次插入操作--------------------------------------------');
            --执行删除操作
            DELETE FROM LCOA.OA_SDE_ATTENDEE_LIST
             WHERE C_MEETING_ID = is_exists_meeting_id;
        
            dbms_output.put_line('会议id 存在，删除以前的旧会议缺席列表数据：' ||
                                 sql%rowcount ||
                                 '行....................');
        
            --执行插入操作
            total := SDE_ATTENDEE_LIST.count;
        
            for i in 1 .. total loop
                V_SDE_ATTENDEE_LIST := PKG_COMMON.Split(SDE_ATTENDEE_LIST(i),
                                                        '^'); --获取第一条记录
            
                if V_SDE_ATTENDEE_LIST(1) is not null and
                   V_SDE_ATTENDEE_LIST(2) is not null then
                    INSERT INTO LCOA.OA_SDE_ATTENDEE_LIST
                        (C_MEETING_ID, --会议ID
                         C_USER_ID, --参会人ID
                         N_ABSENT_FLAG) --是否缺席
                    VALUES
                        (trim(is_exists_meeting_id),
                         trim(V_SDE_ATTENDEE_LIST(1)),
                         V_SDE_ATTENDEE_LIST(2));
                
                    count_rows := (count_rows +
                                  sql%rowcount);
                end if;
            
            end loop;
            dbms_output.put_line('update操作会议缺席信息表：' ||
                                 count_rows ||
                                 '行数据..........................................');
            dbms_output.put_line('update操作会议缺席信息表..............完成...................................................');
            dbms_output.put_line('---------------------------------------------------------------------------------------------');
        
            dbms_output.put_line('update会议纪要内容列表：开始................................................................');
            --commit;
            result_int := 1;
            ErrMsg     := 0;
            return result_int;
        
        else
            v_meeting_id := metting_id;
            dbms_output.put_line('-----------------------------------------------------------------------------------------');
            dbms_output.put_line('操作会议缺席信息表：开始.................................................................');
        
            total := SDE_ATTENDEE_LIST.count;
        
            for i in 1 .. total loop
                V_SDE_ATTENDEE_LIST := PKG_COMMON.Split(SDE_ATTENDEE_LIST(i),
                                                        '^'); --获取第一条记录
                if V_SDE_ATTENDEE_LIST(1) is not null and
                   V_SDE_ATTENDEE_LIST(2) is not null then
                
                    dbms_output.put_line('插入的值：参会人id ' ||
                                         V_SDE_ATTENDEE_LIST(1) ||
                                         '是否缺席：' ||
                                         V_SDE_ATTENDEE_LIST(2));
                
                    INSERT INTO LCOA.OA_SDE_ATTENDEE_LIST
                        (C_MEETING_ID, --会议ID
                         C_USER_ID, --参会人ID
                         N_ABSENT_FLAG) --是否缺席
                    VALUES
                        (v_meeting_id,
                         V_SDE_ATTENDEE_LIST(1),
                         V_SDE_ATTENDEE_LIST(2));
                
                    count_rows := (count_rows +
                                  sql%rowcount);
                
                end if;
            
            end loop;
            dbms_output.put_line('操作会议缺席信息表：' ||
                                 count_rows ||
                                 '行数据.........................................');
            dbms_output.put_line('操作会议缺席信息表..............' ||
                                 '完成................................................');
            dbms_output.put_line('-----------------------------------------------------------------------------------.-----');
        
            result_int := 1;
            ErrMsg     := 0;
            return result_int;
        end if;
    
    end ADD_SDE_ATTENDEE_LIST;

    /*
       业务操作
             3 OA_SDE_MEETING_CONTENT_LIST  会议纪要内容列表
       time
             2020-04-15
       author
             jiaxinxin
    
    */
    function add_SDE_MEETING_CONTENT_LIST(SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                          is_exist_meeting_id      in char,
                                          C_MEETING_ID             in char,
                                          ErrMsg                   OUT VARCHAR2)
        return number
    
     is
    
        V_SDE_MEETING_CONTENT_LIST PKG_COMMON.ARR_LONGSTR; -- 会议纪要内容列表
    
        count_rows integer := 0; --记录插入的行数
        result_int number := 0; --记录返回值 1 成功，0为失败。
        errcode    VARCHAR2(50); --保存错误代码
        --meeting_id    char(32);    -- 保存会议id
        C_USER_ID     varchar2(32);
        meeting_tille varchar2(50);
        total         integer; --记录会议纪要内容条数
    
    begin
    
        total := SDE_MEETING_CONTENT_LIST.count;
    
        if is_exist_meeting_id is not null then
            dbms_output.put_line('--------会议id 存在，执行删除再次插入操作--------------------------------------------');
            --删除数据
            delete from LCOA.OA_SDE_MEETING_CONTENT_LIST
             where C_MEETING_ID = is_exist_meeting_id;
            dbms_output.put_line('删除以前的旧数据：.....................................................' ||
                                 sql%rowcount);
        
            --执行更新操作
            for i in 1 .. total loop
                V_SDE_MEETING_CONTENT_LIST := PKG_COMMON.Split(SDE_MEETING_CONTENT_LIST(i),
                                                               '^');
            
                INSERT INTO LCOA.OA_SDE_MEETING_CONTENT_LIST
                    (C_ID, --数据id
                     C_MEETING_ID, --会议ID
                     V_CONTENT, --内容
                     D_INPUT_TIME, --录入时间
                     N_SEQ --序号
                     )
                VALUES
                    (lower(sys_guid()),
                     is_exist_meeting_id,
                     V_SDE_MEETING_CONTENT_LIST(1),
                     sysdate,
                     V_SDE_MEETING_CONTENT_LIST(2));
                count_rows := (count_rows + sql%rowcount);
            end loop;
            result_int := 1;
            ErrMsg     := 0;
            return result_int;
        
            dbms_output.put_line('更新会议纪要内容信息：' ||
                                 sql%rowcount ||
                                 '行数据....................................');
            dbms_output.put_line('更新会议纪要内容信息：................完成............................................');
            dbms_output.put_line('--------------------------------------------------------------------------------------');
        else
            for i in 1 .. total loop
                V_SDE_MEETING_CONTENT_LIST := PKG_COMMON.Split(SDE_MEETING_CONTENT_LIST(i),
                                                               '^');
            
                dbms_output.put_line('插入的值：会议纪要内容列表数据id ' ||
                                     sys_guid() || '会议id：' ||
                                     is_exist_meeting_id || '内容' ||
                                     V_SDE_MEETING_CONTENT_LIST(1) ||
                                     sysdate);
            
                INSERT INTO LCOA.OA_SDE_MEETING_CONTENT_LIST
                    (C_ID, --数据id
                     C_MEETING_ID, --会议ID
                     V_CONTENT, --内容
                     D_INPUT_TIME, --录入时间
                     N_SEQ --序号
                     )
                VALUES
                    (lower(sys_guid()),
                     C_MEETING_ID,
                     V_SDE_MEETING_CONTENT_LIST(1),
                     sysdate,
                     V_SDE_MEETING_CONTENT_LIST(2));
                count_rows := (count_rows + sql%rowcount);
            end loop;
            result_int := 1;
            ErrMsg     := 0;
            return result_int;
        
            dbms_output.put_line('插入会议纪要内容信息：' ||
                                 sql%rowcount ||
                                 '行数据.................................');
            dbms_output.put_line('插入会议纪要内容信息：完成.........................................................');
            dbms_output.put_line('-----------------------------------------------------------------------------------');
        end if;
    
    end add_SDE_MEETING_CONTENT_LIST;

    /*
       4 业务操作
             会议纪要待办事项  会议纪要待办事项
       time
             2020-04-15
       author
             jiaxinxin
    
    */

    function add_SDE_TODO_LIST(OA_SDE_TODO_LIST    IN ARR_LONGSTR,
                               is_exist_meeting_id in char,
                               meeting_id          in char,
                               ErrMsg              OUT VARCHAR2
                               
                               ) return number
    
     is
        total              integer; --记录执行插入总条数
        V_OA_SDE_TODO_LIST PKG_COMMON.ARR_LONGSTR; -- 会议纪要待办事项
        count_rows         integer := 0; --记录插入的行数
        result_int         number := 0; --记录返回值 1 成功，0为失败。
        v_meeting_id       varchar2(50);
    begin
        if is_exist_meeting_id is not null then
            dbms_output.put_line('更新：--------会议id 存在，执行删除再次插入操作--------------------------------------------');
            --删除数据
        
            DELETE FROM LCOA.OA_SDE_TODO_LIST
             WHERE C_MEETING_ID = is_exist_meeting_id;
        
            dbms_output.put_line('删除以前的旧数据：.....................................................' ||
                                 sql%rowcount);
            --直接添加操作
            v_meeting_id := is_exist_meeting_id;
            dbms_output.put_line('操作会议纪要待办事项：开始..........................................................');
        
            total := OA_SDE_TODO_LIST.count;
            for i in 1 .. total loop
                V_OA_SDE_TODO_LIST := PKG_COMMON.Split(OA_SDE_TODO_LIST(i),
                                                       '^');
            
                INSERT INTO LCOA.OA_SDE_TODO_LIST
                    (C_TODO_ID, --数据ID
                     C_MEETING_ID, --会议ID
                     V_TODO_CONTENT, --事项内容*
                     V_TODO_TRACE, --后续跟踪情况
                     D_LIMIT_TIME, --待办截止时间
                     C_ASK_USER_ID, --提出人ID
                     V_ASK_USER_NAME, --提出人名称
                     C_DUTY_USER_ID, --负责人ID
                     V_DUTY_USER_NAME, --负责人名称
                     D_INPUT_TIME, --录入时间
                     N_SEQ --序号
                     )
                VALUES
                    (lower(sys_guid()),
                     v_meeting_id,
                     V_OA_SDE_TODO_LIST(1),
                     V_OA_SDE_TODO_LIST(2),
                     to_date(V_OA_SDE_TODO_LIST(3),
                             'yyyymmddhh24miss'),
                     0, --待办提出人id
                     V_OA_SDE_TODO_LIST(4),
                     0, --负责人ID
                     V_OA_SDE_TODO_LIST(5),
                     sysdate,
                     V_OA_SDE_TODO_LIST(6));
            
            end loop;
            --commit;
            result_int := 1;
            ErrMsg     := '';
            return result_int;
            count_rows := (count_rows + sql%rowcount);
        
            dbms_output.put_line('更新会议纪要待办事项内容信息：' ||
                                 sql%rowcount || '行数据' ||
                                 '......................');
            dbms_output.put_line('更新会议纪要待办事项内容信息：完成....................................................');
            dbms_output.put_line('--------------------------------------------------------------------------------------');
        
        else
            v_meeting_id := meeting_id;
            dbms_output.put_line('操作会议纪要待办事项：开始..........................................................');
        
            total := OA_SDE_TODO_LIST.count;
        
            for i in 1 .. total loop
                V_OA_SDE_TODO_LIST := PKG_COMMON.Split(OA_SDE_TODO_LIST(i),
                                                       '^');
            
                INSERT INTO LCOA.OA_SDE_TODO_LIST
                    (C_TODO_ID, --数据ID
                     C_MEETING_ID, --会议ID
                     V_TODO_CONTENT, --事项内容*
                     V_TODO_TRACE, --后续跟踪情况
                     D_LIMIT_TIME, --待办截止时间
                     C_ASK_USER_ID, --提出人ID
                     V_ASK_USER_NAME, --提出人名称
                     C_DUTY_USER_ID, --负责人ID
                     V_DUTY_USER_NAME, --负责人名称
                     D_INPUT_TIME, --录入时间
                     N_SEQ --序号
                     
                     )
                VALUES
                    (lower(sys_guid()),
                     v_meeting_id,
                     V_OA_SDE_TODO_LIST(1),
                     V_OA_SDE_TODO_LIST(2),
                     to_date(V_OA_SDE_TODO_LIST(3),
                             'yyyymmddhh24miss'),
                     0, --待办提出人id
                     V_OA_SDE_TODO_LIST(4),
                     0, --负责人ID
                     V_OA_SDE_TODO_LIST(5),
                     sysdate,
                     V_OA_SDE_TODO_LIST(6));
            
            end loop;
            --commit;
            result_int := 1;
            ErrMsg     := '';
            return result_int;
            count_rows := (count_rows + sql%rowcount);
        
            dbms_output.put_line('插入会议纪要待办事项内容信息：' ||
                                 sql%rowcount || '行数据' ||
                                 '......................');
            dbms_output.put_line('插入会议纪要待办事项内容信息：完成....................................................');
            dbms_output.put_line('--------------------------------------------------------------------------------------');
        
        end if;
    
    end add_SDE_TODO_LIST;

    /*
       5 业务操作
             USER_UPLOAD_INFO 附件信息表
       time
             2020-04-15
       author
             jiaxinxin
    
    */
    function add_USER_UPLOAD_INFO(USER_UPLOAD_INFO    IN ARR_LONGSTR,
                                  is_exist_meeting_id in char,
                                  meeting_id          in char,
                                  ErrMsg              OUT VARCHAR2
                                  
                                  ) return number
    
     is
        total              integer; --记录执行插入总条数
        V_USER_UPLOAD_INFO PKG_COMMON.ARR_LONGSTR; --附件信息表
        result_int         number := 0; --记录返回值 1 成功，0为失败。
        count_rows         integer := 0; --记录插入的行数
    begin
        if is_exist_meeting_id is not null then
            dbms_output.put_line('更新：会议附件信息表：开始.....................................................');
            --删除附件信息表
            DELETE FROM LCOA.OA_USER_UPLOAD_INFO
             WHERE C_FORIGN_ID = is_exist_meeting_id;
        
            dbms_output.put_line('删除以前的旧数据：.....................................................' ||
                                 sql%rowcount);
            --更新操作（插入）
            total := USER_UPLOAD_INFO.count;
            for i in 1 .. total loop
                V_USER_UPLOAD_INFO := PKG_COMMON.Split(USER_UPLOAD_INFO(i),
                                                       '^');
            
                INSERT INTO LCOA.OA_USER_UPLOAD_INFO
                    (C_FILE_ID, -- 文件ID
                     N_FILE_TYPE, --文件类型
                     C_FORIGN_ID, -- 外键
                     V_FILE_NAME, --文件名
                     V_FILE_PATH, --文件路径
                     D_UPLOAD_TIME) --上传时间
                VALUES
                    (lower(sys_guid()),
                     50,
                     trim(is_exist_meeting_id),
                     V_USER_UPLOAD_INFO(1),
                     V_USER_UPLOAD_INFO(2),
                     sysdate);
                count_rows := (count_rows + sql%rowcount);
            end loop;
        
            --commit;
            result_int := 1;
            ErrMsg     := 0;
            return result_int;
            dbms_output.put_line('更新附件信息内容信息：' ||
                                 count_rows || '行数据' ||
                                 '....................................');
            dbms_output.put_line('更新附件信息内容信息:完成................................................................');
            dbms_output.put_line('------------------------------------------------------------------------------------------');
        else
        
            dbms_output.put_line('插入：操作会议附件信息表：开始................................................................');
            total := USER_UPLOAD_INFO.count;
            for i in 1 .. total loop
                V_USER_UPLOAD_INFO := PKG_COMMON.Split(USER_UPLOAD_INFO(i),
                                                       '^');
            
                INSERT INTO LCOA.OA_USER_UPLOAD_INFO
                    (C_FILE_ID, -- 文件ID
                     N_FILE_TYPE, --文件类型
                     C_FORIGN_ID, -- 外键
                     V_FILE_NAME, --文件名
                     V_FILE_PATH, --文件路径
                     D_UPLOAD_TIME) --上传时间
                VALUES
                    (lower(sys_guid()),
                     50,
                     meeting_id,
                     V_USER_UPLOAD_INFO(1),
                     V_USER_UPLOAD_INFO(2),
                     sysdate);
                count_rows := (count_rows + sql%rowcount);
            end loop;
        
            commit;
            result_int := 1;
            ErrMsg     := 0;
            return result_int;
            dbms_output.put_line('插入：附件信息内容信息：' ||
                                 count_rows || '行数据' ||
                                 '....................................');
            dbms_output.put_line('插入：附件信息内容信息:完成................................................................');
            dbms_output.put_line('------------------------------------------------------------------------------------------');
        
        end if;
    
    end add_USER_UPLOAD_INFO;

    /*
       6 业务操作 会议纪要发布操作表
             MSG_MESSAGE_INFO  用户消息表
       time
             2020-04-15
    
    
       author
             jiaxinxin
    
    */
    function add_MSG_MESSAGE_INFO(SDE_MEETING_INFO IN varchar2,
                                  meeting_title    in varchar2,
                                  meeting_id       in varchar2,
                                  operation_id     in varchar2,
                                  ErrMsg           OUT VARCHAR2)
        return number
    
     is
    
        --type C_MESSAGE_INFO is ref cursor return lcoa.OA_SDE_SCHEDULE_NUMBER%rowtype;
    
        type C_MESSAGE_INFO is ref cursor;
        result_int number := 0; --记录返回值 1 成功，0为失败。
        count_rows integer := 0; --记录插入的行数
        C_USER_ID  varchar2(32);
    
        SdeSchedulenumber C_MESSAGE_INFO; --定义游标存储用户消息记录
    
        V_SDE_MEETING_INFO PKG_COMMON.ARR_LONGSTR; -- 接收会议基础新
    
        --v_sde_schedulue_record lcoa.OA_SDE_SCHEDULE_NUMBER%rowtype; -- 声明记录类型
        V_User_id varchar2(50); --获取用户id
    
        meeting_type integer; -- 会议类型
    begin
        if meeting_id is null then
            raise pkg_common.EXP_PARAM;
        end if;
        V_SDE_MEETING_INFO := PKG_COMMON.Split(SDE_MEETING_INFO,
                                               '^');
        dbms_output.put_line('开始更新户消息信息................................................................');
    
        --判断会议类型(0 公开，1，保密，2 绝密)
        meeting_type := V_SDE_MEETING_INFO(3);
        if (meeting_type = 0) then
            --游标赋值
            open SdeSchedulenumber for
                select C_user_id from LCBASE.t_zip_User where d_enddate > sysdate;
        
        elsif (meeting_type = 1) then
            open SdeSchedulenumber for
                SELECT n.C_user_id
                  from lcoa.OA_SDE_ATTENDEE_LIST n
                 WHERE n.c_MEETING_ID =
                       V_SDE_MEETING_INFO(1)
                UNION
                select UT.C_USER_ID
                  from lcbase.T_PROJECT_TEAM t,
                       lcbase.T_USER_TEAM    ut
                 where t.c_team_id = ut.c_team_id
                   and t.v_team_name = '办公会';
        else
            open SdeSchedulenumber for
                select UT.C_USER_ID
                  from lcbase.T_PROJECT_TEAM t,
                       lcbase.T_USER_TEAM    ut
                 where t.c_team_id = ut.c_team_id
                   and t.v_team_name = '办公会';
        
        end if;
    
        --循环游标取值
        FETCH SdeSchedulenumber
            INTO V_User_id;
        while SdeSchedulenumber%found loop
        
            dbms_output.put_line('---------------------' ||
                                 V_User_id);
            --插入用户消息表
            INSERT INTO LCOA.OA_MSG_MESSAGE_INFO
                (C_MSG_ID, -- 数据ID
                 N_MSG_TYPE, --消息类型(0:心情,1:公告,2:纪要,3:通知)
                 N_ISTOP_FLAG, --是否置顶(0否1是)
                 --D_ISTOP_TIME,                              --置顶时间
                 V_MSG_TITLE, --消息标题
                 D_MSG_TIME, --录入时间
                 N_READ_FLAG, --是否已读(0否1是)
                 C_MSG_USER_ID, --消息接收人ID
                 C_MSG_SRC, --消息源的关联数据ID
                 V_MSG_CONTENT, --消息内容
                 V_MSG_SENDER, --消息发送者名称
                 D_UPDATE_TIME --更新时间
                 --N_ENABLE
                 )
            VALUES
                (lower(sys_guid()),
                 52,
                 0,
                 '【' || meeting_title || '】会议纪要',
                 sysdate,
                 0,
                 trim(V_User_id), -- 循环出来的user_id
                 trim(meeting_id),
                 V_SDE_MEETING_INFO(4),
                 V_SDE_MEETING_INFO(6),
                 sysdate);
            FETCH SdeSchedulenumber
                INTO V_User_id;
            count_rows := (count_rows + sql%rowcount);
        end loop;
        close SdeSchedulenumber;
        dbms_output.put_line('用户消息信息..................更新完成............' ||
                             count_rows);
        commit;
        dbms_output.put_line('...............................................................');
    
        result_int := 1;
        ErrMsg     := 0;
        return result_int;
    
    end add_MSG_MESSAGE_INFO;

    /*
        7 业务需求
                更新用户待办事项 会议纪要发布操作表
        根据日程ID：
                C_SCH_ID
    
         in ： 字符串信息 C_SCH_ID
         out： return 1 为成功/0为失败
    
    */
    function UPDATE_TDO_TODOINFO(V_SCH_ID in varchar2,
                                 ErrMsg   OUT VARCHAR2
                                 
                                 ) return number is
    
        type C_TDO_TODOINFO is ref cursor return lcoa.OA_TDO_TODO_INFO%rowtype;
    
        TODO_INFO C_TDO_TODOINFO; --定义游标
    
        RECORD_TODO_INFO lcoa.OA_TDO_TODO_INFO%rowtype; --记录记录类型 属性为TDO_todo_info table
    
        V_MEETING_CLERK_ID varchar2(50); --记录速记人
        result_int         number := 0; --记录返回标识
        row_count          integer;
    
    begin
        -- 根据日程id 查询会议记录人id
        dbms_output.put_line('.........................更新用户待办消息开始........................................................' ||
                             V_SCH_ID);
    
        UPDATE LCOA.OA_TDO_TODO_INFO
           SET N_STATUS = 1 --状态改为1
        
         WHERE C_TODO_DATA_ID = V_SCH_ID;
        result_int := 1;
        ErrMsg     := '更新待办异常.....';
        return result_int;
    
    end UPDATE_TDO_TODOINFO;

    /*
        业务类型
          新增会议纪要 / 更新会议纪要
    
        操作类型：
           会议纪要 状态： "保存"
    
        涉及的表
          OA_SDE_MEETING_INFO                    会议纪要信息表
          OA_SDE_ATTENDEE_LIST                   是否缺席表
          OA_SDE_MEETING_CONTENT_LIST            会议纪要内容列表
          OA_USER_UPLOAD_INFO                    附件信息表
    
    
    
        in ：字符串信息
        out： return 1 为成功/0为失败
    
    */
    function add_meetingsummary_info(SDE_MEETING_INFO         IN varchar2,
                                     SDE_ATTENDEE_LIST        IN ARR_LONGSTR,
                                     SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                     OA_SDE_TODO_LIST         IN ARR_LONGSTR,
                                     USER_UPLOAD_INFO         IN ARR_LONGSTR,
                                     operation_id             in varchar2,
                                     ErrMsg                   OUT VARCHAR2,
                                     sys_meeting_id           out varchar2)
        return number is
        V_SDE_MEETING_INFO PKG_COMMON.ARR_LONGSTR; -- 接收会议基础新
    
        is_exist_meeting_id char(32); -- 会议id 用于判断
        meeting_id          char(32); -- 会议id 用户传值（新增）
        V_SCH_ID            char(32); -- 接收日程id
        result_int          integer default 0; --定义返回值 1 成功，0 失败
        meeting_title       varchar2(100);
        results             varchar2(50); --定义返回结果记录变量
        count_rows          integer;
        CLERK_NAME          varchar2(50); -- 接收速记人
        V_N_STATUS          number(1);
        C_V_USER_NAME       varchar2(50);
        row_count           integer; --记录行数
    
    begin
        V_SDE_MEETING_INFO := PKG_COMMON.Split(SDE_MEETING_INFO,
                                               '^'); -- 获取会议信息并使切分数据
        --加入判断
        meeting_id := V_SDE_MEETING_INFO(1);
        SELECT count(*)
          into count_rows
          FROM LCOA.OA_SDE_MEETING_INFO
         where C_MEETING_ID = meeting_id;
        if count_rows > 0 then
        
            -- 判断会议id是否存在： 
            -- if V_SDE_MEETING_INFO(1) is not null then
            --判断当前用户是否是速记人
            SELECT count(*)
              into row_count
              FROM lcbase.T_ZIP_USER
             WHERE C_USER_ID = operation_id and d_enddate > sysdate;
            ----------------------------------------------------------------------
            if row_count > 0 then
                SELECT V_USER_NAME
                  into C_V_USER_NAME
                  FROM lcbase.T_ZIP_USER
                 WHERE C_USER_ID = operation_id and d_enddate > sysdate;
            
                if (C_V_USER_NAME <> V_SDE_MEETING_INFO(6)) then
                
                    Dbms_Output.put_line('当前用户不是速记人............................');
                    ErrMsg := '当前用户不是速记人........................................';
                    return result_int;
                else
                    --判断状态。
                    SELECT count(*)
                      into row_count
                      FROM LCOA.OA_SDE_MEETING_INFO
                     WHERE C_MEETING_ID =
                           V_SDE_MEETING_INFO(1);
                
                    if row_count > 0 then
                        SELECT N_STATUS
                          into V_N_STATUS
                          FROM LCOA.OA_SDE_MEETING_INFO
                         WHERE C_MEETING_ID =
                               V_SDE_MEETING_INFO(1);
                    else
                        dbms_output.put_line('---------------------------------------:判断状态');
                        ErrMsg := '消息不存在..................................................';
                        return result_int;
                    end if;
                
                    ------------------
                    if V_N_STATUS = 1 then
                        dbms_output.put_line('---------------------------------------:已发布状态');
                        ErrMsg := '消息发布，非法修改............................................';
                        return result_int;
                    
                    else
                        --消息未发布状
                        dbms_output.put_line('-----------------------:消息状态：未发布： 本速记人');
                        --1.插入/更新会议基础信息表
                        dbms_output.put_line('------------------插入会议纪要开始--------------------------------');
                        results := Pkg_Meet_Info.add_meeting_info(SDE_MEETING_INFO,
                                                                  is_exist_meeting_id,
                                                                  meeting_id,
                                                                  meeting_title,
                                                                  V_SCH_ID,
                                                                  ErrMsg
                                                                  
                                                                  );
                        dbms_output.put_line('----------------meeting_id：返回result结果（0 为失败、1为成功）：' ||
                                             results);
                        dbms_output.put_line('---------------插入会议纪要结束---------------------------------------');
                    
                        --2.插入/更新会议缺席表
                        dbms_output.put_line('---------------插入会议缺席表开始-------------------------------------');
                        results := Pkg_Meet_Info.ADD_SDE_ATTENDEE_LIST(SDE_ATTENDEE_LIST,
                                                                       is_exist_meeting_id,
                                                                       meeting_id,
                                                                       ErrMsg);
                        dbms_output.put_line('---------------------------------------' ||
                                             'meeting_id' ||
                                             '返回result结果（0 为失败、1为成功）：' ||
                                             results);
                    
                        dbms_output.put_line('------------------插入缺席表开始结束---------------------------------');
                    
                        --3.插入/更新会议纪要内容列表
                        dbms_output.put_line('---------------------插入会议纪要内容列表开始------------------------');
                        results := Pkg_Meet_Info.add_SDE_MEETING_CONTENT_LIST(SDE_MEETING_CONTENT_LIST,
                                                                              is_exist_meeting_id,
                                                                              meeting_id,
                                                                              ErrMsg);
                        dbms_output.put_line('---------------------------------------' ||
                                             'meeting_id' ||
                                             '返回result结果（0 为失败、1为成功）：' ||
                                             results);
                        dbms_output.put_line('--------------插入缺席表开始结束-------------------------------------------');
                    
                        --4.会议纪要待办事项
                        dbms_output.put_line('----------插入会议会议纪要待办事项:操作-"开始"-----------------------------');
                        results := Pkg_Meet_Info.
                                   add_SDE_TODO_LIST(OA_SDE_TODO_LIST,
                                                     is_exist_meeting_id,
                                                     meeting_id,
                                                     ErrMsg);
                        dbms_output.put_line('---------------------------------------' ||
                                             '返回result结果（0 为失败、1为成功）：' ||
                                             results);
                        dbms_output.put_line('----------------插入会议会议纪要待办-"操作"结束"---------------------------');
                    
                        --5 附件信息表
                        dbms_output.put_line('............插入会议附件信息表：操作-"开始"................................');
                    
                        results := Pkg_Meet_Info.add_USER_UPLOAD_INFO(USER_UPLOAD_INFO,
                                                                      is_exist_meeting_id,
                                                                      meeting_id,
                                                                      ErrMsg);
                    
                        dbms_output.put_line('---------------------------------------' ||
                                             '返回result结果（0 为失败、1为成功）：' ||
                                             results);
                        dbms_output.put_line('..............插入会议附件信息表：操作-"结束"....................................');
                    
                        --更新代办
                        UPDATE OA_TDO_TODO_INFO s
                           SET s.V_TODO_TITLE = '【' ||
                                                V_SDE_MEETING_INFO(5) ||
                                                '】会议纪要'
                         WHERE C_TODO_DATA_ID =
                               V_SDE_MEETING_INFO(1);
                    
                        UPDATE lcoa.OA_SDE_SCHEDULE_INFO
                           SET V_SCH_TITLE = V_SDE_MEETING_INFO(5)
                         WHERE C_SCH_ID =
                               (SELECT OSSF.C_SCH_ID
                                  FROM lcoa.OA_SDE_SCHEDULING_FLOW OSSF
                                 WHERE OSSF.C_FLOW_ID =
                                       V_SDE_MEETING_INFO(1));
                    
                        commit;
                        sys_meeting_id := is_exist_meeting_id;
                        result_int     := 1; --最后结果 0为成功/1 为失败
                        ErrMsg         := '成功...........';
                        return result_int;
                    end if;
                
                end if;
            else
                --非法用户
                result_int := 0;
                ErrMsg     := '用户和速记人不匹配........................................';
                return result_int;
            end if;
            ---------------------------------------------------------------
        else
            --插入操作
            --1.插入/更新会议基础信息表
            results := Pkg_Meet_Info.add_meeting_info(SDE_MEETING_INFO,
                                                      is_exist_meeting_id,
                                                      meeting_id,
                                                      meeting_title,
                                                      V_SCH_ID,
                                                      ErrMsg);
            --2.插入/更新会议缺席表
            results := Pkg_Meet_Info.ADD_SDE_ATTENDEE_LIST(SDE_ATTENDEE_LIST,
                                                           is_exist_meeting_id,
                                                           meeting_id,
                                                           ErrMsg);
        
            --3.插入/更新会议纪要内容列表
            results := Pkg_Meet_Info.add_SDE_MEETING_CONTENT_LIST(SDE_MEETING_CONTENT_LIST,
                                                                  is_exist_meeting_id,
                                                                  meeting_id,
                                                                  ErrMsg);
        
            --4.会议纪要待办事项
            results := Pkg_Meet_Info.
                       add_SDE_TODO_LIST(OA_SDE_TODO_LIST,
                                         is_exist_meeting_id,
                                         meeting_id,
                                         ErrMsg);
            --5 附件信息表
            results := Pkg_Meet_Info.add_USER_UPLOAD_INFO(USER_UPLOAD_INFO,
                                                          is_exist_meeting_id,
                                                          meeting_id,
                                                          ErrMsg);
            dbms_output.put_line('.....插入会议附件信息表：操作-"结束"--------------');
            sys_meeting_id := meeting_id; --赋值会议id
            commit;
            result_int := 1;
            ErrMsg     := '成功.................add';
            return result_int;
        
        end if;
    exception
        WHEN OTHERS THEN
            ErrMsg := 'sql 操作: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            ROLLBACK;
            return result_int;
        
    end add_meetingsummary_info;

    /*
        业务类型
             发布会议纪要
    
        涉及的表
          OA_MSG_MESSAGE_INFO  用户消息表
          OA_TDO_TODO_INFO     用户待办事项
    
        in ：
        out： return 1 为发布成功/0为发布失败
    
    */
    function Meeting_msg_releaseInfo(SDE_MEETING_INFO         IN varchar2,
                                     SDE_ATTENDEE_LIST        IN ARR_LONGSTR,
                                     SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                     OA_SDE_TODO_LIST         IN ARR_LONGSTR,
                                     USER_UPLOAD_INFO         IN ARR_LONGSTR,
                                     operation_id             in varchar2,
                                     ErrMsg                   OUT VARCHAR2)
        return number is
    
        type C_MEETING_INFO is ref cursor;
        meeting_id    char(32); -- 保存会议id
        V_SCH_ID      char(32); -- 接收日程id
        result_int    integer default 0; --定义返回值 1 成功，0 失败
        meeting_title varchar2(100);
    
        results varchar2(50); --定义返回结果记录变量
    
        EMP_MEETING_INFO C_MEETING_INFO;
        errcode          number(6) := 0;
        emp_status       varchar(50);
    
        N_STATUS           integer; --获取会议发布状态
        V_SDE_MEETING_INFO PKG_COMMON.ARR_LONGSTR; -- 接收会议基础新
    
        meeting_id2 char(32); -- 保存会议id
        count_rows  integer;
    begin
        V_SDE_MEETING_INFO := PKG_COMMON.Split(SDE_MEETING_INFO,
                                               '^');
        meeting_title      := V_SDE_MEETING_INFO(5);
        meeting_id         := V_SDE_MEETING_INFO(1);
        V_SCH_ID           := V_SDE_MEETING_INFO(2);
    
        --加入判断
        SELECT count(*)
          into count_rows
          FROM LCOA.OA_SDE_MEETING_INFO
         where C_MEETING_ID = meeting_id;
        if count_rows > 0 then
            --if meeting_id is not null then
            OPEN EMP_MEETING_INFO FOR
                SELECT N_STATUS
                  FROM LCOA.OA_SDE_MEETING_INFO
                 WHERE C_MEETING_ID = meeting_id;
            loop
                fetch EMP_MEETING_INFO
                    into emp_status;
                exit when EMP_MEETING_INFO %notfound;
                dbms_output.put_line('--------------------------------' ||
                                     emp_status);
            end loop;
        
            if emp_status = 1 then
                result_int := 0;
                ErrMsg     := '会议纪要已经发布，不可再次发布......................';
                return result_int;
            else
                --调用会议更新方法，进行更新
                results := pkg_meet_info.add_meetingsummary_info(SDE_MEETING_INFO,
                                                                 SDE_ATTENDEE_LIST,
                                                                 SDE_MEETING_CONTENT_LIST,
                                                                 OA_SDE_TODO_LIST,
                                                                 USER_UPLOAD_INFO,
                                                                 operation_id,
                                                                 ErrMsg,
                                                                 meeting_id);
            
                --发布操作（发布消息--更新待办）
                if results = 1 then
                
                    results := Pkg_Meet_Info.add_MSG_MESSAGE_INFO(SDE_MEETING_INFO,
                                                                  meeting_title,
                                                                  meeting_id,
                                                                  operation_id,
                                                                  ErrMsg);
                    if results = 1 then
                        --当添加用户消息表 results =1 消息成功
                        --7 更新待办（根据日程id 查询会议记录人id）
                    
                        results := Pkg_Meet_Info.UPDATE_TDO_TODOINFO(meeting_id,
                                                                     ErrMsg);
                    
                        if results = 1 then
                        
                            /*results := pkg_meet_info.del_OA_SDE_TODO_LIST(V_SDE_MEETING_INFO(1),
                            ErrMsg);
                            */
                            if results = 1 then
                                --更新会议状态
                                results    := pkg_meet_info.update_meeting_status(meeting_id,
                                                                                  ErrMsg);
                                result_int := 1;
                                commit;
                                ErrMsg := '会议发布成功..................................';
                                return result_int;
                            
                            else
                                result_int := 0;
                                ErrMsg     := '会议发布失败.....更新待办异常.............................';
                                return result_int;
                            end if;
                        
                            --删除待办信息
                            return result_int;
                        else
                            result_int := 0;
                            ErrMsg     := ErrMsg;
                            return result_int;
                        end if;
                    
                    else
                        result_int := 0;
                        ErrMsg     := '会议纪要信息-消息部分：更新消息失败，发布失败，.............';
                        return result_int;
                    end if;
                
                else
                    result_int := 0;
                    ErrMsg     := '会议纪要信息更新失败，发布失败.............';
                    return result_int;
                end if;
            
            end if;
        
        else
            --添加发布一次性执行操作
            -- 1-2-3-4-5 会议纪要add/update
            results := pkg_meet_info.add_meetingsummary_info(SDE_MEETING_INFO,
                                                             SDE_ATTENDEE_LIST,
                                                             SDE_MEETING_CONTENT_LIST,
                                                             OA_SDE_TODO_LIST,
                                                             USER_UPLOAD_INFO,
                                                             operation_id,
                                                             ErrMsg,
                                                             meeting_id);
        
            --发布操作（发布消息--更新待办）
            if results = 1 then
                results := Pkg_Meet_Info.add_MSG_MESSAGE_INFO(SDE_MEETING_INFO,
                                                              meeting_title,
                                                              meeting_id,
                                                              operation_id,
                                                              ErrMsg);
                if results = 1 then
                    --当添加用户消息表 results =1 消息成功
                    --7 更新待办（根据日程id 查询会议记录人id）
                    results := Pkg_Meet_Info.UPDATE_TDO_TODOINFO(meeting_id,
                                                                 ErrMsg);
                
                    if results = 1 then
                    
                        if results = 1 then
                            --更新会议状态
                            results    := pkg_meet_info.update_meeting_status(meeting_id,
                                                                              ErrMsg);
                            result_int := 1;
                            commit;
                            ErrMsg := '会议发布成功..................................';
                            return result_int;
                        
                        else
                            -- 删除数据
                            result_int := 11;
                            ErrMsg     := '会议发布失败.....更新待办异常.............................';
                            return result_int;
                        end if;
                    
                        --删除待办信息
                        return result_int;
                    else
                        result_int := 0;
                        ErrMsg     := '更新待办失败.........';
                        return result_int;
                    end if;
                
                else
                    result_int := 0;
                    ErrMsg     := '会议纪要信息-消息部分：更新消息失败，发布失败，.............';
                    return result_int;
                end if;
            
            else
                result_int := 0;
                ErrMsg     := '会议纪要信息更新失败，发布失败.............';
                return result_int;
            end if;
        
        end if;
    
    exception
        WHEN PKG_COMMON.EXP_PARAM THEN
            return errcode;
        WHEN OTHERS THEN
            ErrMsg := '发布消息: ' || SQLCODE || ',' || SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            ROLLBACK;
            return result_int;
    end Meeting_msg_releaseInfo;

    /*
          业务需求
                  获取会议详情
          return corsor_data;
    
    */
    function get_meetingsummary_detals(C_MEETING_ID   IN char, -- 会议ID
                                       C_SCH_ID       IN varchar2, -- 日程ID
                                       metting_detals out SYS_REFCURSOR,
                                       ErrMsg         OUT VARCHAR2
                                       
                                       ) return number is
        result integer := 0;
    begin
        dbms_output.put_line(' -------------------------获取会议详情开始------------------------');
    
        result := 1;
        return result;
    end get_meetingsummary_detals;

    --删除待办信息
    /*
        业务类型
            待办信息操作
            OA_SDE_TODO_LIST
        涉及的表
        out： return 1 为发布成功/0为发布失败
    */
    /*
    function del_OA_SDE_TODO_LIST(C_MEETING_ID IN char, ErrMsg OUT VARCHAR2)
      return number is
    
      result_int integer := 0;
    begin
      dbms_output.put_line('-------------------------------------------------');
      DELETE FROM lcoa.OA_SDE_TODO_LIST WHERE C_MEETING_ID = C_MEETING_ID;
    
      result_int := 1;
      return result_int;
    
    
    
    
    end del_OA_SDE_TODO_LIST;
    */
    /*
     更新meting status 
    */

    function update_meeting_status(meeting_id IN varchar2,
                                   ErrMsg     OUT VARCHAR2)
        return number is
    
        result_int integer default 0;
    begin
        dbms_output.put_line('update_meeting_status-------------------------' ||
                             meeting_id);
        UPDATE LCOA.OA_SDE_MEETING_INFO
           SET N_STATUS = 1
         WHERE C_MEETING_ID = meeting_id;
    
        dbms_output.put_line('会议id ' || meeting_id ||
                             '返回结果：' ||
                             '-------------------------------------------------' ||
                             result_int || '更新的行数' ||
                             sql%rowcount);
        result_int := 1;
        return result_int;
    exception
        when NO_DATA_FOUND THEN
            dbms_output.put_line('没有查询到任何数据');
        
            return result_int;
        
    end update_meeting_status;

end PKG_MEET_info;
/

