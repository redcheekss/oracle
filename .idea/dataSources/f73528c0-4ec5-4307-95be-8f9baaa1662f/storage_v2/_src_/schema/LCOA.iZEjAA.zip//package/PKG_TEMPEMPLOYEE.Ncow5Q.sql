create package PKG_TEMPEMPLOYEE is

    -- Author  : lihuawei
    -- Created : 2020/3/7
    -- Purpose :

    -- Public function and procedure declarations
    FUNCTION Update_Employee(PEmployeeInfo IN VARCHAR2,
                             ErrMsg        OUT VARCHAR2)
        RETURN NUMBER;
    FUNCTION Get_Employee(Employee_Id     IN VARCHAR2,
                          OperationUserId IN VARCHAR2,
                          CUR_DATA        OUT SYS_REFCURSOR,
                          ErrMsg          OUT VARCHAR2)
        RETURN NUMBER;
    FUNCTION Get_EmployeeByLoginNum(LoginNumber IN VARCHAR2,
                                    CUR_DATA    OUT SYS_REFCURSOR,
                                    ErrMsg      OUT VARCHAR2)
        RETURN NUMBER;
    FUNCTION Check_EmployeeLoginNum(LoginNumber IN VARCHAR2,
                                    ErrMsg      OUT VARCHAR2)
        RETURN NUMBER;
    FUNCTION Update_EmployeePic(Employee_Id  IN VARCHAR2,
                                Pic_Type     IN NUMBER,
                                Employee_Pic IN VARCHAR2,
                                ErrMsg       OUT VARCHAR2)
        RETURN NUMBER;
    FUNCTION Get_EmployeePic(Employee_Id IN VARCHAR2,
                             CUR_DATA    OUT SYS_REFCURSOR,
                             ErrMsg      OUT VARCHAR2)
        RETURN NUMBER;
    FUNCTION Delete_EmployeePic(Employee_Id IN VARCHAR2,
                                PicType     IN NUMBER,
                                PicAddr     IN VARCHAR2,
                                ErrMsg      OUT VARCHAR2)
        RETURN NUMBER;

    --判断身份证号是否为空
    function IS_ID_CARD_EXISTS(ID_CARD_NUMBER in varchar2,
                               user_id        in char,
                               ErrMsg         out varchar2)
        return number;

    --判断身份证号是否为空-INSERT 
    function IS_ID_CARD_EXISTS_INSERT(ID_CARD_NUMBER in varchar2,
                                      ErrMsg         out varchar2)
        return number;

    --判断银行卡号
    function IS_BANK_CARD_EXISTS(BANK_CARD_NUMBER in varchar2,
                                 user_id          in char,
                                 ErrMsg           out varchar2)
        return number;

    --判断银行卡号_inset    
    function IS_BANK_CARD_EXISTS_INSERT(BANK_CARD_NUMBER in varchar2,
                                        ErrMsg           out varchar2)
        return number;

end PKG_TEMPEMPLOYEE;
/

