create package body PKG_INS_SIGNATURE_INFO is
  function save_signature_info(datainfo in varchar2,
                               userId   OUT VARCHAR2,
                               ErrMsg   OUT VARCHAR2) return number is
    DATAARR  Pkg_Common.ARR_LONGSTR;
    countpic number(6);
  begin
    DATAARR := PKG_COMMON.SPLIT(datainfo, '^');
    userId  := DATAARR(1);
    select count(*)
      into countpic
      from lcbase.t_signature_pic p
     where p.c_user_id = userId;
    if countpic > 0 then
      UPDATE lcbase.t_signature_pic
         SET L_PIC = DATAARR(2), D_UPDATETIME = sysdate
       WHERE C_USER_ID = userId;
    else
      insert into lcbase.t_signature_pic
        (C_USER_ID, L_PIC, D_UPDATETIME)
      values
        (userId, DATAARR(2), sysdate);
    end if;
    return 0;
  exception
    when others then
      ErrMsg := 'save_signature_info: ' || sqlcode || ',' || sqlerrm;
      raise;
      return - 1;
  end;
end;
/

