create package body PKG_TEST_Expenses_Item is

  FUNCTION Insert_Expenses_Info(DataInfo        in varchar2, --报销主表
                                DataItemInfo    in ARR_LONGSTR, --报销明细表
                                ArrFile         in ARR_LONGSTR,
                                OperationUserId in varchar2,
                                DataId          out varchar2,
                                ErrMsg          out varchar2) return number is
    DATAARR          PKG_COMMON.ARR_LONGSTR;
    P_ID             char(32);
    deptFullName     varchar2(50);
    expensesUserName varchar2(20);
    vFileInfo        varchar2(1000);
    n_result         number(1) := 0;
    time_start       timestamp;
    time_end         timestamp;
    n_duration       number(10);
    n_errcode        number(6);
  BEGIN
    DATAARR := PKG_COMMON.Split(DataInfo, '^');
    P_ID    := LOWER(SYS_GUID());
    select v_organization_name
      into deptFullName
      from lcbase.t_organization
     where c_organization_id = DATAARR(6);
  
    select v_user_name
      into expensesUserName
      from lcbase.t_user
     where c_user_id = DATAARR(3);
  
    insert into oa_eps_expenses_info
      (c_expenses_id,
       n_expenses_type,
       c_expenses_user_id,
       v_expenses_user_name,
       v_expenses_user_tel,
       c_dept_id,
       v_dept_name,
       c_top1_dept_id,
       c_top2_dept_id,
       c_top3_dept_id,
       c_top4_dept_id,
       v_dept_full_name,
       c_position_id,
       v_position_name,
       c_lk_corp_id,
       v_expenses_reason,
       c_project_id,
       v_project_name,
       n_borrowed_fee,
       n_total_fee,
       n_payable_fee,
       v_expenses_no,
       v_bar_code,
       n_repay_flag,
       n_repay_type,
       n_repay_amount,
       d_input_time,
       d_reject_time,
       c_reject_user_id,
       v_reject_user_name,
       v_reject_remark,
       d_update_time,
       c_update_user_id,
       n_status,
       n_approval_avoid_flag,
       n_finance_status,
       n_current_level,
       n_paid_fee,
       c_pay_lk_corp_id,
       n_ebank_pay_status,
       v_payment_flow_no,
       v_payment_flow_no_prefix,
       v_bank_flow_no,
       n_payment_fee,
       v_payment_failed_reason,
       v_payment_account_no,
       c_payment_user_id,
       d_payment_date,
       v_payment_purpose,
       n_record_flag,
       d_record_time,
       n_check_flag,
       v_check_remark,
       d_check_time,
       c_check_user_id,
       n_notice_payable_fee,
       n_notice_status,
       v_notice_remark,
       n_disabled_flag,
       c_last_invalid_userid,
       d_last_invalid_date,
       v_last_invalid_memo,
       v_finance_reject_reson,
       d_finance_reject_date,
       c_finance_reject_user_id,
       v_finance_reject_user_name,
       n_invalid_status,
       v_ex_memo)
    values
      (P_ID,
       DATAARR(2),
       OperationUserId,
       expensesUserName,
       DATAARR(5),
       DATAARR(6),
       DATAARR(7),
       DATAARR(8),
       DATAARR(9),
       DATAARR(10),
       DATAARR(11),
       deptFullName,
       DATAARR(13),
       DATAARR(14),
       DATAARR(15),
       DATAARR(16),
       DATAARR(17),
       DATAARR(18),
       DATAARR(19),
       DATAARR(20),
       DATAARR(21),
       DATAARR(22),
       DATAARR(23),
       DATAARR(24),
       DATAARR(25),
       DATAARR(26),
       sysdate,
       DATAARR(28),
       DATAARR(29),
       DATAARR(30),
       DATAARR(31),
       sysdate,
       DATAARR(33),
       DATAARR(34),
       DATAARR(35),
       DATAARR(36),
       DATAARR(37),
       DATAARR(38),
       DATAARR(39),
       DATAARR(40),
       DATAARR(41),
       DATAARR(42),
       DATAARR(43),
       DATAARR(44),
       DATAARR(45),
       DATAARR(46),
       DATAARR(47),
       DATAARR(48),
       '付报销款',
       DATAARR(50),
       DATAARR(51),
       DATAARR(52),
       DATAARR(53),
       DATAARR(54),
       DATAARR(55),
       DATAARR(56),
       DATAARR(57),
       DATAARR(58),
       DATAARR(59),
       DATAARR(60),
       DATAARR(61),
       DATAARR(62),
       DATAARR(63),
       DATAARR(64),
       DATAARR(65),
       DATAARR(66),
       DATAARR(67),
       DATAARR(68));
  
    DataId := P_ID;
  
    if DataItemInfo is null or DataItemInfo.Count = 0 then
      ErrMsg := '报销明细不能为空';
      return - 1;
    end if;
    for i in DataItemInfo.FIRST .. DataItemInfo.LAST loop
      vFileInfo := DataItemInfo(i);
    
      n_result := lcoa.pkg_test_expenses_item.Insert_Expenses_Item(DataInfo   => vFileInfo,
                                                                   ExpensesId => DataId,
                                                                   DataId     => DataId,
                                                                   ErrMsg     => errmsg);
    
    end loop;
  
    lcoa.pkg_user_schedule.Insert_User_Upload_File(DataId   => DataId,
                                                   FileType => 4,
                                                   ArrFile  => ArrFile);
  
    commit;
    return 0;
  
  exception
    when others then
      ErrMsg := 'Insert_Expenses_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
    
      if n_errcode = 0 then
        return 0;
      elsif n_errcode = -20999 then
        RAISE_APPLICATION_ERROR(n_errcode, errmsg, false);
      else
        return n_errcode;
      end if;
    
  END;

  --插入报销单明细
  function Insert_Expenses_Item(DataInfo   in varchar2,
                                ExpensesId in varchar2,
                                DataId     out varchar2,
                                ErrMsg     out varchar2) return number is
    DATAARR PKG_COMMON.ARR_LONGSTR;
    P_ID    char(32);
  begin
    DATAARR := PKG_COMMON.Split(DataInfo, '^');
    P_ID    := LOWER(SYS_GUID());
    insert into oa_eps_expenses_item
      (c_expenses_item_id,
       v_expenses_item_type,
       v_expenses_item_subtype,
       c_expenses_id,
       d_start_date,
       d_end_date,
       v_start_place,
       v_end_place,
       v_tool_key,
       v_tool,
       n_person_num,
       n_tickets_way_key,
       v_tickets_way,
       n_fee,
       n_bill_num,
       v_logement,
       n_unit_price,
       n_days,
       n_room,
       v_memo,
       v_cause,
       n_index,
       n_disabled_flag)
    values
      (P_ID,
       DATAARR(2),
       DATAARR(3),
       ExpensesId,
       to_date(DATAARR(5), 'yyyymmddhh24miss'),
       to_date(DATAARR(6), 'yyyymmddhh24miss'),
       DATAARR(7),
       DATAARR(8),
       DATAARR(9),
       DATAARR(10),
       DATAARR(11),
       DATAARR(12),
       DATAARR(13),
       DATAARR(14),
       DATAARR(15),
       DATAARR(16),
       DATAARR(17),
       DATAARR(18),
       DATAARR(19),
       DATAARR(20),
       DATAARR(21),
       DATAARR(22),
       DATAARR(23));
  
    DataId := P_ID;
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'Insert_Expenses_Item: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE_APPLICATION_ERROR(-20008, errmsg, false);
    
  end;

  --修改报销信息
  function Update_Expense_Info(DataInfo        in TYPE_EXPENSES_list, --报销主表
                               DataItemInfo    in type_expenses_item_list, --报销明细表
                               OperationUserId in varchar2,
                               ErrMsg          out varchar2) return number is
  
    P_ID     char(32);
    P_STATUS number(1);
    P_UUID   char(32);
  begin
    P_ID := DataInfo(1).expensesId;
  
    select n_status
      into P_STATUS
      from oa_eps_expenses_info
     where c_expenses_id = P_ID;
  
    if P_STATUS in (-1, 0, 5) then
      --修改报销表
      update oa_eps_expenses_info
         set n_expenses_type            = DataInfo(1).expensesType,
             c_expenses_user_id         = DataInfo(1).expensesUserId,
             v_expenses_user_name       = DataInfo(1).expensesUserName,
             v_expenses_user_tel        = DataInfo(1).expensesUserTel,
             c_dept_id                  = DataInfo(1).deptId,
             v_dept_name                = DataInfo(1).deptName,
             c_top1_dept_id             = DataInfo(1).top1DeptId,
             c_top2_dept_id             = DataInfo(1).top2DeptId,
             c_top3_dept_id             = DataInfo(1).top3DeptId,
             c_top4_dept_id             = DataInfo(1).top4DeptId,
             v_dept_full_name           = DataInfo(1).deptFullName,
             c_position_id              = DataInfo(1).positionId,
             v_position_name            = DataInfo(1).positionName,
             c_lk_corp_id               = DataInfo(1).lkCorpId,
             v_expenses_reason          = DataInfo(1).expensesReason,
             c_project_id               = DataInfo(1).projectId,
             v_project_name             = DataInfo(1).projectName,
             n_borrowed_fee             = DataInfo(1).borrowedFee,
             n_total_fee                = DataInfo(1).totalFee,
             n_payable_fee              = DataInfo(1).payableFee,
             v_expenses_no              = DataInfo(1).expensesNo,
             v_bar_code                 = DataInfo(1).barCode,
             n_repay_flag               = DataInfo(1).repayFlag,
             n_repay_type               = DataInfo(1).repayType,
             n_repay_amount             = DataInfo(1).repayAmount,
             d_reject_time              = to_date(DataInfo(1).rejectTime,
                                                  'yyyymmddhh24miss'),
             c_reject_user_id           = DataInfo(1).rejectUserId,
             v_reject_user_name         = DataInfo(1).rejectUserName,
             v_reject_remark            = DataInfo(1).rejectRemark,
             d_update_time              = sysdate,
             c_update_user_id           = OperationUserId,
             n_status                   = DataInfo(1).status,
             n_approval_avoid_flag      = DataInfo(1).approvalAvoidFlag,
             n_finance_status           = DataInfo(1).financeStatus,
             n_current_level            = DataInfo(1).currentLevel,
             n_paid_fee                 = DataInfo(1).paidFee,
             c_pay_lk_corp_id           = DataInfo(1).payLkCorpId,
             n_ebank_pay_status         = DataInfo(1).ebankPayStatus,
             v_payment_flow_no          = DataInfo(1).paymentFlowNo,
             v_payment_flow_no_prefix   = DataInfo(1).paymentFlowNoPrefix,
             v_bank_flow_no             = DataInfo(1).bankFlowNo,
             n_payment_fee              = DataInfo(1).paymentFee,
             v_payment_failed_reason    = DataInfo(1).paymentFailedReason,
             v_payment_account_no       = DataInfo(1).paymentAccountNo,
             c_payment_user_id          = DataInfo(1).paymentUserId,
             d_payment_date             = DataInfo(1).paymentDate,
             v_payment_purpose          = DataInfo(1).paymentPurpose,
             n_record_flag              = DataInfo(1).recordFlag,
             d_record_time              = DataInfo(1).recordTime,
             n_check_flag               = DataInfo(1).checkFlag,
             v_check_remark             = DataInfo(1).checkRemark,
             d_check_time               = DataInfo(1).checkTime,
             c_check_user_id            = DataInfo(1).checkUserId,
             n_notice_payable_fee       = DataInfo(1).noticePayableFee,
             n_notice_status            = DataInfo(1).noticeStatus,
             v_notice_remark            = DataInfo(1).noticeRemark,
             n_disabled_flag            = DataInfo(1).disabledFlag,
             c_last_invalid_userid      = DataInfo(1).lastInvalidUserid,
             d_last_invalid_date        = DataInfo(1).lastInvalidDate,
             v_last_invalid_memo        = DataInfo(1).lastInvalidMemo,
             v_finance_reject_reson     = DataInfo(1).financeRejectReson,
             d_finance_reject_date      = DataInfo(1).financeRejectDate,
             c_finance_reject_user_id   = DataInfo(1).financeRejectUserId,
             v_finance_reject_user_name = DataInfo(1).financeRejectUserName,
             n_invalid_status           = DataInfo(1).invalidStatus,
             v_ex_memo                  = DataInfo(1).exMemo
       where c_expenses_id = P_ID;
    
      --清除明细表
      delete from oa_eps_expenses_item where c_expenses_id = P_ID;
      --新增报销明细表
      for i in 1 .. DataItemInfo.count loop
        select lower(RAWTOHEX(sys_guid())) into P_UUID from dual;
        insert into oa_eps_expenses_item
          (c_expenses_item_id,
           v_expenses_item_type,
           v_expenses_item_subtype,
           c_expenses_id,
           d_start_date,
           d_end_date,
           v_start_place,
           v_end_place,
           v_tool_key,
           v_tool,
           n_person_num,
           n_tickets_way_key,
           v_tickets_way,
           n_fee,
           n_bill_num,
           v_logement,
           n_unit_price,
           n_days,
           n_room,
           v_memo,
           v_cause,
           n_index,
           n_disabled_flag)
        values
          (P_UUID,
           DataItemInfo(i).expensesItemType,
           DataItemInfo(i).expensesItemSubtype,
           P_ID,
           DataItemInfo(i).startDate,
           DataItemInfo(i).endDate,
           DataItemInfo(i).startPlace,
           DataItemInfo(i).endPlace,
           DataItemInfo(i).toolKey,
           DataItemInfo(i).tool,
           DataItemInfo(i).personNum,
           DataItemInfo(i).ticketsWayKey,
           DataItemInfo(i).ticketsWay,
           DataItemInfo(i).fee,
           DataItemInfo(i).billNum,
           DataItemInfo(i).logement,
           DataItemInfo(i).unitPrice,
           DataItemInfo(i).days,
           DataItemInfo(i).room,
           DataItemInfo(i).memo,
           DataItemInfo(i).cause,
           DataItemInfo(i).nIndex,
           DataItemInfo(i).disabledFlag);
      end loop;
      commit;
    else
      RAISE_APPLICATION_ERROR(-20008, '已经审批中，不能修改', false);
    end if;
    return 0;
  exception
    when others then
      ErrMsg := 'Update_Expense_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE_APPLICATION_ERROR(-20008, errmsg, false);
  end;

end PKG_TEST_Expenses_Item;
/

