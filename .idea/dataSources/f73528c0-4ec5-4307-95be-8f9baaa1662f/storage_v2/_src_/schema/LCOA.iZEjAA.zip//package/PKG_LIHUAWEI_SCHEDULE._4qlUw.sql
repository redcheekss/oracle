create package PKG_LIHUAWEI_SCHEDULE is

  -- Author  : USER
  -- Created : 2020/4/12 16:43:10
  -- Purpose : TEMP

  -- Public type declarations
  --type <TypeName> is <Datatype>;

  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  --<VariableName> <Datatype>;
  -- Public function and procedure declarations
  --function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;
  procedure GetDirectSuperiorByUserId(UserId            in varchar2,
                                      SuperiorUserId    out varchar2,
                                      SuperiorUserName  out varchar2,
                                      SuperiorUserTitle out varchar2);
  procedure GetDirectSuperiorByOrgId(OrganizationId    in varchar2,
                                     SuperiorUserId    out varchar2,
                                     SuperiorUserName  out varchar2,
                                     SuperiorUserTitle out varchar2);

end PKG_LIHUAWEI_SCHEDULE;
/

