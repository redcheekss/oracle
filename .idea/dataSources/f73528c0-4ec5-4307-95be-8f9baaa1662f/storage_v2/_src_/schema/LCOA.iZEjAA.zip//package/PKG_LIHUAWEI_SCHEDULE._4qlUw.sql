create package PKG_LIHUAWEI_SCHEDULE is

  -- Author  : USER
  -- Created : 2020/4/12 16:43:10
  -- Purpose : TEMP

  -- Public type declarations
  --type <TypeName> is <Datatype>;

  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  --<VariableName> <Datatype>;
  -- Public function and procedure declarations
  --function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;

  function Insert_News_info(cbNewsContent clob, ErrMsg OUT VARCHAR2)
    return NUMBER;

end PKG_LIHUAWEI_SCHEDULE;
/

