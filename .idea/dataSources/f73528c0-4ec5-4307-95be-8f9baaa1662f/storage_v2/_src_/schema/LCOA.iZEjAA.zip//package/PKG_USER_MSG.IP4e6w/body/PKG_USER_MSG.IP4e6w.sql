create package body PKG_USER_MSG as
  function Insert_UserMsgFeed(PUserMsgFeed    IN VARCHAR2,
                              OperationUserId IN VARCHAR2,
                              MsgFeedId       out varchar2,
                              ErrMsg          out VARCHAR2) return number as
    DATAARR    PKG_COMMON.ARR_LONGSTR;
    P_ID       CHAR(32);
    errcode    number(6) := 0;
    P_CNT      number(6);
  begin
    begin
      DATAARR := PKG_COMMON.Split(PUserMsgFeed, '^');
      P_ID    := LOWER(SYS_GUID());
    
      P_CNT := my_tabcolscount('OA_MSG_FEED_LIST');
      if P_CNT <> DATAARR.count then
        ErrMsg  := pkg_common.g_errmsg_afw_param;
        errcode := pkg_common.g_errcode_afw_param;
        raise pkg_common.EXP_PARAM;
      end if;
    
      --    dbms_lock.sleep(0.01);
      insert into OA_MSG_FEED_LIST
        (C_FEED_ID,
         C_MSG_ID,
         v_FEED_CONTENT,
         C_FEED_USER_ID,
         V_FEED_USER_NAME,
         D_FEED_TIME,
         C_PRE_FEED_ID,
         C_PRE_USER_ID,
         V_PRE_USER_NAME,
         N_SIGNATURE_TYPE)
      values
        (P_ID,
         DATAARR(2),
         DATAARR(3),
         DATAARR(4),
         DATAARR(5),
         to_date(DATAARR(6), 'yyyy-mm-dd hh24:mi:ss'),
         DATAARR(7),
         DATAARR(8),
         DATAARR(9),
         DATAARR(10));
      MsgFeedId := P_ID;
      commit;
      return 0;
    EXCEPTION
      WHEN PKG_COMMON.EXP_PARAM THEN
        return errcode;
      WHEN OTHERS THEN
        ErrMsg  := '新增用户消息评论信息异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
        errcode := pkg_common.g_errcode_exception;
        ROLLBACK;
        RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
    end;
  end;
  function Update_UserMsgFeed(PUserMsgFeed    IN VARCHAR2,
                              OperationUserId IN VARCHAR2,
                              ErrMsg          out VARCHAR2) return NUMBER as
    DATAARR    PKG_COMMON.ARR_LONGSTR;
    P_ID       CHAR(32);
    errcode    number(6) := 0;
    P_CNT      number(6);
  BEGIN
    BEGIN
      DATAARR := PKG_COMMON.Split(PUserMsgFeed, '^');
      P_ID    := LOWER(SYS_GUID());
    
      P_CNT := my_tabcolscount('OA_MSG_FEED_LIST');
      if P_CNT <> DATAARR.count then
        ErrMsg  := pkg_common.g_errmsg_afw_param;
        errcode := pkg_common.g_errcode_afw_param;
        raise pkg_common.EXP_PARAM;
      end if;
    
      P_ID := LOWER(DATAARR(1));
    
      UPDATE OA_MSG_FEED_LIST
         SET C_MSG_ID         = DATAARR(2),
             v_FEED_CONTENT   = DATAARR(3),
             C_FEED_USER_ID   = DATAARR(4),
             V_FEED_USER_NAME = DATAARR(5),
             D_FEED_TIME      = to_date(DATAARR(6), 'yyyy-mm-dd hh24:mi:ss'),
             C_PRE_FEED_ID    = DATAARR(7),
             C_PRE_USER_ID    = DATAARR(8),
             V_PRE_USER_NAME  = DATAARR(9),
             N_SIGNATURE_TYPE = DATAARR(10)
       WHERE C_FEED_ID = P_ID;
    
      COMMIT;
      return 0;
    EXCEPTION
      WHEN PKG_COMMON.EXP_PARAM THEN
        return errcode;
      WHEN OTHERS THEN
        ErrMsg  := '更新用户消息评论信息异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
        errcode := pkg_common.g_errcode_exception;
        ROLLBACK;
        RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
    END;
  END;
  function Update_UserMsgReaded(MsgId           IN VARCHAR2,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) return number as
    errcode   number(6) := 0;
    nReadFlag number(1);
  BEGIN
    BEGIN
      if MsgId is null then
        ErrMsg  := pkg_common.g_errmsg_afw_param;
        errcode := pkg_common.g_errcode_afw_param;
        raise pkg_common.EXP_PARAM;
      end if;
    
      select n_read_flag
        into nReadFlag
        from OA_MSG_MESSAGE_INFO
       where C_MSG_ID = MsgId;
      if nReadFlag = 1 then
        ErrMsg := '该消息已读状态，无需重复操作.';
        raise PKG_COMMON.EXP_CHECK;
      elsif nReadFlag <> 0 then
        ErrMsg := '该消息已读状态非法Flag=[' || nReadFlag || ']';
        raise PKG_COMMON.EXP_CHECK;
      end if;
    
      UPDATE OA_MSG_MESSAGE_INFO
         SET n_read_flag = 1, d_update_time = sysdate
       WHERE C_MSG_ID = MsgId;
    
      COMMIT;
      return 0;
    EXCEPTION
      WHEN PKG_COMMON.EXP_PARAM THEN
        return errcode;
      WHEN PKG_COMMON.EXP_CHECK THEN
        return 0; --此类参数错误，前端不展示，按正常处理
      WHEN CASE_NOT_FOUND THEN
        ErrMsg  := pkg_common.g_errmsg_afw_nodata;
        errcode := pkg_common.g_errcode_afw_nodata;
        ROLLBACK;
        return errcode;
      WHEN NO_DATA_FOUND THEN
        ErrMsg  := pkg_common.g_errmsg_afw_nodata;
        errcode := pkg_common.g_errcode_afw_nodata;
        ROLLBACK;
        return errcode;
      WHEN OTHERS THEN
        ErrMsg  := '更新用户消息已读状态异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
        errcode := pkg_common.g_errcode_exception;
        ROLLBACK;
        RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
    END;
  END;
  function Update_UserMsgTop(PNewsInfo       IN VARCHAR2,
                             OperationUserId IN VARCHAR2,
                             ErrMsg          OUT VARCHAR2) return number as
    DATAARR    PKG_COMMON.ARR_LONGSTR;
    errcode    number(6) := 0;
    nIsTopFlag number(1);
    nNewsType  number(1);
    NewsId     char(32);
    IsTopFlag  number(1);
    P_CNT      number(6);
  BEGIN
    BEGIN
      DATAARR := PKG_COMMON.Split(PNewsInfo, '^');
    
      P_CNT := my_tabcolscount('OA_MSG_PUBLISH_INFO');
      if P_CNT <> DATAARR.count then
        ErrMsg  := pkg_common.g_errmsg_afw_param;
        errcode := pkg_common.g_errcode_afw_param;
        raise pkg_common.EXP_PARAM;
      end if;
      NewsId    := DATAARR(1);
      IsTopFlag := DATAARR(11);
      if NewsId is null then
        ErrMsg  := pkg_common.g_errmsg_afw_param;
        errcode := pkg_common.g_errcode_afw_param;
        raise pkg_common.EXP_PARAM;
      end if;
      if OperationUserId is null then
        ErrMsg  := pkg_common.g_errmsg_afw_param;
        errcode := pkg_common.g_errcode_afw_param;
        raise pkg_common.EXP_PARAM;
      end if;
      if IsTopFlag not in (0, 1) then
        ErrMsg  := pkg_common.g_errmsg_afw_param;
        errcode := pkg_common.g_errcode_afw_param;
        raise pkg_common.EXP_PARAM;
      end if;
    
      select n_istop_flag, n_news_type
        into nIsTopFlag, nNewsType
        from OA_MSG_PUBLISH_INFO
       where C_NEWS_ID = NewsId;
      if nNewsType <> 1 then
        Errmsg := '只有公告才能置顶.';
        raise PKG_COMMON.EXP_CHECK;
      end if;
      if nIsTopFlag = IsTopFlag then
        ErrMsg := '该公告置顶状态与计划变更一致，无需操作.';
        raise PKG_COMMON.EXP_CHECK;
      end if;
    
      UPDATE OA_MSG_PUBLISH_INFO
         SET n_istop_flag = IsTopFlag
       WHERE C_NEWS_ID = NewsId;
    
      COMMIT;
      return 0;
    EXCEPTION
      WHEN PKG_COMMON.EXP_PARAM THEN
        return errcode;
      WHEN PKG_COMMON.EXP_CHECK THEN
        return 0;
      WHEN CASE_NOT_FOUND THEN
        ErrMsg  := pkg_common.g_errmsg_afw_nodata;
        errcode := pkg_common.g_errcode_afw_nodata;
        ROLLBACK;
        return errcode;
      WHEN NO_DATA_FOUND THEN
        ErrMsg  := pkg_common.g_errmsg_afw_nodata;
        errcode := pkg_common.g_errcode_afw_nodata;
        ROLLBACK;
        return errcode;
      WHEN OTHERS THEN
        ErrMsg  := '设置公告置顶状态异常: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
        errcode := pkg_common.g_errcode_exception;
        ROLLBACK;
        RAISE_APPLICATION_ERROR(SQLCODE, errmsg, false);
    END;
  END;
end PKG_USER_MSG;
/

