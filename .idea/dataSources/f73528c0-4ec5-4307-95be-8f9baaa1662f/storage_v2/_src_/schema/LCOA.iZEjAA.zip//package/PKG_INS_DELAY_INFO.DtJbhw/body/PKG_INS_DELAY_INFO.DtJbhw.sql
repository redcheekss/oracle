create package body PKG_INS_DELAY_INFO is
  function getDelayApproverList(userId       in varchar2, --操作人ID
                                loanInfo     out sys_refcursor, --未还清借款单列表 
                                ApproveUsers out sys_refcursor, --审批人详情
                                ErrMsg       out varchar2) return number is
    Days     number(3);
    Hours    number(3);
    n_result number(6) := 0;
  begin
    begin
      --查询借款信息
      open loanInfo for
        select *
          from LCOA.OA_AFW_LOAN_INFO L
         WHERE L.N_PAYOFF_STATUS = 0
           AND L.c_user_id = userId;
    
      --查询审批人详情包括申请人信息
      n_result := LCOA.PKG_EXT_AFW_WORKFLOW.Get_Pre_Approval_Userlist(userId, --WorkflowUserId用户ID
                                                                      7, --WorkflowType申请类型
                                                                      '', --WorkflowSubType--具体类型
                                                                      null, --开始时间
                                                                      null, --结束时间
                                                                      '', --NewOrganizationId新部门
                                                                      Days,
                                                                      Hours,
                                                                      ApproveUsers, --游标审批人列表
                                                                      ErrMsg);
    
      return n_result;
    
    exception
      when others then
        ErrMsg := 'getDelayApproverList: ' || sqlcode || ',' || sqlerrm;
        raise;
        return - 1;
    end;
  end;

  function save_delay_info(loanIds   in varchar2,
                           delayInfo in varchar2,
                           userId    IN VARCHAR2,
                           c_cursor  out sys_refcursor,
                           ErrMsg    OUT VARCHAR2) return number is
    idArrays   Pkg_Common.ARR_LONGSTR;
    dataArr    Pkg_Common.ARR_LONGSTR;
    todoTitle  varchar2(40);
    total      number(3);
    totalCount number(1);
    P_ID       char(32);
  begin
    begin
      if userId is null then
        ErrMsg := '无用户信息,请先登录';
        return - 1;
      else
        idArrays := PKG_COMMON.SPLIT(loanIds, '^');
        dataArr  := PKG_COMMON.SPLIT(delayInfo, '^');
        total    := idArrays.count;
        for i in 1 .. total loop
          P_ID := LOWER(SYS_GUID());
          select u.v_pet_name || '的借款延期申请'
            into todoTitle
            from lcbase.t_zip_user u
           where u.c_user_id = userId
             and u.d_enddate > sysdate;
          insert into OA_AFW_LOAN_EXTENSION
            (c_ID,
             C_USER_ID,
             C_LOAN_ID,
             D_EXTENSION_DATE,
             V_CAUSE,
             N_STATUS,
             N_APPROVAL_STATUS,
             D_APPLY_TIME,
             D_UPDATE_TIME)
          values
            (P_ID,
             userId,
             idArrays(i),
             to_date(DATAARR(1), 'yyyymmddhh24miss'),
             DATAARR(2),
             0,
             0,
             Sysdate,
             Sysdate);
          update lcoa.oa_tdo_todo_info info
             set info.n_status = 1
           where info.c_todo_data_id = idArrays(i)
             and info.n_todo_type = 55;
          lcoa.pkg_ins_afw_workflow.Create_Approval_By_Id(P_ID, 7);
          lcoa.pkg_ins_afw_workflow.Create_Next_Approval_Todo(P_ID,
                                                              todoTitle,
                                                              c_cursor);
        end loop;
        return 0;
      end if;
    exception
      when others then
        ErrMsg := 'save_delay_info: ' || sqlcode || ',' || sqlerrm;
        raise;
        return - 1;
    end;
  end;

  function getDelayInfo(delayId         in varchar2, --借款信息ID
                        operationUserId in varchar2, --操作人ID
                        loanInfo        out sys_refcursor, --借款单详情 
                        ApproveUsers    out sys_refcursor, --审批人详情
                        delayInfo       out sys_refcursor,
                        ErrMsg          out varchar2) return number is
    d_approdate date;
    loanUserId  char(32);
    loanPetName char(32);
  begin
    begin
      --查询借款单申请时间
      select loan.d_apply_time
        into d_approdate
        from LCOA.Oa_Afw_Loan_Extension info
        left join lcoa.oa_afw_loan_info loan
          on loan.c_id = info.C_LOAN_ID
       where info.c_id = delayId;
      --查询延期人ID,
      select info.c_user_id
        into loanUserId
        from LCOA.Oa_Afw_Loan_Extension info
       where info.c_id = delayId;
      --查询延期人员姓名
      select u.v_pet_name
        into loanPetName
        from lcbase.t_zip_user u
       where u.c_user_id = loanUserId
         and d_approdate <= trunc(u.D_ENDDATE)
         and d_approdate >= trunc(u.d_startdate);
    
      --查询借款信息
      open loanInfo for
        select info.*,
               u.v_headpic_aly,
               u.v_pet_name,
               emp.v_user_title,
               lk.v_company as C_USER_CORP_NAME,
               org.v_organization_name
          from lcoa.oa_afw_loan_extension delay
          left join LCOA.OA_AFW_LOAN_INFO info
            on delay.c_loan_id = info.c_id
          left join lcbase.t_zip_user u
            on u.c_user_id = info.c_user_id
          left join lcbase.t_employees_info emp
            on info.c_user_id = emp.c_user_id
          left join lcbase.t_zip_organization org
            on u.c_organization_id = org.c_organization_id
          left join lcbase.T_LK_COMPANY_INFO lk
            on lk.c_company_id = info.c_user_corp_id
         where delay.c_id = delayId
           and d_approdate <= trunc(u.D_ENDDATE)
           and d_approdate >= trunc(u.d_startdate);
    
      --查询审批人详情包括申请人信息
      open ApproveUsers for
        select f.*, u.v_headpic_aly, s.l_pic as "V_SIGNATURE_PIC"
          from (select * --查询审批人信息
                  from oa_afw_workflow_approval_flow f
                union
                select --查询申请人信息  
                 null,
                 11,
                 delayId,
                 0,
                 null,
                 loanUserId,
                 loanPetName,
                 null,
                 1,
                 null,
                 null,
                 0,
                 1
                  from dual) f
          left join lcbase.t_zip_user u
            on f.c_approval_user_id = u.c_user_id
          left join lcbase.t_signature_pic s
            on f.c_approval_user_id = s.c_user_id
         where f.c_workflow_id = delayId
           and d_approdate <= trunc(u.D_ENDDATE)
           and d_approdate >= trunc(u.d_startdate)
         order by f.n_approval_order;
      open delayInfo for
        select delay.*
          from lcoa.oa_afw_loan_extension delay
         where delay.c_id = delayId;
      return 0;
    exception
      when others then
        ErrMsg := 'getDelayInfo: ' || sqlcode || ',' || sqlerrm;
        raise;
        rollback;
        return - 1;
    end;
  end;
  function cutDelayApproval(loanId in varchar2, ErrMsg OUT VARCHAR2)
    return number is
    delayCount number;
    delayId    char(32);
  begin
    begin
      select count(*)
        into delayCount
        from lcoa.oa_afw_loan_extension delay
       where delay.c_loan_id = loanId
         and (delay.n_approval_status = 0 or delay.n_approval_status = 1);
      if delayCount = 1 then
      
        --查询延期表中的主键ID
        select delay.c_id
          into delayId
          from lcoa.oa_afw_loan_extension delay
         where delay.c_loan_id = loanId
           and (delay.n_approval_status = 0 or delay.n_approval_status = 1);
      
        --更新延期表中的审批状态
        update lcoa.oa_afw_loan_extension delay
           set delay.n_approval_status = 4
         where delay.c_loan_id = loanId;
        --将代办表中的状态更新
        update lcoa.oa_tdo_todo_info tdo
           set tdo.n_status = 1
         where tdo.c_todo_data_id in
               (select flow.c_data_id
                  from lcoa.oa_afw_workflow_approval_flow flow
                 where flow.c_workflow_id = delayId
                   and flow.N_APPROVAL_STATUS = 0);
        --将还未审批的审批人移走
        --先新增
        insert into oa_afw_countsign_approval_flow
          (c_data_id,
           n_workflow_type,
           c_workflow_id,
           n_approval_order,
           n_approval_model,
           c_approval_user_id,
           v_approval_user_name,
           v_approval_user_title,
           n_approval_status,
           d_approval_time,
           v_approval_remark,
           n_skip_flag,
           n_approval_sort)
          select flow.c_data_id,
                 flow.n_workflow_type,
                 flow.c_workflow_id,
                 flow.n_approval_order,
                 flow.n_approval_model,
                 flow.c_approval_user_id,
                 flow.v_approval_user_name,
                 flow.v_approval_user_title,
                 flow.n_approval_status,
                 flow.d_approval_time,
                 nvl(flow.v_approval_remark, '') ||
                 to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'),
                 flow.n_skip_flag,
                 flow.n_approval_sort
            from lcoa.oa_afw_workflow_approval_flow flow
           where flow.c_workflow_id = delayId
             and flow.N_APPROVAL_STATUS = 0;
        --删除
        delete from oa_afw_workflow_approval_flow flow
         where c_workflow_id = delayId
           and flow.N_APPROVAL_STATUS = 0;
      end if;
      return 0;
    exception
      when others then
        ErrMsg := 'getDelayInfo: ' || sqlcode || ',' || sqlerrm;
        raise;
        rollback;
        return - 1;
    end;
  end;
end;
/

