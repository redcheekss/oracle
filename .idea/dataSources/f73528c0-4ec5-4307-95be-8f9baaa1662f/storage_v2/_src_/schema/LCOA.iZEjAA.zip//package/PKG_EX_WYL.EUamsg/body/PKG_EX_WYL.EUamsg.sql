create package body PKG_EX_WYL is
  function underLinePayment(userId     in varchar2,
                            expensesId in varchar2,
                            resultMsg  out varchar2) return number is
  begin
    update OA_EPS_EXPENSES_INFO
       set N_STATUS          = 4,
           C_PAYMENT_USER_ID = userId,
           D_PAYMENT_DATE    = sysdate
     where C_EXPENSES_ID = expensesId;
    update lcoa.oa_afw_workflow_approval_flow t
       set N_APPROVAL_STATUS = 1, D_APPROVAL_TIME = sysdate
     where t.c_workflow_id = expensesId
       and t.c_approval_user_id = userId;
    commit;
    resultMsg := '线下支付成功！';
    return 0;
  exception
    when others then
      return - 1;
  end;
  function refusePayment(userId     in varchar2,
                         expensesId in varchar2,
                         reason     in varchar2,
                         resultMsg out varchar2) return number is
  begin
     update OA_EPS_EXPENSES_INFO
       set V_FINANCE_REJECT_RESON          = reason,
           D_FINANCE_REJECT_DATE = sysdate,
           /*V_FINANCE_REJECT_USER_NAME    = (select v_user_name from t_User where C_USER_ID = userId),*/
           C_FINANCE_REJECT_USER_ID = userId,
           N_FINANCE_STATUS = -3
     where C_EXPENSES_ID = expensesId;
   commit;
    resultMsg := '驳回成功！';
    return 0;
  exception
    when others then
      return - 1;
  end;

end PKG_EX_WYL;
/

