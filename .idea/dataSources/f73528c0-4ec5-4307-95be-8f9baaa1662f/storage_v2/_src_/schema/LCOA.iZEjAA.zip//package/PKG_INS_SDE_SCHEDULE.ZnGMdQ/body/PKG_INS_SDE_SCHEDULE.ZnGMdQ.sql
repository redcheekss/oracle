create package body PKG_INS_SDE_SCHEDULE is

  -- Private type declarations
  --type <TypeName> is <Datatype>;
  -- Private constant declarations
  --<ConstantName> constant <Datatype> := <Value>;
  -- Private variable declarations
  --<VariableName> <Datatype>;
  i number(1);

  function Update_Schedule_Info(DataInfo        IN VARCHAR2,
                                ArrAttendee     in ARR_LONGSTR,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) return NUMBER as
    DATAARR      PKG_COMMON.ARR_LONGSTR;
    DataId       char(32);
    T_DY         date;
    schDate      date;
    TodoTitle    varchar2(100);
    n_errcode    number(6);
    nUserDiff    number(1);
    oldSchStatus NUMBER(1);
    newSchStatus NUMBER(1);
    updateStatus number(1);
   oldDateCount number(1);
  begin
    DATAARR      := PKG_COMMON.Split(DataInfo, '^');
    DataId       := DATAARR(1);
    newSchStatus := DATAARR(9);
    schDate      := to_date(DATAARR(2), 'yyyymmddhh24miss');
   SELECT count(*) INTO oldDateCount FROM lcoa.OA_SDE_SCHEDULING_FLOW ossf WHERE ossf.C_SCH_ID = DataId AND OSSF .D_FLOW_DATE = TRUNC(SYSDATE,'dd'); 
   
    SELECT N_SCH_TYPE
    INTO   oldSchStatus
    FROM   lcoa.OA_SDE_SCHEDULE_INFO ossi
    WHERE  ossi.C_SCH_ID = DataId;
    nUserDiff := CheckClerkUserDiff(DATAARR(11), DataId);
    UpdateScheduleInfo(DATAARR);
    UpdateAttendeeList(DataId, ArrAttendee);
    T_DY      := trunc(to_date(DATAARR(2), 'yyyymmddhh24miss'), 'dd');
    TodoTitle := '【' || DATAARR(6) || '】会议纪要';
    RecreateScheduleFlow(DataId => DataId, RepeadType => DATAARR(8),
                         ScheduleType => DATAARR(9), UserDiff => nUserDiff,
                         Today => T_DY, TodoUserId => DATAARR(11),
                         TodoTitle => TodoTitle);
    commit;
    if newSchStatus = 2 and oldSchStatus = 2 THEN
    	IF oldDateCount >0 OR schDate = TRUNC(SYSDATE,'dd') THEN 
      		updateStatus := updateEmail(DataId, schDate);
     	END IF;
    end if;
    return 0;
  end;

  function CheckClerkUserDiff(TodoUserId in varchar2,
                              DataId     in varchar2) return number is
    nRet        number(1) := 0;
    cOldClerkId char(32);
  begin
    select c_meeting_clerk_id
    into   cOldClerkId
    from   OA_SDE_SCHEDULE_INFO
    WHERE  c_sch_id = DataId;
    if cOldClerkId = TodoUserId then
      nRet := 0;
    else
      nRet := 1;
    end if;
    return nRet;
  end;

  procedure RecreateScheduleFlow(DataId       in varchar2,
                                 RepeadType   in number,
                                 ScheduleType in number,
                                 UserDiff     in number,
                                 Today        in date,
                                 TodoUserId   in varchar2,
                                 TodoTitle    in varchar2) is
    P_ID char(32);
    W_IX number(1);
  begin
    --删除上次生成的日程待办（当前时间之后的）
    delete from lcoa.oa_tdo_todo_info t
    where  t.n_status = 0 --已完成的待办信息不处理，会议纪要待办以发布会议纪要为准；单纯保存会议纪要，该状态无变化
    and    t.c_todo_data_id in
           (select c_flow_id
             from   LCOA.OA_SDE_SCHEDULING_FLOW f
             where  f.c_sch_id = DataId
                   --and f.d_flow_date >= trunc(Today, 'dd') --只删除要调整日程日及以后的待办信息
             and    f.d_flow_date >= trunc(sysdate, 'dd') --删除当前之后的
             and    f.c_flow_id not in (select c_meeting_id
                                        from   lcoa.oa_sde_meeting_info
                                        where  c_sch_id = DataId
                                        and n_status = 1  --只要保存会议纪要则不删除
                                        ));
    --删除上次生成的日程（当前时间之后的）
    delete from LCOA.OA_SDE_SCHEDULING_FLOW f
    where  f.c_sch_id = DataId
          --and f.d_flow_date >= trunc(Today, 'dd') 
    and    f.d_flow_date >= trunc(sysdate, 'dd')
    and    f.c_flow_id not in (select c_meeting_id
                               from   lcoa.oa_sde_meeting_info
                               where  c_sch_id = DataId
                               and n_status = 1
                               );
    --重新生成当前时间之后的日程
    --重复方式(0不重复1每日2工作日3每周4每月)
    if RepeadType = 0 then
      P_ID := lower(sys_guid());
      insert into LCOA.OA_SDE_SCHEDULING_FLOW
        (c_flow_id, c_sch_id, d_flow_date)
      values
        (P_ID, DataId, Today);
      if ScheduleType = 2 then
        insert into lcoa.oa_tdo_todo_info
          (c_todo_id,
           c_todo_user_id,
           d_todo_time,
           n_todo_type,
           v_todo_title,
           d_input_time,
           n_status,
           --d_done_time,
           c_todo_data_id)
        values
          (lower(sys_guid()),
           TodoUserId,
           Today,
           52,
           TodoTitle,
           sysdate,
           0,
           --null,
           P_ID);
      end if;
    elsif RepeadType = 1 then
      for i in 0 .. 365 loop
        P_ID := lower(sys_guid());
        insert into LCOA.OA_SDE_SCHEDULING_FLOW
          (c_flow_id, c_sch_id, d_flow_date)
        values
          (P_ID, DataId, Today + i);
        if ScheduleType = 2 then
          insert into lcoa.oa_tdo_todo_info
            (c_todo_id,
             c_todo_user_id,
             d_todo_time,
             n_todo_type,
             v_todo_title,
             d_input_time,
             n_status,
             --d_done_time,
             c_todo_data_id)
          values
            (lower(sys_guid()),
             TodoUserId,
             Today + i,
             52,
             TodoTitle,
             sysdate,
             0,
             --null,
             P_ID);
        end if;
      end loop;
    elsif RepeadType = 2 then
      W_IX := to_char(Today, 'd');
      for i in 0 .. 365 loop
        if MOD(W_IX + i, 7) > 1 then
          -- in (0,1)
          P_ID := lower(sys_guid());
          insert into LCOA.OA_SDE_SCHEDULING_FLOW
            (c_flow_id, c_sch_id, d_flow_date)
          values
            (P_ID, DataId, Today + i);
          if ScheduleType = 2 then
            insert into lcoa.oa_tdo_todo_info
              (c_todo_id,
               c_todo_user_id,
               d_todo_time,
               n_todo_type,
               v_todo_title,
               d_input_time,
               n_status,
               --d_done_time,
               c_todo_data_id)
            values
              (lower(sys_guid()),
               TodoUserId,
               Today + i,
               52,
               TodoTitle,
               sysdate,
               0,
               --null,
               P_ID);
          end if;
        end if;
      end loop;
    elsif RepeadType = 3 then
      for i in 0 .. 52 loop
        P_ID := lower(sys_guid());
        insert into LCOA.OA_SDE_SCHEDULING_FLOW
          (c_flow_id, c_sch_id, d_flow_date)
        values
          (P_ID, DataId, Today + i * 7);
        if ScheduleType = 2 then
          insert into lcoa.oa_tdo_todo_info
            (c_todo_id,
             c_todo_user_id,
             d_todo_time,
             n_todo_type,
             v_todo_title,
             d_input_time,
             n_status,
             --d_done_time,
             c_todo_data_id)
          values
            (lower(sys_guid()),
             TodoUserId,
             Today + i * 7,
             52,
             TodoTitle,
             sysdate,
             0,
             --null,
             P_ID);
        end if;
      end loop;
    elsif RepeadType = 4 then
      for i in 0 .. 12 loop
        P_ID := lower(sys_guid());
        insert into LCOA.OA_SDE_SCHEDULING_FLOW
          (c_flow_id, c_sch_id, d_flow_date)
        values
          (P_ID, DataId, add_months(Today, i));
        if ScheduleType = 2 then
          insert into lcoa.oa_tdo_todo_info
            (c_todo_id,
             c_todo_user_id,
             d_todo_time,
             n_todo_type,
             v_todo_title,
             d_input_time,
             n_status,
             --d_done_time,
             c_todo_data_id)
          values
            (lower(sys_guid()),
             TodoUserId,
             add_months(Today, i),
             52,
             TodoTitle,
             sysdate,
             0,
             --null,
             P_ID);
        end if;
      end loop;
    end if;
  end;

  procedure UpdateAttendeeList(DataId      in varchar2,
                               ArrAttendee in ARR_LONGSTR) is
    ATTEARR PKG_COMMON.ARR_LONGSTR;
  begin
    --added by lihuawei at 2020/5/7
    --参会人列表 采用删除再重新插入的形式进行更新
    --因参会人存在变化的情况，则针对会议纪要应生成对应的参会人列表，以便明确当时参会人
    delete from lcoa.oa_sde_schedule_number where c_sch_id = DataId;
    if ArrAttendee is not null and ArrAttendee.Count > 0 then
      for I in ArrAttendee.First .. ArrAttendee.Last loop
        ATTEARR := PKG_COMMON.Split(ArrAttendee(I), '^');
        insert into lcoa.oa_sde_schedule_number
          (c_sch_id, c_user_id, n_type)
        values
          (DataId, ATTEARR(1), 1);
      end loop;
    end if;
  end;

  procedure UpdateScheduleInfo(DATAARR PKG_COMMON.ARR_LONGSTR) is
  begin
    UPDATE OA_SDE_SCHEDULE_INFO
    SET    d_sch_date           = to_date(DATAARR(2), 'yyyymmddhh24miss'),
           d_sch_start_time     = to_date(DATAARR(3), 'yyyymmddhh24miss'),
           d_sch_end_time       = to_date(DATAARR(4), 'yyyymmddhh24miss'),
           c_sch_user_id        = DATAARR(5),
           v_sch_title          = DATAARR(6),
           v_sch_remark         = DATAARR(7),
           n_repead_type        = DATAARR(8),
           n_sch_type           = DATAARR(9),
           n_meeting_type       = DATAARR(10),
           c_meeting_clerk_id   = DATAARR(11),
           c_meeting_clerk_name = DATAARR(12),
           c_mroom_no           = DATAARR(13)
    WHERE  c_sch_id = DATAARR(1);
  end;

  function updateEmail(schId   in varchar2,
                       schDate in date) return number is
    emailId    char(32);
    sendStatus number(1);
    flowCount  number(3);
  begin
    emailId := sys_guid();
    INSERT INTO OA_MSG_RECIPIENT_ADDR email
      select emailId, u.v_User_Name, u.v_email
      from   lcoa.oa_sde_schedule_number sn
      left   join lcbase.t_zip_user u
      on     sn.c_user_id = u.c_user_id
      where  sn.c_sch_id = schId
      and u.d_enddate >= trunc(sysdate);
    INSERT INTO OA_MSG_EMAIL_INFO email
      SELECT emailId,
             flow.c_flow_id,
             52,
             2,
             2,
             tu.V_USER_NAME,
             tu.V_EMAIL,
             '【会议更新提醒】'||info.V_SCH_TITLE,
             '<div class="container"><div><h2 style="font-size: 24px; color: #333333;"><b>' ||
             info.V_SCH_TITLE ||
             '</b><span style="color: rgb(255, 115, 0);font-size: 14px;margin-left: 10px;">已更改</span></h2></div><div><span style="width: 80px;text-align: left;font-size: 16px;font-weight: 500;">会议时间:</span><span style="font-size: 16px;margin-left: 20px;">' ||
             TO_CHAR(flow.D_FLOW_DATE, 'YYYY.MM.DD') || ' ' ||
             TO_CHAR(info.D_SCH_START_TIME, 'hh24:mi') || ' ~ ' ||
             TO_CHAR(flow.D_FLOW_DATE, 'YYYY.MM.DD') || ' ' ||
             TO_CHAR(info.D_SCH_END_TIME, 'hh24:mi') ||
             '</span></div><div><span style="width: 80px;text-align: left;font-size: 16px;font-weight: 500;">会议地点:</span><span style="font-size: 16px;margin-left: 20px;">' ||
             decode(INFO.N_MEETING_TYPE, 1, '电话会议', room.V_MROOM_NAME) ||
             '</span></div><div style="margin-top: 30px;">登录OA系统查阅更多详情</div></div>',
             0,
             0,
             sysdate,
             NULL,
             0,
             1
      FROM   lcoa.oa_sde_scheduling_flow flow
      LEFT   JOIN lcoa.oa_Sde_schedule_info info
      ON     flow.C_SCH_ID = INFO.C_SCH_ID
      LEFT   JOIN lcbase.T_zip_USER tu
      ON     info.C_SCH_USER_ID = tu.C_USER_ID
      LEFT   JOIN lcoa.OA_SDE_MEETINGROOM_INFO room
      ON     info.C_MROOM_NO = room.C_MROOM_NO
      WHERE  flow.c_sch_id = schId
      and tu.d_enddate >= trunc(sysdate)
      AND    trunc(flow.D_FLOW_DATE, 'dd') = trunc(schDate, 'dd');
    return 0;
  end;

--此块进行变量初始化，可删除
begin
  -- Initialization
  i := 1;
end PKG_INS_SDE_SCHEDULE;
/

