create package body PKG_INS_SDE_SCHEDULE is

    -- Private type declarations
    --type <TypeName> is <Datatype>;

    -- Private constant declarations
    --<ConstantName> constant <Datatype> := <Value>;

    -- Private variable declarations
    --<VariableName> <Datatype>;
    i number(1);

    function Update_Schedule_Info(DataInfo        IN VARCHAR2,
                                  ArrAttendee     in ARR_LONGSTR,
                                  OperationUserId IN VARCHAR2,
                                  ErrMsg          OUT VARCHAR2)
        return NUMBER as
        DATAARR   PKG_COMMON.ARR_LONGSTR;
        DataId    char(32);
        T_DY      date;
        TodoTitle varchar2(100);
        n_errcode number(6);
        nUserDiff number(1);
    begin
        DATAARR := PKG_COMMON.Split(DataInfo, '^');
        DataId  := DATAARR(1);
    
        nUserDiff := CheckClerkUserDiff(DATAARR(11), DataId);
        UpdateScheduleInfo(DATAARR);
        UpdateAttendeeList(DataId, ArrAttendee);
    
        T_DY      := trunc(to_date(DATAARR(2),
                                   'yyyymmddhh24miss'),
                           'dd');
        TodoTitle := '【' || DATAARR(6) || '】会议纪要';
    
        RecreateScheduleFlow(DataId       => DataId,
                             RepeadType   => DATAARR(8),
                             ScheduleType => DATAARR(9),
                             UserDiff     => nUserDiff,
                             Today        => T_DY,
                             TodoUserId   => DATAARR(11),
                             TodoTitle    => TodoTitle);
        return 0;
    
    end;

    function CheckClerkUserDiff(TodoUserId in varchar2,
                                DataId     in varchar2)
        return number is
        nRet        number(1) := 0;
        cOldClerkId char(32);
    begin
        select c_meeting_clerk_id
          into cOldClerkId
          from OA_SDE_SCHEDULE_INFO
         WHERE c_sch_id = DataId;
        if cOldClerkId = TodoUserId then
            nRet := 0;
        else
            nRet := 1;
        end if;
        return nRet;
    end;

    procedure RecreateScheduleFlow(DataId       in varchar2,
                                   RepeadType   in number,
                                   ScheduleType in number,
                                   UserDiff     in number,
                                   Today        in date,
                                   TodoUserId   in varchar2,
                                   TodoTitle    in varchar2) is
        P_ID char(32);
        W_IX number(1);
    begin
        --删除上次生成的日程待办（当前时间之后的）
        delete from lcoa.oa_tdo_todo_info t
         where t.n_status = 0 --已完成的待办信息不处理，会议纪要待办以发布会议纪要为准；单纯保存会议纪要，该状态无变化
           and t.c_todo_data_id in
               (select c_flow_id
                  from LCOA.OA_SDE_SCHEDULING_FLOW f
                 where f.c_sch_id = DataId
                   and f.d_flow_date >= trunc(Today, 'dd') --只删除要调整日程日及以后的待办信息
                );
    
        --删除上次生成的日程（当前时间之后的）
        delete from LCOA.OA_SDE_SCHEDULING_FLOW f
         where f.c_sch_id = DataId
           and f.d_flow_date >= trunc(Today, 'dd')
           and f.c_flow_id not in
               (select c_meeting_id
                  from lcoa.oa_sde_meeting_info
                 where c_sch_id = DataId
                   and n_status = 1);
        --重新生成当前时间之后的日程
        --重复方式(0不重复1每日2工作日3每周4每月)
        if RepeadType = 0 then
            P_ID := lower(sys_guid());
            insert into LCOA.OA_SDE_SCHEDULING_FLOW
                (c_flow_id, c_sch_id, d_flow_date)
            values
                (P_ID, DataId, Today);
            if ScheduleType = 2 then
                insert into lcoa.oa_tdo_todo_info
                    (c_todo_id,
                     c_todo_user_id,
                     d_todo_time,
                     n_todo_type,
                     v_todo_title,
                     d_input_time,
                     n_status,
                     --d_done_time,
                     c_todo_data_id)
                values
                    (lower(sys_guid()),
                     TodoUserId,
                     Today,
                     52,
                     TodoTitle,
                     sysdate,
                     0,
                     --null,
                     P_ID);
            end if;
        elsif RepeadType = 1 then
            for i in 0 .. 365 loop
                P_ID := lower(sys_guid());
                insert into LCOA.OA_SDE_SCHEDULING_FLOW
                    (c_flow_id, c_sch_id, d_flow_date)
                values
                    (P_ID, DataId, Today + i);
                if ScheduleType = 2 then
                    insert into lcoa.oa_tdo_todo_info
                        (c_todo_id,
                         c_todo_user_id,
                         d_todo_time,
                         n_todo_type,
                         v_todo_title,
                         d_input_time,
                         n_status,
                         --d_done_time,
                         c_todo_data_id)
                    values
                        (lower(sys_guid()),
                         TodoUserId,
                         Today + i,
                         52,
                         TodoTitle,
                         sysdate,
                         0,
                         --null,
                         P_ID);
                end if;
            end loop;
        elsif RepeadType = 2 then
            W_IX := to_char(Today, 'd');
            for i in 0 .. 365 loop
                if MOD(W_IX + i, 7) > 1 then
                    -- in (0,1)
                    P_ID := lower(sys_guid());
                    insert into LCOA.OA_SDE_SCHEDULING_FLOW
                        (c_flow_id, c_sch_id, d_flow_date)
                    values
                        (P_ID, DataId, Today + i);
                    if ScheduleType = 2 then
                        insert into lcoa.oa_tdo_todo_info
                            (c_todo_id,
                             c_todo_user_id,
                             d_todo_time,
                             n_todo_type,
                             v_todo_title,
                             d_input_time,
                             n_status,
                             --d_done_time,
                             c_todo_data_id)
                        values
                            (lower(sys_guid()),
                             TodoUserId,
                             Today + i,
                             52,
                             TodoTitle,
                             sysdate,
                             0,
                             --null,
                             P_ID);
                    end if;
                end if;
            end loop;
        elsif RepeadType = 3 then
            for i in 0 .. 52 loop
                P_ID := lower(sys_guid());
                insert into LCOA.OA_SDE_SCHEDULING_FLOW
                    (c_flow_id, c_sch_id, d_flow_date)
                values
                    (P_ID, DataId, Today + i * 7);
                if ScheduleType = 2 then
                    insert into lcoa.oa_tdo_todo_info
                        (c_todo_id,
                         c_todo_user_id,
                         d_todo_time,
                         n_todo_type,
                         v_todo_title,
                         d_input_time,
                         n_status,
                         --d_done_time,
                         c_todo_data_id)
                    values
                        (lower(sys_guid()),
                         TodoUserId,
                         Today + i * 7,
                         52,
                         TodoTitle,
                         sysdate,
                         0,
                         --null,
                         P_ID);
                end if;
            end loop;
        elsif RepeadType = 4 then
            for i in 0 .. 12 loop
                P_ID := lower(sys_guid());
                insert into LCOA.OA_SDE_SCHEDULING_FLOW
                    (c_flow_id, c_sch_id, d_flow_date)
                values
                    (P_ID, DataId, add_months(Today, i));
                if ScheduleType = 2 then
                    insert into lcoa.oa_tdo_todo_info
                        (c_todo_id,
                         c_todo_user_id,
                         d_todo_time,
                         n_todo_type,
                         v_todo_title,
                         d_input_time,
                         n_status,
                         --d_done_time,
                         c_todo_data_id)
                    values
                        (lower(sys_guid()),
                         TodoUserId,
                         add_months(Today, i),
                         52,
                         TodoTitle,
                         sysdate,
                         0,
                         --null,
                         P_ID);
                end if;
            end loop;
        end if;
    end;

    procedure UpdateAttendeeList(DataId      in varchar2,
                                 ArrAttendee in ARR_LONGSTR) is
        ATTEARR PKG_COMMON.ARR_LONGSTR;
    begin
        --added by lihuawei at 2020/5/7
        --参会人列表 采用删除再重新插入的形式进行更新
        --因参会人存在变化的情况，则针对会议纪要应生成对应的参会人列表，以便明确当时参会人
        delete from lcoa.oa_sde_schedule_number
         where c_sch_id = DataId;
    
        if ArrAttendee is not null and
           ArrAttendee.Count > 0 then
            for I in ArrAttendee.First .. ArrAttendee.Last loop
                ATTEARR := PKG_COMMON.Split(ArrAttendee(I),
                                            '^');
                insert into lcoa.oa_sde_schedule_number
                    (c_sch_id, c_user_id, n_type)
                values
                    (DataId, ATTEARR(1), 1);
            end loop;
        end if;
    end;
    procedure UpdateScheduleInfo(DATAARR PKG_COMMON.ARR_LONGSTR) is
    begin
        UPDATE OA_SDE_SCHEDULE_INFO
           SET d_sch_date           = to_date(DATAARR(2),
                                              'yyyymmddhh24miss'),
               d_sch_start_time     = to_date(DATAARR(3),
                                              'yyyymmddhh24miss'),
               d_sch_end_time       = to_date(DATAARR(4),
                                              'yyyymmddhh24miss'),
               c_sch_user_id        = DATAARR(5),
               v_sch_title          = DATAARR(6),
               v_sch_remark         = DATAARR(7),
               n_repead_type        = DATAARR(8),
               n_sch_type           = DATAARR(9),
               n_meeting_type       = DATAARR(10),
               c_meeting_clerk_id   = DATAARR(11),
               c_meeting_clerk_name = DATAARR(12),
               c_mroom_no           = DATAARR(13)
         WHERE c_sch_id = DATAARR(1);
    end;

--此块进行变量初始化，可删除
begin
    -- Initialization
    i := 1;
end PKG_INS_SDE_SCHEDULE;
/

