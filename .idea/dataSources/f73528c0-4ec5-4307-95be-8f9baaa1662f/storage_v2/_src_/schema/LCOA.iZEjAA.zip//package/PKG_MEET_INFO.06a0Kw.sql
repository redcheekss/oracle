create package PKG_MEET_info as

    /*
       业务操作
             --获取会议基础信息
       time
             2020-04-05
       author
             jiaxinxin
    
    */
    procedure meetingmanager_GetMeetBaseInfo(operationUserId in char,
                                             rooms_result    out SYS_REFCURSOR);

    /*
       业务操作
             获取会议类型
       time
             2020-04-05
       author
             jiaxinxin
    
    */

    procedure meetingmanager_GetMeetTypeInfo(operationUserId in char,
                                             N_MEETING_TYPE  out SYS_REFCURSOR);

    /*
       业务操作
             获取参会人
       time
             2020-04-05
       author
             jiaxinxin
    
    */
    procedure meetingmanager_GetPeopleInfo(operationUserId in char,
                                           c_meting_id     in char,
                                           V_USER_NAMES    out SYS_REFCURSOR);

    /*
       业务操作
             --test 测试
       time
             2020-04-05
       author
             jiaxinxin
    
    */
    function test(name in varchar2) RETURN NUMBER;

    /*
       1 业务操作
             Add_OA_SDE_MEETING_INFO  会议纪要信息表
       time
             2020-04-15
       author
             jiaxinxin
    
    */
    function add_meeting_info(SDE_MEETING_INFO     IN varchar2,
                              is_exists_meeting_id out varchar2,
                              meeting_id           out varchar2,
                              meeting_title        out varchar2,
                              V_SCH_ID             out varchar2,
                              ErrMsg               OUT VARCHAR2)
        return number;

    /*
     2 业务操作
          OA_SDE_ATTENDEE_LIST  是否缺席表
     time
           2020-04-15
     author
           jiaxinxin
    
    */
    function ADD_SDE_ATTENDEE_LIST(SDE_ATTENDEE_LIST    IN ARR_LONGSTR,
                                   is_exists_meeting_id in varchar2,
                                   metting_id           IN char,
                                   ErrMsg               OUT VARCHAR2)
        return number;

    /*
       3 业务操作
             OA_SDE_MEETING_CONTENT_LIST  会议纪要内容列表
       time
             2020-04-15
       author
             jiaxinxin
    
    */
    function add_SDE_MEETING_CONTENT_LIST(SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                          is_exist_meeting_id      in char,
                                          C_MEETING_ID             in char,
                                          ErrMsg                   OUT VARCHAR2)
        return number;

    /*
       4 业务操作
             会议纪要待办事项  会议纪要待办事项
       time
             2020-04-15
       author
             jiaxinxin
    
    */
    function add_SDE_TODO_LIST(OA_SDE_TODO_LIST    IN ARR_LONGSTR,
                               is_exist_meeting_id in char,
                               meeting_id          in char,
                               ErrMsg              OUT VARCHAR2
                               
                               ) return number;

    /*
       5 业务操作
             USER_UPLOAD_INFO 附件信息表
       time
             2020-04-15
       author
             jiaxinxin
    
    */
    function add_USER_UPLOAD_INFO(USER_UPLOAD_INFO    IN ARR_LONGSTR,
                                  is_exist_meeting_id in char,
                                  meeting_id          in char,
                                  ErrMsg              OUT VARCHAR2
                                  
                                  ) return number;

    /*
       6 业务操作
             MSG_MESSAGE_INFO  用户消息表
       time
             2020-04-15
       author
             jiaxinxin
    
    */
    function add_MSG_MESSAGE_INFO(SDE_MEETING_INFO IN varchar2,
                                  meeting_title    in varchar2,
                                  meeting_id       in varchar2,
                                  operation_id     in varchar2,
                                  ErrMsg           OUT VARCHAR2)
        return number;

    /*
       6 业务操作
            -- 更新用户待办信息状态 表
       time
             2020-04-15
       author
             jiaxinxin
    
    */

    function UPDATE_TDO_TODOINFO(V_SCH_ID in varchar2,
                                 ErrMsg   OUT VARCHAR2
                                 
                                 ) return number;

    /*
        业务类型
          新增会议纪要
        涉及的表
          OA_SDE_MEETING_INFO                    会议纪要信息表
          OA_SDE_ATTENDEE_LIST                   是否缺席表
          OA_SDE_MEETING_CONTENT_LIST            会议纪要内容列表
          OA_USER_UPLOAD_INFO                    附件信息表
    
    
    
        in ：字符串信息
        out： return 1 为成功/0为失败
    
    */
    function add_meetingsummary_info(SDE_MEETING_INFO         IN varchar2,
                                     SDE_ATTENDEE_LIST        IN ARR_LONGSTR,
                                     SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                     OA_SDE_TODO_LIST         IN ARR_LONGSTR,
                                     USER_UPLOAD_INFO         IN ARR_LONGSTR,
                                     operation_id             in varchar2,
                                     ErrMsg                   OUT VARCHAR2,
                                     sys_meeting_id           out varchar2)
        return number;

    /*
        业务类型
             发布会议纪要
    
        涉及的表
          OA_MSG_MESSAGE_INFO  用户消息表
          OA_TDO_TODO_INFO  用户待办事项
    
        out： return 1 为发布成功/0为发布失败
    
    */
    function Meeting_msg_releaseInfo(SDE_MEETING_INFO         IN varchar2,
                                     SDE_ATTENDEE_LIST        IN ARR_LONGSTR,
                                     SDE_MEETING_CONTENT_LIST IN ARR_LONGSTR,
                                     OA_SDE_TODO_LIST         IN ARR_LONGSTR,
                                     USER_UPLOAD_INFO         IN ARR_LONGSTR,
                                     operation_id             in varchar2,
                                     ErrMsg                   OUT VARCHAR2)
        return number;

    --获取会议纪要详情信息内容
    function get_meetingsummary_detals(C_MEETING_ID IN char, -- 会议ID
                                       C_SCH_ID     IN varchar2, -- 日程ID
                                       
                                       metting_detals out SYS_REFCURSOR,
                                       ErrMsg         OUT VARCHAR2
                                       
                                       ) return number;

    --删除待办信息
    /*
        业务类型
            待办信息操作
            OA_SDE_TODO_LIST
        涉及的表
        out： return 1 为发布成功/0为发布失败
    */
    /*
    
      function del_OA_SDE_TODO_LIST(C_MEETING_ID IN char, ErrMsg OUT VARCHAR2)
        return number;
    */
    /*
        业务类型
           更新meeting_info 表状态 status
        涉及的表
        out： return 1 为发布成功/0为发布失败
    */
    function update_meeting_status(meeting_id IN varchar2,
                                   ErrMsg     OUT VARCHAR2)
        return number;

end PKG_MEET_info;
/

