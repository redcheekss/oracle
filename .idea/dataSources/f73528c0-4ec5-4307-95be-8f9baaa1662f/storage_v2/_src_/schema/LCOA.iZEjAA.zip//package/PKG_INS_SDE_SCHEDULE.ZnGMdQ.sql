create package PKG_INS_SDE_SCHEDULE is

  -- Author  : USER
  -- Created : 2020/4/12 16:43:10
  -- Purpose : TEMP
  -- Public type declarations
  --type <TypeName> is <Datatype>;
  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;
  -- Public variable declarations
  --<VariableName> <Datatype>;
  -- Public function and procedure declarations
  --function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;
  function Update_Schedule_Info(DataInfo        IN VARCHAR2,
                                ArrAttendee     in ARR_LONGSTR,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) return NUMBER;

  procedure UpdateScheduleInfo(DATAARR PKG_COMMON.ARR_LONGSTR);

  procedure UpdateAttendeeList(DataId      in varchar2,
                               ArrAttendee in ARR_LONGSTR);

  procedure RecreateScheduleFlow(DataId       in varchar2,
                                 RepeadType   in number,
                                 ScheduleType in number,
                                 UserDiff     in number,
                                 Today        in date,
                                 TodoUserId   in varchar2,
                                 TodoTitle    in varchar2);

  --检查会议记录人是否发生变化
  --依据日程原有记录人与新传入记录入进行比对
  --输入：TodoUserId新会议记录人，DataId日程ID
  --返回值：0无变化，1有变化
  function CheckClerkUserDiff(TodoUserId in varchar2,
                              DataId     in varchar2) return number;

  function updateEmail(schId   in varchar2,
                       schDate in date) return number;

end PKG_INS_SDE_SCHEDULE;
/

