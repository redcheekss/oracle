create package body PKG_INS_TRANSFERPOSITION_INFO is

  function get_approval_list(recordvo        in varchar2,
                             pageNum         in number,
                             PageSize        in number,
                             getapprovallist out sys_refcursor,
                             totalPage       out number,
                             totalCount      out number,
                             errmsg          out varchar2) return number is
    dataarr  pkg_common.arr_longstr;
    listtype number(6);
    n_result number(6);
    v_sql    varchar2(2000);
  begin
    dataarr  := pkg_common.split(recordvo, '^');
    listtype := dataarr(2);
    -- 查询插入请假列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_leave_list(dataarr(1),
                                                             dataarr(3),
                                                             dataarr(4),
                                                             1,
                                                             errmsg);
    -- 查询插入外出列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_egress_list(dataarr(1),
                                                              dataarr(3),
                                                              dataarr(4),
                                                              1,
                                                              errmsg);
    -- 查询插入公告列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_news_list(dataarr(1),
                                                            dataarr(3),
                                                            dataarr(4),
                                                            1,
                                                            errmsg);
    -- 查询插入调岗列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_adjustpost_list(dataarr(1),
                                                                  dataarr(3),
                                                                  dataarr(4),
                                                                  1,
                                                                  errmsg);
    -- 查询插入转正列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_promotion_list(dataarr(1),
                                                                 dataarr(3),
                                                                 dataarr(4),
                                                                 1,
                                                                 errmsg);
    -- 查询插入借款列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_loan_list(dataarr(1),
                                                            dataarr(3),
                                                            dataarr(4),
                                                            1,
                                                            errmsg);
    -- 查询插入还款列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_repayment_list(dataarr(1),
                                                                 dataarr(3),
                                                                 dataarr(4),
                                                                 1,
                                                                 errmsg);
    -- 查询插入借款延期列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_extension_list(dataarr(1),
                                                                 dataarr(3),
                                                                 dataarr(4),
                                                                 1,
                                                                 errmsg);
    -- 查询插入数据修改列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_datamodify_list(dataarr(1),
                                                                  dataarr(3),
                                                                  dataarr(4),
                                                                  1,
                                                                  errmsg);
    -- 判断是否传入查询类型参数 如果没有就查询全部，否则按传入类型查询列表
    v_sql := 'select DISTINCT ID, TYPES, TYPENAME, USERNAME, STATUS, STARTTIME,
										 ENDTIME, INPUTUSERID, ABSTRACTS, STATUSNAME, ISTOP, INPUTDATE
										 from lcoa.oa_afw_approval_list ';
    if listtype is not null then
      v_sql := v_sql || ' where types = ' || listtype;
    end if;
    v_sql    := v_sql || 'order by inputdate desc';
    n_result := lcoa.pkg_common.GetPagingInfo(v_sql,
                                              PageSize,
                                              pageNum,
                                              getapprovallist,
                                              totalCount,
                                              totalPage);
    delete from lcoa.oa_afw_approval_list;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'get_approval_list: ' || sqlcode || ',' || sqlerrm;
      raise;
      rollback;
      return 1;
  end;

  function get_apply_list(recordvo     in varchar2,
                          pageNum      in number,
                          PageSize     in number,
                          getapplylist out sys_refcursor,
                          totalPage    out number,
                          totalCount   out number,
                          errmsg       out varchar2) return number is
    dataarr  pkg_common.arr_longstr;
    listtype number(6);
    n_result number(6);
    v_sql    varchar2(2000);
  begin
    dataarr  := pkg_common.split(recordvo, '^');
    listtype := dataarr(2);
    -- 查询插入请假列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_leave_list(dataarr(1),
                                                             dataarr(3),
                                                             dataarr(4),
                                                             2,
                                                             errmsg);
    -- 查询插入外出列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_egress_list(dataarr(1),
                                                              dataarr(3),
                                                              dataarr(4),
                                                              2,
                                                              errmsg);
    -- 查询插入公告列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_news_list(dataarr(1),
                                                            dataarr(3),
                                                            dataarr(4),
                                                            2,
                                                            errmsg);
    -- 查询插入调岗列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_adjustpost_list(dataarr(1),
                                                                  dataarr(3),
                                                                  dataarr(4),
                                                                  2,
                                                                  errmsg);
    -- 查询插入转正列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_promotion_list(dataarr(1),
                                                                 dataarr(3),
                                                                 dataarr(4),
                                                                 2,
                                                                 errmsg);
    -- 查询插入借款列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_loan_list(dataarr(1),
                                                            dataarr(3),
                                                            dataarr(4),
                                                            2,
                                                            errmsg);
    -- 查询插入还款列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_repayment_list(dataarr(1),
                                                                 dataarr(3),
                                                                 dataarr(4),
                                                                 2,
                                                                 errmsg);
    -- 查询插入借款延期列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_extension_list(dataarr(1),
                                                                 dataarr(3),
                                                                 dataarr(4),
                                                                 2,
                                                                 errmsg);
    -- 查询插入借款延期列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_datamodify_list(dataarr(1),
                                                                  dataarr(3),
                                                                  dataarr(4),
                                                                  2,
                                                                  errmsg);
    -- 判断是否传入查询类型参数 如果没有就查询全部，否则按传入类型查询列表
    v_sql := 'select DISTINCT ID, TYPES, TYPENAME, USERNAME, STATUS, STARTTIME,
										 ENDTIME, INPUTUSERID, ABSTRACTS, STATUSNAME, ISTOP, INPUTDATE
										 from lcoa.oa_afw_approval_list ';
    if listtype is not null then
      v_sql := v_sql || ' where types = ' || listtype;
    end if;
    v_sql    := v_sql || 'order by inputdate desc';
    n_result := lcoa.pkg_common.GetPagingInfo(v_sql,
                                              PageSize,
                                              pageNum,
                                              getapplylist,
                                              totalCount,
                                              totalPage);
    delete from lcoa.oa_afw_approval_list;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'get_apply_list: ' || sqlcode || ',' || sqlerrm;
      raise;
      rollback;
      return 1;
  end;

  function add_leave_list(userid            in varchar2,
                          startdate         in varchar2,
                          enddate           in varchar2,
                          approvalapplytype in number,
                          errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT a.c_leave_id AS id,
                       1 AS types,
                       '请假' AS typeName,
                       t.v_pet_name AS userName,
                       a.n_status AS status,
                       a.d_leave_start_time AS startTime,
                       a.d_leave_end_time AS endTime,
                       a.c_leave_user_id AS inputUserId,
                       DECODE(a.n_leave_type,
                              1,
                              '事假',
                              2,
                              '病假',
                              3,
                              '调休',
                              4,
                              '年假',
                              5,
                              '产假',
                              6,
                              '哺乳假',
                              7,
                              '婚假',
                              8,
                              '丧假',
                              9,
                              '陪产假',
                              10,
                              '产检假',
                              '其它请假') || CASE
                         WHEN a.n_leave_days > 0 THEN
                          a.n_leave_days || '天'
                         ELSE
                          NULL
                       END || CASE
                         WHEN a.n_leave_hours > 0 THEN
                          a.n_leave_hours || '小时'
                         ELSE
                          NULL
                       END || '【' ||
                       TO_CHAR(a.d_leave_start_time, 'yyyy-MM-dd HH24:mi') ||
                       ' 至 ' ||
                       TO_CHAR(a.d_leave_end_time, 'yyyy-MM-dd HH24:mi') || '】' AS abstracts,
                       DECODE(a.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       a.d_input_date AS inputDate
                  FROM lcoa.OA_AFW_LEAVE_INFO a
                  LEFT JOIN lcbase.t_zip_user t
                    ON a.c_leave_user_id = t.c_user_id
                 where a.c_leave_id in
                       (select f.c_workflow_id
                          from lcoa.oa_afw_workflow_approval_flow f
                         where f.c_approval_user_id = userid
                           and f.n_approval_status != 0)
                   and (a.d_input_date >= trunc(t.d_startdate) and
                       a.d_input_date < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT a.c_leave_id AS id,
                       1 AS types,
                       '请假' AS typeName,
                       t.v_pet_name AS userName,
                       a.n_status AS status,
                       a.d_leave_start_time AS startTime,
                       a.d_leave_end_time AS endTime,
                       a.c_leave_user_id AS inputUserId,
                       DECODE(a.n_leave_type,
                              1,
                              '事假',
                              2,
                              '病假',
                              3,
                              '调休',
                              4,
                              '年假',
                              5,
                              '产假',
                              6,
                              '哺乳假',
                              7,
                              '婚假',
                              8,
                              '丧假',
                              9,
                              '陪产假',
                              10,
                              '产检假',
                              '其它请假') || CASE
                         WHEN a.n_leave_days > 0 THEN
                          a.n_leave_days || '天'
                         ELSE
                          NULL
                       END || CASE
                         WHEN a.n_leave_hours > 0 THEN
                          a.n_leave_hours || '小时'
                         ELSE
                          NULL
                       END || '【' ||
                       TO_CHAR(a.d_leave_start_time, 'yyyy-MM-dd HH24:mi') ||
                       ' 至 ' ||
                       TO_CHAR(a.d_leave_end_time, 'yyyy-MM-dd HH24:mi') || '】' AS abstracts,
                       DECODE(a.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       a.d_input_date AS inputDate
                  FROM lcoa.OA_AFW_LEAVE_INFO a
                  LEFT JOIN LCBASE.t_zip_user t
                    ON a.c_leave_user_id = t.c_user_id
                 WHERE a.c_leave_user_id = userid
                   and (a.d_input_date >= trunc(t.d_startdate) and
                       a.d_input_date < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_leave_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_egress_list(userid            in varchar2,
                           startdate         in varchar2,
                           enddate           in varchar2,
                           approvalapplytype in number,
                           errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT b.c_egress_id AS id,
                       2 AS types,
                       '外出' AS typeName,
                       t.v_pet_name AS userName,
                       B.n_status AS status,
                       B.d_egress_start_time AS startTime,
                       B.d_egress_end_time AS endTime,
                       B.C_EGRESS_USER_ID AS inputUserId,
                       DECODE(b.n_egress_type,
                              1,
                              '市内外出',
                              2,
                              '出差',
                              '其它外出') || CASE
                         WHEN b.n_egress_days > 0 THEN
                          b.n_egress_days || '天'
                         ELSE
                          NULL
                       END || CASE
                         WHEN b.n_egress_hours > 0 THEN
                          b.n_egress_hours || '小时'
                         ELSE
                          NULL
                       END || '【' ||
                       TO_CHAR(b.d_egress_start_time, 'yyyy-MM-dd HH24:mi') ||
                       ' 至 ' ||
                       TO_CHAR(b.d_egress_end_time, 'yyyy-MM-dd HH24:mi') || '】' AS abstracts,
                       DECODE(B.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       B.d_input_date AS inputDate
                  FROM LCOA.OA_AFW_EGRESS_INFO b
                  LEFT JOIN lcbase.t_zip_user t
                    ON b.c_egress_user_id = t.c_user_id
                 WHERE b.c_egress_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0)
                   and (b.d_input_date >= trunc(t.d_startdate) and
                       b.d_input_date < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT b.c_egress_id AS id,
                       2 AS types,
                       '外出' AS typeName,
                       t.v_pet_name AS userName,
                       B.n_status AS status,
                       B.d_egress_start_time AS startTime,
                       B.d_egress_end_time AS endTime,
                       B.C_EGRESS_USER_ID AS inputUserId,
                       DECODE(b.n_egress_type,
                              1,
                              '市内外出',
                              2,
                              '出差',
                              '其它外出') || CASE
                         WHEN b.n_egress_days > 0 THEN
                          b.n_egress_days || '天'
                         ELSE
                          NULL
                       END || CASE
                         WHEN b.n_egress_hours > 0 THEN
                          b.n_egress_hours || '小时'
                         ELSE
                          NULL
                       END || '【' ||
                       TO_CHAR(b.d_egress_start_time, 'yyyy-MM-dd HH24:mi') ||
                       ' 至 ' ||
                       TO_CHAR(b.d_egress_end_time, 'yyyy-MM-dd HH24:mi') || '】' AS abstracts,
                       DECODE(B.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       B.d_input_date AS inputDate
                  FROM LCOA.OA_AFW_EGRESS_INFO b
                  LEFT JOIN LCBASE.t_zip_user t
                    ON b.c_egress_user_id = t.c_user_id
                 WHERE b.c_egress_user_id = userid
                   and (b.d_input_date >= trunc(t.d_startdate) and
                       b.d_input_date < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_egress_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_news_list(userid            in varchar2,
                         startdate         in varchar2,
                         enddate           in varchar2,
                         approvalapplytype in number,
                         errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_news_id AS id,
                       3 AS types,
                       '公告' AS typeName,
                       t.v_pet_name AS userName,
                       c.n_status AS status,
                       c.d_input_time AS startTime,
                       c.d_input_time AS endTime,
                       c.c_input_user_id AS inputUserId,
                       c.v_news_title || ' -- ' ||
                       DECODE(d.n_target_type,
                              0,
                              '个人',
                              1,
                              '部门',
                              2,
                              '全员') || ' -- ' ||
                       DECODE(c.N_SIGNATURE_TYPE,
                              0,
                              '匿名发布',
                              1,
                              '实名发布',
                              2,
                              '部门发布') || ' -- ' ||
                       DECODE(N_COMMENT_ALLOW,
                              1,
                              '允许评论',
                              0,
                              '不允许评论') || ' -- ' ||
                       DECODE(c.N_MUST_FEEDBACK,
                              1,
                              '需要点击"我已阅"',
                              '不需要点击"我已阅"') ||
                       DECODE(c.N_ISTOP_FLAG, 1, ' -- 置顶') AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       c.N_ISTOP_FLAG AS isTop,
                       c.d_input_time AS inputDate
                  FROM LCOA.OA_MSG_PUBLISH_INFO c
                  LEFT JOIN LCOA.OA_MSG_PUBLISH_RANGE d
                    ON c.c_news_id = d.c_news_id
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_input_user_id = t.c_user_id
                 WHERE c.c_news_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0
                           AND c.N_STATUS <> -2)
                   and (c.d_input_time >= trunc(t.d_startdate) and
                       c.d_input_time < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_news_id AS id,
                       3 AS types,
                       '公告' AS typeName,
                       t.v_pet_name AS userName,
                       c.n_status AS status,
                       c.d_input_time AS startTime,
                       c.d_input_time AS endTime,
                       c.c_input_user_id AS inputUserId,
                       c.v_news_title || ' -- ' ||
                       DECODE(d.n_target_type,
                              0,
                              '个人',
                              1,
                              '部门',
                              2,
                              '全员') || ' -- ' ||
                       DECODE(c.N_SIGNATURE_TYPE,
                              0,
                              '匿名发布',
                              1,
                              '实名发布',
                              2,
                              '部门发布') || ' -- ' ||
                       DECODE(N_COMMENT_ALLOW,
                              1,
                              '允许评论',
                              0,
                              '不允许评论') || ' -- ' ||
                       DECODE(c.N_MUST_FEEDBACK,
                              1,
                              '需要点击"我已阅"',
                              '不需要点击"我已阅"') ||
                       DECODE(c.N_ISTOP_FLAG, 1, ' -- 置顶') AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       c.N_ISTOP_FLAG AS isTop,
                       c.d_input_time AS inputDate
                  FROM LCOA.OA_MSG_PUBLISH_INFO c
                  LEFT JOIN LCOA.OA_MSG_PUBLISH_RANGE d
                    ON c.c_news_id = d.c_news_id
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_input_user_id = t.c_user_id
                 WHERE c.c_input_user_id = userid
                   AND c.N_NEWS_TYPE = 1
                   AND c.N_STATUS <> -2
                   and (c.d_input_time >= trunc(t.d_startdate) and
                       c.d_input_time < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_news_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_adjustpost_list(userid            in varchar2,
                               startdate         in varchar2,
                               enddate           in varchar2,
                               approvalapplytype in number,
                               errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_adjust_id AS id,
                       12 AS types,
                       '调岗' AS typeName,
                       t.v_pet_name AS userName,
                       c.n_status AS status,
                       c.d_input_date AS startTime,
                       c.d_input_date AS endTime,
                       c.c_adjust_user_id AS inputUserId,
                       '现部门：' || oldn.v_organization_name || '- 现岗位：' ||
                       c.v_old_post || '<br/> 调整后部门：' ||
                       newn.v_organization_name || ' -调整后岗位：' ||
                       c.v_new_post AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '已同意',
                              3,
                              '已拒绝',
                              0,
                              '待审批') AS statusName,
                       0 AS isTop,
                       c.d_input_date AS inputDate
                  FROM LCOA.Oa_Afw_Adjustpost_Info c
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_adjust_user_id = t.c_user_id
                  left join lcbase.t_zip_organization oldn
                    on c.c_old_orgnization_id = oldn.c_organization_id
                  left join lcbase.t_zip_organization newn
                    on c.c_new_orgnization_id = newn.c_organization_id
                 WHERE c.c_adjust_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0)
                   and (c.d_input_date >= trunc(oldn.d_startdate) and
                       c.d_input_date < trunc(oldn.d_enddate))
                   and (c.d_input_date >= trunc(newn.d_startdate) and
                       c.d_input_date < trunc(newn.d_enddate))
                   and (c.d_input_date >= trunc(t.d_startdate) and
                       c.d_input_date < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_adjust_id AS id,
                       12 AS types,
                       '调岗' AS typeName,
                       t.v_pet_name AS userName,
                       c.n_status AS status,
                       c.d_input_date AS startTime,
                       c.d_input_date AS endTime,
                       '' AS inputUserId,
                       '现部门：' || oldn.v_organization_name || '- 现岗位：' ||
                       c.v_old_post || '<br/> 调整后部门：' ||
                       newn.v_organization_name || ' -调整后岗位：' ||
                       c.v_new_post AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '已同意',
                              3,
                              '已拒绝',
                              0,
                              '待审批') AS statusName,
                       0 AS isTop,
                       c.d_input_date AS inputDate
                  FROM LCOA.Oa_Afw_Adjustpost_Info c
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_adjust_user_id = t.c_user_id
                  left join lcbase.t_zip_organization oldn
                    on c.c_old_orgnization_id = oldn.c_organization_id
                  left join lcbase.t_zip_organization newn
                    on c.c_new_orgnization_id = newn.c_organization_id
                 WHERE c.c_adjust_user_id = userid
                   and (c.d_input_date >= trunc(oldn.d_startdate) and
                       c.d_input_date < trunc(oldn.d_enddate))
                   and (c.d_input_date >= trunc(newn.d_startdate) and
                       c.d_input_date < trunc(newn.d_enddate))
                   and (c.d_input_date >= trunc(t.d_startdate) and
                       c.d_input_date < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_adjustpost_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_promotion_list(userid            in varchar2,
                              startdate         in varchar2,
                              enddate           in varchar2,
                              approvalapplytype in number,
                              errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_promotion_id AS id,
                       11 AS types,
                       '转正' AS typeName,
                       t.v_pet_name AS userName,
                       c.n_status AS status,
                       c.d_input_date AS startTime,
                       c.d_input_date AS endTime,
                       c.c_promotion_user_id AS inputUserId,
                       '转正 - 入职日期：' ||
                       to_char(c.d_ht_hire_date, 'yyyy-mm-dd') ||
                       ' - 合同转正日期：' ||
                       to_char(c.d_ht_promotion_date, 'yyyy-mm-dd') AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '已同意',
                              3,
                              '已拒绝',
                              4,
                              '已延期',
                              0,
                              '待审批') AS statusName,
                       0 AS isTop,
                       c.d_input_date AS inputDate
                  FROM lcoa.oa_afw_promotion_info c
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_promotion_user_id = t.c_user_id
                 WHERE c.c_promotion_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0)
                   and (c.d_input_date >= trunc(t.d_startdate) and
                       c.d_input_date < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_promotion_id AS id,
                       11 AS types,
                       '转正' AS typeName,
                       t.v_pet_name AS userName,
                       c.n_status AS status,
                       c.d_input_date AS startTime,
                       c.d_input_date AS endTime,
                       c.c_promotion_user_id AS inputUserId,
                       '转正 - 入职日期：' ||
                       to_char(c.d_ht_hire_date, 'yyyy-mm-dd') ||
                       ' - 合同转正日期：' ||
                       to_char(c.d_ht_promotion_date, 'yyyy-mm-dd') AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '已同意',
                              3,
                              '已拒绝',
                              4,
                              '已延期',
                              0,
                              '待审批') AS statusName,
                       0 AS isTop,
                       c.d_input_date AS inputDate
                  FROM lcoa.oa_afw_promotion_info c
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_promotion_user_id = t.c_user_id
                 WHERE c.c_promotion_user_id = userid
                   and (c.d_input_date >= trunc(t.d_startdate) and
                       c.d_input_date < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_promotion_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_loan_list(userid            in varchar2,
                         startdate         in varchar2,
                         enddate           in varchar2,
                         approvalapplytype in number,
                         errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_id AS id,
                       5 AS types,
                       '借款' AS typeName,
                       t.v_pet_name AS userName,
                       DECODE(c.n_approval_status, 4, 6, c.n_approval_status) AS status,
                       c.d_apply_time AS startTime,
                       c.d_apply_time AS endTime,
                       c.c_user_id AS inputUserId,
                       c.v_flow_number || ' - ' ||
                       DECODE(c.n_loan_type, 1, '备用金', 2, '个人借款') || ' - ' ||
                       c.N_AMOUNT || '元 - ' || c.v_cause AS abstracts,
                       DECODE(c.n_approval_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '审批完成',
                              3,
                              '已拒绝',
                              4,
                              '财务审批中',
                              5,
                              '已支付',
                              7,
                              '待支付',
                              0,
                              '待审批') AS statusName,
                       0 AS isTop,
                       c.d_apply_time AS inputDate
                  FROM lcoa.oa_afw_loan_info c
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_user_id = t.c_user_id
                 WHERE c.c_id IN (SELECT f.C_WORKFLOW_ID
                                    FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                                   WHERE f.C_APPROVAL_USER_ID = userid
                                     AND f.N_APPROVAL_STATUS != 0)
                   and (c.d_apply_time >= trunc(t.d_startdate) and
                       c.d_apply_time < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_id AS id,
                       5 AS types,
                       '借款' AS typeName,
                       t.v_pet_name AS userName,
                       DECODE(c.n_approval_status, 4, 6, c.n_approval_status) AS status,
                       c.d_apply_time AS startTime,
                       c.d_apply_time AS endTime,
                       c.c_user_id AS inputUserId,
                       c.v_flow_number || ' - ' ||
                       DECODE(c.n_loan_type, 1, '备用金', 2, '个人借款') || ' - ' ||
                       c.N_AMOUNT || '元 - ' || c.v_cause AS abstracts,
                       DECODE(c.n_approval_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '审批完成',
                              3,
                              '已拒绝',
                              4,
                              '财务审批中',
                              5,
                              '已支付',
                              7,
                              '待支付',
                              0,
                              '待审批') AS statusName,
                       0 AS isTop,
                       c.d_apply_time AS inputDate
                  FROM lcoa.oa_afw_loan_info c
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_user_id = t.c_user_id
                 WHERE c.c_user_id = userid
                   and (c.d_apply_time >= trunc(t.d_startdate) and
                       c.d_apply_time < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_loan_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_repayment_list(userid            in varchar2,
                              startdate         in varchar2,
                              enddate           in varchar2,
                              approvalapplytype in number,
                              errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_id AS id,
                       6 AS types,
                       '还款' AS typeName,
                       t.v_pet_name AS userName,
                       DECODE(c.n_confirm_status, 0, 8, 1, 9) AS status,
                       c.d_apply_time AS startTime,
                       c.d_apply_time AS endTime,
                       c.c_user_id AS inputUserId,
                       DECODE(c.n_replayment_type,
                              1,
                              '个人还款',
                              2,
                              '报销还款') || ' - ' || c.N_REPLAYMENT_AMOUNT || '元' AS abstracts,
                       DECODE(c.n_confirm_status,
                              0,
                              '还款待确认',
                              1,
                              '已还款') AS statusName,
                       0 AS isTop,
                       c.d_apply_time AS inputDate
                  FROM lcoa.oa_afw_repayment_info c
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_user_id = t.c_user_id
                 WHERE c.c_id IN (SELECT f.C_WORKFLOW_ID
                                    FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                                   WHERE f.C_APPROVAL_USER_ID = userid
                                     AND f.N_APPROVAL_STATUS != 0)
                   and c.n_status = 0
                   and (c.d_apply_time >= trunc(t.d_startdate) and
                       c.d_apply_time < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_id AS id,
                       6 AS types,
                       '还款' AS typeName,
                       t.v_pet_name AS userName,
                       DECODE(c.n_confirm_status, 0, 8, 1, 9) AS status,
                       c.d_apply_time AS startTime,
                       c.d_apply_time AS endTime,
                       c.c_user_id AS inputUserId,
                       DECODE(c.n_replayment_type,
                              1,
                              '个人还款',
                              2,
                              '报销还款') || ' - ' || c.N_REPLAYMENT_AMOUNT || '元' AS abstracts,
                       DECODE(c.n_confirm_status,
                              0,
                              '还款待确认',
                              1,
                              '已还款') AS statusName,
                       0 AS isTop,
                       c.d_apply_time AS inputDate
                  FROM lcoa.oa_afw_repayment_info c
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_user_id = t.c_user_id
                 WHERE c.c_user_id = userid
                   and c.n_status = 0
                   and (c.d_apply_time >= trunc(t.d_startdate) and
                       c.d_apply_time < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_repayment_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_extension_list(userid            in varchar2,
                              startdate         in varchar2,
                              enddate           in varchar2,
                              approvalapplytype in number,
                              errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_id AS id,
                       7 AS types,
                       '借款延期' AS typeName,
                       t.v_pet_name AS userName,
                       c.n_approval_status AS status,
                       c.d_apply_time AS startTime,
                       c.d_apply_time AS endTime,
                       c.c_user_id AS inputUserId,
                       d.v_flow_number || ' - ' ||
                       DECODE(d.n_loan_type, 1, '备用金', 2, '个人借款') || ' - ' ||
                       d.n_amount || '元 - ' || c.v_cause || ' - 延期时间：' ||
                       to_char(c.d_extension_date, 'yyyy-mm-dd') AS abstracts,
                       DECODE(c.n_approval_status,
                              0,
                              '待审批',
                              1,
                              '审批中',
                              2,
                              '审批完成',
                              3,
                              '驳回',
                              4,
                              '已还款') AS statusName,
                       0 AS isTop,
                       c.d_apply_time AS inputDate
                  FROM lcoa.oa_afw_loan_extension c
                  left join lcoa.oa_afw_loan_info d
                    on c.c_loan_id = d.C_ID
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_user_id = t.c_user_id
                 WHERE c.c_id IN (SELECT f.C_WORKFLOW_ID
                                    FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                                   WHERE f.C_APPROVAL_USER_ID = userid
                                     AND f.N_APPROVAL_STATUS != 0)
                   and (c.d_apply_time >= trunc(t.d_startdate) and
                       c.d_apply_time < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_id AS id,
                       7 AS types,
                       '借款延期' AS typeName,
                       t.v_pet_name AS userName,
                       c.n_approval_status AS status,
                       c.d_apply_time AS startTime,
                       c.d_apply_time AS endTime,
                       c.c_user_id AS inputUserId,
                       d.v_flow_number || ' - ' ||
                       DECODE(d.n_loan_type, 1, '备用金', 2, '个人借款') || ' - ' ||
                       d.n_amount || '元 - ' || c.v_cause || ' - 延期时间：' ||
                       to_char(c.d_extension_date, 'yyyy-mm-dd') AS abstracts,
                       DECODE(c.n_approval_status,
                              0,
                              '待审批',
                              1,
                              '审批中',
                              2,
                              '审批完成',
                              3,
                              '驳回',
                              4,
                              '已还款') AS statusName,
                       0 AS isTop,
                       c.d_apply_time AS inputDate
                  FROM lcoa.oa_afw_loan_extension c
                  left join lcoa.oa_afw_loan_info d
                    on c.c_loan_id = d.C_ID
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_user_id = t.c_user_id
                 WHERE c.c_user_id = userid
                   and (c.d_apply_time >= trunc(t.d_startdate) and
                       c.d_apply_time < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_extension_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_datamodify_list(userid            in varchar2,
                               startdate         in varchar2,
                               enddate           in varchar2,
                               approvalapplytype in number,
                               errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_datamodify_apply_id AS id,
                       16 AS types,
                       '数据修改' AS typeName,
                       t.v_pet_name AS userName,
                       c.n_status AS status,
                       c.d_input_date AS startTime,
                       c.d_input_date AS endTime,
                       c.c_input_user_id AS inputUserId,
                       DECODE(c.n_business_type,
                              1,
                              '干线',
                              2,
                              '精拼',
                              3,
                              'KA') || ' - 修改内容' || c.v_modify_content AS abstracts,
                       DECODE(c.n_status, --状态（0:已申请(待审批);1:审批中;2:已通过;3:已拒绝;4:待分发;5:处理中;6:处理完成;-1:撤回）
                              -2,
                              '处理人驳回',
                              -1,
                              '已撤回',
                              0,
                              '待审批',
                              1,
                              '审批中',
                              2,
                              '已通过',
                              3,
                              '已拒绝',
                              4,
                              '待分发',
                              5,
                              '处理中',
                              6,
                              '处理完成') AS statusName,
                       0 AS isTop,
                       c.d_input_date AS inputDate
                  FROM lcoa.oa_afw_dmd_apply c
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_input_user_id = t.c_user_id
                 WHERE c.c_datamodify_apply_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0)
                   and (c.d_input_date >= trunc(t.d_startdate) and
                       c.d_input_date < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_datamodify_apply_id AS id,
                       16 AS types,
                       '数据修改' AS typeName,
                       t.v_pet_name AS userName,
                       c.n_status AS status,
                       c.d_input_date AS startTime,
                       c.d_input_date AS endTime,
                       c.c_input_user_id AS inputUserId,
                       DECODE(c.n_business_type,
                              1,
                              '干线',
                              2,
                              '精拼',
                              3,
                              'KA') || ' - 修改内容' || c.v_modify_content AS abstracts,
                       DECODE(c.n_status, --状态（0:已申请(待审批);1:审批中;2:已通过;3:已拒绝;4:待分发;5:处理中;6:处理完成;-1:撤回）
                              -2,
                              '处理人驳回',
                              -1,
                              '已撤回',
                              0,
                              '待审批',
                              1,
                              '审批中',
                              2,
                              '已通过',
                              3,
                              '已拒绝',
                              4,
                              '待分发',
                              5,
                              '处理中',
                              6,
                              '处理完成') AS statusName,
                       0 AS isTop,
                       c.d_input_date AS inputDate
                  FROM lcoa.oa_afw_dmd_apply c
                  LEFT JOIN LCBASE.t_zip_user t
                    ON c.c_input_user_id = t.c_user_id
                 WHERE c.c_input_user_id = userid
                   and (c.d_input_date >= trunc(t.d_startdate) and
                       c.d_input_date < trunc(t.d_enddate))) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_datamodify_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise;
  end;

  --调岗信息添加
  --调岗基础信息申请 拉链表需求：改动
  --调岗基础信息申请 拉链表需求：改动
  function save_AfwAdjustpost_Info(datainfo        in varchar2,
                                   OperationUserId IN VARCHAR2,
                                   --DataId1         out char,
                                   c_cursor out sys_refcursor,
                                   ErrMsg   OUT VARCHAR2) return number is
    data_value         Pkg_Common.ARR_LONGSTR; --存储接收datainfo 信息
    rows               integer; --判断返回行数
    v_adjustUserId     char(32); --存储userid
    V_ORGANIZATION_ID  char(32); --存在组织id
    V_TITLE            varchar2(50); --职位
    v_is_bp_exits      integer; -- 判断vp 是否存在
    newOrgnizationId   char(32); --新部门id
    TodoTitle          varchar2(50); --拼接待办标题
    V_ADJUST_ID        char(32); --存储生成主键id
    DataId             char(32); --存储数据id
    ids                varchar(200);
    is_value           integer;
    V_APPROVAL_USER_ID char(32);
    --c_cursor           sys_refcursor;
  begin
    data_value := Pkg_Common.SPLIT(datainfo, '^'); --数据切分
    --判断申请人id不能为空！
    if data_value(1) is null then
      ErrMsg := '申请人id不能为空！';
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
    end if;
    --判断申请人id不能为空！
    if data_value(2) is null then
      ErrMsg := '申请组织不能为空！';
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
    end if;
    v_adjustUserId   := trim(data_value(1)); --获取申请人id
    newOrgnizationId := trim(data_value(2)); --新部门id
    --判断用户存在性
    SELECT count(*)
      into rows
      FROM LCBASE.T_ZIP_USER U
      LEFT JOIN LCBASE.T_ZIP_ORGANIZATION O
        ON U.C_ORGANIZATION_ID = O.C_ORGANIZATION_ID
      LEFT JOIN LCBASE.T_EMPLOYEES_INFO E
        ON U.C_USER_ID = E.C_USER_ID
     WHERE U.C_USER_ID = v_adjustUserId
       AND U.D_ENDDATE > sysdate;
    if rows <= 0 then
      ErrMsg := '用户根本就不存在！';
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
    end if;
    --查询用户旧组织id和用户职位
    SELECT O.C_ORGANIZATION_ID, E.V_USER_TITLE
      into V_ORGANIZATION_ID, V_TITLE
      FROM LCBASE.T_ZIP_USER U
      LEFT JOIN LCBASE.T_ZIP_ORGANIZATION O
        ON U.C_ORGANIZATION_ID = O.C_ORGANIZATION_ID
      LEFT JOIN LCBASE.T_EMPLOYEES_INFO E
        ON U.C_USER_ID = E.C_USER_ID
     WHERE U.C_USER_ID = v_adjustUserId
       AND U.D_ENDDATE > sysdate
       AND o.D_ENDDATE > sysdate;
    /*
    if v_is_bp_exits = -1 then
      ErrMsg := '旧部门不存在bp,请给组织设置bp！';
      return - 1;
    end if;
    */
    --判断新部门组织id是否存在
    SELECT count(*)
      into rows
      from LCBASE.T_ZIP_ORGANIZATION
     where C_ORGANIZATION_ID = newOrgnizationId
       AND D_ENDDATE > sysdate;
    if rows <= 0 then
      ErrMsg := '组织_ID在组织表中没有，请核实！';
      return - 1;
    end if;
    --判断用户是否有正在进行的：调岗申请
    SELECT count(*)
      into rows
      FROM LCOA.OA_AFW_ADJUSTPOST_INFO
     WHERE C_ADJUST_USER_ID = trim(v_adjustUserId)
       AND N_STATUS IN (0, 1);
    if rows > 0 then
      ErrMsg := '当前用户的调岗申请正在进行！';
      return - 1;
    end if;
    V_ADJUST_ID := trim(lower(sys_guid()));
    INSERT INTO LCOA.OA_AFW_ADJUSTPOST_INFO
      (C_ADJUST_ID, --调岗ID
       C_ADJUST_USER_ID, --调岗申请人ID
       D_ADJUST_DATE, --调岗日期
       C_NEW_ORGNIZATION_ID, --新所属部门ID
       V_NEW_POST, --新岗位名称
       C_ADJUSTPOST_NO, --编号
       V_ADJUSTPOST_REASON, --调岗原因
       D_INPUT_DATE, --录入时间
       N_STATUS, --当前状态(-1撤回0待审批1审批中2审批完成3已拒绝)
       C_OLD_ORGNIZATION_ID, --原所属部门ID
       V_OLD_POST --原岗位名称
       )
    VALUES
      (V_ADJUST_ID,
       v_adjustUserId,
       sysdate,
       newOrgnizationId,
       data_value(3),
       LCOA.pkg_common.getflownumber('TG', 4),
       data_value(4),
       sysdate,
       0,
       V_ORGANIZATION_ID,
       V_TITLE);
    select t.v_pet_name || '的调岗审批'
      into TodoTitle
      from lcbase.t_zip_user t
     where t.c_user_id = v_adjustUserId
       and D_ENDDATE > sysdate;
    --调用审批流函数
    DataId := V_ADJUST_ID;
    lcoa.pkg_ins_afw_workflow.Create_Approval_By_Id(DataId, 12);
    lcoa.pkg_ins_afw_workflow.Create_Next_Approval_Todo(DataId,
                                                        TodoTitle,
                                                        c_cursor);
    /*   --返回审第一个人审批-user_id
    SELECT C_APPROVAL_USER_ID
      into V_APPROVAL_USER_ID
      FROM lcoa.OA_AFW_WORKFLOW_APPROVAL_FLOW
     WHERE N_APPROVAL_ORDER = 1
       and C_WORKFLOW_ID = V_ADJUST_ID;
    
    DataId1 := V_APPROVAL_USER_ID;*/
    --commit;
    ErrMsg := '成功！';
    return 0;
  exception
    when others then
      ErrMsg := 'saveAfwAdjustpostInfo: ' || sqlcode || ',' || sqlerrm;
      raise;
      rollback;
      return - 1;
  end save_AfwAdjustpost_Info;

  --调岗详情-模块更新(user_组织使用拉链表信息)
  --调岗信息添加
  --调岗详情
  function query_AfwAdjustpost_info(Adjust_id            in char,
                                    OperationUserId      IN VARCHAR2,
                                    AdjustPost_Info      out sys_refcursor,
                                    transferApplyForPost out sys_refcursor,
                                    ErrMsg               OUT VARCHAR2)
    return number is
    V_WORKFLOW_ID        char(32);
    V_APPROVAL_USER_ID   char(32);
    V_APPROVAL_USER_NAME varchar(50);
  begin
    if Adjust_id is not null then
      OPEN AdjustPost_Info FOR
        SELECT A.C_ADJUST_ID            as "ADJUSTID ",
               A.C_ADJUST_USER_ID       as "ADJUSTUSERID",
               A.D_ADJUST_DATE          as "ADJUSTDATE",
               A.C_NEW_ORGNIZATION_ID   as NEWORGNIZATIONID,
               A.V_NEW_POST             as "NEWPOST",
               A.C_ADJUSTPOST_NO        as "ADJUSTPOSTNO",
               A.V_ADJUSTPOST_REASON    as "ADJUSTPOSTREASON",
               A.D_INPUT_DATE           as "INPUTDATE",
               A.N_STATUS               as "STATUS",
               A.C_OLD_ORGNIZATION_ID   as "OLDORGNIZATIONID",
               A.V_OLD_POST             as "OLDPOST",
               T.V_PET_NAME             AS "adjustUserName",
               newN.V_ORGANIZATION_NAME AS "newOrgnizationName",
               Oldn.V_ORGANIZATION_NAME AS "orgnizationName",
               A.V_NEW_POST             AS "postName"
          FROM LCOA.OA_AFW_ADJUSTPOST_INFO A
          LEFT JOIN LCBASE.t_Zip_User T
            ON A.C_ADJUST_USER_ID = T.C_USER_ID
          LEFT JOIN LCBASE.t_Zip_Organization Oldn
            ON A.C_OLD_ORGNIZATION_ID = Oldn.C_ORGANIZATION_ID
          LEFT JOIN LCBASE.t_Zip_Organization newN
            ON A.C_NEW_ORGNIZATION_ID = newN.C_ORGANIZATION_ID
         WHERE C_ADJUST_ID = trim(Adjust_id)
           and (A.D_INPUT_DATE >= trunc(T.d_Startdate) and
               A.D_INPUT_DATE < trunc(t.d_enddate))
           and (A.D_INPUT_DATE >= trunc(Oldn.d_Startdate) and
               A.D_INPUT_DATE < trunc(Oldn.d_Enddate))
           and (A.D_INPUT_DATE >= trunc(newN.d_Startdate) and
               A.D_INPUT_DATE < trunc(newN.d_Enddate));
      SELECT A.C_ADJUST_ID, A.C_ADJUST_USER_ID, T.V_PET_NAME
        into V_WORKFLOW_ID, V_APPROVAL_USER_ID, V_APPROVAL_USER_NAME
        FROM lcoa.OA_AFW_ADJUSTPOST_INFO A
        LEFT JOIN LCBASE.t_Zip_User T
          ON A.C_ADJUST_USER_ID = T.C_USER_ID
       WHERE C_ADJUST_ID = trim(Adjust_id)
         and T.D_ENDDATE > sysdate;
      open transferApplyForPost for
        select f.*, u.v_headpic_aly,s.l_pic as "V_SIGNATURE_PIC"
          from (select * --查询审批人信息
                  from lcoa.oa_afw_workflow_approval_flow f
                union
                select --查询申请人信息
                 null,
                 12,
                 V_WORKFLOW_ID,
                 0,
                 null,
                 V_APPROVAL_USER_ID,
                 V_APPROVAL_USER_NAME,
                 null,
                 1,
                 null,
                 null,
                 0,
                 1
                  from dual) f
          left join lcbase.t_zip_user u
            on f.c_approval_user_id = u.c_user_id
            left join lcbase.t_signature_pic s
            on f.c_approval_user_id = s.c_user_id
         where f.c_workflow_id = V_WORKFLOW_ID
           and u.D_ENDDATE > sysdate
         order by decode(N_APPROVAL_STATUS, 1, 9, -1, 8, 0, 0, 0) desc,
                  N_APPROVAL_ORDER;
      ErrMsg := '成功！';
      return 0;
    else
      ErrMsg := 'Adjust_id is  null';
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
    end if;
  exception
    when others then
      ErrMsg := 'queryAfwAdjustpost: ' || sqlcode || ',' || sqlerrm;
      raise;
      return - 1;
  end query_AfwAdjustpost_info;

  --更新调岗后的用户职位信息
  function update_UserAndEmployees_info(Adjust_Id in char,
                                        ErrMsg    OUT VARCHAR2) return number is
    rows                 integer; --判断返回行数
    v_adjust_user_id     char(32); --存储user_id
    v_new_orgnization_id char(32); --存储orgnization_id
    new_post             varchar2(50); --新职位信息
    V_old_ORGNIZATION_ID char(32); --存储旧组织id
    result_int           integer;
  begin
    --判断新岗位信息是否存在
    select count(*)
      into rows
      FROM lcoa.OA_AFW_ADJUSTPOST_INFO
     WHERE C_ADJUST_ID = Adjust_Id;
    if rows <= 0 then
      ErrMsg := '调岗基础信息_不存在！';
      return - 1;
    end if;
    --查询值进行into 指定变量中
    SELECT C_ADJUST_USER_ID,
           C_NEW_ORGNIZATION_ID,
           V_NEW_POST,
           c_old_ORGNIZATION_ID
      into v_adjust_user_id,
           v_new_orgnization_id,
           new_post,
           V_old_ORGNIZATION_ID
      FROM lcoa.OA_AFW_ADJUSTPOST_INFO
     WHERE C_ADJUST_ID = Adjust_Id;
    --更新-插入数据
    result_int := INSERT_T_USER(v_adjust_user_id,
                                v_new_orgnization_id,
                                ErrMsg);
    if result_int <> 0 then
      ErrMsg := 'update_UserAndEmployees_info：更新-插入数据: ' || sqlcode || ',' ||
                sqlerrm;
      return - 1;
    end if;
    --更新用户职务
    UPDATE LCBASE.T_EMPLOYEES_INFO
       SET V_USER_TITLE = new_post
     WHERE C_USER_ID = v_adjust_user_id;
    ErrMsg := '成功！';
    return 0;
  exception
    when others then
      ErrMsg := 'update_UserAndEmployees_info: ' || sqlcode || ',' ||
                sqlerrm;
      raise;
      return - 1;
  end update_UserAndEmployees_info;

  --判断是否有bp
  function is_oraganization_exits(newOrgnizationId char,
                                  ErrMsg           OUT VARCHAR2)
    return number is
    v_is_bp_exits            integer;
    V_ORGANIZATION_PARENT_ID varchar2(50);
    v_result                 integer;
  begin
    SELECT CASE
             WHEN O.C_ORGANIZATION_BP IS null THEN
              -1
             ELSE
              0
           END AS "value",
           C_ORGANIZATION_PARENT_ID
      into v_is_bp_exits, V_ORGANIZATION_PARENT_ID
      from LCBASE.t_Zip_Organization O
     where O.C_ORGANIZATION_ID = newOrgnizationId
       and D_ENDDATE > sysdate;
  end;

  --插入组织信息
  function INSERT_T_USER(User_id              in char,
                         v_new_orgnization_id in char,
                         ErrMsg               OUT VARCHAR2) return number is
    update_count Date;
    current_time Date;
  begin
    current_time := sysdate;
    select D_STARTDATE
      into update_count
      from LCBASE.T_ZIP_USER
     where C_USER_ID = User_id
       and D_ENDDATE > sysdate;
    --判断
    --判断开始 if起始日期是当天，同一天发生多次变更不做拉链，只更新最新部门id即可
    if trunc(update_count, 'dd') = trunc(current_time, 'dd') then
      update LCBASE.T_ZIP_USER
         set C_ORGANIZATION_ID = v_new_orgnization_id
       where C_USER_ID = User_id
         and D_ENDDATE > sysdate;
    else
      --起始日期不是当天-- 则是当天首次修改，新增拉链信息，更新最新记录
      insert into lcbase.t_zip_user
        select t.d_startdate,
               trunc(sysdate, 'dd'),
               t.c_user_id,
               t.c_organization_id,
               t.v_user_name,
               t.n_user_type,
               t.v_pet_name,
               t.n_mobile_1,
               t.n_mobile_2,
               t.v_tel_1,
               t.v_tel_2,
               t.n_status,
               t.v_email,
               t.c_password,
               t.v_wx_open_id,
               t.v_work_wx_account,
               t.n_sex,
               t.n_authority,
               t.n_work_wx_activation,
               t.v_headpic_aly,
               t.n_work_id,
               t.n_kindofwork,
               t.v_fullname_zh,
							 t.n_work_status
          from lcbase.t_zip_user t
         where t.C_USER_ID = User_id
           and t.D_ENDDATE > sysdate;
      --更新有效期
      update lcbase.T_ZIP_USER
         set D_STARTDATE       = trunc(sysdate, 'dd'),
             C_ORGANIZATION_ID = v_new_orgnization_id
       WHERE C_USER_ID = User_id
         and D_ENDDATE > sysdate;
    end if;
    ErrMsg := '成功！';
    return 0;
  exception
    when others then
      ErrMsg := 'INSERT_T_ZIP_ORGANIZATION: ' || sqlcode || ',' || sqlerrm;
      raise;
      rollback;
      return - 1;
  end INSERT_T_USER;

  function Get_Message_List(UserID     in varchar2,
                            MsgType    in varchar2,
                            pageNum    in number,
                            PageSize   in number,
                            DataInfo   out sys_refcursor,
                            totalPage  out number,
                            totalCount out number,
                            ErrMsg     out varchar2) return number is
    n_result     number(3);
    msg_type_sql varchar2(4000);
    vSql         varchar2(4000);
    char1        varchar2(40) := '1970-01-01';
    char2        varchar2(40) := 'yyyy-mm-dd';
    char3        varchar2(40) := 'C_MSG_ID';
    char4        varchar2(40) := 'cdf8fe6fda614f0f99f03de91e7c178d';
    char5        varchar2(40) := '';
  begin
    if MsgType is not null and MsgType > 50 then
      msg_type_sql := 'C_MSG_USER_ID = ' || '''' || UserID || '''' ||
                      ' and N_MSG_TYPE = ' || '''' || MsgType || '''' || '';
    elsif MsgType is not null and MsgType = 50 then
      msg_type_sql := ' N_MSG_TYPE = ' || '''' || MsgType || '''' ||
                      ' and (C_MSG_USER_ID = ' || '''' || UserID || '''' || ')';
    elsif MsgType is not null and MsgType < 50 and MsgType > 0 then
      msg_type_sql := 'C_MSG_USER_ID = ' || '''' || UserID || '''' ||
                      ' and N_MSG_TYPE < 50 ';
    else
      msg_type_sql := '(C_MSG_USER_ID = ' || '''' || UserID || '''' || ')';
    end if;
    vSql := 'SELECT * FROM (select t.C_MSG_ID,
					 t.N_MSG_TYPE,
					 t.N_ISTOP_FLAG,
					 t.D_ISTOP_TIME,
					 t.V_MSG_TITLE,
					 t.D_MSG_TIME,
					 t.N_READ_FLAG,
					 t.C_MSG_USER_ID,
					 t.C_MSG_SRC,
					 t.V_MSG_CONTENT,
					 t.V_MSG_SENDER,
		       t.N_ENABLE
			from OA_MSG_MESSAGE_INFO t
		 where ' || msg_type_sql || '  union all
										select
										C_MSG_ID,
		                N_MSG_TYPE,
		                N_ISTOP_FLAG,
		                D_ISTOP_TIME,
		                V_MSG_TITLE,
		                D_MSG_TIME,
		                N_READ_FLAG,
		                C_MSG_USER_ID,
		                C_MSG_SRC,
		                V_MSG_CONTENT,
		                V_MSG_SENDER,
		                DECODE(N_ENABLE, 0, 0, 1, 1,1) N_ENABLE
		 from (select msg.C_MSG_ID C_MSG_IDs,
										' || '''' || char3 || '''' || ' as C_MSG_ID,
					 decode(t.n_news_type, 0, 50, 1, 51, 50) N_MSG_TYPE,
					 t.N_ISTOP_FLAG,
					 sysdate D_ISTOP_TIME,
					 t.v_news_title V_MSG_TITLE,
					 t.d_input_time D_MSG_TIME,
					 1 N_READ_FLAG,
					 ' || '''' || UserID || '''' || ' C_MSG_USER_ID,
					 t.c_news_id C_MSG_SRC,
					 ' || '''' || char5 || '''' ||
            ' V_MSG_CONTENT,
					 t.v_input_user_name V_MSG_SENDER,
			     msg.N_ENABLE
			from OA_MSG_PUBLISH_INFO t
			left join OA_MSG_PUBLISH_RANGE r
				on t.c_news_id = r.c_news_id
			left join (select *
									 from OA_MSG_MESSAGE_INFO
									where c_msg_user_id = ' || '''' || UserID || '''' ||
            ') msg
				on t.c_news_id = msg.c_msg_src
		 where ((t.n_news_type = 0 and t.N_STATUS <> -2) or (t.n_news_type = 1 and t.N_NEWS_RANGE = 2 and t.N_STATUS = 2))
				or (t.n_news_type = 1 and t.n_news_range = 1 and t.N_STATUS = 2 and
					 r.c_target_id in
					 (SELECT o.c_organization_id
							 FROM (SELECT *
											 FROM LCBASE.T_ZIP_ORGANIZATION
											WHERE D_ENDDATE > SYSDATE) o
							start with o.c_organization_id in
												 (select u.c_organization_id
														from lcbase.t_zip_user u
													 where u.c_user_id = ' || '''' || UserID || '''' || '
														 and u.d_enddate > sysdate)
						 connect by prior
												 o.c_organization_parent_id = o.c_organization_id))) c
			 where c.C_MSG_IDs is null) t
	     WHERE N_ENABLE = 1
			 order by t.n_istop_flag desc,
										nvl(t.d_istop_time, to_date(' || '''' || char1 || '''' || ', ' || '''' ||
            char2 || '''' || ')) desc,
										t.D_MSG_TIME desc';
    for i in 1 .. 5 loop
      dbms_output.put_line(substr(vSql, 1900 * (i - 1) + 1, 1900));
    end loop;
    n_result := lcoa.pkg_common.GetPagingInfo(vSql,
                                              PageSize,
                                              pageNum,
                                              DataInfo,
                                              totalCount,
                                              totalPage);
    return n_result;
  exception
    when others then
      ErrMsg := 'Get_Message_List: ' || sqlcode || ',' || sqlerrm;
      raise;
      return 1;
  end;

end PKG_INS_TRANSFERPOSITION_INFO;
/

