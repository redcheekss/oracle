create package body PKG_INS_TRANSFERPOSITION_INFO is

  function get_approval_list(recordvo        in varchar2,
                             pageNum         in number,
                             PageSize        in number,
                             getapprovallist out sys_refcursor,
                             totalPage       out number,
                             totalCount      out number,
                             errmsg          out varchar2) return number is
    dataarr  pkg_common.arr_longstr;
    listtype number(6);
    n_result number(6);
    v_sql    varchar2(2000);
  begin
    dataarr  := pkg_common.split(recordvo, '^');
    listtype := dataarr(2);
    -- 查询插入请假列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_leave_list(dataarr(1),
                                                             dataarr(3),
                                                             dataarr(4),
                                                             1,
                                                             errmsg);
    -- 查询插入外出列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_egress_list(dataarr(1),
                                                              dataarr(3),
                                                              dataarr(4),
                                                              1,
                                                              errmsg);
    -- 查询插入公告列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_news_list(dataarr(1),
                                                            dataarr(3),
                                                            dataarr(4),
                                                            1,
                                                            errmsg);
    -- 查询插入调岗列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_adjustpost_list(dataarr(1),
                                                                  dataarr(3),
                                                                  dataarr(4),
                                                                  1,
                                                                  errmsg);
    -- 查询插入转正列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_promotion_list(dataarr(1),
                                                                 dataarr(3),
                                                                 dataarr(4),
                                                                 1,
                                                                 errmsg);
    -- 判断是否传入查询类型参数 如果没有就查询全部，否则按传入类型查询列表
    v_sql := 'select DISTINCT ID, TYPES, TYPENAME, USERNAME, STATUS, STARTTIME, 
                     ENDTIME, INPUTUSERID, ABSTRACTS, STATUSNAME, ISTOP, INPUTDATE 
                     from lcoa.oa_afw_approval_list ';
    if listtype is not null then
      v_sql := v_sql || ' where types = ' || listtype;
    end if;
    v_sql    := v_sql || 'order by inputdate desc';
    n_result := lcoa.pkg_common.GetPagingInfo(v_sql,
                                              PageSize,
                                              pageNum,
                                              getapprovallist,
                                              totalCount,
                                              totalPage);
    delete from lcoa.oa_afw_approval_list;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'get_approval_list: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(sqlcode, errmsg, false);
      rollback;
      return 1;
  end;

  function get_apply_list(recordvo     in varchar2,
                          pageNum      in number,
                          PageSize     in number,
                          getapplylist out sys_refcursor,
                          totalPage    out number,
                          totalCount   out number,
                          errmsg       out varchar2) return number is
    dataarr  pkg_common.arr_longstr;
    listtype number(6);
    n_result number(6);
    v_sql    varchar2(2000);
  begin
    dataarr  := pkg_common.split(recordvo, '^');
    listtype := dataarr(2);
    -- 查询插入请假列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_leave_list(dataarr(1),
                                                             dataarr(3),
                                                             dataarr(4),
                                                             2,
                                                             errmsg);
    -- 查询插入外出列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_egress_list(dataarr(1),
                                                              dataarr(3),
                                                              dataarr(4),
                                                              2,
                                                              errmsg);
    -- 查询插入公告列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_news_list(dataarr(1),
                                                            dataarr(3),
                                                            dataarr(4),
                                                            2,
                                                            errmsg);
    -- 查询插入调岗列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_adjustpost_list(dataarr(1),
                                                                  dataarr(3),
                                                                  dataarr(4),
                                                                  2,
                                                                  errmsg);
    -- 查询插入转正列表
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_promotion_list(dataarr(1),
                                                                 dataarr(3),
                                                                 dataarr(4),
                                                                 2,
                                                                 errmsg);
    -- 判断是否传入查询类型参数 如果没有就查询全部，否则按传入类型查询列表
    v_sql := 'select DISTINCT ID, TYPES, TYPENAME, USERNAME, STATUS, STARTTIME, 
                     ENDTIME, INPUTUSERID, ABSTRACTS, STATUSNAME, ISTOP, INPUTDATE 
                     from lcoa.oa_afw_approval_list ';
    if listtype is not null then
      v_sql := v_sql || ' where types = ' || listtype;
    end if;
    v_sql    := v_sql || 'order by inputdate desc';
    n_result := lcoa.pkg_common.GetPagingInfo(v_sql,
                                              PageSize,
                                              pageNum,
                                              getapplylist,
                                              totalCount,
                                              totalPage);
    delete from lcoa.oa_afw_approval_list;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'get_apply_list: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(sqlcode, errmsg, false);
      rollback;
      return 1;
  end;

  function add_leave_list(userid            in varchar2,
                          startdate         in varchar2,
                          enddate           in varchar2,
                          approvalapplytype in number,
                          errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT a.c_leave_id AS id,
                       1 AS types,
                       '请假' AS typeName,
                       t.v_user_name AS userName,
                       a.n_status AS status,
                       a.d_leave_start_time AS startTime,
                       a.d_leave_end_time AS endTime,
                       a.c_leave_user_id AS inputUserId,
                       DECODE(a.n_leave_type,
                              1,
                              '事假',
                              2,
                              '病假',
                              3,
                              '调休',
                              4,
                              '年假',
                              5,
                              '产假',
                              6,
                              '哺乳假',
                              7,
                              '婚假',
                              8,
                              '丧假',
                              9,
                              '陪产假',
                              10,
                              '产检假',
                              '其它请假') || CASE
                         WHEN a.n_leave_days > 0 THEN
                          a.n_leave_days || '天'
                         ELSE
                          NULL
                       END || CASE
                         WHEN a.n_leave_hours > 0 THEN
                          a.n_leave_hours || '小时'
                         ELSE
                          NULL
                       END || '【' ||
                       TO_CHAR(a.d_leave_start_time, 'yyyy-MM-dd HH24:mi') ||
                       ' 至 ' ||
                       TO_CHAR(a.d_leave_end_time, 'yyyy-MM-dd HH24:mi') || '】' AS abstracts,
                       DECODE(a.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       a.d_input_date AS inputDate
                  FROM lcoa.OA_AFW_LEAVE_INFO a
                  LEFT JOIN lcbase.t_user t
                    ON a.c_leave_user_id = t.c_user_id
                 WHERE a.c_leave_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0)) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT a.c_leave_id AS id,
                       1 AS types,
                       '请假' AS typeName,
                       t.v_user_name AS userName,
                       a.n_status AS status,
                       a.d_leave_start_time AS startTime,
                       a.d_leave_end_time AS endTime,
                       a.c_leave_user_id AS inputUserId,
                       DECODE(a.n_leave_type,
                              1,
                              '事假',
                              2,
                              '病假',
                              3,
                              '调休',
                              4,
                              '年假',
                              5,
                              '产假',
                              6,
                              '哺乳假',
                              7,
                              '婚假',
                              8,
                              '丧假',
                              9,
                              '陪产假',
                              10,
                              '产检假',
                              '其它请假') || CASE
                         WHEN a.n_leave_days > 0 THEN
                          a.n_leave_days || '天'
                         ELSE
                          NULL
                       END || CASE
                         WHEN a.n_leave_hours > 0 THEN
                          a.n_leave_hours || '小时'
                         ELSE
                          NULL
                       END || '【' ||
                       TO_CHAR(a.d_leave_start_time, 'yyyy-MM-dd HH24:mi') ||
                       ' 至 ' ||
                       TO_CHAR(a.d_leave_end_time, 'yyyy-MM-dd HH24:mi') || '】' AS abstracts,
                       DECODE(a.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       a.d_input_date AS inputDate
                  FROM lcoa.OA_AFW_LEAVE_INFO a
                  LEFT JOIN LCBASE.t_user t
                    ON a.c_leave_user_id = t.c_user_id
                 WHERE a.c_leave_user_id = userid) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_leave_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_egress_list(userid            in varchar2,
                           startdate         in varchar2,
                           enddate           in varchar2,
                           approvalapplytype in number,
                           errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT b.c_egress_id AS id,
                       2 AS types,
                       '外出' AS typeName,
                       t.v_user_name AS userName,
                       B.n_status AS status,
                       B.d_egress_start_time AS startTime,
                       B.d_egress_end_time AS endTime,
                       B.C_EGRESS_USER_ID AS inputUserId,
                       DECODE(b.n_egress_type,
                              1,
                              '市内外出',
                              2,
                              '出差',
                              '其它外出') || CASE
                         WHEN b.n_egress_days > 0 THEN
                          b.n_egress_days || '天'
                         ELSE
                          NULL
                       END || CASE
                         WHEN b.n_egress_hours > 0 THEN
                          b.n_egress_hours || '小时'
                         ELSE
                          NULL
                       END || '【' ||
                       TO_CHAR(b.d_egress_start_time, 'yyyy-MM-dd HH24:mi') ||
                       ' 至 ' ||
                       TO_CHAR(b.d_egress_end_time, 'yyyy-MM-dd HH24:mi') || '】' AS abstracts,
                       DECODE(B.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       B.d_input_date AS inputDate
                  FROM LCOA.OA_AFW_EGRESS_INFO b
                  LEFT JOIN lcbase.t_user t
                    ON b.c_egress_user_id = t.c_user_id
                 WHERE b.c_egress_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0)) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT b.c_egress_id AS id,
                       2 AS types,
                       '外出' AS typeName,
                       t.v_user_name AS userName,
                       B.n_status AS status,
                       B.d_egress_start_time AS startTime,
                       B.d_egress_end_time AS endTime,
                       B.C_EGRESS_USER_ID AS inputUserId,
                       DECODE(b.n_egress_type,
                              1,
                              '市内外出',
                              2,
                              '出差',
                              '其它外出') || CASE
                         WHEN b.n_egress_days > 0 THEN
                          b.n_egress_days || '天'
                         ELSE
                          NULL
                       END || CASE
                         WHEN b.n_egress_hours > 0 THEN
                          b.n_egress_hours || '小时'
                         ELSE
                          NULL
                       END || '【' ||
                       TO_CHAR(b.d_egress_start_time, 'yyyy-MM-dd HH24:mi') ||
                       ' 至 ' ||
                       TO_CHAR(b.d_egress_end_time, 'yyyy-MM-dd HH24:mi') || '】' AS abstracts,
                       DECODE(B.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       0 AS isTop,
                       B.d_input_date AS inputDate
                  FROM LCOA.OA_AFW_EGRESS_INFO b
                  LEFT JOIN LCBASE.t_user t
                    ON b.c_egress_user_id = t.c_user_id
                 WHERE b.c_egress_user_id = userid) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_egress_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_news_list(userid            in varchar2,
                         startdate         in varchar2,
                         enddate           in varchar2,
                         approvalapplytype in number,
                         errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_news_id AS id,
                       3 AS types,
                       '公告' AS typeName,
                       t.v_user_name AS userName,
                       c.n_status AS status,
                       c.d_input_time AS startTime,
                       c.d_input_time AS endTime,
                       c.c_input_user_id AS inputUserId,
                       c.v_news_title || ' -- ' ||
                       DECODE(d.n_target_type,
                              0,
                              '个人',
                              1,
                              '部门',
                              2,
                              '全员') || ' -- ' ||
                       DECODE(c.N_SIGNATURE_TYPE,
                              0,
                              '匿名发布',
                              1,
                              '实名发布',
                              2,
                              '部门发布') || ' -- ' ||
                       DECODE(N_COMMENT_ALLOW,
                              1,
                              '允许评论',
                              0,
                              '不允许评论') || ' -- ' ||
                       DECODE(c.N_MUST_FEEDBACK,
                              1,
                              '需要点击"我已阅"',
                              '不需要点击"我已阅"') ||
                       DECODE(c.N_ISTOP_FLAG, 1, ' -- 置顶') AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       c.N_ISTOP_FLAG AS isTop,
                       c.d_input_time AS inputDate
                  FROM LCOA.OA_MSG_PUBLISH_INFO c
                  LEFT JOIN LCOA.OA_MSG_PUBLISH_RANGE d
                    ON c.c_news_id = d.c_news_id
                  LEFT JOIN LCBASE.t_user t
                    ON c.c_input_user_id = t.c_user_id
                 WHERE c.c_news_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0
                           AND c.N_STATUS <> -2)) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_news_id AS id,
                       3 AS types,
                       '公告' AS typeName,
                       t.v_user_name AS userName,
                       c.n_status AS status,
                       c.d_input_time AS startTime,
                       c.d_input_time AS endTime,
                       c.c_input_user_id AS inputUserId,
                       c.v_news_title || ' -- ' ||
                       DECODE(d.n_target_type,
                              0,
                              '个人',
                              1,
                              '部门',
                              2,
                              '全员') || ' -- ' ||
                       DECODE(c.N_SIGNATURE_TYPE,
                              0,
                              '匿名发布',
                              1,
                              '实名发布',
                              2,
                              '部门发布') || ' -- ' ||
                       DECODE(N_COMMENT_ALLOW,
                              1,
                              '允许评论',
                              0,
                              '不允许评论') || ' -- ' ||
                       DECODE(c.N_MUST_FEEDBACK,
                              1,
                              '需要点击"我已阅"',
                              '不需要点击"我已阅"') ||
                       DECODE(c.N_ISTOP_FLAG, 1, ' -- 置顶') AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              0,
                              '待审批',
                              2,
                              '已同意',
                              3,
                              '已拒绝') AS statusName,
                       c.N_ISTOP_FLAG AS isTop,
                       c.d_input_time AS inputDate
                  FROM LCOA.OA_MSG_PUBLISH_INFO c
                  LEFT JOIN LCOA.OA_MSG_PUBLISH_RANGE d
                    ON c.c_news_id = d.c_news_id
                  LEFT JOIN LCBASE.t_user t
                    ON c.c_input_user_id = t.c_user_id
                 WHERE c.c_input_user_id = userid
                   AND c.N_NEWS_TYPE = 1
                   AND c.N_STATUS <> -2) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_news_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_adjustpost_list(userid            in varchar2,
                               startdate         in varchar2,
                               enddate           in varchar2,
                               approvalapplytype in number,
                               errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_adjust_id AS id,
                       12 AS types,
                       '调岗' AS typeName,
                       t.v_user_name AS userName,
                       c.n_status AS status,
                       c.d_input_date AS startTime,
                       c.d_input_date AS endTime,
                       c.c_adjust_user_id AS inputUserId,
                       '现部门：' || oldn.v_organization_name || '- 现岗位：' ||
                       c.v_old_post || '<br/> 调整后部门：' ||
                       newn.v_organization_name || ' -调整后岗位：' ||
                       c.v_new_post AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '已同意',
                              3,
                              '已拒绝',
                              0,
                              '待审批') AS statusName,
                       0 AS isTop,
                       c.d_input_date AS inputDate
                  FROM LCOA.Oa_Afw_Adjustpost_Info c
                  LEFT JOIN LCBASE.t_user t
                    ON c.c_adjust_user_id = t.c_user_id
                  left join lcbase.t_organization oldn
                    on c.c_old_orgnization_id = oldn.c_organization_id
                  left join lcbase.t_organization newn
                    on c.c_new_orgnization_id = newn.c_organization_id
                 WHERE c.c_adjust_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0)) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_adjust_id AS id,
                       12 AS types,
                       '调岗' AS typeName,
                       t.v_user_name AS userName,
                       c.n_status AS status,
                       c.d_input_date AS startTime,
                       c.d_input_date AS endTime,
                       '' AS inputUserId,
                       '现部门：' || oldn.v_organization_name || '- 现岗位：' ||
                       c.v_old_post || '<br/> 调整后部门：' ||
                       newn.v_organization_name || ' -调整后岗位：' ||
                       c.v_new_post AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '已同意',
                              3,
                              '已拒绝',
                              0,
                              '待审批') AS statusName,
                       0 AS isTop,
                       c.d_input_date AS inputDate
                  FROM LCOA.Oa_Afw_Adjustpost_Info c
                  LEFT JOIN LCBASE.t_user t
                    ON c.c_adjust_user_id = t.c_user_id
                  left join lcbase.t_organization oldn
                    on c.c_old_orgnization_id = oldn.c_organization_id
                  left join lcbase.t_organization newn
                    on c.c_new_orgnization_id = newn.c_organization_id
                 WHERE c.c_adjust_user_id = userid) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_adjustpost_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_promotion_list(userid            in varchar2,
                              startdate         in varchar2,
                              enddate           in varchar2,
                              approvalapplytype in number,
                              errmsg            out varchar2) return number is
    starttimes varchar2(40) := to_char(to_date('1994-01-01 00:00:00',
                                               'yyyy-mm-dd hh24:mi:ss'),
                                       'yyyy-mm-dd hh24:mi:ss');
    endtimes   varchar2(40);
  begin
    select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
      into endtimes
      from dual;
    if startdate is not null then
      starttimes := startdate;
    end if;
    if enddate is not null then
      endtimes := enddate;
    end if;
    if approvalapplytype = 1 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_promotion_id AS id,
                       11 AS types,
                       '转正' AS typeName,
                       t.v_user_name AS userName,
                       c.n_status AS status,
                       c.d_input_date AS startTime,
                       c.d_input_date AS endTime,
                       c.c_promotion_user_id AS inputUserId,
                       '转正 - 入职日期：' ||
                       to_char(c.d_ht_hire_date, 'yyyy-mm-dd') ||
                       ' - 合同转正日期：' ||
                       to_char(c.d_ht_promotion_date, 'yyyy-mm-dd') AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '已同意',
                              3,
                              '已拒绝',
                              4,
                              '已延期',
                              0,
                              '待审批') AS statusName,
                       0 AS isTop,
                       c.d_input_date AS inputDate
                  FROM lcoa.oa_afw_promotion_info c
                  LEFT JOIN LCBASE.t_user t
                    ON c.c_promotion_user_id = t.c_user_id
                 WHERE c.c_promotion_id IN
                       (SELECT f.C_WORKFLOW_ID
                          FROM LCOA.OA_AFW_WORKFLOW_APPROVAL_FLOW f
                         WHERE f.C_APPROVAL_USER_ID = userid
                           AND f.N_APPROVAL_STATUS != 0)) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    elsif approvalapplytype = 2 then
      insert into lcoa.oa_afw_approval_list
        select *
          from (SELECT c.c_promotion_id AS id,
                       11 AS types,
                       '转正' AS typeName,
                       t.v_user_name AS userName,
                       c.n_status AS status,
                       c.d_input_date AS startTime,
                       c.d_input_date AS endTime,
                       c.c_promotion_user_id AS inputUserId,
                       '转正 - 入职日期：' ||
                       to_char(c.d_ht_hire_date, 'yyyy-mm-dd') ||
                       ' - 合同转正日期：' ||
                       to_char(c.d_ht_promotion_date, 'yyyy-mm-dd') AS abstracts,
                       DECODE(c.n_status,
                              -1,
                              '已撤回',
                              1,
                              '审批中',
                              2,
                              '已同意',
                              3,
                              '已拒绝',
                              4,
                              '已延期',
                              0,
                              '待审批') AS statusName,
                       0 AS isTop,
                       c.d_input_date AS inputDate
                  FROM lcoa.oa_afw_promotion_info c
                  LEFT JOIN LCBASE.t_user t
                    ON c.c_promotion_user_id = t.c_user_id
                 WHERE c.c_promotion_user_id = userid) w
         where 1 = 1
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') >=
               to_char(to_date(starttimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
           and to_char(w.inputdate, 'yyyy-mm-dd hh24:mi:ss') <=
               to_char(to_date(endtimes, 'yyyy-mm-dd hh24:mi:ss'),
                       'yyyy-mm-dd hh24:mi:ss')
         order by w.inputdate desc;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_promotion_list: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function get_user_todo(userId      in varchar2,
                         pageNum     in number,
                         PageSize    in number,
                         getUserTodo out sys_refcursor,
                         totalPage   out number,
                         totalCount  out number,
                         errmsg      out varchar2) return number is
    n_result number(6);
    v_sql    varchar2(2000);
  begin
  
    --插入审批代办
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_usertodo_forward(userId,
                                                                   errmsg);
    --插入会议纪要代办
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_usertodo_meetinfo(userId,
                                                                    errmsg);
    --插入转正代办
    n_result := PKG_INS_TRANSFERPOSITION_INFO.add_usertodo_promotion(userId,
                                                                     errmsg);
  
    v_sql    := 'select DISTINCT TODOID, TODOUSERID, TODOTIME, TODOTYPE, TODOTITLE, 
                     INPUTTIME, STATUS, DONETIME, TODODATAID
                     from lcoa.oa_tdo_todo_list ORDER BY TODOTIME desc';
    n_result := lcoa.pkg_common.GetPagingInfo(v_sql,
                                              PageSize,
                                              pageNum,
                                              getUserTodo,
                                              totalCount,
                                              totalPage);
    delete from lcoa.oa_tdo_todo_list;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'get_user_todo: ' || sqlcode || ',' || sqlerrm;
      raise_application_error(sqlcode, errmsg, false);
      rollback;
      return 1;
  end;

  function add_usertodo_forward(userid in varchar2, errmsg out varchar2)
    return number is
  begin
    insert into lcoa.oa_tdo_todo_list
      select t.C_TODO_ID      as todoId,
             t.C_TODO_USER_ID as todoUserId,
             t.D_TODO_TIME    as todoTime,
             t.N_TODO_TYPE    as todoType,
             t.V_TODO_TITLE   as todoTitle,
             t.D_INPUT_TIME   as inputTime,
             t.N_STATUS       as status,
             t.D_DONE_TIME    as doneTime,
             f.c_workflow_id  as todoDataId
        from lcoa.oa_tdo_todo_info t
        left join lcoa.oa_afw_workflow_approval_flow f
          on f.c_data_id = t.c_todo_data_id
       where t.n_todo_type <= 15
         and t.n_status = 0
         and t.c_todo_user_id = userid;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_usertodo_forward: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_usertodo_meetinfo(userid in varchar2, errmsg out varchar2)
    return number is
  begin
    insert into lcoa.oa_tdo_todo_list
      select t.C_TODO_ID as todoId,
             t.C_TODO_USER_ID as todoUserId,
             TO_DATE(TO_CHAR(t.D_TODO_TIME, 'YYYYMMDD') ||
                     TO_CHAR(s.D_SCH_START_TIME, 'hh24mi'),
                     'YYYYMMDDHH24mi') AS todoTime,
             t.N_TODO_TYPE as todoType,
             t.V_TODO_TITLE as todoTitle,
             t.D_INPUT_TIME as inputTime,
             t.N_STATUS as status,
             t.D_DONE_TIME as doneTime,
             t.C_TODO_DATA_ID as todoDataId
        from lcoa.oa_tdo_todo_info t
        LEFT JOIN lcoa.oa_sde_scheduling_flow f
          ON t.c_todo_data_id = f.c_flow_id
        LEFT JOIN lcoa.oa_sde_schedule_info s
          ON s.c_sch_id = f.c_sch_id
       where t.n_todo_type = 52
         and t.n_status = 0
         and t.D_TODO_TIME < TRUNC(SYSDATE, 'dd') + 2
         and t.c_todo_user_id = userid;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_usertodo_meetinfo: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  function add_usertodo_promotion(userid in varchar2, errmsg out varchar2)
    return number is
    countuser number(6);
  begin
    select count(*)
      into countuser
      from lcoa.oa_afw_promotion_info p
     where p.c_promotion_user_id = userid;
    if countuser = 0 then
      insert into lcoa.oa_tdo_todo_list
        select t.C_TODO_ID      as todoId,
               t.C_TODO_USER_ID as todoUserId,
               t.D_TODO_TIME    AS todoTime,
               t.N_TODO_TYPE    as todoType,
               t.V_TODO_TITLE   as todoTitle,
               t.D_INPUT_TIME   as inputTime,
               t.N_STATUS       as status,
               t.D_DONE_TIME    as doneTime,
               t.C_TODO_DATA_ID as todoDataId
          from lcoa.oa_tdo_todo_info t
          LEFT JOIN lcoa.oa_sde_scheduling_flow f
            ON t.c_todo_data_id = f.c_flow_id
         where t.n_todo_type = 53
           and t.n_status = 0
           and t.c_todo_user_id = userid;
    end if;
    commit;
    return 0;
  exception
    when others then
      errmsg := 'add_usertodo_promotion: ' || sqlcode || ',' || sqlerrm;
      rollback;
      raise_application_error(sqlcode, errmsg, false);
  end;

  --调岗信息添加
  function save_AfwAdjustpost_Info(datainfo        in varchar2,
                                   OperationUserId IN OUT VARCHAR2,
                                   DataId1         out char,
                                   ErrMsg          OUT VARCHAR2)
    return number
  
   is
    data_value         Pkg_Common.ARR_LONGSTR; --存储接收datainfo 信息
    rows               integer; --判断返回行数             
    v_adjustUserId     char(32); --存储userid
    V_ORGANIZATION_ID  char(32); --存在组织id
    V_TITLE            varchar2(50); --职位
    v_is_bp_exits      integer; -- 判断vp 是否存在
    newOrgnizationId   char(32); --新部门id 
    TodoTitle          varchar2(50); --拼接待办标题
    V_ADJUST_ID        char(32); --存储生成主键id
    DataId             char(32); --存储数据id 
    ids                varchar(200);
    is_value           integer;
    V_APPROVAL_USER_ID char(32);
  
  begin
    data_value := Pkg_Common.SPLIT(datainfo, '^'); --数据切分
    --判断申请人id不能为空！
    if data_value(1) is null then
      ErrMsg := '申请人id不能为空！';
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
    end if;
    --判断申请人id不能为空！
    if data_value(2) is null then
      ErrMsg := '申请组织不能为空！';
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
    end if;
  
    v_adjustUserId   := trim(data_value(1)); --获取申请人id
    newOrgnizationId := trim(data_value(2)); --新部门id
  
    --判断用户存在性
    SELECT count(*)
      into rows
      FROM LCBASE.T_USER U
      LEFT JOIN LCBASE.T_ORGANIZATION O
        ON U.C_ORGANIZATION_ID = O.C_ORGANIZATION_ID
      LEFT JOIN LCBASE.T_EMPLOYEES_INFO E
        ON U.C_USER_ID = E.C_USER_ID
     WHERE U.C_USER_ID = v_adjustUserId;
    if rows <= 0 then
      ErrMsg := '用户根本就不存在！';
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
    end if;
  
    --判断旧部门是否有bp
    SELECT O.C_ORGANIZATION_ID,
           E.V_USER_TITLE,
           CASE
             WHEN O.C_ORGANIZATION_BP IS null THEN
              '-1'
             ELSE
              '0'
           END AS "vp"
      into V_ORGANIZATION_ID, V_TITLE, v_is_bp_exits
      FROM LCBASE.T_USER U
      LEFT JOIN LCBASE.T_ORGANIZATION O
        ON U.C_ORGANIZATION_ID = O.C_ORGANIZATION_ID
      LEFT JOIN LCBASE.T_EMPLOYEES_INFO E
        ON U.C_USER_ID = E.C_USER_ID
     WHERE U.C_USER_ID = v_adjustUserId;
  
    if v_is_bp_exits = -1 then
      ErrMsg := '旧部门不存在bp,请给组织设置bp！';
      return - 1;
    end if;
  
    --判断新部门组织id是否存在
    SELECT count(*)
      into rows
      from LCBASE.T_ORGANIZATION
     where C_ORGANIZATION_ID = newOrgnizationId;
    if rows <= 0 then
      ErrMsg := '组织_ID在组织表中没有，请核实！';
      return - 1;
    end if;
    --判断新部门是否有bp
    /* SELECT CASE
               WHEN O.C_ORGANIZATION_BP IS null THEN
                '-1'
               ELSE
                '0'
           END AS "value"
      into v_is_bp_exits
      from LCBASE.T_ORGANIZATION O
     where O.C_ORGANIZATION_ID = newOrgnizationId;
    
    if v_is_bp_exits = -1 then
        ErrMsg := '新部门不存在bp,请给新部门设置bp！';
        return - 1;
    end if;*/
  
    --判断用户是否有正在进行的：调岗申请
    SELECT count(*)
      into rows
      FROM LCOA.OA_AFW_ADJUSTPOST_INFO
     WHERE C_ADJUST_USER_ID = trim(v_adjustUserId)
       AND N_STATUS IN (0, 1);
    if rows > 0 then
      ErrMsg := '当前用户的调岗申请正在进行！';
      return - 1;
    end if;
    V_ADJUST_ID := trim(lower(sys_guid()));
    INSERT INTO LCOA.OA_AFW_ADJUSTPOST_INFO
      (C_ADJUST_ID, --调岗ID
       C_ADJUST_USER_ID, --调岗申请人ID
       --D_ADJUST_DATE, --调岗日期
       C_NEW_ORGNIZATION_ID, --新所属部门ID
       V_NEW_POST, --新岗位名称
       C_ADJUSTPOST_NO, --编号
       V_ADJUSTPOST_REASON, --调岗原因
       D_INPUT_DATE, --录入时间
       N_STATUS, --当前状态(-1撤回0待审批1审批中2审批完成3已拒绝)
       C_OLD_ORGNIZATION_ID, --原所属部门ID
       V_OLD_POST --原岗位名称
       )
    VALUES
      (V_ADJUST_ID,
       v_adjustUserId,
       --sysdate,
       newOrgnizationId,
       data_value(3),
       LCOA.pkg_common.getflownumber('TG', 4),
       data_value(4),
       sysdate,
       0,
       V_ORGANIZATION_ID,
       V_TITLE);
  
    select t.v_user_name || '的调岗审批'
      into TodoTitle
      from lcbase.t_user t
     where t.c_user_id = v_adjustUserId;
  
    --调用审批流函数
    DataId := V_ADJUST_ID;
    lcoa.pkg_user_workflow.Create_Approval_By_Id(DataId, 12);
    lcoa.pkg_user_workflow.Create_Next_Approval_Todo(DataId, TodoTitle);
    --返回审第一个人审批-user_id
  
    SELECT C_APPROVAL_USER_ID
      into V_APPROVAL_USER_ID
    
      FROM lcoa.OA_AFW_WORKFLOW_APPROVAL_FLOW
     WHERE N_APPROVAL_ORDER = 1
       and C_WORKFLOW_ID = V_ADJUST_ID;
  
    DataId1 := V_APPROVAL_USER_ID;
    commit;
    ErrMsg := '成功！';
    return 0;
  exception
    when others then
      ErrMsg := 'saveAfwAdjustpostInfo: ' || sqlcode || ',' || sqlerrm;
      raise;
      rollback;
      return - 1;
    
  end save_AfwAdjustpost_Info;

  --调岗详情
  function query_AfwAdjustpost_info(Adjust_id            in char,
                                    OperationUserId      IN VARCHAR2,
                                    AdjustPost_Info      out sys_refcursor,
                                    transferApplyForPost out sys_refcursor,
                                    
                                    ErrMsg OUT VARCHAR2) return number
  
   is
  
    V_WORKFLOW_ID        char(32);
    V_APPROVAL_USER_ID   char(32);
    V_APPROVAL_USER_NAME varchar(50);
  
  begin
    if Adjust_id is not null then
    
      OPEN AdjustPost_Info FOR
        SELECT A.C_ADJUST_ID            as "ADJUSTID ",
               A.C_ADJUST_USER_ID       as "ADJUSTUSERID",
               A.D_ADJUST_DATE          as "ADJUSTDATE",
               A.C_NEW_ORGNIZATION_ID   as NEWORGNIZATIONID,
               A.V_NEW_POST             as "NEWPOST",
               A.C_ADJUSTPOST_NO        as "ADJUSTPOSTNO",
               A.V_ADJUSTPOST_REASON    as "ADJUSTPOSTREASON",
               A.D_INPUT_DATE           as "INPUTDATE",
               A.N_STATUS               as "STATUS",
               A.C_OLD_ORGNIZATION_ID   as "OLDORGNIZATIONID",
               A.V_OLD_POST             as "OLDPOST",
               T.V_USER_NAME            AS "adjustUserName",
               newN.V_ORGANIZATION_NAME AS "newOrgnizationName",
               Oldn.V_ORGANIZATION_NAME AS "orgnizationName",
               A.V_NEW_POST             AS "postName"
          FROM LCOA.OA_AFW_ADJUSTPOST_INFO A
          LEFT JOIN LCBASE.T_USER T
            ON A.C_ADJUST_USER_ID = T.C_USER_ID
          LEFT JOIN LCBASE.T_ORGANIZATION Oldn
            ON A.C_OLD_ORGNIZATION_ID = Oldn.C_ORGANIZATION_ID
          LEFT JOIN LCBASE.T_ORGANIZATION newN
            ON A.C_NEW_ORGNIZATION_ID = newN.C_ORGANIZATION_ID
         WHERE C_ADJUST_ID = trim(Adjust_id);
    
      --查询用户基础信息
      SELECT A.C_ADJUST_ID, A.C_ADJUST_USER_ID, T.V_USER_NAME
        into V_WORKFLOW_ID, V_APPROVAL_USER_ID, V_APPROVAL_USER_NAME
        FROM lcoa.OA_AFW_ADJUSTPOST_INFO A
        LEFT JOIN LCBASE.T_USER T
          ON A.C_ADJUST_USER_ID = T.C_USER_ID
       WHERE C_ADJUST_ID = trim(Adjust_id);
    
      open transferApplyForPost for
        select f.*, u.v_headpic_aly
          from (select * --查询审批人信息
                  from lcoa.oa_afw_workflow_approval_flow f
                union
                select --查询申请人信息  
                 null,
                 12,
                 V_WORKFLOW_ID,
                 0,
                 null,
                 V_APPROVAL_USER_ID,
                 V_APPROVAL_USER_NAME,
                 null,
                 1,
                 null,
                 null,
                 0
                  from dual) f
          left join lcbase.t_user u
            on f.c_approval_user_id = u.c_user_id
         where f.c_workflow_id = V_WORKFLOW_ID
         order by decode(N_APPROVAL_STATUS, 1, 9, -1, 8, 0, 0, 0) desc,
                  N_APPROVAL_ORDER;
    
      ErrMsg := '成功！';
      return 0;
    else
      ErrMsg := 'Adjust_id is  null';
      raise_application_error(lcoa.pkg_common.g_errcode_exception,
                              ErrMsg,
                              false);
      return - 1;
    end if;
  exception
    when others then
      ErrMsg := 'queryAfwAdjustpost: ' || sqlcode || ',' || sqlerrm;
      raise;
      return - 1;
  end query_AfwAdjustpost_info;

  --更新调岗后的用户职位信息 
  function update_UserAndEmployees_info(Adjust_Id in char,
                                        ErrMsg    OUT VARCHAR2) return number
  
   is
    rows                 integer; --判断返回行数 
    v_adjust_user_id     char(32); --存储user_id
    v_new_orgnization_id char(32); --存储orgnization_id
    new_post             varchar2(50); --新职位信息                
  
  begin
    --判断新岗位信息是否存在
    select count(*)
      into rows
      FROM lcoa.OA_AFW_ADJUSTPOST_INFO
     WHERE C_ADJUST_ID = Adjust_Id;
  
    if rows <= 0 then
      ErrMsg := '调岗基础信息_不存在！';
      return - 1;
    end if;
  
    --查询值进行into 指定变量中
    SELECT C_ADJUST_USER_ID, C_NEW_ORGNIZATION_ID, V_NEW_POST
      into v_adjust_user_id, v_new_orgnization_id, new_post
      FROM lcoa.OA_AFW_ADJUSTPOST_INFO
     WHERE C_ADJUST_ID = Adjust_Id;
  
    -- 判断V_NEW_POST 是否有值
  
    --更新用户组织
    UPDATE LCBASE.T_USER
       SET C_ORGANIZATION_ID = v_new_orgnization_id
     WHERE C_USER_ID = v_adjust_user_id;
  
    --更新用户职务
    UPDATE LCBASE.T_EMPLOYEES_INFO
       SET V_USER_TITLE = new_post
     WHERE C_USER_ID = v_adjust_user_id;
  
    ErrMsg := '成功！';
    return 0;
  
  exception
    when others then
      ErrMsg := 'update_UserAndEmployees_info: ' || sqlcode || ',' ||
                sqlerrm;
      raise;
      return - 1;
    
  end update_UserAndEmployees_info;

  --判断是否有bp  
  function is_oraganization_exits(newOrgnizationId char,
                                  ErrMsg           OUT VARCHAR2)
    return number
  
   is
    v_is_bp_exits            integer;
    V_ORGANIZATION_PARENT_ID varchar2(50);
    v_result                 integer;
  begin
    SELECT CASE
             WHEN O.C_ORGANIZATION_BP IS null THEN
              -1
             ELSE
              0
           END AS "value",
           C_ORGANIZATION_PARENT_ID
      into v_is_bp_exits, V_ORGANIZATION_PARENT_ID
      from LCBASE.T_ORGANIZATION O
     where O.C_ORGANIZATION_ID = newOrgnizationId;
  
  end;

end PKG_INS_TRANSFERPOSITION_INFO;
/

