create package pkg_zl_dept_info is
  --新增部门
  function insert_children_organization(DataInfo        in varchar2, --新增的部门名称^父部门ID
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增部门ID
                                        ErrMsg          out varchar2)
    return number;

  --修改部门名称
  function update_children_organization(DataInfo        in varchar2, --部门id^部门名称
                                        OperationUserId IN VARCHAR2,
                                        ErrMsg          out varchar2)
    return number;

  --修改部门BP,VP
  function update_organization_leader(DataInfo        in varchar2, --部门id^负责人id^负责人类型1负责人 2 BP 3 VP
                                      OperationUserId IN VARCHAR2,
                                      ErrMsg          out varchar2)
    return number;

  --删除部门
  function delete_organization(OrganizationId  in varchar2, --部门id
                               OperationUserId IN VARCHAR2,
                               ErrMsg          out varchar2) return number;


  --新增角色
  function createrole(datainfo        in varchar2, --新增角色名称
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增角色ID
                                        ErrMsg          out varchar2)
  return number;

  --部门下添加角色
  function create_organization_role(organizationid        in varchar2, --新增角色的部门id
                                    DataInfo          IN VARCHAR2,--角色id集
                                    ErrMsg            out varchar2)
  return number;
  --新增用户角色
  function create_user_role(userid            in varchar2, --新增角色的用户id
                            DataInfo          IN VARCHAR2,--角色id集合
                            entrytype         in number,
                            ErrMsg            out varchar2)
  return number;
  --查询副部们角色信息
  function get_parentorg_role(organizationid            in varchar2, --部门id
                              roles                     out sys_refcursor,
                              ErrMsg                    out varchar2)
  return number;
  --修改角色
  function update_role(datainfo        in varchar2, --修改角色名称
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增角色ID
                                        ErrMsg          out varchar2)
  return number;
  --停用角色
  function update_delrole(datainfo        in varchar2, --修改角色名称
                                        OperationUserId IN VARCHAR2,
                                        DataId          out varchar2, --返回新增角色ID
                                        ErrMsg          out varchar2)
  return number;
end pkg_zl_dept_info;
/

