create package PKG_INS_SIGNATURE_INFO is
  function save_signature_info(datainfo in varchar2,
                               userId   OUT VARCHAR2,
                               ErrMsg   OUT VARCHAR2) return number;
end;
/

