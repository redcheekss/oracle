create TYPE MenuTable IS TABLE OF object
/

