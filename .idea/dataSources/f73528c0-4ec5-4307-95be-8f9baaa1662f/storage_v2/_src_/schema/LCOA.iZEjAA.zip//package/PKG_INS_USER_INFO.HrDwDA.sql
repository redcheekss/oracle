create package PKG_INS_USER_INFO is
  FUNCTION OAGetUserInfo(UserID   IN VARCHAR2,
                         User_CUR OUT sys_refcursor,
                         ErrMsg   OUT VARCHAR2) return number;
  procedure GetDirectSuperiorByUserId(UserId            in varchar2,
                                      SuperiorUserId    out varchar2,
                                      SuperiorUserName  out varchar2,
                                      SuperiorUserTitle out varchar2);
  procedure GetDirectSuperiorByOrgId(OrganizationId    in varchar2,
                                     SuperiorUserId    out varchar2,
                                     SuperiorUserName  out varchar2,
                                     SuperiorUserTitle out varchar2);
  procedure GetVPByUserId(UserId      in varchar2,
                          VPUserId    out varchar2,
                          VPUserName  out varchar2,
                          VPUserTitle out varchar2);
  procedure GetBPByOrgId(OrganizationId in varchar2,
                         BPUserId       out varchar2,
                         BPUserName     out varchar2,
                         BPUserTitle    out varchar2);

  function IsVPUserByUserId(UserId      in varchar2,
                            VPUserId    out varchar2,
                            VPUserName  out varchar2,
                            VPUserTitle out varchar2) return number;
  function IsCEOByUserId(UserId   in varchar2,
                         CEOId    out varchar2,
                         CEOName  out varchar2,
                         CEOTitle out varchar2) return number;
  --针对二级部门负责人                         
  function IsLv2OwnerByUserId(UserId        in varchar2,
                              Lv2OwnerId    out varchar2,
                              Lv2OwnerName  out varchar2,
                              Lv2OwnerTitle out varchar2) return number;

end PKG_INS_USER_INFO;
/

