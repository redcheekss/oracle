create package body PKG_EXPENSES_HW is

    --报销--查看 
    function expense_GetExpenseBaseInfo(DataId   in char,
                                        CUR_DATA OUT SYS_REFCURSOR,
                                        CUR_FLOW OUT SYS_REFCURSOR,
                                        CUR_FILE OUT SYS_REFCURSOR,
                                        ErrMsg   OUT VARCHAR2)
        return number IS
    begin
        OPEN CUR_DATA FOR
            select *
              from oa_eps_expenses_info a
             where a.c_expenses_id = DataId;
        open CUR_FLOW for
            select *
              from LCOA.oa_eps_expenses_item f
             where f.c_expenses_id = DataId
               and f.n_disabled_flag = 0;
        open CUR_FILE for
            select *
              from LCOA.OA_USER_UPLOAD_INFO l
             where l.c_forign_id = DataId
             order by l.d_upload_time;
        RETURN 0;
    exception
        when OTHERS then
            ErrMsg := 'Get_Expenses_Info: ' || SQLCODE || ',' ||
                      SQLERRM;
            RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
    end;

    --报销--附件查看 
    function expense_GetExpenseUploadInfo(DataId   in char,
                                          CUR_FILE OUT SYS_REFCURSOR,
                                          ErrMsg   OUT VARCHAR2)
        return number IS
    begin
        open CUR_FILE for
            select *
              from LCOA.OA_USER_UPLOAD_INFO l
             where l.c_forign_id = DataId
             order by l.d_upload_time;
        RETURN 0;
    exception
        when OTHERS then
            ErrMsg := 'Get_Expenses_Info: ' || SQLCODE || ',' ||
                      SQLERRM;
            RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
    end;

    --报销--报销进度查看 
    function expense_GetExpenseScheduleInfo(DataId       in char,
                                            CUR_FLOW     OUT SYS_REFCURSOR,
                                            CUR_Schedule OUT SYS_REFCURSOR,
                                            ErrMsg       OUT VARCHAR2)
        return number IS
    begin
        open CUR_Schedule for
            select *
              from LCOA.Oa_Afw_Workflow_Approval_Flow f
             where f.c_workflow_id = DataId
             order by f.n_approval_order;
        open CUR_FLOW for
            select *
              from LCOA.oa_afw_workflow_approval_log b
             where b.c_workflow_id = DataId
             order by b.d_approval_time desc;
        RETURN 0;
    exception
        when OTHERS then
            ErrMsg := 'Get_Expenses_Info: ' || SQLCODE || ',' ||
                      SQLERRM;
            RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
    end;
end PKG_EXPENSES_HW;
/

