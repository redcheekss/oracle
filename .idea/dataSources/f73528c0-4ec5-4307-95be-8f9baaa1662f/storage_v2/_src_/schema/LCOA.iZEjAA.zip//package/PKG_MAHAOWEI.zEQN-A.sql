create package pkg_mahaowei is
  procedure get_meet_message;
  function get_meeting_major(dataid          in varchar2,
                             datasource      in number,
                             operationuserid in varchar2,
                             getmeetinginfo  out sys_refcursor,
                             getmeetcontent  out sys_refcursor,
                             gettodolist     out sys_refcursor,
                             getuploadinfo   out sys_refcursor,
                             getattendeelist out sys_refcursor,
                             getschedulenum  out sys_refcursor,
                             getuserschedule out sys_refcursor,
                             countmeetingid  out number,
                             errmsg          out varchar2) return number;
  /**
  function get_meeting_info(dataid          in varchar2,
                            operationuserid in varchar2,
                            getmeetinginfo  out sys_refcursor,
                            getmeetcontent  out sys_refcursor,
                            gettodolist     out sys_refcursor,
                            getuploadinfo   out sys_refcursor,
                            getattendeelist out sys_refcursor,
                            getschedulenum  out sys_refcursor,
                            errmsg          out varchar2) return number;
  **/
  function get_meeting_status(dataid          in varchar2,
                              operationuserid in varchar2,
                              errmsg          out varchar2) return number;
  function get_clerk_id(dataid          in varchar2,
                        operationuserid in varchar2,
                        errmsg          out varchar2) return varchar2;
  function get_secret_type(dataid          in varchar2,
                           operationuserid in varchar2,
                           errmsg          out varchar2) return number;
  function check_meetinguser(dataid          in varchar2,
                             datasource      in number,
                             operationuserid in varchar2,
                             errmsg          out varchar2) return number;
  function get_meetingid_count(dataid          in varchar2,
                               datasource      in number,
                               operationuserid in varchar2,
                               errmsg          out varchar2) return number;
  function check_userteam(operationuserid in varchar2, errmsg out varchar2)
    return number;
  function get_approval_list(recordvo        in varchar2,
                             getapprovallist out sys_refcursor,
                             errmsg          out varchar2) return number;
  function get_apply_list(recordvo     in varchar2,
                          getapplylist out sys_refcursor,
                          errmsg       out varchar2) return number;
  function add_leave_list(userid            in varchar2,
                          startdate         in varchar2,
                          enddate           in varchar2,
                          approvalapplytype in number,
                          errmsg            out varchar2) return number;
  function add_egress_list(userid            in varchar2,
                           startdate         in varchar2,
                           enddate           in varchar2,
                           approvalapplytype in number,
                           errmsg            out varchar2) return number;
  function add_news_list(userid            in varchar2,
                         startdate         in varchar2,
                         enddate           in varchar2,
                         approvalapplytype in number,
                         errmsg            out varchar2) return number;

  function add_adjustpost_list(userid            in varchar2,
                               startdate         in varchar2,
                               enddate           in varchar2,
                               approvalapplytype in number,
                               errmsg            out varchar2) return number;

end pkg_mahaowei;
/

