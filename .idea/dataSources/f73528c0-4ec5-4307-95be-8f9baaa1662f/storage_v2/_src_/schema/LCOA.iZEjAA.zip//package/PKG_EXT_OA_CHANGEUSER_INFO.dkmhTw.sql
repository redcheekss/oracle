create package PKG_EXT_OA_CHANGEUSER_INFO is

  -- Author  : EDZ
  -- Created : 2020/5/21 18:06:57
  function ApprovalForList(RecordVo        in varchar2,
                           PageNum         in number,
                           PageSize        in number,
                           OperationUserId in varchar2,
                           GetApprovalList out sys_refcursor,
                           TotalPage       out number,
                           TotalCount      out number,
                           ErrMsg          out varchar2) return number;

  function ApplyForList(RecordVo        in varchar2,
                        PageNum         in number,
                        PageSize        in number,
                        OperationUserId in varchar2,
                        GetApplyList    out sys_refcursor,
                        TotalPage       out number,
                        TotalCount      out number,
                        ErrMsg          out varchar2) return number;

  function GetUserToDo(UserId          in varchar2,
                       skipStatus      in number,
                       PageNum         in number,
                       PageSize        in number,
                       OperationUserId out varchar2,
                       GetUserTodo     out sys_refcursor,
                       TotalPage       out number,
                       TotalCount      out number,
                       Errmsg          out varchar2) return number;

  --查询人员转正信息
  function QueryHireDate(UserId              in varchar2, --用户ID
                         OperationUserId     IN VARCHAR2,
                         HtHireDate          out Date, --入职时间
                         HtPromotionDate     out Date, --转正时间
                         GetApprovalUserList out sys_refcursor, --审批人列表
                         ErrMsg              out varchar2) return number;
  --查询人员转正审批信息
  function QueryAfwPromotion(PromotionId         in varchar2, --转正信息ID
                             OperationUserId     IN VARCHAR2,
                             CUR_DATA_HIRE       out sys_refcursor, --转正信息
                             CUR_DATA_APPRO_LIST out sys_refcursor, --审批流详情
                             ErrMsg              out varchar2) return number;

  --转正申请-添加 修改
  function SaveAfwPromotion(DataInfo        in varchar2,
                            OperationUserId IN VARCHAR2,
                            c_cursor        out sys_refcursor,
                            ErrMsg          out varchar2) return number;

  --调岗原部门基础信息
  /*  function queryPostAndOrganization(User_id         in char,
                                  Post_info       out sys_refcursor,
                                  OperationUserId IN OUT VARCHAR2,
                                  ErrMsg          OUT VARCHAR2)
  return number;*/

  --调岗信息添加
  function save_AfwAdjustpost_Info(DataInfo        in varchar2,
                                   OperationUserId IN VARCHAR2,
                                   --DataID1         out varchar2,
                                   c_cursor out sys_refcursor,
                                   ErrMsg   OUT VARCHAR2) return number;

  --调岗详情
  function query_AfwAdjustpost_info(Adjust_id            in char,
                                    OperationUserId      IN VARCHAR2,
                                    AdjustPost_Info      out sys_refcursor,
                                    transferApplyForPost out sys_refcursor,
                                    ErrMsg               OUT VARCHAR2)
    return number;

  function Create_ToDo_info(UserId_List out sys_refcursor,
                            ErrMsg      out varchar2) return number;

end PKG_EXT_OA_CHANGEUSER_INFO;

/

