create FUNCTION BITOR(nExpression1 number, nExpression2 number)
RETURN number
IS

BEGIN
   RETURN (nExpression1 + nExpression2) - bitand(nExpression1,nExpression2);
END BITOR;
/

