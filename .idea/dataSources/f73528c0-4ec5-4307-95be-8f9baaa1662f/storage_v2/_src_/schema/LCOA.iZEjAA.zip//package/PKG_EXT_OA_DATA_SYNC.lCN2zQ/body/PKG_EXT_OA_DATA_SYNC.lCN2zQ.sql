create package body PKG_EXT_OA_DATA_SYNC is

  -- Private type declarations
  --type <TypeName> is <Datatype>;

  -- Private constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Private variable declarations
  --<VariableName> <Datatype>;
  i number(1);

  function OAUserInfoSync return number is
    n_result     number(6) := 0;
    time_start   timestamp;
    time_end     timestamp;
    n_duration   number(10);
    n_status     number(1) := 0;
    p_id         char(32);
    v_op_content varchar2(4000);
  begin
    time_start := systimestamp;
    PKG_COMMON.InsertSpCallLog('OAUserInfoSync',
                               time_start + 0,
                               'call in',
                               p_id);

    begin
      n_result := CheckOAUserDiff();
      if n_result = 0 then
        dbms_output.put_line('没有变化');
      else
        dbms_output.put_line('有变化ReturnNum=' || n_result);
      end if;

      if bitand(n_result, 1) = 1 then
        InsertOAUser(v_op_content);
      end if;
      if bitand(n_result, 2) = 2 then
        UpdateOAUserMobile(v_op_content);
      end if;
      if bitand(n_result, 4) = 4 then
        UpdateOAUserStatus(v_op_content);
      end if;
      if bitand(n_result, 8) = 8 then
        UpdateOAUserPwd(v_op_content);
      end if;
      if bitand(n_result, 16) = 16 then
        UpdateOAUserType(v_op_content);
      end if;

      UpdateOAUserPetName;
      NOA2OAUser;
      UpdateAFWUsers(v_op_content);
      commit;
    EXCEPTION
      WHEN OTHERS THEN
        v_op_content := 'OAUserInfoSync: ' ||
                        pkg_common.g_errcode_exception || ',' || SQLERRM || ',' ||
                        DBMS_UTILITY.format_error_backtrace;
        n_result     := pkg_common.g_errcode_exception;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = pkg_common.g_errcode_exception) then
      n_status := 1;
    else
      n_status     := 0;
      v_op_content := v_op_content || ' call out!';
    end if;
    PKG_COMMON.UpdateSpCallLog(p_id,
                               time_end + 0,
                               n_duration,
                               v_op_content,
                               n_status);
    return n_result;
  end;

  --差异情况
  --1.新增用户 旧OA有 新OA没有
  --2.用户更新
  ----2.1手机号更新
  ----2.2状态更新
  ----2.3密码更新
  ----2.4员工状态
  function CheckOAUserDiff return number is
    n_count integer := 0;
    n_ret   integer := 0;
    n_pos   integer := 0;
  begin
    --1.新增用户
    n_pos := n_pos + 1;
    select count(*)
      into n_count
      from lcyw.t_lk_user_info src
      left join lcbase.t_zip_user u
        on src.c_user_id = u.c_user_id
       and u.d_enddate > sysdate
      left join lcyw.oa_department_users depusr
        on src.c_user_id = depusr.c_users_id
      left join lcyw.oa_department dep
        on depusr.c_department_id = dep.id
     where u.c_user_id is null --不在新OA用户表中
       and src.d_hire_date is not null --过滤 入职时间为空的无效记录
       and dep.id is not null
       and src.d_input_date > to_date('20200101', 'yyyymmdd');
    if n_count > 0 then
      n_ret := n_ret + setbit(0, n_pos, 1);
    end if;
    --2.1手机号更新
    n_pos := n_pos + 1;
    select count(*)
      into n_count
      from lcyw.t_lk_user_info t
      left join lcbase.t_zip_user u
        on t.c_user_id = u.c_user_id
       and u.d_enddate > sysdate
     where u.c_user_id is not null --在新OA用户表中
       and t.c_user_mobile <> u.n_mobile_1;

    if n_count > 0 then
      n_ret := n_ret + setbit(0, n_pos, 1);
    end if;
    --2.2状态更新
    n_pos := n_pos + 1;
    select count(*)
      into n_count
      from lcyw.t_lk_user_info t
      left join lcbase.t_zip_user u
        on t.c_user_id = u.c_user_id
       and u.d_enddate > sysdate
     where u.c_user_id is not null --在新OA用户表中
       and decode(t.n_enabled, 0, 1, 1, 0, 0) <> u.n_status;

    if n_count > 0 then
      n_ret := n_ret + setbit(0, n_pos, 1);
    end if;
    --2.3密码更新
    n_pos := n_pos + 1;
    select count(*)
      into n_count
      from lcyw.t_lk_user_info t
      left join lcbase.t_zip_user u
        on t.c_user_id = u.c_user_id
       and u.d_enddate > sysdate
     where u.c_user_id is not null --在新OA用户表中
       and t.c_user_password <> u.c_password;
    if n_count > 0 then
      n_ret := n_ret + setbit(0, n_pos, 1);
    end if;
    --2.4员工状态
    n_pos := n_pos + 1;
    select count(*)
      into n_count
      from lcyw.t_lk_user_info t
      left join lcbase.t_zip_user u
        on t.c_user_id = u.c_user_id
       and u.d_enddate > sysdate
       and decode(t.n_employee_type, 0, 1, 1, 0, 2, 2, 0) <> u.N_USER_TYPE;
    if n_count > 0 then
      n_ret := n_ret + setbit(0, n_pos, 1);
    end if;
    return n_ret;
  end;

  procedure InsertOAUser(vCallContent out varchar2) is
    user_cur  sys_refcursor;
    user_info lcyw.t_lk_user_info % rowtype;
  begin
    open user_cur for
      select src.*
        from lcyw.t_lk_user_info src
        left join lcbase.t_zip_user u
          on src.c_user_id = u.c_user_id
         and u.d_enddate > sysdate
       where u.c_user_id is null --不在新OA用户表中
         and src.d_hire_date is not null --过滤 入职时间为空的无效记录
         and src.d_input_date > to_date('20200101', 'yyyymmdd');

    fetch user_cur
      into user_info;

    while user_cur%found loop
      insert into lcbase.t_user
        select user_info.c_user_id,
               dep.id,
               user_info.v_user_name,
               decode(user_info.n_employee_type, 0, 1, 1, 0, 2, 2, 1) 用户类型,
               null,
               user_info.c_user_mobile,
               null,
               null,
               null,
               decode(user_info.n_enabled, 0, 1, 1, 0, 0) 状态,
               user_info.v_user_email,
               user_info.c_user_password,
               user_info.v_wx_open_id,
               null,
               decode(user_info.N_SEX, 0, 1, 1, 2, 2, 0, 0) 性别,
               0 权限,
               1 企业微信激活状态,
               user_info.v_headpic_aly,
               null, --n_work_id 此字段 生产库与开发库位置不一致，需要调整
               0,
               REPLACE(user_info.v_user_email, '@lecarlink.com', '')
          from lcyw.oa_department_users depusr
          left join lcyw.oa_department dep
            on depusr.c_department_id = dep.id
         where depusr.c_users_id = user_info.c_user_id
           and dep.id is not null
           and rownum = 1;
      insert into lcbase.t_employees_info
        select user_info.c_user_id,
               user_info.n_city_code,
               user_info.n_city_code,
               pos.pos_name,
               user_info.V_ID_CARD_NUMBER,
               user_info.d_hire_date,
               decode(user_info.n_political_apperar,
                      0,
                      1,
                      1,
                      2,
                      2,
                      3,
                      3,
                      0,
                      0) 政治面貌,
               nt.n_nation_id 民族,
               decode(user_info.n_marriage, 0, 3, 1, 0, 2, 3, 3, 4, 4, 5, 0) 婚姻状况 --(0:已婚;1:未婚;2:已婚已育;3:已婚未育;4:离异)
              ,
               user_info.v_id_card_address,
               decode(user_info.N_HU_KOU_TYPE, 0, 1, 1, 2, 0) 户口,
               user_info.v_present_address,
               user_info.v_urgency_link_man,
               user_info.v_urgency_link_tel,
               user_info.v_college,
               user_info.v_major,
               user_info.n_learning,
               user_info.d_entrance,
               user_info.d_graduation,
               user_info.n_hobbies,
               user_info.v_grades,
               user_info.d_promotion,
               decode(user_info.n_education,
                      0,
                      3,
                      1,
                      7,
                      2,
                      4,
                      3,
                      5,
                      4,
                      6,
                      5,
                      5,
                      6,
                      2,
                      7,
                      2,
                      8,
                      5,
                      10,
                      4,
                      0) 学历,
               user_info.v_bank_card_number,
               0,
               user_info.v_opening_bank,
               null as v_remark,
               0 --,user_info.n_social_security_type
              ,
               null as d_leave,
               user_info.n_work_number + 2,
               user_info.n_work_number,
               null c_labor_ref,
               0 n_status,
               user_info.c_lk_company_id
          from lcyw.oa_users_postion usrpos
          left join lcyw.oa_postion pos
            on usrpos.c_postion_id = pos.id
          left join lcbase.t_sys_nation nt
            on user_info.v_nation = nt.v_nation_name
         where usrpos.c_user_id = user_info.c_user_id
           and rownum = 1;

      --添加默认权限（普通用户1）added by lihuawei at 2020/5/20
      INSERT INTO Oa_Aut_User_Role
        (C_USER_ID, c_Role_Id)
        select u.c_user_id,
               (select r.c_role_id from Oa_Aut_Role r where r.role_type = 1)
          from LCbase.T_USER u
         where u.c_user_id = user_info.c_user_id;

      vCallContent := vCallContent || user_info.v_user_name || '(' ||
                      user_info.n_work_number || ')';
      fetch user_cur
        into user_info;
    end loop;
    close user_cur;
  end;

  procedure UpdateOAUserMobile(vCallContent out varchar2) is
    user_cur  sys_refcursor;
    user_info lcyw.t_lk_user_info % rowtype;
  begin
    open user_cur for
      select src.*
        from lcyw.t_lk_user_info src
        left join lcbase.t_zip_user u
          on src.c_user_id = u.c_user_id and u.d_enddate > sysdate
        left join lcyw.oa_department_users depusr
          on src.c_user_id = depusr.c_users_id
        left join lcyw.oa_department dep
          on depusr.c_department_id = dep.id
       where src.c_user_mobile <> u.n_mobile_1 --新老用户表手机号不一致
         and src.d_hire_date is not null --过滤 入职时间为空的无效记录
         and dep.id is not null
         and src.c_user_id not in
             ('bd41774627f24042a23b1afc7a769249',
              '92ed95356c7b45668c76999de8f385be',
              'e1069309843944eb8926a0dad848b71a',
              '9544b749920c4c389710f6e4890810b3',
              '33bed1d8a4dd4c9db8c9ccab2a53304a',
              '8bcf1e7e11004b18888ddef7a0e0b268',
              'd6790aec5f644afd921c61702476a40a',
              '558a8c9359a04cf390d78dd422ef36da',
              '461d1fe99e674293ad56063d79613e6f',
              '136ea603c31b4395863be352f7dae5d0',
              'c23e589f032941b7bfbe0b2e378802ff',
              '3148035ad0074fde84eb215a01e57f1b',
              '9a4e73651ee241fb8f988610d9ee3606',
              '8b96e21161f541bcb3088fbb7b8ede50',
              'eafa67b626474abf84fc28b42b9c5fdf',
              '55aa9566806b4770a228723bd5d6d730',
              '04c3ee0784f44b37b268d998f60e24c7',
              'a83300d3d27348c3a8f795f58c7c9f05',
              '562a30ff266045d89d126d2397ed2652',
              'abbe6f5e4e5b4e80aa1bd2396defd0ed'); --剔除20个不需要关注变更的手机号

    fetch user_cur
      into user_info;

    while user_cur%found loop
      update lcbase.t_zip_user u
         set u.n_mobile_1 = user_info.c_user_mobile
       where u.c_user_id = user_info.c_user_id and u.d_enddate > sysdate;

      vCallContent := vCallContent || user_info.v_user_name || '(' ||
                      user_info.n_work_number || ')';
      fetch user_cur
        into user_info;
    end loop;
    close user_cur;
  end;

  procedure UpdateOAUserStatus(vCallContent out varchar2) is
    user_cur  sys_refcursor;
    user_info lcyw.t_lk_user_info % rowtype;
  begin
    open user_cur for
      select src.*
        from lcyw.t_lk_user_info src
        left join lcbase.t_zip_user u
          on src.c_user_id = u.c_user_id and u.d_enddate > sysdate
        left join lcyw.oa_department_users depusr
          on src.c_user_id = depusr.c_users_id
        left join lcyw.oa_department dep
          on depusr.c_department_id = dep.id
       where decode(src.n_enabled, 0, 1, 1, 0, 0) <> u.n_status --新老用户表手机号不一致
         and src.d_hire_date is not null --过滤 入职时间为空的无效记录
         and dep.id is not null;

    fetch user_cur
      into user_info;

    while user_cur%found loop
      update lcbase.t_zip_user u
         set u.n_status = decode(user_info.n_enabled, 0, 1, 1, 0, 0)
       where u.c_user_id = user_info.c_user_id and u.d_enddate > sysdate;

      vCallContent := vCallContent || user_info.v_user_name || '(' ||
                      user_info.n_work_number || ')';
      fetch user_cur
        into user_info;
    end loop;
    close user_cur;
  end;
  procedure UpdateOAUserPwd(vCallContent out varchar2) is
    user_cur  sys_refcursor;
    user_info lcyw.t_lk_user_info % rowtype;
  begin
    open user_cur for
      select src.*
        from lcyw.t_lk_user_info src
        left join lcbase.t_zip_user u
          on src.c_user_id = u.c_user_id and u.d_enddate > sysdate
        left join lcyw.oa_department_users depusr
          on src.c_user_id = depusr.c_users_id
        left join lcyw.oa_department dep
          on depusr.c_department_id = dep.id
       where src.c_user_password <> u.c_password --新老用户表手机号不一致
         and src.d_hire_date is not null --过滤 入职时间为空的无效记录
         and dep.id is not null;

    fetch user_cur
      into user_info;

    while user_cur%found loop
      update lcbase.t_zip_user u
         set u.c_password = user_info.c_user_password
       where u.c_user_id = user_info.c_user_id and u.d_enddate >sysdate;

      vCallContent := vCallContent || user_info.v_user_name || '(' ||
                      user_info.n_work_number || ')';
      fetch user_cur
        into user_info;
    end loop;
    close user_cur;
  end;
  procedure UpdateOAUserType(vCallContent out varchar2) is
    user_cur  sys_refcursor;
    user_info lcyw.t_lk_user_info % rowtype;
  begin
    open user_cur for
      select src.*
        from lcyw.t_lk_user_info src
        left join lcbase.t_zip_user u
          on src.c_user_id = u.c_user_id and u.d_enddate > sysdate
        left join lcyw.oa_department_users depusr
          on src.c_user_id = depusr.c_users_id
        left join lcyw.oa_department dep
          on depusr.c_department_id = dep.id
       where decode(src.n_employee_type, 0, 1, 1, 0, 2, 2, 1) <>
             u.n_user_type --新老用户表手机号不一致
         and src.d_hire_date is not null --过滤 入职时间为空的无效记录
         and dep.id is not null;

    fetch user_cur
      into user_info;

    while user_cur%found loop
      update lcbase.t_zip_user u
         set u.n_user_type = decode(user_info.n_employee_type,
                                    0,
                                    1,
                                    1,
                                    0,
                                    2,
                                    2,
                                    1)
       where u.c_user_id = user_info.c_user_id and u.d_enddate >sysdate;

      vCallContent := vCallContent || user_info.v_user_name || '(' ||
                      user_info.n_work_number || ')';
      fetch user_cur
        into user_info;
    end loop;
    close user_cur;
  end;
  procedure UpdateOAUserPetName is
  begin
    --刷新重名的数据
    update lcbase.t_zip_user t
       set t.v_pet_name =
           (select u.v_user_name || '(' || e.n_work_num_old || ')'
              from lcbase.t_user u, lcbase.t_employees_info e
             where u.c_user_id = e.c_user_id
               and u.c_user_id = t.c_user_id)
     where t.v_user_name in (select t.v_user_name
                               from lcbase.t_zip_user t
                               where t.d_enddate > sysdate
                              group by t.v_user_name
                             having count(*) > 1) and t.d_enddate > sysdate;
    --刷新唯一姓名数据
    update lcbase.t_zip_user t
       set t.v_pet_name = t.v_user_name
     where t.v_user_name in (select t.v_user_name
                               from lcbase.t_zip_user t
                               where t.d_enddate > sysdate
                              group by t.v_user_name
                             having count(*) = 1) and t.d_enddate > sysdate;
  end;
  procedure NOA2OAUser is
  begin
    --因为查询条件需要过滤老OA表，需要先加角色权限，再添加用户表信息
    insert into lcyw.oa_user_roles
      select lower(sys_guid()), ur.c_user_id, ur.c_role_id
        from lcbase.t_zip_user nu
        left join lcyw.t_lk_user_info ou
          on nu.c_user_id = ou.c_user_id
        left join lcbase.t_employees_info e
          on nu.c_user_id = e.c_user_id
        left join lcoa.oa_aut_user_role ur
          on nu.c_user_id = ur.c_user_id
       where ou.c_user_id is NULL
         and nu.d_enddate > sysdate
         and nu.n_status = 0;

    INSERT INTO LCYW.T_LK_USER_INFO
      (C_USER_ID,
       C_USER_MOBILE,
       C_USER_PASSWORD,
       V_USER_NAME,
       C_CORP_ID,
       V_USER_EMAIL,
       C_INPUT_USER_ID,
       V_INPUT_USER_NAME,
       D_INPUT_DATE,
       N_ENABLED,
       N_ROLE_TYPE,
       N_RANK,
       C_POSITION_ID,
       IS_LOGIN_OA_PERMISSIONS,
       IS_LOGIN_BI_PERMISSIONS,
       IS_LOGIN_LECARLINK_PERMISSION,
       V_HEADPIC_ALY,
       N_WORK_NUMBER,
       V_ID_CARD_NUMBER,
       D_HIRE_DATE,
       IS_LOGIN_ZT_ADMIN,
       N_PROVINCE_CODE,
       N_CITY_CODE,
       C_DIRECT_SUPERIOR_ID,
       N_USER_TYPE,
       C_LK_COMPANY_ID,
       N_CONTRACT_TYPE,
       V_BANK_NAME,
       D_UPDATE_DATE,
       N_VERIFICATION_TYPE,
       IS_LOGIN_KA,
       IS_LOGIN_WXLECAR,
       IS_LOGIN_WXOA,
       IS_LOGIN_APP_ADMIN,
       N_VERIFICATION_TYPE_PHONE,
       N_VERIFICATION_TYPE_MAC,
       N_VERIFICATION_TYPE_IPHONE,
       V_MACHINE_WIN_MSG)
      select nu.c_user_id,
             nu.n_mobile_1,
             nu.C_PASSWORD,
             nu.V_USER_NAME,
             'lcsm0000000000000000000000000001' C_CORP_ID,
             nu.V_EMAIL,
             '' C_INPUT_USER_ID,
             '新OA同步' V_INPUT_USER_NAME,
             SYSDATE D_INPUT_DATE,
             decode(nu.N_STATUS, 1, 0, 0, 1, 0) 状态,
             0 N_ROLE_TYPE,
             0 N_RANK,
             null C_POSITION_ID,
             1 IS_LOGIN_OA_PERMISSIONS,
             1 IS_LOGIN_BI_PERMISSIONS,
             1 IS_LOGIN_LECARLINK_PERMISSION,
             nu.V_HEADPIC_ALY,
             e.n_work_num_old,
             e.C_ID_CARD_NUMBER,
             e.D_HIRE_DATE,
             0 IS_LOGIN_ZT_ADMIN,
             substr(e.n_work_place, 1, 2) || '0000' N_PROVINCE_CODE,
             substr(e.n_work_place, 1, 4) || '00' N_CITY_CODE,
             '' C_DIRECT_SUPERIOR_ID,
             0 N_USER_TYPE,
             e.C_LK_COMPANY_ID,
             0 N_CONTRACT_TYPE,
             '' V_BANK_NAME,
             SYSDATE D_UPDATE_DATE,
             1 N_VERIFICATION_TYPE,
             0 IS_LOGIN_KA,
             0 IS_LOGIN_WXLECAR,
             0 IS_LOGIN_WXOA,
             0 IS_LOGIN_APP_ADMIN,
             1 N_VERIFICATION_TYPE_PHONE,
             1 N_VERIFICATION_TYPE_MAC,
             1 N_VERIFICATION_TYPE_IPHONE,
             '' V_MACHINE_WIN_MSG
        from lcbase.t_zip_user nu
        left join lcyw.t_lk_user_info ou
          on nu.c_user_id = ou.c_user_id
        left join lcbase.t_employees_info e
          on nu.c_user_id = e.c_user_id
       where ou.c_user_id is NULL and nu.d_enddate > sysdate
         and nu.n_status = 0;

    --commit;
  end;

  procedure UpdateAFWUsers(vCallContent out varchar2) is
  begin
      lcoa.pkg_ins_user_info.workflow_approval_Reset(vCallContent);
  end;
  --此块进行变量初始化，可删除
begin
  -- Initialization
  i := 1;
end PKG_EXT_OA_DATA_SYNC;

/

