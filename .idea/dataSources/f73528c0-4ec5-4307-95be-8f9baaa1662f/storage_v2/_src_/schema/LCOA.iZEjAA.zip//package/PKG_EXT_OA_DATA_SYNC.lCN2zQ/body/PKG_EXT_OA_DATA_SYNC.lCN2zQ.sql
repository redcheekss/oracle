create package body PKG_EXT_OA_DATA_SYNC is

  -- Private type declarations
  --type <TypeName> is <Datatype>;

  -- Private constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Private variable declarations
  --<VariableName> <Datatype>;
  i number(1);

  function OAUserInfoSync return number is
    n_result     number(6) := 0;
    time_start   timestamp;
    time_end     timestamp;
    n_duration   number(10);
    n_status     number(1) := 0;
    p_id         char(32);
    v_op_content varchar2(4000);
  begin
    time_start := systimestamp;
    PKG_COMMON.InsertSpCallLog('OAUserInfoSync',
                               time_start + 0,
                               'call in',
                               p_id);
  
    begin
      n_result := CheckOAUserDiff();
      if n_result = 0 then
        dbms_output.put_line('没有变化');
      else
        dbms_output.put_line('有变化ReturnNum=' || n_result);
      end if;
    
      if bitand(n_result, 1) = 1 then
        InsertOAUser(v_op_content);
      end if;
      if bitand(n_result, 2) = 2 then
        UpdateOAUserMobile(v_op_content);
      end if;
      if bitand(n_result, 4) = 4 then
        UpdateOAUserStatus(v_op_content);
      end if;
      if bitand(n_result, 8) = 8 then
        UpdateOAUserPwd(v_op_content);
      end if;
      if bitand(n_result, 16) = 16 then
        UpdateOAUserType(v_op_content);
      end if;
    
      commit;
    EXCEPTION
      WHEN OTHERS THEN
        v_op_content := 'OAUserInfoSync: ' ||
                        pkg_common.g_errcode_exception || ',' || SQLERRM || ',' ||
                        DBMS_UTILITY.format_error_backtrace;
        n_result     := pkg_common.g_errcode_exception;
        rollback;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = pkg_common.g_errcode_exception) then
      n_status := 1;
    else
      n_status     := 0;
      v_op_content := v_op_content || ' call out!';
    end if;
    PKG_COMMON.UpdateSpCallLog(p_id,
                               time_end + 0,
                               n_duration,
                               v_op_content,
                               n_status);
    return n_result;
  end;

  --差异情况
  --1.新增用户 旧OA有 新OA没有
  --2.用户更新 
  ----2.1手机号更新
  ----2.2状态更新
  ----2.3密码更新
  ----2.4员工状态
  function CheckOAUserDiff return number is
    n_count integer := 0;
    n_ret   integer := 0;
    n_pos   integer := 0;
  begin
    --1.新增用户
    n_pos := n_pos + 1;
    select count(*)
      into n_count
      from lcyw.t_lk_user_info src
      left join lcbase.t_user u
        on src.c_user_id = u.c_user_id
      left join lcyw.oa_department_users depusr
        on src.c_user_id = depusr.c_users_id
      left join lcyw.oa_department dep
        on depusr.c_department_id = dep.id
     where u.c_user_id is null --不在新OA用户表中
       and src.d_hire_date is not null --过滤 入职时间为空的无效记录
       and dep.id is not null
       and src.d_input_date > to_date('20200101', 'yyyymmdd');
    if n_count > 0 then
      n_ret := n_ret + setbit(0, n_pos, 1);
    end if;
    --2.1手机号更新
    n_pos := n_pos + 1;
    select count(*)
      into n_count
      from lcyw.t_lk_user_info t
      left join lcbase.t_user u
        on t.c_user_id = u.c_user_id
     where u.c_user_id is not null --在新OA用户表中
       and t.c_user_mobile <> u.n_mobile_1;
  
    if n_count > 0 then
      n_ret := n_ret + setbit(0, n_pos, 1);
    end if;
    --2.2状态更新
    n_pos := n_pos + 1;
    select count(*)
      into n_count
      from lcyw.t_lk_user_info t
      left join lcbase.t_user u
        on t.c_user_id = u.c_user_id
     where u.c_user_id is not null --在新OA用户表中
       and decode(t.n_enabled, 0, 1, 1, 0, 0) <> u.n_status;
  
    if n_count > 0 then
      n_ret := n_ret + setbit(0, n_pos, 1);
    end if;
    --2.3密码更新
    n_pos := n_pos + 1;
    select count(*)
      into n_count
      from lcyw.t_lk_user_info t
      left join lcbase.t_user u
        on t.c_user_id = u.c_user_id
     where u.c_user_id is not null --在新OA用户表中
       and t.c_user_password <> u.c_password;
    if n_count > 0 then
      n_ret := n_ret + setbit(0, n_pos, 1);
    end if;
    --2.4员工状态
    n_pos := n_pos + 1;
    select count(*)
      into n_count
      from lcyw.t_lk_user_info t
      left join lcbase.t_user u
        on t.c_user_id = u.c_user_id
       and decode(t.n_employee_type, 0, 1, 1, 0, 2, 2, 0) <> u.N_USER_TYPE;
    if n_count > 0 then
      n_ret := n_ret + setbit(0, n_pos, 1);
    end if;
    return n_ret;
  end;

  procedure InsertOAUser(vCallContent out varchar2) is
    user_cur  sys_refcursor;
    user_info lcyw.t_lk_user_info % rowtype;
  begin
    open user_cur for
      select src.*
        from lcyw.t_lk_user_info src
        left join lcbase.t_user u
          on src.c_user_id = u.c_user_id
       where u.c_user_id is null --不在新OA用户表中
         and src.d_hire_date is not null --过滤 入职时间为空的无效记录
         and src.d_input_date > to_date('20200101', 'yyyymmdd');
  
    fetch user_cur
      into user_info;
  
    while user_cur%found loop
      insert into lcbase.t_user
        select user_info.c_user_id,
               dep.id,
               user_info.v_user_name,
               decode(user_info.n_employee_type, 0, 1, 1, 0, 2, 2, 1) 用户类型,
               null, --n_work_id 此字段 生产库与开发库位置不一致，需要调整
               null,
               user_info.c_user_mobile,
               null,
               null,
               null,
               decode(user_info.n_enabled, 0, 1, 1, 0, 0) 状态,
               user_info.v_user_email,
               user_info.c_user_password,
               user_info.v_wx_open_id,
               null,
               decode(user_info.N_SEX, 0, 1, 1, 2, 2, 0, 0) 性别,
               0 权限,
               1 企业微信激活状态,
               user_info.v_headpic_aly
        
          from lcyw.oa_department_users depusr
          left join lcyw.oa_department dep
            on depusr.c_department_id = dep.id
         where depusr.c_users_id = user_info.c_user_id
           and dep.id is not null
           and rownum = 1;
      insert into lcbase.t_employees_info
        select user_info.c_user_id,
               user_info.n_city_code,
               user_info.n_city_code,
               pos.pos_name,
               user_info.V_ID_CARD_NUMBER,
               user_info.d_hire_date,
               decode(user_info.n_political_apperar,
                      0,
                      1,
                      1,
                      2,
                      2,
                      3,
                      3,
                      0,
                      0) 政治面貌,
               nt.n_nation_id 民族,
               decode(user_info.n_marriage, 0, 3, 1, 0, 2, 3, 3, 4, 4, 5, 0) 婚姻状况 --(0:已婚;1:未婚;2:已婚已育;3:已婚未育;4:离异)
              ,
               user_info.v_id_card_address,
               decode(user_info.N_HU_KOU_TYPE, 0, 1, 1, 2, 0) 户口,
               user_info.v_present_address,
               user_info.v_urgency_link_man,
               user_info.v_urgency_link_tel,
               user_info.v_college,
               user_info.v_major,
               user_info.n_learning,
               user_info.d_entrance,
               user_info.d_graduation,
               user_info.n_hobbies,
               user_info.v_grades,
               user_info.d_promotion,
               decode(user_info.n_education,
                      0,
                      3,
                      1,
                      7,
                      2,
                      4,
                      3,
                      5,
                      4,
                      6,
                      5,
                      5,
                      6,
                      2,
                      7,
                      2,
                      8,
                      5,
                      10,
                      4,
                      0) 学历,
               user_info.v_bank_card_number,
               0,
               user_info.v_opening_bank,
               null as v_remark,
               0 --,user_info.n_social_security_type
              ,
               null as d_leave,
               user_info.n_work_number + 2,
               user_info.n_work_number,
               null c_labor_ref,
               0 n_status,
               user_info.c_lk_company_id
          from lcyw.oa_users_postion usrpos
          left join lcyw.oa_postion pos
            on usrpos.c_postion_id = pos.id
          left join lcbase.t_sys_nation nt
            on user_info.v_nation = nt.v_nation_name
         where usrpos.c_user_id = user_info.c_user_id
           and rownum = 1;
    
      vCallContent := vCallContent || user_info.v_user_name || '(' ||
                      user_info.n_work_number || ')';
      fetch user_cur
        into user_info;
    end loop;
    close user_cur;
  end;

  procedure UpdateOAUserMobile(vCallContent out varchar2) is
    user_cur  sys_refcursor;
    user_info lcyw.t_lk_user_info % rowtype;
  begin
    open user_cur for
      select src.*
        from lcyw.t_lk_user_info src
        left join lcbase.t_user u
          on src.c_user_id = u.c_user_id
        left join lcyw.oa_department_users depusr
          on src.c_user_id = depusr.c_users_id
        left join lcyw.oa_department dep
          on depusr.c_department_id = dep.id
       where src.c_user_mobile <> u.n_mobile_1 --新老用户表手机号不一致
         and src.d_hire_date is not null --过滤 入职时间为空的无效记录
         and dep.id is not null;
  
    fetch user_cur
      into user_info;
  
    while user_cur%found loop
      update lcbase.t_user u
         set u.n_mobile_1 = user_info.c_user_mobile
       where u.c_user_id = user_info.c_user_id;
    
      vCallContent := vCallContent || user_info.v_user_name || '(' ||
                      user_info.n_work_number || ')';
      fetch user_cur
        into user_info;
    end loop;
    close user_cur;
  end;

  procedure UpdateOAUserStatus(vCallContent out varchar2) is
    user_cur  sys_refcursor;
    user_info lcyw.t_lk_user_info % rowtype;
  begin
    open user_cur for
      select src.*
        from lcyw.t_lk_user_info src
        left join lcbase.t_user u
          on src.c_user_id = u.c_user_id
        left join lcyw.oa_department_users depusr
          on src.c_user_id = depusr.c_users_id
        left join lcyw.oa_department dep
          on depusr.c_department_id = dep.id
       where decode(src.n_enabled, 0, 1, 1, 0, 0) <> u.n_status --新老用户表手机号不一致
         and src.d_hire_date is not null --过滤 入职时间为空的无效记录
         and dep.id is not null;
  
    fetch user_cur
      into user_info;
  
    while user_cur%found loop
      update lcbase.t_user u
         set u.n_status = decode(user_info.n_enabled, 0, 1, 1, 0, 0)
       where u.c_user_id = user_info.c_user_id;
    
      vCallContent := vCallContent || user_info.v_user_name || '(' ||
                      user_info.n_work_number || ')';
      fetch user_cur
        into user_info;
    end loop;
    close user_cur;
  end;
  procedure UpdateOAUserPwd(vCallContent out varchar2) is
    user_cur  sys_refcursor;
    user_info lcyw.t_lk_user_info % rowtype;
  begin
    open user_cur for
      select src.*
        from lcyw.t_lk_user_info src
        left join lcbase.t_user u
          on src.c_user_id = u.c_user_id
        left join lcyw.oa_department_users depusr
          on src.c_user_id = depusr.c_users_id
        left join lcyw.oa_department dep
          on depusr.c_department_id = dep.id
       where src.c_user_password <> u.c_password --新老用户表手机号不一致
         and src.d_hire_date is not null --过滤 入职时间为空的无效记录
         and dep.id is not null;
  
    fetch user_cur
      into user_info;
  
    while user_cur%found loop
      update lcbase.t_user u
         set u.c_password = user_info.c_user_password
       where u.c_user_id = user_info.c_user_id;
    
      vCallContent := vCallContent || user_info.v_user_name || '(' ||
                      user_info.n_work_number || ')';
      fetch user_cur
        into user_info;
    end loop;
    close user_cur;
  end;
  procedure UpdateOAUserType(vCallContent out varchar2) is
    user_cur  sys_refcursor;
    user_info lcyw.t_lk_user_info % rowtype;
  begin
    open user_cur for
      select src.*
        from lcyw.t_lk_user_info src
        left join lcbase.t_user u
          on src.c_user_id = u.c_user_id
        left join lcyw.oa_department_users depusr
          on src.c_user_id = depusr.c_users_id
        left join lcyw.oa_department dep
          on depusr.c_department_id = dep.id
       where decode(src.n_employee_type, 0, 1, 1, 0, 2, 2, 1) <>
             u.n_user_type --新老用户表手机号不一致
         and src.d_hire_date is not null --过滤 入职时间为空的无效记录
         and dep.id is not null;
  
    fetch user_cur
      into user_info;
  
    while user_cur%found loop
      update lcbase.t_user u
         set u.n_user_type = decode(user_info.n_employee_type,
                                    0,
                                    1,
                                    1,
                                    0,
                                    2,
                                    2,
                                    1)
       where u.c_user_id = user_info.c_user_id;
    
      vCallContent := vCallContent || user_info.v_user_name || '(' ||
                      user_info.n_work_number || ')';
      fetch user_cur
        into user_info;
    end loop;
    close user_cur;
  end;
  procedure UpdateAFWUsers(vCallContent out varchar2) is
    cursor afw_cur is
      select t.c_data_id,
             t.n_workflow_type,
             t.n_approval_order,
             flows.bstype,
             t.c_approval_user_id,
             t.v_approval_user_name,
             flows.userid,
             u.v_user_name,
             u.c_organization_id
      
        from lcoa.oa_afw_workflow_approval_flow t
        left join (select '请假' bstype,
                          leave.c_leave_id flowid,
                          leave.c_leave_user_id userid
                     from lcoa.oa_afw_leave_info leave
                   union all
                   select '外出' bstype,
                          egress.c_egress_id flowid,
                          egress.c_egress_user_id userid
                     from lcoa.oa_afw_egress_info egress
                   union all
                   select '公告' bstype,
                          pub.c_news_id flowid,
                          pub.c_input_user_id userid
                     from lcoa.oa_msg_publish_info pub) flows
          on t.c_workflow_id = flows.flowid
       inner join lcbase.t_user u
          on flows.userid = u.c_user_id
       where t.n_approval_status not in (-1, 1);
    afwinfo           afw_cur % rowtype;
    SuperiorUserId    char(32);
    SuperiorUserName  varchar2(20);
    SuperiorUserTitle varchar2(20);
    VPUserId          char(32);
    VPUserName        varchar2(20);
    VPUserTitle       varchar2(20);
  
  begin
    open afw_cur;
    fetch afw_cur
      into afwinfo;
  
    while afw_cur%found loop
      vCallContent := vCallContent;
      --判断申请人是否为VP
      if (lcoa.pkg_ins_user_info.IsVPUserByUserId(afwinfo.userid,
                                                  VPUserId,
                                                  VPUserName,
                                                  VPUserTitle) = 0) then
        lcoa.pkg_ins_user_info.GetDirectSuperiorByUserId(afwinfo.userid,
                                                         SuperiorUserId,
                                                         SuperiorUserName,
                                                         SuperiorUserTitle);
        if (afwinfo.c_approval_user_id <> SuperiorUserId and
           afwinfo.n_approval_order = 1) then
          dbms_output.put_line('dataid:=' || afwinfo.c_data_id || '申请人:' ||
                               afwinfo.v_user_name || ',原审批人:' ||
                               afwinfo.v_approval_user_name || ',新审批人:' ||
                               SuperiorUserName);
        end if;
      end if;
      lcoa.pkg_ins_user_info.GetVPByUserId(afwinfo.userid,
                                           VPUserId,
                                           VPUserName,
                                           VPUserTitle);
      if (afwinfo.c_approval_user_id <> VPUserId and
         afwinfo.n_approval_order = 3) then
        dbms_output.put_line('dataid:=' || afwinfo.c_data_id || '申请人:' ||
                             afwinfo.v_user_name || ',原审批人:' ||
                             afwinfo.v_approval_user_name || ',新审批人:' ||
                             VPUserName);
      end if;
      fetch afw_cur
        into afwinfo;
    end loop;
    close afw_cur;
  end;
  --此块进行变量初始化，可删除
begin
  -- Initialization
  i := 1;
end PKG_EXT_OA_DATA_SYNC;
/

