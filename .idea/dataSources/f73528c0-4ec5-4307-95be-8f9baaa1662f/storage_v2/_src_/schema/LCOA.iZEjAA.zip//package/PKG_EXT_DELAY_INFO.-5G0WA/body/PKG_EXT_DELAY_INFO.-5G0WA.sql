create package body PKG_EXT_DELAY_INFO is
  function getDelayApproverList(userId       in varchar2, --操作人ID
                                loanInfo     out sys_refcursor, --未还清借款单列表 
                                ApproveUsers out sys_refcursor, --审批人详情
                                ErrMsg       out varchar2) return number is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
  begin
    time_start := systimestamp;
    begin
      n_optype := 1;
      n_result := lcoa.PKG_INS_DELAY_INFO.getDelayApproverList(userId,
                                                               loanInfo,
                                                               ApproveUsers,
                                                               ErrMsg);
    
    EXCEPTION
      WHEN OTHERS THEN
        --ErrMsg := pkg_common.g_errmsg_common;
        ErrMsg   := SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(userId,
                                  'getDelayApproverList',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function save_delay_info(loanIds   in varchar2,
                           delayInfo in varchar2,
                           userId    IN VARCHAR2,
                           c_cursor  out sys_refcursor,
                           ErrMsg    OUT VARCHAR2) return number is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
  begin
    time_start := systimestamp;
    begin
      n_optype := 2;
      n_result := lcoa.PKG_INS_DELAY_INFO.save_delay_info(loanIds,
                                                          delayInfo,
                                                          userId,
                                                          c_cursor,
                                                          ErrMsg);
    
    EXCEPTION
      WHEN OTHERS THEN
        --ErrMsg := pkg_common.g_errmsg_common;
        ErrMsg   := SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
      commit;
    else
      n_status := 1;
      rollback;
    end if;
    PKG_COMMON.InsertOperationLog(userId,
                                  'save_delay_info',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;

  function getDelayInfo(delayId         in varchar2, --借款信息ID
                        operationUserId in varchar2, --操作人ID
                        loanInfo        out sys_refcursor, --借款单详情 
                        ApproveUsers    out sys_refcursor, --审批人详情
                        delayInfo       out sys_refcursor,
                        ErrMsg          out varchar2) return number is
    n_optype   number(6); --1查2插3更4删
    n_status   number(6) := 0; --0成功1失败
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_result   number(6);
  begin
    time_start := systimestamp;
    begin
      n_optype := 1;
      n_result := lcoa.PKG_INS_DELAY_INFO.getDelayInfo(delayId,
                                                       operationUserId,
                                                       loanInfo,
                                                       ApproveUsers,
                                                       delayInfo,
                                                       ErrMsg);
    
    EXCEPTION
      WHEN OTHERS THEN
        --ErrMsg := pkg_common.g_errmsg_common;
        ErrMsg   := SQLCODE || ',' || SQLERRM || ',' ||
                    DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    END;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(OperationUserId,
                                  'getDelayInfo',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
end;
/

