create package body PKG_TEMPEMPLOYEE is
    FUNCTION Update_Employee(PEmployeeInfo IN VARCHAR2,
                             ErrMsg        OUT VARCHAR2)
        RETURN NUMBER IS
        DATAARR  PKG_COMMON.ARR_LONGSTR;
        P_ID     CHAR(32);
        P_STEP   NUMBER(2) := 0;
        P_CNT    NUMBER(3) := 0;
        P_OPTYPE NUMBER(1) := 1;
        ErrMsg2  varchar2(50);
        result_n integer;
    BEGIN
        BEGIN
            DATAARR := PKG_COMMON.Split(PEmployeeInfo, '^');
            P_ID    := DATAARR(1);
            --判断身份证银行卡是否为空
        
            result_n := Pkg_Tempemployee.IS_ID_CARD_EXISTS(DATAARR(5),
                                                           P_ID,
                                                           ErrMsg);
            if result_n = -1 then
                return - 1;
            end if;
            result_n := Pkg_Tempemployee.IS_BANK_CARD_EXISTS(DATAARR(24),
                                                             P_ID,
                                                             ErrMsg);
            if result_n = -1 then
                return - 1;
            end if;
        
            UPDATE LCBASE.T_EMPLOYEES_INFO
               SET N_WORK_PLACE             = DATAARR(2),
                   N_POSSESSION             = DATAARR(3),
                   V_USER_TITLE             = DATAARR(4),
                   C_ID_CARD_NUMBER         = DATAARR(5),
                   D_HIRE_DATE              = to_date(DATAARR(6),
                                                      'yyyymmddhh24miss'),
                   N_POLITICAL_APPERAR      = DATAARR(7),
                   V_NATION                 = DATAARR(8),
                   N_MARRIAGE               = DATAARR(9),
                   V_ID_CARD_ADDRESS        = DATAARR(10),
                   N_HU_KOU_TYPE            = DATAARR(11),
                   V_PRESENT_ADDRESS        = DATAARR(12),
                   V_URGENCY_LINK_MAN       = DATAARR(13),
                   V_URGENCY_LINK_TEL       = DATAARR(14),
                   V_COLLEGE                = DATAARR(15),
                   V_MAJOR                  = DATAARR(16),
                   N_LEARNING               = DATAARR(17),
                   D_ENTRANCE               = to_date(DATAARR(18),
                                                      'yyyymmddhh24miss'),
                   D_GRADUATION             = to_date(DATAARR(19),
                                                      'yyyymmddhh24miss'),
                   N_HOBBIES                = DATAARR(20),
                   V_GRADES                 = DATAARR(21),
                   D_PROMOTION              = to_date(DATAARR(22),
                                                      'yyyymmddhh24miss'),
                   N_EDUCATION              = DATAARR(23),
                   V_BANK_CARD_NUMBER       = DATAARR(24),
                   V_ACCUMULATION_FUND_TYPE = DATAARR(25),
                   V_OPENING_BANK           = DATAARR(26),
                   V_REMARK                 = DATAARR(27),
                   N_SOCIAL_SECURITY_TYPE   = DATAARR(28),
                   D_LEAVE                  = DATAARR(29),
                   --N_WORK_NUM               = DATAARR(30),
                   --N_WORK_NUM_OLD           = DATAARR(31),
                   C_LABOR_REF     = DATAARR(32),
                   N_STATUS        = DATAARR(33),
                   C_LK_COMPANY_ID = DATAARR(34)
             WHERE C_USER_ID = P_ID;
            RETURN 0;
        
        EXCEPTION
            WHEN OTHERS THEN
                ErrMsg := 'UPDATE_EMPLOYEE: ' || sqlcode || ',' ||
                          sqlerrm;
                raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                        ErrMsg,
                                        false);
        END;
        ROLLBACK;
    
        RETURN - 1;
    END;

    FUNCTION Get_Employee(Employee_Id     IN VARCHAR2,
                          OperationUserId IN VARCHAR2,
                          CUR_DATA        OUT SYS_REFCURSOR,
                          ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT emp.*, usr.v_user_name
              FROM lcbase.TEMP_EMPLOYEES_INFO emp,
                   lcbase.T_USER              usr
             WHERE emp.c_user_id = usr.c_user_id
               and emp.c_user_id = Employee_Id;
    
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询临时员工表数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
        
            RETURN - 1;
    END;

    FUNCTION Get_EmployeeByLoginNum(LoginNumber IN VARCHAR2,
                                    CUR_DATA    OUT SYS_REFCURSOR,
                                    ErrMsg      OUT VARCHAR2)
        RETURN NUMBER IS
        UserId char(32);
    BEGIN
        select c_user_id
          into UserId
          from lcbase.TEMP_EMPLOYEES_INFO
         WHERE n_login_num = LoginNumber;
    
        OPEN CUR_DATA FOR
            SELECT emp.*, usr.v_user_name
              FROM lcbase.TEMP_EMPLOYEES_INFO emp,
                   lcbase.T_USER              usr
             WHERE emp.c_user_id = usr.c_user_id
               and emp.n_login_num = LoginNumber;
    
        /*  pkg_common.InsertOperationLog(UserId,
        'TEMP_EMPLOYEES_INFO',
        1,
        1);*/
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询临时员工表数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            if UserID is not null then
                pkg_common.InsertOperationLog(UserId,
                                              'TEMP_EMPLOYEES_INFO',
                                              1,
                                              0);
            end if;
            RETURN - 1;
    END;

    FUNCTION Check_EmployeeLoginNum(LoginNumber IN VARCHAR2,
                                    ErrMsg      OUT VARCHAR2)
        RETURN NUMBER IS
        UserId char(32);
    BEGIN
        select c_user_id
          into UserId
          from lcbase.TEMP_EMPLOYEES_INFO
         WHERE n_login_num = LoginNumber;
        if UserId is not null then
            pkg_common.InsertOperationLog(UserId,
                                          'TEMP_EMPLOYEES_INFO',
                                          1,
                                          1);
            return 0;
        end if;
        ErrMsg := '手机号' || LoginNumber || '无效.';
        return - 1;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '校验临时员工表数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            if UserID is not null then
                pkg_common.InsertOperationLog(UserId,
                                              'TEMP_EMPLOYEES_INFO',
                                              1,
                                              0);
            end if;
            RETURN - 1;
    END;

    FUNCTION Update_EmployeePic(Employee_Id  IN VARCHAR2,
                                Pic_Type     IN NUMBER,
                                Employee_Pic IN VARCHAR2,
                                ErrMsg       OUT VARCHAR2)
        RETURN NUMBER IS
        P_CNT    NUMBER(3) := 0;
        P_OPTYPE NUMBER(1) := 1;
    BEGIN
        BEGIN
            SELECT count(*)
              into P_CNT
              FROM LCBASE.t_User_Pic
             WHERE c_user_id = Employee_Id
               and n_pic_type = Pic_Type;
        
            IF P_CNT = 0 THEN
                P_OPTYPE := 2;
            ELSE
                P_OPTYPE := 3;
            END IF;
        
            IF P_CNT = 0 THEN
                insert into lcbase.t_user_pic
                values
                    (Employee_Id, Pic_Type, Employee_Pic);
            ELSE
                update lcbase.t_user_pic
                   set c_pic_addr = Employee_Pic
                 where c_user_id = Employee_Id
                   and n_pic_type = Pic_Type;
            END IF;
        
            --COMMIT;
            /*
            pkg_common.InsertOperationLog(Employee_Id,
                                          't_user_pic',
                                          P_OPTYPE,
                                          1);*/
            RETURN 0;
        EXCEPTION
            WHEN OTHERS THEN
                ErrMsg := 'Update_EmployeePic: ' || sqlcode || ',' ||
                          sqlerrm;
                raise_application_error(lcoa.pkg_common.g_errcode_exception,
                                        ErrMsg,
                                        false);
            
        END;
        ROLLBACK;
        RETURN - 1;
    END;

    FUNCTION Get_EmployeePic(Employee_Id IN VARCHAR2,
                             CUR_DATA    OUT SYS_REFCURSOR,
                             ErrMsg      OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT *
              FROM lcbase.t_user_pic
             WHERE c_user_id = Employee_Id;
    
        pkg_common.InsertOperationLog(Employee_Id,
                                      't_user_pic',
                                      1,
                                      1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询临时员工图片数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            /* pkg_common.InsertOperationLog(Employee_Id,
            't_user_pic',
            1,
            0);*/
            RETURN - 1;
    END;

    FUNCTION Delete_EmployeePic(Employee_Id IN VARCHAR2,
                                PicType     IN NUMBER,
                                PicAddr     IN VARCHAR2,
                                ErrMsg      OUT VARCHAR2)
        RETURN NUMBER IS
        P_CNT NUMBER(3) := 0;
    BEGIN
    
        SELECT count(*)
          into P_CNT
          FROM LCBASE.t_User_Pic t
         where t.c_user_id = Employee_Id
           and t.n_pic_type = PicType
           and t.c_pic_addr = PicAddr;
    
        IF P_CNT = 0 THEN
            ErrMsg := '删除临时员工图片数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            pkg_common.InsertOperationLog(Employee_Id,
                                          't_user_pic',
                                          4,
                                          0);
            RETURN - 1;
        end if;
    
        delete from lcbase.t_user_pic t
         where t.c_user_id = Employee_Id
           and t.n_pic_type = PicType
           and t.c_pic_addr = PicAddr;
    
        COMMIT;
    
        pkg_common.InsertOperationLog(Employee_Id,
                                      't_user_pic',
                                      4,
                                      1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '删除临时员工图片数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            pkg_common.InsertOperationLog(Employee_Id,
                                          't_user_pic',
                                          4,
                                          0);
            RETURN - 1;
    END;

    --判断身份证号是否为空
    function IS_ID_CARD_EXISTS(ID_CARD_NUMBER in varchar2,
                               user_id        in char,
                               ErrMsg         out varchar2)
        return number is
        counts integer;
    begin
        SELECT count(*)
          into counts
          FROM LCBASE.T_EMPLOYEES_INFO
         WHERE C_ID_CARD_NUMBER = ID_CARD_NUMBER
           AND C_USER_ID <> user_id;
        if counts > 0 then
        
            ErrMsg := '身份证号重复!';
            return - 1;
        else
            return 0;
        
        end if;
    
    end;

    --判断身份证号是否为空-INSERT 
    function IS_ID_CARD_EXISTS_INSERT(ID_CARD_NUMBER in varchar2,
                                      ErrMsg         out varchar2)
        return number is
        counts integer;
    begin
        SELECT count(*)
          into counts
          FROM LCBASE.T_EMPLOYEES_INFO
         WHERE C_ID_CARD_NUMBER = ID_CARD_NUMBER;
    
        if counts > 0 then
        
            ErrMsg := '身份证号重复!';
            return - 1;
        else
            return 0;
        
        end if;
    
    end;

    --判断银行卡号
    function IS_BANK_CARD_EXISTS(BANK_CARD_NUMBER in varchar2,
                                 user_id          in char,
                                 ErrMsg           out varchar2)
        return number is
        counts integer;
    begin
        SELECT count(*)
          into counts
          FROM LCBASE.T_EMPLOYEES_INFO
         WHERE V_BANK_CARD_NUMBER = BANK_CARD_NUMBER
           AND C_USER_ID <> user_id;
        if counts > 0 then
        
            ErrMsg := '银行卡号重复!';
            return - 1;
        end if;
        return 0;
    end;

    --判断银行卡号_inset
    function IS_BANK_CARD_EXISTS_INSERT(BANK_CARD_NUMBER in varchar2,
                                        ErrMsg           out varchar2)
        return number is
        counts integer;
    begin
        SELECT count(*)
          into counts
          FROM LCBASE.T_EMPLOYEES_INFO
         WHERE V_BANK_CARD_NUMBER = BANK_CARD_NUMBER;
        if counts > 0 then
        
            ErrMsg := '银行卡号重复!';
            return - 1;
        end if;
        return 0;
    
    end;

end PKG_TEMPEMPLOYEE;
/

