create package PKG_EXT_SIGNATURE_INFO is
  function save_signature_info(DataInfo        in varchar2,
                               OperationUserId IN VARCHAR2,
                               UserId          OUT VARCHAR2,
                               ErrMsg          OUT VARCHAR2) return number;
end;
/

