create package body PKG_EXT_USER_INFO is
  FUNCTION OAGetUserInfo(UserID   IN VARCHAR2,
                         User_CUR OUT sys_refcursor,
                         ErrMsg   OUT VARCHAR2) return number as
    n_optype   number(1);
    n_result   number(6) := 0;
    time_start timestamp;
    time_end   timestamp;
    n_duration number(10);
    n_status   number(1) := 0;
  begin
    time_start := systimestamp;
    begin
      n_optype := 1;
      n_result := lcoa.pkg_ins_user_info.OAGetUserInfo(UserID,
                                                  User_CUR,
                                                  ErrMsg);
    EXCEPTION
      WHEN OTHERS THEN
        ErrMsg   := 'OAGetUserInfo: ' || pkg_common.g_errcode_exception || ',' ||
                    SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := pkg_common.g_errcode_exception;
    end;
    time_end   := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    if (n_result = 0) then
      n_status := 0;
    else
      n_status := 1;
    end if;
    PKG_COMMON.InsertOperationLog(UserID,
                                  'OAGetUserInfo',
                                  n_optype,
                                  n_status,
                                  n_duration);
  
    if n_result = pkg_common.g_errcode_exception then
      RAISE_APPLICATION_ERROR(pkg_common.g_errcode_exception,
                              errmsg,
                              false);
    else
      return n_result;
    end if;
  end;
end PKG_EXT_USER_INFO;
/

