create package PKG_ztest_info as
    --判断是否有bp
    function is_oraganization_exits(newOrgnizationId char,
                                    ErrMsg           OUT VARCHAR2)
        return number;

end PKG_ztest_info;
/

