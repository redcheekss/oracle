create package PKG_USER_RESTTIME is

  -- Author  : USER
  -- Created : 2020/4/12 16:43:10
  -- Purpose : TEMP

  -- Public type declarations
  --type <TypeName> is <Datatype>;

  -- Public constant declarations
  --<ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  --<VariableName> <Datatype>;

  -- Public function and procedure declarations
  --function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;
  --获取假期时长
  --传入参数：用户Id，起始时间，结束时间
  --传出参数：天数，时长
  --返回值：0成功，非0失败
  function getHolidayDuration(cUserId    in varchar2,
                              dStartTime in Date,
                              dEndTime   in Date,
                              nDays      out number,
                              nTimes     out number,
                              vErrMsg    out varchar2) return number;
  --获取用户当日上班时间
  --传入参数：用户Id
  --传出参数：当日上班时间
  --返回值：无返回，如有错误则直接抛异常
  procedure getTodayOndutyTime(cUserId in varchar2, dOndutyTime out Date);
  --获取两个日期范围内有多少个休息日
  --传入参数：起始日期、结束日期
  --传出参数：休息日数量
  --返回值：无返回，如有错误则直接抛异常
  procedure getRestDays(dStartTime in Date,
                        dEndTime   in Date,
                        nRestDays  out number);
  --判断某日期是否为乐卡周末工作日
  --传入参数：待判断日期
  --传出参数：无
  --返回值：0乐卡正常工作日，1表示为乐卡周末工作日，2乐卡休息日
  function checkLecarWorkRestDay(dCheckDay in Date) return number;
  --获取起始日期请假时长
  --传入参数：起始日期
  --传出参数：请假时长
  --返回值：无返回，如有错误则直接抛异常
  procedure getFirstDayTimes(cUserId       in varchar2,
                             dFirstDayTime in Date,
                             dLastDayTime  in Date,
                             nRestDays     out number,
                             nRestTimes    out number);
  --获取结束日期请假时长
  --传入参数：结束日期
  --传出参数：请假时长
  --返回值：无返回，如有错误则直接抛异常
  procedure getLastDayTimes(cUserId      in varchar2,
                            dLastDayTime in Date,
                            nRestDays    out number,
                            nRestTimes   out number);
  --计算乐卡周末工作日请假时长
  --传入参数：起始时间、结束时间
  --传出参数：请假时长
  --返回值：无返回，如有错误则直接抛异常
  --因为乐卡周末工作日时间固定为10-11：30 14:30-18:00
  procedure calLecarWorkDayRestTimes(dStartTime in Date,
                                     dEndTime   in Date,
                                     nRestTimes out number);

  --计算乐卡正常工作日请假时长
  --传入参数：工作起始时间、工作结束时间，请假起始时间、请假结束时间
  --传出参数：请假时长
  --返回值：无返回，如有错误则直接抛异常
  --因为乐卡正常工作日时间弹性为9-10~18-19
  procedure calWorkDayRestTimes(dStartWorkTime in Date,
                                dEndWorkTime   in Date,
                                dStartTime     in Date,
                                dEndTime       in Date,
                                nRestTimes     out number);

  --组织工作日弹性工作起始、结束时间
  --传入参数：用户ID、请假起始时间
  --传出参数：工作起始时间、工作结束时间
  --返回值：无返回，如有错误则直接抛异常
  procedure buildWorkDayWorkTime(cUserId        in varchar2,
                                 dWorkTime      in Date,
                                 dStartWorkTime out Date,
                                 dEndWorkTime   out Date);

end PKG_USER_RESTTIME;
/

