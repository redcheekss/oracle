create package body PKG_DMD_APPLY is
  --数据修改新增
  FUNCTION INSERT_OADMDAPPLY(OADMDAPPLY      IN VARCHAR2,
                             enclosure_LIST  in arr_longstr,
                             OperationUserID IN VARCHAR2,
                             TodoSender_Cur  out sys_refcursor,
                             ErrMsg          OUT VARCHAR2) RETURN NUMBER is
    DATAARR       PKG_COMMON.ARR_LONGSTR;
    P_ID          CHAR(32);
    department_id CHAR(32);
    user_name     varchar2(50);
    todoTitle     varchar2(500);
    commNO        VARCHAR(90);
  BEGIN
  
    DATAARR := PKG_COMMON.Split(OADMDAPPLY, '^');
    P_ID    := LOWER(SYS_GUID());
    commNO  := LCOA.pkg_common.getflownumber('DM', 4);
    select U.C_ORGANIZATION_ID
      into department_id
      from LCBASE.T_ZIP_USER U
     WHERE U.C_USER_ID = OperationUserID
       AND U.D_ENDDATE > SYSDATE;
  
    select U.V_PET_NAME
      into user_name
      from LCBASE.T_ZIP_USER U
     WHERE U.C_USER_ID = OperationUserID
       AND U.D_ENDDATE > SYSDATE;
  
    IF department_id is null THEN
      ErrMsg := '该用户没有部门';
      RETURN - 1;
    END IF;
  
    insert into oa_afw_dmd_apply
      (c_datamodify_apply_id,
       n_business_type,
       v_modify_content,
       n_status,
       n_deleted,
       c_input_user_id,
       d_input_date,
       c_department_id,
       V_DATAMODIFY_NO)
    values
      (P_ID,
       DATAARR(2),
       DATAARR(3),
       0,
       0,
       OperationUserID,
       sysdate,
       department_id,
       commNO);
    IF enclosure_LIST IS NOT NULL THEN
    
      FOR i IN enclosure_LIST.FIRST .. enclosure_LIST.LAST LOOP
        insert into t_lk_attachment
          (c_img_id,
           c_business_id,
           v_image_url,
           d_image_date,
           n_isdel_state,
           v_input_user_name,
           d_input_time,
           n_operation_type,
           c_input_user_id)
        values
          (LOWER(SYS_GUID()),
           P_ID,
           enclosure_LIST(i),
           sysdate,
           0,
           user_name,
           sysdate,
           6,
           OperationUserID);
      END LOOP;
    END if;
    todoTitle := user_name || '的数据修改申请单!';
    lcoa.pkg_ins_afw_workflow.Create_Approval_By_Id(P_ID, 16);
    lcoa.pkg_ins_afw_workflow.Create_Next_Approval_Todo(P_ID,
                                                        todoTitle,
                                                        TodoSender_Cur);
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := '数据修改申请单保存失败,' || SQLERRM;
      RETURN - 1;
  END;
  --数据申请撤回
  FUNCTION UPDATE_OADMDAPPLY(datamodify_apply_id IN VARCHAR2,
                             OperationUserID     IN VARCHAR2,
                             ErrMsg              OUT VARCHAR2) RETURN NUMBER is
    applyType      number(1);
    TodoTitle      varchar(50);
    user_name      varchar2(50);
    TodoSender_Cur sys_refcursor;
    resultNum      number(1);
  BEGIN
    select a.n_status
      into applyType
      from oa_afw_dmd_apply a
     where a.c_datamodify_apply_id = datamodify_apply_id;
    if applyType <> -2 and applyType <> -1 then
      update oa_afw_dmd_apply
         set n_status         = -1,
             c_update_user_id = OperationUserID,
             d_update_date    = sysdate
       where c_datamodify_apply_id = datamodify_apply_id;
    
      select U.V_USER_NAME
        INTO user_name
        from LCBASE.t_Zip_User U
       WHERE U.C_USER_ID = OperationUserID
         AND U.D_ENDDATE > SYSDATE;
      TodoTitle := user_name || '已撤回了数据修改申请';
      for c in (select a.c_todo_user_id
                  from oa_tdo_todo_info a
                 where a.c_todo_data_id in
                       (select tt.c_data_id
                          from Oa_Afw_Workflow_Approval_Flow tt
                         where tt.c_workflow_id = datamodify_apply_id)
                   and a.n_status = 0) loop
        resultNum := Create_Approval_MESSAGE(datamodify_apply_id,
                                             TodoTitle,
                                             c.c_todo_user_id,
                                             16,
                                             TodoSender_Cur,
                                             ErrMsg);
        update oa_tdo_todo_info a
           set a.n_status = 1
         where a.c_todo_data_id in
               (select tt.c_data_id
                  from Oa_Afw_Workflow_Approval_Flow tt
                 where tt.c_workflow_id = datamodify_apply_id)
           and a.n_status = 0;
      end loop;
    end IF;
  
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := '数据修改申请单保存失败,' || SQLERRM;
      RETURN - 1;
  END;
  --消息发送
  FUNCTION INSER_OADMDCOMMENT(COMMEN                IN VARCHAR2,
                              OperationUserID       IN VARCHAR2,
                              messageReceiverUserID in VARCHAR2,
                              datamodify_comment_id in VARCHAR2,
                              datamodify_apply_id   in VARCHAR2,
                              TodoSender_Cur        out sys_refcursor,
                              ErrMsg                OUT VARCHAR2)
    RETURN NUMBER IS
    DATAARR   PKG_COMMON.ARR_LONGSTR;
    P_ID      CHAR(32);
    resultNum number(1);
    UserID    CHAR(32);
  BEGIN
    DATAARR := PKG_COMMON.Split(COMMEN, '^');
    P_ID    := LOWER(SYS_GUID());
    UserID  := messageReceiverUserID;
    if UserID is null then
      select t.c_input_user_id
        into UserID
        from Oa_Afw_Dmd_Apply t
       where t.c_datamodify_apply_id = datamodify_apply_id;
    
    end if;
    if DATAARR(1) is null then
      RETURN 0;
    end IF;
    insert into oa_afw_dmd_comment
      (c_datamodify_comment_id,
       c_input_user_id,
       d_input_date,
       C_TO_REPLY_USER_ID,
       v_message,
       c_parent_datamodify_comment_id,
       n_message_type,
       c_datamodify_apply_id)
    values
      (P_ID,
       OperationUserID,
       SYSDATE,
       UserID,
       DATAARR(1),
       datamodify_comment_id,
       DATAARR(2),
       datamodify_apply_id);
    if UserID <> OperationUserID then
      resultNum := Create_Approval_MESSAGE(datamodify_apply_id,
                                           '您有一条数据修改留言',
                                           UserID,
                                           54,
                                           TodoSender_Cur,
                                           ErrMsg);
    end IF;
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := '消息回复失败,' || SQLERRM;
      RETURN - 1;
  END;
  FUNCTION SELECT_OADMDAPPLY(datamodify_apply_id IN VARCHAR2,
                             OperationUserID     IN VARCHAR2,
                             TodoSender_Cur      out sys_refcursor,
                             enclosure           out sys_refcursor,
                             CUR_FLOW            out sys_refcursor,
                             ErrMsg              OUT VARCHAR2) RETURN NUMBER IS
    approdate date;
    apply_id  VARCHAR2(50);
    role_type number(1);
    countNum  number(1);
  BEGIN
  
    if datamodify_apply_id is not null then
    
      SELECT count(1)
        into countNum
        from oa_afw_dmd_apply a
       where a.c_datamodify_apply_id = datamodify_apply_id;
      if countNum <= 0 then
        RETURN 1;
      end IF;
      select a.d_input_date
        into approdate
        from oa_afw_dmd_apply a
       where a.c_datamodify_apply_id = datamodify_apply_id;
    
      OPEN TodoSender_Cur FOR -- 查询审批单信息
        select dmd.c_datamodify_apply_id,
               dmd.n_business_type,
               dmd.v_modify_content,
               dmd.d_input_date,
               dmd.c_department_id,
               dmd.v_datamodify_no,
               u.c_user_id as C_INPUT_USER_ID,
               u.v_user_name as C_INPUT_USER_NAME,
               u.v_user_name,
               u.c_user_id,
               E.V_USER_TITLE,
               o.v_organization_name,
               dmd.n_status,
               dmd.n_colse_status
          from OA_AFW_dmd_apply dmd
          left join LCBASE.T_ZIP_USER u
            on dmd.c_input_user_id = u.c_user_id
           and u.d_enddate > sysdate
          left join LCBASE.T_EMPLOYEES_INFO e
            on dmd.c_input_user_id = e.c_user_id
          LEFT JOIN lcbase.t_zip_organization o
            on dmd.c_department_id = o.c_organization_id
           and o.d_enddate > sysdate
         where dmd.n_deleted = 0
           and dmd.c_datamodify_apply_id = datamodify_apply_id;
      OPEN enclosure FOR --查询附件信息
        select c_img_id          as C_FILE_ID,
               c_business_id     as C_FORIGN_ID,
               n_image_size,
               n_image_type      as N_FILE_TYPE,
               v_image_url       as V_FILE_PATH,
               d_image_date,
               n_isdel_state,
               v_input_user_name,
               d_input_time      as D_UPLOAD_TIME,
               v_image_name      as V_FILE_NAME,
               n_operation_type,
               c_input_user_id,
               v_hash_content
          from t_lk_attachment
         where c_business_id = datamodify_apply_id;
      open CUR_FLOW for --查询申请流程
        select '' as C_DATA_ID,
               16 as N_WORKFLOW_TYPE,
               tt.c_datamodify_apply_id as C_WORKFLOW_ID,
               0 as N_APPROVAL_ORDER,
               1 as N_APPROVAL_MODEL,
               tt.c_input_user_id as C_APPROVAL_USER_ID,
               u.v_user_name as V_APPROVAL_USER_NAME,
               '申请人' as V_APPROVAL_USER_TITLE,
               1 as N_APPROVAL_STATUS,
               tt.d_input_date as D_APPROVAL_TIME,
               '' as V_APPROVAL_REMARK,
               0 as N_SKIP_FLAG,
               1 as N_APPROVAL_SORT,
               u.v_headpic_aly
          from OA_AFW_DMD_APPLY tt
          left join LCBASE.T_ZIP_USER u
            on tt.c_input_user_id = u.c_user_id
           and u.d_enddate > sysdate
         where tt.c_datamodify_apply_id = datamodify_apply_id
        union all
        select f.*, u.v_headpic_aly
          from LCOA.Oa_Afw_Workflow_Approval_Flow f
          left join lcbase.t_zip_user u
            on u.c_user_id = f.c_approval_user_id
           and trunc(approdate) >= trunc(u.d_startdate)
           and trunc(approdate) < trunc(u.d_enddate)
         where f.c_workflow_id = datamodify_apply_id;
    
    else
      SELECT count(1)
        into countNum
        from (select decode(ro.role_type, 216, 0, 215, 1, 3) as role_type,
                     ro.role_name
                from Oa_Aut_User_Role a
                left join Oa_Aut_Role ro
                  on a.c_role_id = ro.c_role_id
               where ro.role_type in (215, 216)
                 and a.c_user_id = OperationUserID
               order by ro.role_type desc) T
       where rownum = 1;
      if countNum <= 0 then
        RETURN 1;
      end IF;
    
      select t.role_type
        into role_type
        from (select decode(ro.role_type, 216, 0, 215, 1, 3) as role_type,
                     ro.role_name
                from Oa_Aut_User_Role a
                left join Oa_Aut_Role ro
                  on a.c_role_id = ro.c_role_id
               where ro.role_type in (215, 216)
                 and a.c_user_id = OperationUserID
               order by ro.role_type desc) T
       where rownum = 1;
      if role_type = 0 then
        SELECT count(1)
          into countNum
          from (select c_datamodify_apply_id
                  from oa_afw_dmd_apply
                 where (N_STATUS = 2 or
                       (N_STATUS = 5 and C_HANDLE_USER_ID = OperationUserID))
                 order by D_INPUT_DATE desc) T
         where rownum = 1;
        if countNum <= 0 then
          RETURN 1;
        end IF;
        SELECT t.c_datamodify_apply_id
          into apply_id
          from (select c_datamodify_apply_id
                  from oa_afw_dmd_apply
                 where (N_STATUS = 2 or
                       (N_STATUS = 5 and C_HANDLE_USER_ID = OperationUserID))
                 order by D_INPUT_DATE desc) T
         where rownum = 1;
        select a.d_input_date
          into approdate
          from oa_afw_dmd_apply a
         where a.c_datamodify_apply_id = apply_id;
      
        OPEN TodoSender_Cur FOR -- 查询审批信息
          select dmd.c_datamodify_apply_id,
                 dmd.n_business_type,
                 dmd.v_modify_content,
                 dmd.d_input_date,
                 dmd.c_department_id,
                 dmd.v_datamodify_no,
                 u.v_user_name,
                 u.c_user_id,
                 E.V_USER_TITLE,
                 o.v_organization_name,
                 dmd.n_status,
                 dmd.n_colse_status
            from OA_AFW_dmd_apply dmd
            left join LCBASE.T_ZIP_USER u
              on dmd.c_input_user_id = u.c_user_id
             and u.d_enddate > sysdate
            left join LCBASE.T_EMPLOYEES_INFO e
              on dmd.c_input_user_id = e.c_user_id
            LEFT JOIN lcbase.t_zip_organization o
              on dmd.c_department_id = o.c_organization_id
             and o.d_enddate > sysdate
           where dmd.c_datamodify_apply_id = apply_id;
      
        OPEN enclosure FOR --查询附件信息
          select c_img_id          as C_FILE_ID,
                 c_business_id     as C_FORIGN_ID,
                 n_image_size,
                 n_image_type      as N_FILE_TYPE,
                 v_image_url       as V_FILE_PATH,
                 d_image_date,
                 n_isdel_state,
                 v_input_user_name,
                 d_input_time      as D_UPLOAD_TIME,
                 v_image_name      as V_FILE_NAME,
                 n_operation_type,
                 c_input_user_id,
                 v_hash_content
            from t_lk_attachment
          
           where c_business_id = apply_id;
        open CUR_FLOW for --查询申请流程
          select '' as C_DATA_ID,
                 16 as N_WORKFLOW_TYPE,
                 tt.c_datamodify_apply_id as C_WORKFLOW_ID,
                 0 as N_APPROVAL_ORDER,
                 1 as N_APPROVAL_MODEL,
                 tt.c_input_user_id as C_APPROVAL_USER_ID,
                 u.v_user_name as V_APPROVAL_USER_NAME,
                 '申请人' as V_APPROVAL_USER_TITLE,
                 1 as N_APPROVAL_STATUS,
                 tt.d_input_date as D_APPROVAL_TIME,
                 '' as V_APPROVAL_REMARK,
                 0 as N_SKIP_FLAG,
                 1 as N_APPROVAL_SORT,
                 u.v_headpic_aly
            from OA_AFW_DMD_APPLY tt
            left join LCBASE.T_ZIP_USER u
              on tt.c_input_user_id = u.c_user_id
             and u.d_enddate > sysdate
           where tt.c_datamodify_apply_id = apply_id
          union all
          select f.*, u.v_headpic_aly
            from LCOA.Oa_Afw_Workflow_Approval_Flow f
            left join lcbase.t_zip_user u
              on u.c_user_id = f.c_approval_user_id
             and trunc(approdate) >= trunc(u.d_startdate)
             and trunc(approdate) < trunc(u.d_enddate)
           where f.c_workflow_id = apply_id;
        RETURN 0;
      end IF;
      if role_type = 1 then
        SELECT count(1)
          into countNum
          from (select c_datamodify_apply_id
                  from oa_afw_dmd_apply
                 where (N_STATUS = 5 and C_HANDLE_USER_ID = OperationUserID)
                 order by D_INPUT_DATE desc) T
         where rownum = 1;
        if countNum <= 0 then
          RETURN 1;
        end IF;
        SELECT t.c_datamodify_apply_id
          into apply_id
          from (select c_datamodify_apply_id
                  from oa_afw_dmd_apply
                 where (N_STATUS = 5 and C_HANDLE_USER_ID = OperationUserID)
                 order by D_INPUT_DATE desc) T
         where rownum = 1;
        select a.d_input_date
          into approdate
          from oa_afw_dmd_apply a
         where a.c_datamodify_apply_id = apply_id;
      
        OPEN TodoSender_Cur FOR -- 查询审批信息
          select dmd.c_datamodify_apply_id,
                 dmd.n_business_type,
                 dmd.v_modify_content,
                 dmd.d_input_date,
                 dmd.c_department_id,
                 dmd.v_datamodify_no,
                 u.v_user_name,
                 u.c_user_id,
                 E.V_USER_TITLE,
                 o.v_organization_name,
                 dmd.n_status,
                 dmd.n_colse_status
            from OA_AFW_dmd_apply dmd
            left join LCBASE.T_ZIP_USER u
              on dmd.c_input_user_id = u.c_user_id
             and u.d_enddate > sysdate
            left join LCBASE.T_EMPLOYEES_INFO e
              on dmd.c_input_user_id = e.c_user_id
            LEFT JOIN lcbase.t_zip_organization o
              on dmd.c_department_id = o.c_organization_id
             and o.d_enddate > sysdate
           where dmd.c_datamodify_apply_id = apply_id;
      
        OPEN enclosure FOR --查询附件信息
          select c_img_id          as C_FILE_ID,
                 c_business_id     as C_FORIGN_ID,
                 n_image_size,
                 n_image_type      as N_FILE_TYPE,
                 v_image_url       as V_FILE_PATH,
                 d_image_date,
                 n_isdel_state,
                 v_input_user_name,
                 d_input_time      as D_UPLOAD_TIME,
                 v_image_name      as V_FILE_NAME,
                 n_operation_type,
                 c_input_user_id,
                 v_hash_content
            from t_lk_attachment
          
           where c_business_id = apply_id;
        open CUR_FLOW for --查询申请流程
          select '' as C_DATA_ID,
                 16 as N_WORKFLOW_TYPE,
                 tt.c_datamodify_apply_id as C_WORKFLOW_ID,
                 0 as N_APPROVAL_ORDER,
                 1 as N_APPROVAL_MODEL,
                 tt.c_input_user_id as C_APPROVAL_USER_ID,
                 u.v_user_name as V_APPROVAL_USER_NAME,
                 '申请人' as V_APPROVAL_USER_TITLE,
                 1 as N_APPROVAL_STATUS,
                 tt.d_input_date as D_APPROVAL_TIME,
                 '' as V_APPROVAL_REMARK,
                 0 as N_SKIP_FLAG,
                 1 as N_APPROVAL_SORT,
                 u.v_headpic_aly
            from OA_AFW_DMD_APPLY tt
            left join LCBASE.T_ZIP_USER u
              on tt.c_input_user_id = u.c_user_id
             and u.d_enddate > sysdate
          
           where tt.c_datamodify_apply_id = apply_id
          union all
          select f.*, u.v_headpic_aly
            from LCOA.Oa_Afw_Workflow_Approval_Flow f
            left join lcbase.t_zip_user u
              on u.c_user_id = f.c_approval_user_id
             and trunc(approdate) >= trunc(u.d_startdate)
             and trunc(approdate) < trunc(u.d_enddate)
           where f.c_workflow_id = apply_id;
        RETURN 0;
      end IF;
      SELECT count(1)
        into countNum
        from (select c_datamodify_apply_id
                from oa_afw_dmd_apply
               order by D_INPUT_DATE desc) T
       where rownum = 1;
      if countNum <= 0 then
        RETURN 1;
      end IF;
      SELECT t.c_datamodify_apply_id
        into apply_id
        from (select c_datamodify_apply_id
                from oa_afw_dmd_apply
               order by D_INPUT_DATE desc) T
       where rownum = 1;
      select a.d_input_date
        into approdate
        from oa_afw_dmd_apply a
       where a.c_datamodify_apply_id = apply_id;
    
      OPEN TodoSender_Cur FOR -- 查询审批信息
        SELECT *
          from (select dmd.c_datamodify_apply_id,
                       dmd.n_business_type,
                       dmd.v_modify_content,
                       dmd.d_input_date,
                       dmd.c_department_id,
                       dmd.v_datamodify_no,
                       u.v_user_name,
                       u.c_user_id,
                       E.V_USER_TITLE,
                       o.v_organization_name,
                       dmd.n_status,
                       dmd.n_colse_status
                  from OA_AFW_dmd_apply dmd
                  left join LCBASE.T_ZIP_USER u
                    on dmd.c_input_user_id = u.c_user_id
                   and u.d_enddate > sysdate
                  left join LCBASE.T_EMPLOYEES_INFO e
                    on dmd.c_input_user_id = e.c_user_id
                  LEFT JOIN lcbase.t_zip_organization o
                    on dmd.c_department_id = o.c_organization_id
                   and o.d_enddate > sysdate
                 where dmd.n_deleted = 0
                 order by DMD.d_input_date DESC) T
         where rownum = 1;
    
      OPEN enclosure FOR --查询附件信息
        select c_img_id          as C_FILE_ID,
               c_business_id     as C_FORIGN_ID,
               n_image_size,
               n_image_type      as N_FILE_TYPE,
               v_image_url       as V_FILE_PATH,
               d_image_date,
               n_isdel_state,
               v_input_user_name,
               d_input_time      as D_UPLOAD_TIME,
               v_image_name      as V_FILE_NAME,
               n_operation_type,
               c_input_user_id,
               v_hash_content
          from t_lk_attachment
        
         where c_business_id = apply_id;
      open CUR_FLOW for --查询申请流程
        select '' as C_DATA_ID,
               16 as N_WORKFLOW_TYPE,
               tt.c_datamodify_apply_id as C_WORKFLOW_ID,
               0 as N_APPROVAL_ORDER,
               1 as N_APPROVAL_MODEL,
               tt.c_input_user_id as C_APPROVAL_USER_ID,
               u.v_user_name as V_APPROVAL_USER_NAME,
               '申请人' as V_APPROVAL_USER_TITLE,
               1 as N_APPROVAL_STATUS,
               tt.d_input_date as D_APPROVAL_TIME,
               '' as V_APPROVAL_REMARK,
               0 as N_SKIP_FLAG,
               1 as N_APPROVAL_SORT,
               u.v_headpic_aly
          from OA_AFW_DMD_APPLY tt
          left join LCBASE.T_ZIP_USER u
            on tt.c_input_user_id = u.c_user_id
           and u.d_enddate > sysdate
        
         where tt.c_datamodify_apply_id = apply_id
        union all
        select f.*, u.v_headpic_aly
          from LCOA.Oa_Afw_Workflow_Approval_Flow f
          left join lcbase.t_zip_user u
            on u.c_user_id = f.c_approval_user_id
           and trunc(approdate) >= trunc(u.d_startdate)
           and trunc(approdate) < trunc(u.d_enddate)
         where f.c_workflow_id = apply_id;
    end IF;
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := '暂无数据处理数据';
      RETURN - 1;
  END;

  FUNCTION SELETE_OADMDCOMMENT(datamodify_apply_id in VARCHAR2,
                               OperationUserID     IN VARCHAR2,
                               nPageSize           IN NUMBER, --每页显示大小>0
                               nPageCur            IN NUMBER, --当前页码[1-总页数]
                               CUR_DATA            OUT SYS_REFCURSOR, --oracle标准游标
                               nOutRows            OUT number, --输出总记录数
                               nOutPageCount       OUT number, --输出总页数
                               datamodify          out sys_refcursor,
                               ErrMsg              OUT VARCHAR2)
    RETURN NUMBER IS
    V_SQL     VARCHAR2(2000);
    resultNum number(1);
  BEGIN
    V_SQL     := ' SELECT t.*, u.v_user_name as INPUTUSERNAME, zip.v_user_name
        from oa_afw_dmd_comment t
        left join LCBASE.t_Zip_User u
          on t.c_input_user_id = u.c_user_id
         and u.d_enddate > t.d_input_date
         and u.d_startdate <= t.d_input_date
        left join LCBASE.t_Zip_User zip
          on t.c_input_user_id = zip.c_user_id
         and zip.d_enddate > t.d_input_date
         and zip.d_startdate <= t.d_input_date
       where t.c_datamodify_apply_id = ' || '''' ||
                 datamodify_apply_id || '''' || '
         and t.c_parent_datamodify_comment_id is null';
    resultNum := PKG_COMMON.GetPagingInfo(V_SQL,
                                          nPageSize,
                                          nPageCur,
                                          CUR_DATA,
                                          nOutRows,
                                          nOutPageCount);
  
    OPEN datamodify FOR
      SELECT t.*, u.v_user_name as INPUTUSERNAME, zip.v_user_name
        from oa_afw_dmd_comment t
        left join LCBASE.t_Zip_User u
          on t.c_input_user_id = u.c_user_id
         and u.d_enddate > t.d_input_date
         and u.d_startdate <= t.d_input_date
        left join LCBASE.t_Zip_User zip
          on t.c_input_user_id = zip.c_user_id
         and zip.d_enddate > t.d_input_date
         and zip.d_startdate <= t.d_input_date
       where t.c_datamodify_apply_id = datamodify_apply_id
         and t.c_parent_datamodify_comment_id is not null;
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := '暂无数据' || SQLERRM;
      RETURN - 1;
  END;
  --分发 
  FUNCTION distribute_OADMDAPPLY(datamodify_apply_id in VARCHAR2, --申请单ID
                                 OperationUserID     IN VARCHAR2,
                                 distributeUserID    IN VARCHAR2, --分发人ID
                                 distributeRemarks   IN VARCHAR2, --备注
                                 apply_id            out VARCHAR2,
                                 TodoSender_Cur      out sys_refcursor,
                                 ErrMsg              OUT VARCHAR2)
    RETURN NUMBER is
    applyType number(1);
    resultNum number(1);
    countNum  number;
    TodoTitle varchar2(50);
    user_name varchar2(50);
  BEGIN
  
    select a.n_status
      into applyType
      from oa_afw_dmd_apply a
     where a.c_datamodify_apply_id = datamodify_apply_id;
    if applyType <> 2 then
      ErrMsg := '分发错误' || '请刷新页面重新操作';
      RETURN - 1;
    end IF;
    update oa_afw_dmd_apply
       set c_handle_user_id   = distributeUserID,
           v_dispatch_memo    = distributeRemarks,
           d_dispatch_date    = sysdate,
           c_dispatch_user_id = OperationUserID,
           N_STATUS           = 5
     where c_datamodify_apply_id = datamodify_apply_id;
  
    select zip.v_user_name
      into user_name
      from oa_afw_dmd_apply a
      left join LCBASe.t_Zip_User zip
        on a.c_input_user_id = zip.c_user_id
       and zip.d_enddate > sysdate
     where a.c_datamodify_apply_id = datamodify_apply_id;
    TodoTitle := user_name || '的数据修改申请待处理';
    resultNum := Create_Approval_Todo(datamodify_apply_id,
                                      TodoTitle,
                                      distributeUserID,
                                      54,
                                      TodoSender_Cur,
                                      ErrMsg);
    update oa_tdo_todo_info a
       set a.n_status = 1
     where a.c_todo_user_id in
           (select ru.c_user_id
              from Oa_Aut_User_Role ru
             where ru.c_role_id in
                   (select r.c_role_id
                      from Oa_Aut_Role r
                     where r.role_type in (216)))
       and a.c_todo_data_id = datamodify_apply_id
       and a.n_status = 0
          
       and a.N_TODO_TYPE = 54;
    SELECT count(1)
      into countNum
      from (select c_datamodify_apply_id
              from oa_afw_dmd_apply
             where (N_STATUS = 2 or
                   (N_STATUS = 5 and C_HANDLE_USER_ID = OperationUserID))
             order by D_INPUT_DATE desc) T
     where rownum = 1;
    if countNum <= 0 then
      RETURN 0;
    end IF;
    SELECT t.c_datamodify_apply_id
      into apply_id
      from (select c_datamodify_apply_id
              from oa_afw_dmd_apply
             where (N_STATUS = 2 or
                   (N_STATUS = 5 and C_HANDLE_USER_ID = OperationUserID))
             order by D_INPUT_DATE desc) T
     where rownum = 1;
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := '分发失败' || SQLERRM;
      RETURN - 1;
  END;
  FUNCTION close_OADMDAPPLY(datamodify_apply_id in VARCHAR2,
                            OperationUserID     IN VARCHAR2,
                            closeStatus         IN NUMBER,
                            closeRemarks        IN VARCHAR2,
                            apply_id            out VARCHAR2,
                            ErrMsg              OUT VARCHAR2) RETURN NUMBER is
    TodoSender_Cur        sys_refcursor;
    applyType             number(1);
    resultNum             number(1);
    messageReceiverUserID char(32);
    countNum              number;
    userNmae              varchar(50);
    TodoTitle             varchar(50);
    user_name             varchar2(50);
    user_Id               varchar2(50);
  BEGIN
    select a.n_status
      into applyType
      from oa_afw_dmd_apply a
     where a.c_datamodify_apply_id = datamodify_apply_id;
    if applyType <> 2 and applyType <> 5 then
      ErrMsg := '关闭错误' || '请刷新页面重新操作';
      RETURN - 1;
    end IF;
  
    select a.c_input_user_id
      into messageReceiverUserID
      from oa_afw_dmd_apply a
     where a.c_datamodify_apply_id = datamodify_apply_id;
  
    update oa_afw_dmd_apply
       set N_STATUS                = 6,
           N_COLSE_STATUS          = closeStatus,
           V_CLOSE_MEMO            = closeRemarks,
           C_ACTUAL_HANDLE_USER_ID = OperationUserID,
           D_HANDLE_DATE           = sysdate
     where c_datamodify_apply_id = datamodify_apply_id;
    update oa_tdo_todo_info a
       set a.n_status = 1
     where a.c_todo_user_id = OperationUserID
       and a.c_todo_data_id = datamodify_apply_id;
  
    select a.v_user_name
      into userNmae
      from LCBASE.T_zip_USER a
     where a.c_user_id = OperationUserID
       and a.d_enddate >= sysdate;
  
    --处理成功发送消息-
    select a.c_input_user_id
      into user_Id
      from oa_afw_dmd_apply a
     where a.c_datamodify_apply_id = datamodify_apply_id;
    TodoTitle := userNmae || '的数据修改申请待处理';
    /*    resultNum := Create_Approval_MESSAGE(datamodify_apply_id,
    TodoTitle,
    user_Id,
    54,
    TodoSender_Cur,
    ErrMsg);*/
  
    resultNum := INSER_OADMDCOMMENT(closeRemarks || '^2',
                                    OperationUserID,
                                    user_Id,
                                    '',
                                    datamodify_apply_id,
                                    TodoSender_Cur,
                                    ErrMsg);
    SELECT count(1)
      into countNum
      from (select c_datamodify_apply_id
              from oa_afw_dmd_apply
             where (N_STATUS = 5 and C_HANDLE_USER_ID = OperationUserID)
             order by D_INPUT_DATE desc) T
     where rownum = 1;
    if countNum <= 0 then
      RETURN 0;
    end IF;
    SELECT t.c_datamodify_apply_id
      into apply_id
      from (select c_datamodify_apply_id
              from oa_afw_dmd_apply
             where (N_STATUS = 5 and C_HANDLE_USER_ID = OperationUserID)
             order by D_INPUT_DATE desc) T
     where rownum = 1;
    RETURN 0;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := '关闭错误' || SQLERRM;
      RETURN - 1;
  END;

  FUNCTION reject_OADMDAPPLY(datamodify_apply_id in VARCHAR2,
                             OperationUserID     IN VARCHAR2,
                             rejectRemarks       IN VARCHAR2,
                             apply_id            out VARCHAR2,
                             ErrMsg              OUT VARCHAR2) RETURN NUMBER is
    TodoSender_Cur        sys_refcursor;
    applyType             number(1);
    messageReceiverUserID char(32);
    resultNum             number(1);
    countNum              number;
    userNmae              varchar(50);
    TodoTitle             varchar(500);
  BEGIN
    select a.n_status
      into applyType
      from oa_afw_dmd_apply a
     where a.c_datamodify_apply_id = datamodify_apply_id;
    if applyType <> 2 and applyType <> 5 then
      ErrMsg := '驳回错误' || '请刷新页面重新操作';
      RETURN - 1;
    end IF;
    update oa_afw_dmd_apply
       set N_COLSE_STATUS   = 4,
           N_STATUS         = -2,
           N_REJECT_STATUS  = 1,
           C_REJECT_USER_ID = OperationUserID,
           D_REJECT_DATE    = sysdate,
           V_REJECT_MEMO    = rejectRemarks
     where c_datamodify_apply_id = datamodify_apply_id;
  
    update oa_tdo_todo_info a
       set a.n_status = 1
     where a.c_todo_user_id = OperationUserID
       and a.c_todo_data_id = datamodify_apply_id;
    select a.v_user_name
      into userNmae
      from LCBASE.T_zip_USER a
     where a.c_user_id = OperationUserID
       and a.d_enddate >= sysdate;
  
    select a.c_input_user_id
      into messageReceiverUserID
      from oa_afw_dmd_apply a
     where a.c_datamodify_apply_id = datamodify_apply_id;
    TodoTitle := userNmae || '的数据修改申请待处理';
    /*    resultNum := Create_Approval_MESSAGE(datamodify_apply_id,
    TodoTitle,
    messageReceiverUserID,
    54,
    TodoSender_Cur,
    ErrMsg);*/
    resultNum := INSER_OADMDCOMMENT(rejectRemarks || '^2',
                                    OperationUserID,
                                    messageReceiverUserID,
                                    '',
                                    datamodify_apply_id,
                                    TodoSender_Cur,
                                    ErrMsg);
  
    SELECT count(1)
      into countNum
      from (select c_datamodify_apply_id
              from oa_afw_dmd_apply
             where (N_STATUS = 5 and C_HANDLE_USER_ID = OperationUserID)
             order by D_INPUT_DATE desc) T
     where rownum = 1;
    if countNum <= 0 then
      RETURN 0;
    end IF;
    SELECT t.c_datamodify_apply_id
      into apply_id
      from (select c_datamodify_apply_id
              from oa_afw_dmd_apply
             where (N_STATUS = 5 and C_HANDLE_USER_ID = OperationUserID)
             order by D_INPUT_DATE desc) T
     where rownum = 1;
    RETURN 0;
  
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := '驳回错误' || SQLERRM;
      RETURN - 1;
  END;
  FUNCTION Create_Approval_Todo(WorkflowId            in varchar2,
                                TodoTitle             in varchar2,
                                messageReceiverUserID in varchar2,
                                WORKFLOW_TYPE         in Number,
                                TodoSender_Cur        out sys_refcursor,
                                ErrMsg                OUT VARCHAR2)
    RETURN NUMBER is
  begin
  
    insert into oa_tdo_todo_info
      (c_todo_id,
       c_todo_user_id,
       d_todo_time,
       n_todo_type,
       v_todo_title,
       d_input_time,
       n_status,
       c_todo_data_id)
    values
      (lower(sys_guid()),
       messageReceiverUserID,
       sysdate,
       WORKFLOW_TYPE,
       TodoTitle,
       sysdate,
       0,
       WorkflowId);
    open TodoSender_Cur for
      select messageReceiverUserID from dual;
    RETURN 0;
  
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := '发送待办失败' || SQLERRM;
      RETURN - 1;
  end;
  FUNCTION Create_Approval_MESSAGE(WorkflowId            in varchar2,
                                   TodoTitle             in varchar2,
                                   messageReceiverUserID in varchar2,
                                   WORKFLOW_TYPE         in Number,
                                   TodoSender_Cur        out sys_refcursor,
                                   ErrMsg                OUT VARCHAR2)
    RETURN NUMBER is
  begin
  
    insert into oa_msg_message_info
      (c_msg_id,
       n_msg_type,
       n_istop_flag,
       v_msg_title,
       d_msg_time,
       n_read_flag,
       c_msg_user_id,
       c_msg_src,
       v_msg_content,
       v_msg_sender,
       
       n_enable)
    values
      (LOWER(SYS_GUID()),
       WORKFLOW_TYPE,
       0,
       TodoTitle,
       sysdate,
       0,
       messageReceiverUserID,
       WorkflowId,
       TodoTitle,
       '系统',
       0);
  
    open TodoSender_Cur for
      select messageReceiverUserID from dual;
    RETURN 0;
  
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := '发送消息失败' || SQLERRM;
      RETURN - 1;
  end;

end PKG_DMD_APPLY;
/

