create package body pkg_user_schedule as
   function Insert_Leave_Info (DataInfo in varchar2,OperationUserId in varchar2,DataId out varchar2,ErrMsg out varchar2) return number as
   DATAARR             PKG_COMMON.ARR_LONGSTR;
       P_ID                char(32);
       FirstApprovalUserId char(32);
     begin
       DATAARR := PKG_COMMON.Split(DataInfo, '^');
       P_ID    := LOWER(SYS_GUID());
       insert into lcbase.t_User_Leave_Info
         (c_leave_id,
          n_leave_type,
          c_leave_user_id,
          d_leave_start_time,
          d_leave_end_time,
          n_leave_days,
          v_leave_reason,
          n_enclosure_count,
          d_input_date,
          n_status,
          c_leave_no)
       values
         (P_ID,
          DATAARR(2),
          DATAARR(3),
          to_date(DATAARR(4), 'yyyymmddhh24miss'),
          to_date(DATAARR(5), 'yyyymmddhh24miss'),
          DATAARR(6),
          DATAARR(7),
          DATAARR(8),
          sysdate,
          0,
          lcbase.pkg_common.getflownumber('QJ', 4));
       DataId := P_ID;
       Insert_Approval_Flow(DataId, DATAARR(3), 1, FirstApprovalUserId);
       Insert_Approval_Next_Todo_Info(DataId, null);
       commit;
       return 0;
     exception
       when others then
         ErrMsg := 'Insert_Leave_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
         RAISE_APPLICATION_ERROR(-20008, errmsg, false);
     end;
   function Update_Leave_Info (DataInfo in varchar2,OperationUserId in varchar2,ErrMsg out varchar2) return number as
   DATAARR  PKG_COMMON.ARR_LONGSTR;
       P_ID     char(32);
       P_STATUS number(1);
     begin
       DATAARR := PKG_COMMON.Split(DataInfo, '^');
       P_ID    := DATAARR(1);
       select n_status
         into P_STATUS
         from lcbase.t_User_Leave_Info
        where c_leave_id = P_ID;
       if P_STATUS in (-1, 0, 3) then
         update lcbase.t_User_Leave_Info
            set n_leave_type       = DATAARR(2),
                c_leave_user_id    = DATAARR(3),
                d_leave_start_time = to_date(DATAARR(4), 'yyyymmddhh24miss'),
                d_leave_end_time   = to_date(DATAARR(5), 'yyyymmddhh24miss'),
                n_leave_days       = DATAARR(6),
                v_leave_reason     = DATAARR(7),
                n_enclosure_count  = DATAARR(8)
          where c_leave_id = P_ID;
         commit;
       else
         RAISE_APPLICATION_ERROR(-20008,
                                 '已经审批中，不能修改，请先撤回',
                                 false);
       end if;
       return 0;
     exception
       when others then
         ErrMsg := 'Update_Leave_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
         RAISE_APPLICATION_ERROR(-20008, errmsg, false);
     end;
   function Insert_Egress_Info (DataInfo in varchar2,OperationUserId in varchar2,DataId out varchar2,ErrMsg out varchar2) return number as
   DATAARR             PKG_COMMON.ARR_LONGSTR;
       P_ID                char(32);
       FirstApprovalUserId char(32);
     begin
       DATAARR := PKG_COMMON.Split(DataInfo, '^');
       P_ID    := LOWER(SYS_GUID());
       insert into lcbase.t_User_Egress_Info
         (c_egress_id,
          n_egress_type,
          c_egress_user_id,
          d_egress_start_time,
          d_egress_end_time,
          n_egress_days,
          v_egress_addr,
          v_egress_reason,
          n_enclosure_count,
          d_input_date,
          n_status,
          c_egress_no)
       values
         (P_ID,
          DATAARR(2),
          DATAARR(3),
          to_date(DATAARR(4), 'yyyymmddhh24miss'),
          to_date(DATAARR(5), 'yyyymmddhh24miss'),
          DATAARR(6),
          DATAARR(7),
          DATAARR(8),
          DATAARR(9),
          sysdate,
          0,
          lcbase.pkg_common.getflownumber('WC', 4));
       DataId := P_ID;
       Insert_Approval_Flow(DataId, DATAARR(3), 2, FirstApprovalUserId);
       Insert_Approval_Next_Todo_Info(DataId, null);
       commit;
       return 0;
     exception
       when others then
         ErrMsg := 'Insert_Egress_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
         RAISE_APPLICATION_ERROR(-20008, errmsg, false);
     end;
   function Update_Egress_Info (DataInfo in varchar2,OperationUserId in varchar2,ErrMsg out varchar2) return number as
   DATAARR  PKG_COMMON.ARR_LONGSTR;
       P_ID     char(32);
       P_STATUS number(1);
     begin
       DATAARR := PKG_COMMON.Split(DataInfo, '^');
       P_ID    := DATAARR(1);
       select n_status
         into P_STATUS
         from lcbase.t_User_Egress_Info
        where c_egress_id = P_ID;
       if P_STATUS in (-1, 0, 3) then
         update lcbase.t_User_Egress_Info
            set n_egress_type       = DATAARR(2),
                c_egress_user_id    = DATAARR(3),
                d_egress_start_time = to_date(DATAARR(4), 'yyyymmddhh24miss'),
                d_egress_end_time   = to_date(DATAARR(5), 'yyyymmddhh24miss'),
                n_egress_days       = DATAARR(6),
                v_egress_addr       = DATAARR(7),
                v_egress_reason     = DATAARR(8),
                n_enclosure_count   = DATAARR(9)
          where c_egress_id = P_ID;
         commit;
       else
         RAISE_APPLICATION_ERROR(-20008,
                                 '已经审批中，不能修改，请先撤回',
                                 false);
       end if;
       return 0;
     exception
       when others then
         ErrMsg := 'Update_Egress_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
         RAISE_APPLICATION_ERROR(-20008, errmsg, false);
     end;
   function Insert_News_Info (DataInfo in varchar2,OperationUserId in varchar2,DataId out varchar2,ErrMsg out varchar2) return number as
   DATAARR             PKG_COMMON.ARR_LONGSTR;
       P_ID                char(32);
       FirstApprovalUserId char(32);
     begin
       DATAARR := PKG_COMMON.Split(DataInfo, '^');
       P_ID    := LOWER(SYS_GUID());
       insert into lcbase.t_User_Publish_Info
         (c_news_id,
          n_news_type,
          n_news_range,
          v_news_title,
          v_news_content,
          n_signature_type,
          v_signature_id,
          v_signature_name,
          n_comment_allow,
          n_must_feedback,
          n_istop_flag,
          c_input_user_id,
          v_input_user_name,
          d_input_time,
          n_status,
          c_news_no)
       values
         (P_ID,
          DATAARR(2),
          DATAARR(3),
          DATAARR(4),
          DATAARR(5),
          DATAARR(6),
          DATAARR(7),
          DATAARR(8),
          DATAARR(9),
          DATAARR(10),
          DATAARR(11),
          DATAARR(12),
          DATAARR(13),
          sysdate,
          0,
          DATAARR(16));
       DataId := P_ID;
       Insert_Approval_Flow(DataId, DATAARR(3), 3, FirstApprovalUserId);
       Insert_Approval_Next_Todo_Info(DataId, null);
       commit;
       return 0;
     exception
       when others then
         ErrMsg := 'Insert_News_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
         RAISE_APPLICATION_ERROR(-20008, errmsg, false);
     end;
   function Update_News_Info (DataInfo in varchar2,OperationUserId in varchar2,ErrMsg out varchar2) return number as
   DATAARR  PKG_COMMON.ARR_LONGSTR;
       P_ID     char(32);
       P_STATUS number(1);
     begin
       DATAARR := PKG_COMMON.Split(DataInfo, '^');
       P_ID    := DATAARR(1);
       select n_status
         into P_STATUS
         from lcbase.t_User_Publish_Info
        where c_news_id = P_ID;
       if P_STATUS in (-1, 0, 3) then
         update lcbase.t_User_Publish_Info
            set n_news_type       = DATAARR(2),
                n_news_range      = DATAARR(3),
                v_news_title      = DATAARR(4),
                v_news_content    = DATAARR(5),
                n_signature_type  = DATAARR(6),
                v_signature_id    = DATAARR(7),
                v_signature_name  = DATAARR(8),
                n_comment_allow   = DATAARR(9),
                n_must_feedback   = DATAARR(10),
                n_istop_flag      = DATAARR(11),
                c_input_user_id   = DATAARR(12),
                v_input_user_name = DATAARR(13)
          where c_news_id = P_ID;
         commit;
       else
         RAISE_APPLICATION_ERROR(-20008,
                                 '已经审批中，不能修改，请先撤回',
                                 false);
       end if;
       return 0;
     exception
       when others then
         ErrMsg := 'Update_News_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
         RAISE_APPLICATION_ERROR(-20008, errmsg, false);
     end;
   function Insert_Expense_Info (DataInfo in varchar2,OperationUserId in varchar2,DataId out varchar2,ErrMsg out varchar2) return number as
   DATAARR             PKG_COMMON.ARR_LONGSTR;
       P_ID                char(32);
       FirstApprovalUserId char(32);
     begin
       DATAARR := PKG_COMMON.Split(DataInfo, '^');
       P_ID    := LOWER(SYS_GUID());
       insert into lcbase.t_User_Expenses_Info
         (c_expenses_id,
          n_expenses_type,
          c_expenses_user_id,
          v_expenses_user_name,
          v_expenses_user_tel,
          c_dept_id,
          v_dept_name,
          c_top1_dept_id,
          c_top2_dept_id,
          c_top3_dept_id,
          c_top4_dept_id,
          v_dept_full_name,
          c_position_id,
          v_position_name,
          c_lk_corp_id,
          v_expenses_reason,
          c_project_id,
          v_project_name,
          n_borrowed_fee,
          n_total_fee,
          n_payable_fee,
          v_expenses_no,
          v_bar_code,
          n_repay_flag,
          n_repay_type,
          n_repay_amount,
          d_input_time,
          d_reject_time,
          c_reject_user_id,
          v_reject_user_name,
          v_reject_remark,
          d_update_time,
          c_update_user_id,
          n_status,
          n_approval_avoid_flag,
          n_finance_status,
          n_current_level,
          n_paid_fee,
          c_pay_lk_corp_id,
          n_ebank_pay_status,
          v_payment_flow_no,
          v_payment_flow_no_prefix,
          v_bank_flow_no,
          n_payment_fee,
          v_payment_failed_reason,
          v_payment_account_no,
          c_payment_user_id,
          d_payment_date,
          v_payment_purpose,
          n_record_flag,
          d_record_time,
          n_check_flag,
          v_check_remark,
          d_check_time,
          c_check_user_id,
          n_notice_payable_fee,
          n_notice_status,
          v_notice_remark,
          n_disabled_flag,
          c_last_invalid_userid,
          d_last_invalid_date,
          v_last_invalid_memo,
          v_finance_reject_reson,
          d_finance_reject_date,
          c_finance_reject_user_id,
          v_finance_reject_user_name,
          n_invalid_status,
          v_ex_memo)
       values
         (P_ID,
          DATAARR(2),
          DATAARR(3),
          DATAARR(4),
          DATAARR(5),
          DATAARR(6),
          DATAARR(7),
          DATAARR(8),
          DATAARR(9),
          DATAARR(10),
          DATAARR(11),
          DATAARR(12),
          DATAARR(13),
          DATAARR(14),
          DATAARR(15),
          DATAARR(16),
          DATAARR(17),
          DATAARR(18),
          DATAARR(19),
          DATAARR(20),
          DATAARR(21),
          DATAARR(22),
          DATAARR(23),
          DATAARR(24),
          DATAARR(25),
          DATAARR(26),
          sysdate,
          DATAARR(28),
          DATAARR(29),
          DATAARR(30),
          DATAARR(31),
          DATAARR(32),
          DATAARR(33),
          DATAARR(34),
          DATAARR(35),
          DATAARR(36),
          DATAARR(37),
          DATAARR(38),
          DATAARR(39),
          DATAARR(40),
          DATAARR(41),
          DATAARR(42),
          DATAARR(43),
          DATAARR(44),
          DATAARR(45),
          DATAARR(46),
          DATAARR(47),
          DATAARR(48),
          DATAARR(49),
          DATAARR(50),
          DATAARR(51),
          DATAARR(52),
          DATAARR(53),
          DATAARR(54),
          DATAARR(55),
          DATAARR(56),
          DATAARR(57),
          DATAARR(58),
          DATAARR(59),
          DATAARR(60),
          DATAARR(61),
          DATAARR(62),
          DATAARR(63),
          DATAARR(64),
          DATAARR(65),
          DATAARR(66),
          DATAARR(67),
          DATAARR(68));
       DataId := P_ID;
       Insert_Approval_Flow(DataId, DATAARR(3), 4, FirstApprovalUserId);
       Insert_Approval_Next_Todo_Info(DataId, null);
       commit;
       return 0;
     exception
       when others then
         ErrMsg := 'Insert_Expense_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
         RAISE_APPLICATION_ERROR(-20008, errmsg, false);
     end;
   function Update_Expense_Info (DataInfo in varchar2,OperationUserId in varchar2,ErrMsg out varchar2) return number as
   DATAARR  PKG_COMMON.ARR_LONGSTR;
       P_ID     char(32);
       P_STATUS number(1);
     begin
       DATAARR := PKG_COMMON.Split(DataInfo, '^');
       P_ID    := DATAARR(1);
       select n_status
         into P_STATUS
         from lcbase.t_User_Publish_Info
        where c_news_id = P_ID;
       if P_STATUS in (-1, 0, 3) then
         update lcbase.t_User_Publish_Info
            set n_news_type       = DATAARR(2),
                n_news_range      = DATAARR(3),
                v_news_title      = DATAARR(4),
                v_news_content    = DATAARR(5),
                n_signature_type  = DATAARR(6),
                v_signature_id    = DATAARR(7),
                v_signature_name  = DATAARR(8),
                n_comment_allow   = DATAARR(9),
                n_must_feedback   = DATAARR(10),
                n_istop_flag      = DATAARR(11),
                c_input_user_id   = DATAARR(12),
                v_input_user_name = DATAARR(13)
          where c_news_id = P_ID;
         commit;
       else
         RAISE_APPLICATION_ERROR(-20008,
                                 '已经审批中，不能修改，请先撤回',
                                 false);
       end if;
       return 0;
     exception
       when others then
         ErrMsg := 'Update_Expense_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
         RAISE_APPLICATION_ERROR(-20008, errmsg, false);
     end;
   function Get_Approval_Status (APPROVAL_ID in varchar2,CUR_DATA OUT SYS_REFCURSOR,ErrMsg out varchar2) return number as
   begin
       open CUR_DATA for
         select N_APPROVAL_LEVEL,
                N_APPROVAL_STATUS,
                V_APPROVAL_REMARK,
                C_AFLOW_USER_ID,
                V_AFLOW_USER_NAME,
                D_APPROVAL_TIME
           from t_user_approval_flow
          where c_approval_id = APPROVAL_ID
          order by N_APPROVAL_LEVEL;
       return 0;
     exception
       when others THEN
         ErrMsg := 'Get_Approval_Status: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         return 10001;
     end;
   procedure Insert_Approval_Flow (ApprovalId in varchar2,UserId in varchar2,ApprovalType in number,FirstApprovalUserId out varchar2) as
   ROW_DATA lcbase.t_approval_flow_config%rowtype;
       CUR_DATA sys_refcursor;
     begin
       delete from lcbase.t_user_approval_flow
        where c_approval_id = ApprovalId;

       open CUR_DATA for
         select *
           from lcbase.t_approval_flow_config
          where n_approval_type = ApprovalType
            and c_dept_id = (select c_organization_id
                               from lcbase.t_user
                              where c_user_id = UserId);
       fetch CUR_DATA
         into ROW_DATA;
       if CUR_DATA%found then
         if ROW_DATA.C_AFLOW_USER1_ID is not null then
           insert into lcbase.t_user_approval_flow
             (c_flow_id,
              c_approval_id,
              n_approval_type,
              n_approval_level,
              n_approval_status,
              c_aflow_user_id,
              v_aflow_user_name)
           values
             (lower(sys_guid()),
              ApprovalId,
              ApprovalType,
              1,
              0,
              ROW_DATA.C_AFLOW_USER1_ID,
              ROW_DATA.V_AFLOW_USER1_NAME);
           FirstApprovalUserId := ROW_DATA.C_AFLOW_USER1_ID;
         end if;
         if ROW_DATA.C_AFLOW_USER2_ID is not null then
           insert into lcbase.t_user_approval_flow
             (c_flow_id,
              c_approval_id,
              n_approval_type,
              n_approval_level,
              n_approval_status,
              c_aflow_user_id,
              v_aflow_user_name)
           values
             (lower(sys_guid()),
              ApprovalId,
              ApprovalType,
              2,
              0,
              ROW_DATA.C_AFLOW_USER2_ID,
              ROW_DATA.V_AFLOW_USER2_NAME);
         end if;
         if ROW_DATA.C_AFLOW_USER3_ID is not null then
           insert into lcbase.t_user_approval_flow
             (c_flow_id,
              c_approval_id,
              n_approval_type,
              n_approval_level,
              n_approval_status,
              c_aflow_user_id,
              v_aflow_user_name)
           values
             (lower(sys_guid()),
              ApprovalId,
              ApprovalType,
              3,
              0,
              ROW_DATA.C_AFLOW_USER3_ID,
              ROW_DATA.V_AFLOW_USER3_NAME);
         end if;
         if ROW_DATA.C_AFLOW_USER4_ID is not null then
           insert into lcbase.t_user_approval_flow
             (c_flow_id,
              c_approval_id,
              n_approval_type,
              n_approval_level,
              n_approval_status,
              c_aflow_user_id,
              v_aflow_user_name)
           values
             (lower(sys_guid()),
              ApprovalId,
              ApprovalType,
              4,
              0,
              ROW_DATA.C_AFLOW_USER4_ID,
              ROW_DATA.V_AFLOW_USER4_NAME);
         end if;
         if ROW_DATA.C_AFLOW_USER5_ID is not null then
           insert into lcbase.t_user_approval_flow
             (c_flow_id,
              c_approval_id,
              n_approval_type,
              n_approval_level,
              n_approval_status,
              c_aflow_user_id,
              v_aflow_user_name)
           values
             (lower(sys_guid()),
              ApprovalId,
              ApprovalType,
              5,
              0,
              ROW_DATA.C_AFLOW_USER5_ID,
              ROW_DATA.V_AFLOW_USER5_NAME);
         end if;
       end if;
       close CUR_DATA;
     end;
   procedure Insert_Approval_Next_Todo_Info (ApprovalId in varchar2,PreFlowId in varchar2) as
   ROW_DATA lcbase.t_user_approval_flow%rowtype;
       CUR_DATA sys_refcursor;
       Pre_Find number(1);
     begin
       open CUR_DATA for
         select *
           from lcbase.t_user_approval_flow f
          where f.c_approval_id = ApprovalId
          order by f.n_approval_level;
       fetch CUR_DATA
         into ROW_DATA;
       while CUR_DATA%found loop
         if PreFlowId is null then
           Pre_Find := 2;
           exit;
         elsif ROW_DATA.C_FLOW_ID = PreFlowId then
           Pre_Find := 1;
         elsif Pre_Find = 1 then
           Pre_Find := 2;
           exit;
         end if;
         fetch CUR_DATA
           into ROW_DATA;
       end loop;
       close CUR_DATA;
       if Pre_Find = 2 then
         insert into lcbase.t_user_todo_info
           (c_todo_id,
            c_todo_user_id,
            d_todo_time,
            n_todo_type,
            v_todo_title,
            d_input_time,
            n_status,
            c_todo_data_id)
         values
           (lower(sys_guid()),
            ROW_DATA.C_AFLOW_USER_ID,
            sysdate,
            ROW_DATA.N_APPROVAL_TYPE,
            '请假审批',
            sysdate,
            0,
            ROW_DATA.C_FLOW_ID);
       end if;
     end;
   function Remove_Approval_Flow (ApprovalId in varchar2,ErrMsg out varchar2) return number as
   begin
       delete from lcbase.t_user_approval_flow
        where c_approval_id = ApprovalId;
       commit;
       return 0;
     exception
       when others then
         ErrMsg := 'Remove_Approval_Flow: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
     end;
   procedure Send_New_Message (MsgType in number,MsgTitle in varchar2,MsgUserId in varchar2,MsgSrcId in varchar2,MsgContent in varchar2,MsgSender in varchar2) as
   begin
       insert into lcbase.t_user_msg_info
         (c_msg_id,
          n_msg_type,
          n_istop_flag,
          v_msg_title,
          d_msg_time,
          n_read_flag,
          c_msg_user_id,
          c_msg_src,
          v_msg_content,
          v_msg_sender,
          d_update_time,
          n_enable)
       values
         (lower(sys_guid()),
          MsgType,
          0,
          MsgTitle,
          sysdate,
          0,
          MsgUserId,
          MsgSrcId,
          MsgContent,
          MsgSender,
          sysdate,
          1);
     end;
   function Approval_Target_Pass (ApprovalId in varchar2,ApprovalUserId in varchar2,ApprovalRemark in varchar2,ApprovalType in number,ErrMsg out varchar2) return number as
   ROW_DATA    lcbase.t_user_approval_flow%rowtype;
       HIT_DATA    lcbase.t_user_approval_flow%rowtype;
       CUR_DATA    sys_refcursor;
       LST_STATUS  number(1);
       ALL_CNT     number(2);
       DONE_CNT    number(2);
       APPRO_FLAG  number(1);
       P_SUMMERY   varchar2(200);
       P_MSGUSERID char(32);
     begin
       LST_STATUS := 1;
       APPRO_FLAG := 0;
       open CUR_DATA for
         select *
           from t_user_approval_flow
          where c_approval_id = ApprovalId
          order by n_approval_level;
       fetch CUR_DATA
         into ROW_DATA;
       while CUR_DATA%found loop
         if APPRO_FLAG = 0 then
           if ROW_DATA.C_AFLOW_USER_ID = ApprovalUserId then
             HIT_DATA   := ROW_DATA;
             APPRO_FLAG := 1;
           else
             LST_STATUS := ROW_DATA.N_APPROVAL_STATUS;
           end if;
         else
           if ROW_DATA.N_APPROVAL_STATUS <> 0 then
             APPRO_FLAG := 2;
             exit;
           end if;
         end if;
         fetch CUR_DATA
           into ROW_DATA;
       end loop;
       close CUR_DATA;

       if APPRO_FLAG = 0 then
         ErrMsg := '审批流程错误，无审批权限';
         return - 20001;
       elsif APPRO_FLAG = 2 then
         ErrMsg := '审批流程错误，审批权限已过期';
         return - 20002;
       elsif HIT_DATA.C_AFLOW_USER_ID = ApprovalUserId then
         if LST_STATUS <> 1 then
           ErrMsg := '审批流程错误，前一步审批尚未完成';
           return - 20003;
         end if;
         if HIT_DATA.N_APPROVAL_STATUS = 1 then
           ErrMsg := '审批流程错误，重复审批';
           return - 20004;
         else
           update lcbase.t_user_approval_flow
              set n_approval_status = 1,
                  v_approval_remark = ApprovalRemark,
                  d_approval_time   = sysdate
            where c_approval_id = ApprovalId
              and c_aflow_user_id = ApprovalUserId
              and n_approval_type = HIT_DATA.N_APPROVAL_TYPE;
           update lcbase.t_user_todo_info
              set n_status = 1, d_done_time = sysdate
            where c_todo_data_id = HIT_DATA.C_FLOW_ID;
         end if;
       end if;

       --如果全都审批通过，则修改申请状态为已通过审批
       select count(1),
              sum(case
                    when n_approval_status = 1 then
                     1
                    else
                     0
                  end)
         into ALL_CNT, DONE_CNT
         from t_user_approval_flow
        where c_approval_id = ApprovalId;

       if ALL_CNT = DONE_CNT then
         if ApprovalType = 1 then
           update lcbase.t_user_leave_info t
              set t.n_status = 2
            where t.c_leave_id = ApprovalId;
           insert into lcbase.t_user_msg_info
             (c_msg_id,
              n_msg_type,
              n_istop_flag,
              v_msg_title,
              d_msg_time,
              n_read_flag,
              c_msg_user_id,
              c_msg_src,
              v_msg_content,
              v_msg_sender,
              d_update_time,
              n_enable)
             select lower(sys_guid()),
                    ApprovalType,
                    0,
                    '已经审批完成',
                    sysdate,
                    0,
                    t.c_leave_user_id,
                    ApprovalId,
                    decode(t.n_leave_type,
                           1,
                           '事假',
                           2,
                           '病假',
                           3,
                           '调休',
                           4,
                           '年假',
                           5,
                           '产假',
                           6,
                           '哺乳假',
                           7,
                           '婚假',
                           8,
                           '丧假',
                           '其它') || t.n_leave_days || '天【' ||
                    to_char(t.d_leave_start_time, 'yyyy-MM-dd HH:mi') || '至' ||
                    to_char(t.d_leave_end_time, 'yyyy-MM-dd HH:mi') || '】',
                    '系统',
                    sysdate,
                    1
               from lcbase.t_user_leave_info t
              where t.c_leave_id = ApprovalId;
         elsif ApprovalType = 2 then
           update lcbase.t_user_egress_info t
              set t.n_status = 2
            where t.c_egress_id = ApprovalId;

           insert into lcbase.t_user_msg_info
             (c_msg_id,
              n_msg_type,
              n_istop_flag,
              v_msg_title,
              d_msg_time,
              n_read_flag,
              c_msg_user_id,
              c_msg_src,
              v_msg_content,
              v_msg_sender,
              d_update_time,
              n_enable)
             select lower(sys_guid()),
                    ApprovalType,
                    0,
                    '已经审批完成',
                    sysdate,
                    0,
                    t.c_egress_user_id,
                    ApprovalId,
                    decode(t.n_egress_type, 1, '市内外出', 2, '出差', '其它') ||
                    t.n_egress_days || '小时【' ||
                    to_char(t.d_egress_start_time, 'yyyy-MM-dd HH:mi') || '至' ||
                    to_char(t.d_egress_end_time, 'yyyy-MM-dd HH:mi') || '】',
                    '系统',
                    sysdate,
                    1
               from lcbase.t_user_egress_info t
              where t.c_egress_id = ApprovalId;
         elsif ApprovalType = 3 then
           update lcbase.t_user_publish_info t
              set t.n_status = 2
            where t.c_news_id = ApprovalId;

           select t.v_input_user_name, t.v_news_title
             into P_MSGUSERID, P_SUMMERY
             from lcbase.t_user_publish_info t
            where t.c_news_id = ApprovalId;

           insert into lcbase.t_user_msg_info
             (c_msg_id,
              n_msg_type,
              n_istop_flag,
              v_msg_title,
              d_msg_time,
              n_read_flag,
              c_msg_user_id,
              c_msg_src,
              v_msg_content,
              v_msg_sender,
              d_update_time,
              n_enable)
             select lower(sys_guid()),
                    ApprovalType,
                    0,
                    P_SUMMERY,
                    sysdate,
                    0,
                    c_user_id,
                    ApprovalId,
                    P_SUMMERY,
                    P_MSGUSERID,
                    sysdate,
                    1
               from (select u.c_user_id
                       from lcbase.t_user u
                      where u.c_organization_id in
                            (select g.c_organization_id
                               from lcbase.t_organization g
                             connect by prior g.c_organization_id =
                                         g.c_organization_parent_id
                              start with g.c_organization_id in
                                         (select r.c_target_id
                                            from lcbase.t_user_publish_range r
                                           where r.c_news_id = ApprovalId
                                             and r.n_target_type = 1))
                     union
                     select r.c_target_id
                       from lcbase.t_user_publish_range r
                      where r.c_news_id = ApprovalId
                        and r.n_target_type = 0);
         elsif ApprovalType = 4 then
           update lcbase.t_user_expenses_info t
              set t.n_status = 3
            where t.c_expenses_id = ApprovalId;
           insert into lcbase.t_user_msg_info
             (c_msg_id,
              n_msg_type,
              n_istop_flag,
              v_msg_title,
              d_msg_time,
              n_read_flag,
              c_msg_user_id,
              c_msg_src,
              v_msg_content,
              v_msg_sender,
              d_update_time,
              n_enable)
             select lower(sys_guid()),
                    ApprovalType,
                    0,
                    '已经审批完成',
                    sysdate,
                    0,
                    t.c_expenses_user_id,
                    ApprovalId,
                    t.v_expenses_user_name || '的报销',
                    '系统',
                    sysdate,
                    1
               from lcbase.t_user_expenses_info t
              where t.c_expenses_id = ApprovalId;
         end if;
       else
         Insert_Approval_Next_Todo_Info(ApprovalId, HIT_DATA.C_FLOW_ID);
       end if;
       commit;
       return 0;
     exception
       when others then
         ErrMsg := 'Approval_Target_Status: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
     end;
   function Approval_Target_Reject (ApprovalId in varchar2,ApprovalUserId in varchar2,ApprovalRemark in varchar2,ApprovalType in number,ErrMsg out varchar2) return number as
   ROW_DATA    lcbase.t_user_approval_flow%rowtype;
       HIT_DATA    lcbase.t_user_approval_flow%rowtype;
       CUR_DATA    sys_refcursor;
       LST_STATUS  number(1);
       APPRO_FLAG  number(1);
       P_SUMMERY   varchar2(200);
       P_MSGUSERID char(32);
     begin
       LST_STATUS := 1;
       APPRO_FLAG := 0;
       open CUR_DATA for
         select *
           from t_user_approval_flow
          where c_approval_id = ApprovalId
          order by n_approval_level;
       fetch CUR_DATA
         into ROW_DATA;
       while CUR_DATA%found loop
         if APPRO_FLAG = 0 then
           if ROW_DATA.C_AFLOW_USER_ID = ApprovalUserId then
             HIT_DATA   := ROW_DATA;
             APPRO_FLAG := 1;
           end if;
           LST_STATUS := ROW_DATA.N_APPROVAL_STATUS;
         else
           if ROW_DATA.N_APPROVAL_STATUS <> 0 then
             APPRO_FLAG := 2;
             exit;
           end if;
         end if;
         fetch CUR_DATA
           into ROW_DATA;
       end loop;
       close CUR_DATA;

       if APPRO_FLAG = 0 then
         ErrMsg := '审批流程错误，无审批权限';
         return 10001;
       elsif APPRO_FLAG = 2 then
         ErrMsg := '审批流程错误，审批权限已过期';
         return 10001;
       elsif HIT_DATA.C_AFLOW_USER_ID = ApprovalUserId then
         if LST_STATUS <> 1 then
           ErrMsg := '审批流程错误，前一步审批尚未完成';
           return 10001;
         end if;
         if HIT_DATA.N_APPROVAL_STATUS = -1 then
           ErrMsg := '审批流程错误，重复审批';
           return 10001;
         else
           update lcbase.t_user_approval_flow
              set n_approval_status = -1,
                  v_approval_remark = ApprovalRemark,
                  d_approval_time   = sysdate
            where c_approval_id = ApprovalId
              and c_aflow_user_id = ApprovalUserId
              and n_approval_type = ApprovalType;
         end if;
       end if;

       if ApprovalType = 1 then
         update lcbase.t_user_leave_info t
            set t.n_status = 3
          where t.c_leave_id = ApprovalId;
         select t.c_leave_user_id,
                decode(t.n_leave_type,
                       1,
                       '事假',
                       2,
                       '病假',
                       3,
                       '调休',
                       4,
                       '年假',
                       5,
                       '产假',
                       6,
                       '哺乳假',
                       7,
                       '婚假',
                       8,
                       '丧假',
                       '其它') || t.n_leave_days || '天【' ||
                to_char(t.d_leave_start_time, 'yyyy-MM-dd HH:mi') || '至' ||
                to_char(t.d_leave_end_time, 'yyyy-MM-dd HH:mi') || '】'
           into P_MSGUSERID, P_SUMMERY
           from lcbase.t_user_leave_info t
          where t.c_leave_id = ApprovalId;
       elsif ApprovalType = 2 then
         update lcbase.t_user_egress_info t
            set t.n_status = 3
          where t.c_egress_id = ApprovalId;
         select t.c_egress_user_id,
                decode(t.n_egress_type, 1, '市内外出', 2, '出差', '其它') ||
                t.n_egress_days || '小时【' ||
                to_char(t.d_egress_start_time, 'yyyy-MM-dd HH:mi') || '至' ||
                to_char(t.d_egress_end_time, 'yyyy-MM-dd HH:mi') || '】'
           into P_MSGUSERID, P_SUMMERY
           from lcbase.t_user_egress_info t
          where t.c_egress_id = ApprovalId;
       elsif ApprovalType = 3 then
         update lcbase.t_user_publish_info t
            set t.n_status = 3
          where t.c_news_id = ApprovalId;
         select t.n_news_range, t.v_news_title
           into P_MSGUSERID, P_SUMMERY
           from lcbase.t_user_publish_info t
          where t.c_news_id = ApprovalId;
       elsif ApprovalType = 4 then
         update lcbase.t_user_expenses_info t
            set t.n_status = -1
          where t.c_expenses_id = ApprovalId;
         select t.c_expenses_user_id, t.v_expenses_user_name || '的报销'
           into P_MSGUSERID, P_SUMMERY
           from lcbase.t_user_expenses_info t
          where t.c_expenses_id = ApprovalId;
       end if;
       Send_New_Message(ApprovalType,
                        '已经驳回',
                        P_MSGUSERID,
                        ApprovalId,
                        P_SUMMERY,
                        '系统');
       commit;
       return 0;
     exception
       when others then
         ErrMsg := 'Approval_Target_Status: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
     end;
   function Approval_Target_Cancel (ApprovalId in varchar2,ApprovalUserId in varchar2,ApprovalRemark in varchar2,ApprovalType in number,ErrMsg out varchar2) return number as
   Expired_Days number(10, 5);
     begin
       if ApprovalType = 1 then
         select t.d_leave_start_time - sysdate
           into Expired_Days
           from lcbase.t_user_leave_info t
          where t.c_leave_id = ApprovalId;
         if Expired_Days > 0 then
           update lcbase.t_user_leave_info t
              set t.n_status = -1
            where t.c_leave_id = ApprovalId;
         else
           ErrMsg := '已经过期，不能撤销';
           return - 20001;
         end if;
       elsif ApprovalType = 2 then
         select t.d_egress_start_time - sysdate
           into Expired_Days
           from lcbase.t_user_egress_info t
          where t.c_egress_id = ApprovalId;
         if Expired_Days > 0 then
           update lcbase.t_user_egress_info t
              set t.n_status = -1
            where t.c_egress_id = ApprovalId;
         else
           ErrMsg := '已经过期，不能撤销';
           return - 20001;
         end if;
       elsif ApprovalType = 3 then
         update lcbase.t_user_publish_info t
            set t.n_status = -1
          where t.c_news_id = ApprovalId;
         delete from lcbase.t_user_msg_info t where t.c_msg_src = ApprovalId;
       elsif ApprovalType = 4 then
         select case
                  when t.n_paid_fee > 0 and t.n_status = 4 then
                   1
                  else
                   0
                end
           into Expired_Days
           from lcbase.t_user_expenses_info t
          where t.c_expenses_id = ApprovalId;
         if Expired_Days = 0 then
           update lcbase.t_user_expenses_info t
              set t.n_status = 5
            where t.c_expenses_id = ApprovalId;
         else
           ErrMsg := '已经支付，不能撤销';
           return - 20001;
         end if;
       end if;
       commit;
       return 0;
     exception
       when others then
         ErrMsg := 'Approval_Target_Status: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
     end;
   function Insert_Schedule_Info (DataInfo in varchar2,OperationUserId in varchar2,DataId out varchar2,ErrMsg out varchar2) return number as
   DATAARR PKG_COMMON.ARR_LONGSTR;
       P_ID    char(32);
       T_DY    date;
       W_IX    number(1);
     begin
       DATAARR := PKG_COMMON.Split(DataInfo, '^');
       P_ID    := LOWER(SYS_GUID());
       insert into t_User_Schedule_Info
         (c_sch_id,
          d_sch_date,
          d_sch_start_time,
          d_sch_end_time,
          c_sch_user_id,
          v_sch_title,
          v_sch_remark,
          n_repead_type,
          n_sch_type,
          n_meeting_type,
          c_meeting_clerk_id,
          c_meeting_clerk_name,
          c_mroom_no)
       values
         (P_ID,
          DATAARR(2),
          DATAARR(3),
          DATAARR(4),
          DATAARR(5),
          DATAARR(6),
          DATAARR(7),
          DATAARR(8),
          DATAARR(9),
          DATAARR(10),
          DATAARR(11),
          DATAARR(12),
          DATAARR(13));
       DataId := P_ID;

       --删除上次生成的日程（当前时间之后的）
       delete from lcbase.t_user_scheduling_flow f
        where f.c_sch_id = DataId
          and f.d_flow_date > trunc(sysdate, 'dd');
       --重新生成当前时间之后的日程
       --重复方式(0不重复1每日2工作日3每周4每月)
       T_DY := trunc(to_date(DATAARR(2), 'yyyymmddhh24miss'), 'dd');
       if DATAARR(8) = 0 then
         insert into lcbase.t_user_scheduling_flow
           (c_flow_id, c_sch_id, d_flow_date)
         values
           (lower(sys_guid()), DataId, T_DY);
       elsif DATAARR(8) = 1 then
         for i in 1 .. 365 loop
           insert into lcbase.t_user_scheduling_flow
             (c_flow_id, c_sch_id, d_flow_date)
           values
             (lower(sys_guid()), DataId, T_DY + i);
         end loop;
       elsif DATAARR(8) = 2 then
         W_IX := to_char(T_DY, 'd');
         for i in 1 .. 365 loop
           if MOD(W_IX + i, 7) > 1 then
             -- in (0,1)
             insert into lcbase.t_user_scheduling_flow
               (c_flow_id, c_sch_id, d_flow_date)
             values
               (lower(sys_guid()), DataId, T_DY + i);
           end if;
         end loop;
       elsif DATAARR(8) = 3 then
         for i in 1 .. 52 loop
           insert into lcbase.t_user_scheduling_flow
             (c_flow_id, c_sch_id, d_flow_date)
           values
             (lower(sys_guid()), DataId, T_DY + i * 7);

         end loop;
       elsif DATAARR(8) = 4 then
         for i in 1 .. 12 loop
           insert into lcbase.t_user_scheduling_flow
             (c_flow_id, c_sch_id, d_flow_date)
           values
             (lower(sys_guid()), DataId, add_months(T_DY, i));
         end loop;
       end if;
       commit;
       return 0;
     exception
       when others then
         ErrMsg := 'Add_Schedule_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
     end;
   function Update_Schedule_Info (DataInfo IN VARCHAR2,OperationUserId IN VARCHAR2,ErrMsg OUT VARCHAR2) return NUMBER as
   DATAARR PKG_COMMON.ARR_LONGSTR;
       DataId  char(32);
       T_DY    date;
       W_IX    number(1);
     begin
       DATAARR := PKG_COMMON.Split(DataInfo, '^');
       DataId  := DATAARR(1);
       UPDATE t_User_Schedule_Info
          SET d_sch_date           = DATAARR(2),
              d_sch_start_time     = DATAARR(3),
              d_sch_end_time       = DATAARR(4),
              c_sch_user_id        = DATAARR(5),
              v_sch_title          = DATAARR(6),
              v_sch_remark         = DATAARR(7),
              n_repead_type        = DATAARR(8),
              n_sch_type           = DATAARR(9),
              n_meeting_type       = DATAARR(10),
              c_meeting_clerk_id   = DATAARR(11),
              c_meeting_clerk_name = DATAARR(12),
              c_mroom_no           = DATAARR(13)
        WHERE c_sch_id = DataId;

       --删除上次生成的日程（当前时间之后的）
       delete from lcbase.t_user_scheduling_flow f
        where f.c_sch_id = DataId
          and f.d_flow_date > trunc(sysdate, 'dd');
       --重新生成当前时间之后的日程
       --重复方式(0不重复1每日2工作日3每周4每月)
       T_DY := trunc(to_date(DATAARR(2), 'yyyymmddhh24miss'), 'dd');
       if DATAARR(8) = 0 then
         insert into lcbase.t_user_scheduling_flow
           (c_flow_id, c_sch_id, d_flow_date)
         values
           (lower(sys_guid()), DataId, T_DY);
       elsif DATAARR(8) = 1 then
         for i in 1 .. 365 loop
           insert into lcbase.t_user_scheduling_flow
             (c_flow_id, c_sch_id, d_flow_date)
           values
             (lower(sys_guid()), DataId, T_DY + i);
         end loop;
       elsif DATAARR(8) = 2 then
         W_IX := to_char(T_DY, 'd');
         for i in 1 .. 365 loop
           if MOD(W_IX + i, 7) > 1 then
             -- in (0,1)
             insert into lcbase.t_user_scheduling_flow
               (c_flow_id, c_sch_id, d_flow_date)
             values
               (lower(sys_guid()), DataId, T_DY + i);
           end if;
         end loop;
       elsif DATAARR(8) = 3 then
         for i in 1 .. 52 loop
           insert into lcbase.t_user_scheduling_flow
             (c_flow_id, c_sch_id, d_flow_date)
           values
             (lower(sys_guid()), DataId, T_DY + i * 7);

         end loop;
       elsif DATAARR(8) = 4 then
         for i in 1 .. 12 loop
           insert into lcbase.t_user_scheduling_flow
             (c_flow_id, c_sch_id, d_flow_date)
           values
             (lower(sys_guid()), DataId, add_months(T_DY, i));
         end loop;
       end if;

       commit;
       return 0;
     exception
       when others then
         ErrMsg := 'Update_Schedule_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
     end;
   function Remove_Schedule_Info (ScheduleId IN VARCHAR2,OperationUserId IN VARCHAR2,ErrMsg OUT VARCHAR2) return NUMBER as
   begin
       delete from t_User_Schedule_Info WHERE c_sch_id = ScheduleId;

       --删除上次生成的日程（当前时间之后的）
       delete from lcbase.t_user_scheduling_flow f
        where f.c_sch_id = ScheduleId
          and f.d_flow_date > trunc(sysdate, 'dd');
       commit;
       return 0;
     exception
       when others then
         ErrMsg := 'Remove_Schedule_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                   DBMS_UTILITY.format_error_backtrace;
         rollback;
     end;
end pkg_user_schedule;

/

