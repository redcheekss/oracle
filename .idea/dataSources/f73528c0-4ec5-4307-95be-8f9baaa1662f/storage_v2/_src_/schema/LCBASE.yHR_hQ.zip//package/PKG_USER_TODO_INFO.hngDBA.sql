create package PKG_USER_TODO_INFO AS
/*
  因为待办消息由其他业务新增或修改时进行的消息触发，无需实现insert/update接口
  
*/
  FUNCTION Get_UserToDoInfo(
           					UserId          IN VARCHAR2,
                    OperationUserId IN VARCHAR2,
					          PageSize		IN NUMBER,          --每页显示大小>0
					          PageCur			IN NUMBER,          --当前页码[1-总页数]
                    CUR_DATA 		OUT SYS_REFCURSOR,	--oracle标准游标
                    OutRows			OUT number,			    --输出总记录数
					          OutPageCount	OUT number			  --输出总页数
					) RETURN NUMBER;
end PKG_USER_TODO_INFO;

/

