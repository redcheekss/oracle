create type TYPE_EXPENSES_INFO as object
(
-- Author  : cuiqingchao
-- Created : 2020/4/1 15:12:45
-- Purpose : 

-- Attributes
  expensesId            char(32), --                        费用报销单id
  expensesType          number(1), --                  报销单类型(0:差旅费用报销;1:招待费用报销;2:其他;3:市内交通费用报销)
  expensesUserId        char(32), --                   报销人id
  expensesUserName      varchar2(20), --                   报销人姓名
  expensesUserTel       varchar2(20), --                   报销人联系方式
  deptId                char(32), --                  报销人部门id
  deptName              varchar2(20), --                   部门名称
  top1DeptId            char(32), --                  报销部门的上一级部门（只用于固化报销时的部门）
  top2DeptId            char(32), --                   报销部门的上二级部门（只用于固化报销时的部门）
  top3DeptId            char(32), --                   报销部门的上三级部门（只用于固化报销时的部门）
  top4DeptId            char(32), --                  报销部门的上四级部门（只用于固化报销时的部门）
  deptFullName          varchar2(50), --                  部门完整名称（只用于固化报销时的部门）
  positionId            char(32), --                  报销人岗位id
  positionName          varchar2(20), --                   报销人岗位名称
  lkCorpId              char(32), --                   申请报销的公司主体id（申请人向这个主题申请报销）
  expensesReason        varchar2(50), --                   费用事由（放入子表）
  projectId             char(32), --                 费用所属项目id
  projectName           varchar2(20), --                 费用所属项目名称
  borrowedFee           number(10, 2), --                  已借款金额--之前已借出的金额
  totalFee              number(10, 2), --                 报销单总报销费用
  payableFee            number(10, 2), --                  计算得出的应付款-=总报销款-已借款
  expensesNo            char(11), --                  报销单号
  barCode               char(16), --                  报销单条形码
  repayFlag             number(1), --                 报销人指定报销金额是否用来还款(0:否:1:是)
  repayType             number(1), --                  报销人申请还款类型(0:个人借款;1:备用金)
  repayAmount           number(10, 2), --                 报销人申请还款金额
  inputTime             date, --                 填报日期
  rejectTime            date, --                  驳回日期(部门)（作废）
  rejectUserId          char(32), --                 驳回人id(部门)（作废）
  rejectUserName        varchar2(20), --                 驳回人(部门)（作废）
  rejectRemark          varchar2(200), --                  驳回理由(部门)（作废）
  updateTime            date, --                  更新日期
  updateUserId          char(32), --                  更新用户id
  status                number(1), --        0        审批状态(0:待申请;1:已申请;2.已审批;3.已审核;4.已支付(线下支付/网银支付状态):5:已撤回;6.已冲账;-1:已驳回,-2:已作废)
  approvalAvoidFlag     number(1), --        0        审批人跨两级部门时是否跳过审批(0:需要审批;1:不需要审批)
  financeStatus         number(1), --                  财务审批流状态(0:驳回后重新审批1:已审批;2:通知已发送;3:通知已确认;-1:通知已拒绝-2:已驳回:-3:出纳已驳回)
  currentLevel          number(1), --                 当前审批级别 (作废）
  paidFee               number(10, 2), --                  财务实际报销的金额(不大于应付款)
  payLkCorpId           char(32), --                  财务付款使用的我司主体id（财务给报销人支付）
  ebankPayStatus        number(1), --                 财务付款时的网银支付状态(默认:待支付;1:受理中;2:已支付;-1:支付失败)（财务给报销人支付）
  paymentFlowNo         varchar2(30), --                 财务付款流水编号(以支付流水编号前缀开头)(生成规则:报销单号+支付日期)（财务给报销人支付）
  paymentFlowNoPrefix   varchar2(5), --                  财务付款流水编号前缀（财务给报销人支付）
  bankFlowNo            varchar2(50), --                  财务付款银行流水编号（财务给报销人支付）
  paymentFee            number(10, 2), --                 财务付款银行支付金额（财务给报销人支付）
  paymentFailedReason   varchar2(100), --                  财务付款银行支付失败原因（银行返回）
  paymentAccountNo      varchar2(50), --                  我司主体付款账户
  paymentUserId         char(32), --                  付款人用户id
  paymentDate           date, --                 付款时间
  paymentPurpose        varchar2(50), --                 付款用途
  recordFlag            number(1), --        0        是否入账(0:否;1:是)（只是一个财务入账标记）
  recordTime            date, --                 验收入账时间
  checkFlag             number(1), --         0        是否核查(0:否;1:是)（只是一个财务核查标记）
  checkRemark           varchar2(200), --                 核查备注
  checkTime             date, --                 核查时间
  checkUserId           char(32), --                 核查用户id
  noticePayableFee      number(10, 2), --                 通知应报金额(报销异议实际应报金额)
  noticeStatus          number(1), --                 通知状态(1:已发送待确认;2:通知已确认;-1:通知已拒绝)(为空无确认动作)（通知报销人有问题被驳回）
  noticeRemark          varchar2(100), --                 通知备注(最新的一次)
  disabledFlag          number(1), --   y         0        报销单状态(0:未报废1:已报废)
  lastInvalidUserid     char(32), --   y                  最后一次作废人id
  lastInvalidDate       date, --  y                  最后一次作废时间
  lastInvalidMemo       varchar2(100), -- y                  最后一次作废备注
  financeRejectReson    varchar2(400), -- y                  驳回理由(财务)
  financeRejectDate     date, -- y                  驳回日期(财务)
  financeRejectUserId   char(32), -- y                  驳回人id(财务)
  financeRejectUserName varchar2(20), --  y                  驳回人(财务) 
  invalidStatus         number(1), -- y                  作废处理状态(1:已发送待确认;2:已确认;-1:已拒绝)(为空无确认动作)
  exMemo                varchar2(300), --  y                  异常手动处理备注

  expensesItemList      lcbase.type_expenses_item_list      --报销单明细       
)
/

