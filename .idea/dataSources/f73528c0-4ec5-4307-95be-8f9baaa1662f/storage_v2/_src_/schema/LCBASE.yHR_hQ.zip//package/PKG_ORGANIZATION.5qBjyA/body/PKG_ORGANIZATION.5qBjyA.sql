create package body PKG_ORGANIZATION is
    FUNCTION Insert_Organization(pOrganizations  IN TYP_ORGANIZATION_LIST,
                                 Organization_Id OUT VARCHAR2)
        RETURN NUMBER IS
        ErrCode       number(6);
        ErrMsg        varchar2(1000);
        P_ID          CHAR(32);
        pOrganization TYP_ORGANIZATION_INFO;
    begin
        begin
            P_ID          := LOWER(SYS_GUID());
            pOrganization := pOrganizations(0);
            INSERT INTO LCBASE.T_ORGANIZATION
                (c_organization_id,
                 v_organization_name,
                 c_organization_parent_id,
                 n_organization_level,
                 n_organization_type,
                 c_organization_owner,
                 n_status,
                 v_organization_abbname)
            VALUES
                (P_ID,
                 pOrganization.v_organization_name,
                 pOrganization.c_organization_parent_id,
                 pOrganization.n_organization_level,
                 pOrganization.n_organization_type,
                 pOrganization.c_organization_owner,
                 pOrganization.n_status,
                 pOrganization.v_organization_abbname);
            Organization_Id := P_ID;
            commit;
            return 0;
        EXCEPTION
            WHEN ACCESS_INTO_NULL THEN
                ErrCode := -20001;
                ErrMsg  := '数据不能为空';
            WHEN CASE_NOT_FOUND THEN
                ErrCode := -20002;
                ErrMsg  := '没有找到数据';
            WHEN NO_DATA_FOUND THEN
                ErrCode := -20003;
                ErrMsg  := '没有找到数据' || ',' ||
                           DBMS_UTILITY.format_error_backtrace;
            WHEN INVALID_NUMBER THEN
                ErrCode := -20004;
                ErrMsg  := '无效数字' || ',' ||
                           DBMS_UTILITY.format_error_backtrace;
            WHEN VALUE_ERROR THEN
                ErrCode := -20005;
                ErrMsg  := '数据错误' || ',' ||
                           DBMS_UTILITY.format_error_backtrace;
            WHEN OTHERS THEN
                ErrCode := -20099;
                ErrMsg  := '新增/更新组织信息失败: ' || SQLCODE || ',' ||
                           SQLERRM || ',' ||
                           DBMS_UTILITY.format_error_backtrace;
        end;
        rollback;
        RAISE_APPLICATION_ERROR(ErrCode, ErrMsg);
    end;

    FUNCTION Update_Organization(POrganizationInfo IN VARCHAR2,
                                 OperationUserId   IN VARCHAR2,
                                 Organization_Id   IN OUT VARCHAR2,
                                 ErrMsg            OUT VARCHAR2)
        RETURN NUMBER IS
        DATAARR  PKG_COMMON.ARR_LONGSTR;
        P_ID     CHAR(32);
        P_STEP   NUMBER(2);
        P_CNT    NUMBER(3);
        P_OPTYPE NUMBER(1) := 1;
    BEGIN
        BEGIN
            P_STEP  := 0;
            DATAARR := PKG_COMMON.Split(POrganizationInfo,
                                        '^');
            P_ID    := LOWER(SYS_GUID());
            P_CNT   := my_tabcolscount('t_organization');
        
            IF Organization_Id IS NULL THEN
                P_OPTYPE := 2;
            else
                P_OPTYPE := 3;
            end if;
        
            if P_CNT <> DATAARR.count then
                ErrMsg := '待导入数据项与数据表字段项不符:' || '数据项个数=' ||
                          DATAARR.count || ',数据表字段项个数=' ||
                          P_CNT;
                DBMS_OUTPUT.put_line(ErrMsg);
                lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                                     't_organization',
                                                     P_OPTYPE,
                                                     0);
                return - 1;
            end if;
            IF Organization_Id IS NULL THEN
                INSERT INTO LCBASE.T_ORGANIZATION
                    (c_organization_id,
                     v_organization_name,
                     c_organization_parent_id,
                     n_organization_level,
                     n_organization_type,
                     c_organization_owner,
                     n_status,
                     v_organization_abbname)
                VALUES
                    (P_ID,
                     DATAARR(2),
                     DATAARR(3),
                     DATAARR(4),
                     DATAARR(5),
                     DATAARR(6),
                     DATAARR(7),
                     DATAARR(8));
                Organization_Id := P_ID;
            ELSE
                UPDATE LCBASE.T_ORGANIZATION
                   SET v_organization_name      = DATAARR(2),
                       c_organization_parent_id = DATAARR(3),
                       n_organization_level     = DATAARR(4),
                       n_organization_type      = DATAARR(5),
                       c_organization_owner     = DATAARR(6)
                       --        ,n_status                              = DATAARR(7)
                      ,
                       v_organization_abbname = DATAARR(8)
                 WHERE c_organization_id = Organization_Id;
            END IF;
            COMMIT;
            lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                                 't_organization',
                                                 P_OPTYPE,
                                                 1);
            RETURN 0;
        EXCEPTION
            WHEN ACCESS_INTO_NULL THEN
                ErrMsg := '数据不能为空';
            WHEN CASE_NOT_FOUND THEN
                ErrMsg := '没有找到数据';
            WHEN NO_DATA_FOUND THEN
                ErrMsg := '没有找到数据' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN INVALID_NUMBER THEN
                ErrMsg := '无效数字' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN VALUE_ERROR THEN
                ErrMsg := '数据错误' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN OTHERS THEN
                ErrMsg := '新增/更新组织信息失败: ' || P_STEP || ',' ||
                          SQLCODE || ',' || SQLERRM || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
        END;
        ROLLBACK;
        lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                             't_organization',
                                             P_OPTYPE,
                                             0);
        return - 1;
    END;

    FUNCTION Delete_Organization(Organization_Id IN VARCHAR2,
                                 OperationUserId IN VARCHAR2,
                                 ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
        P_OPTYPE NUMBER(1) := 4;
    BEGIN
        BEGIN
            UPDATE LCBASE.T_ORGANIZATION
               SET n_status = 1
             WHERE c_organization_id = Organization_Id;
            COMMIT;
        
            lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                                 't_organization',
                                                 P_OPTYPE,
                                                 1);
            RETURN 0;
        EXCEPTION
            WHEN ACCESS_INTO_NULL THEN
                ErrMsg := '数据不能为空';
            WHEN CASE_NOT_FOUND THEN
                ErrMsg := '没有找到数据';
            WHEN NO_DATA_FOUND THEN
                ErrMsg := '没有找到数据' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN INVALID_NUMBER THEN
                ErrMsg := '无效数字' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN VALUE_ERROR THEN
                ErrMsg := '数据错误' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN OTHERS THEN
                ErrMsg := '删除组织信息失败: ' || SQLCODE || ',' ||
                          SQLERRM || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
        END;
        ROLLBACK;
        lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                             't_organization',
                                             P_OPTYPE,
                                             0);
        RETURN - 1;
    END;

    FUNCTION Get_OrganizationAlone(Organization_Id IN VARCHAR2,
                                   OperationUserId IN VARCHAR2,
                                   CUR_DATA        OUT SYS_REFCURSOR,
                                   ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT *
              FROM t_organization
             WHERE c_organization_id = Organization_Id;
        lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                             't_organization',
                                             1,
                                             1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                                 't_organization',
                                                 1,
                                                 0);
            RETURN - 1;
    END;

    FUNCTION Get_OrganizationUpward(Organization_Id IN VARCHAR2,
                                    OperationUserId IN VARCHAR2,
                                    CUR_DATA        OUT SYS_REFCURSOR,
                                    ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT *
              FROM t_organization t
             start with t.c_organization_id =
                        Organization_Id
            connect by prior t.c_organization_parent_id =
                        t.c_organization_id;
    
        lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                             't_organization',
                                             1,
                                             1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                                 't_organization',
                                                 1,
                                                 0);
            RETURN - 1;
    END;

    FUNCTION Get_OrganizationUpwardTest(Organization_Id IN VARCHAR2,
                                        OperationUserId IN VARCHAR2,
                                        CUR_DATA        OUT SYS_REFCURSOR,
                                        ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT *
              FROM t_organization t
             start with t.c_organization_id =
                        Organization_Id
            connect by prior t.c_organization_parent_id =
                        t.c_organization_id;
    
        lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                             't_organization',
                                             1,
                                             1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                                 't_organization',
                                                 1,
                                                 0);
            RAISE_APPLICATION_ERROR(50000,
                                    '查询数据失败: ');
            RETURN - 1;
    END;

    FUNCTION Get_OrganizationDownward(Organization_Id IN VARCHAR2,
                                      OperationUserId IN VARCHAR2,
                                      CUR_DATA        OUT SYS_REFCURSOR,
                                      ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT t.c_organization_id        as "organizationId",
                   t.v_organization_name      as "organizationName",
                   t.c_organization_parent_id as "organizationParentId",
                   t.n_organization_level     as "organizationLevel",
                   t.n_organization_type      as "organizationType",
                   t.c_organization_owner     as "organizationOwner",
                   t.n_status                 as "status",
                   t.v_organization_abbname   as "organizationAbbname",
                   t.c_organization_bp        as "organizationBp",
                   t.n_order                  as "order"
              FROM t_organization t
             where t.n_status = 0
             start with t.c_organization_id =
                        Organization_Id
            connect by t.c_organization_parent_id = prior
                       t.c_organization_id
                   and t.n_status = 0;
        lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                             't_organization',
                                             1,
                                             1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                                 't_organization',
                                                 1,
                                                 0);
            RETURN - 1;
    END;

end PKG_ORGANIZATION;
/

