create package body PKG_ORGANIZATION is
/*    FUNCTION Insert_Organization(pOrganizations  IN TYP_ORGANIZATION_LIST,
                                 Organization_Id OUT VARCHAR2)
        RETURN NUMBER IS
        ErrCode       number(6);
        ErrMsg        varchar2(1000);
        P_ID          CHAR(32);
        pOrganization TYP_ORGANIZATION_INFO;
    begin
        begin
            P_ID          := LOWER(SYS_GUID());
            pOrganization := pOrganizations(0);
            INSERT INTO LCBASE.T_ZIP_ORGANIZATION
                (c_organization_id,
                 v_organization_name,
                 c_organization_parent_id,
                 n_organization_level,
                 n_organization_type,
                 c_organization_owner,
                 n_status,
                 v_organization_abbname)
            VALUES
                (P_ID,
                 pOrganization.v_organization_name,
                 pOrganization.c_organization_parent_id,
                 pOrganization.n_organization_level,
                 pOrganization.n_organization_type,
                 pOrganization.c_organization_owner,
                 pOrganization.n_status,
                 pOrganization.v_organization_abbname);
            Organization_Id := P_ID;
            commit;
            return 0;
        EXCEPTION
            WHEN ACCESS_INTO_NULL THEN
                ErrCode := -20001;
                ErrMsg  := '数据不能为空';
            WHEN CASE_NOT_FOUND THEN
                ErrCode := -20002;
                ErrMsg  := '没有找到数据';
            WHEN NO_DATA_FOUND THEN
                ErrCode := -20003;
                ErrMsg  := '没有找到数据' || ',' ||
                           DBMS_UTILITY.format_error_backtrace;
            WHEN INVALID_NUMBER THEN
                ErrCode := -20004;
                ErrMsg  := '无效数字' || ',' ||
                           DBMS_UTILITY.format_error_backtrace;
            WHEN VALUE_ERROR THEN
                ErrCode := -20005;
                ErrMsg  := '数据错误' || ',' ||
                           DBMS_UTILITY.format_error_backtrace;
            WHEN OTHERS THEN
                ErrCode := -20099;
                ErrMsg  := '新增/更新组织信息失败: ' || SQLCODE || ',' ||
                           SQLERRM || ',' ||
                           DBMS_UTILITY.format_error_backtrace;
        end;
        rollback;
        RAISE_APPLICATION_ERROR(ErrCode, ErrMsg);
    end;*/

    FUNCTION Update_Organization(POrganizationInfo IN VARCHAR2,
                                 OperationUserId   IN VARCHAR2,
                                 Organization_Id   IN OUT VARCHAR2,
                                 ErrMsg            OUT VARCHAR2)
        RETURN NUMBER IS
    DATAARR      PKG_COMMON.ARR_LONGSTR;
    P_ID         CHAR(32);
    P_STEP       NUMBER(2);
    P_CNT        NUMBER(3);
    P_OPTYPE     NUMBER(1) := 1;
    current_time Date;
    update_count Date;
  BEGIN
    BEGIN
      current_time := sysdate;
      P_STEP       := 0;
      DATAARR      := PKG_COMMON.Split(POrganizationInfo, '^');
      P_ID         := LOWER(SYS_GUID());
      P_CNT        := my_tabcolscount('lcbase.t_organization');
    
      IF Organization_Id IS NULL THEN
        P_OPTYPE := 2;
      else
        P_OPTYPE := 3;
      end if;
    
      lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                         'lcbase.t_organization',
                                         P_OPTYPE,
                                         0);
      return - 1;
      --判断是否是当天首次修改
      --查最新数据的起始时间是否是当天
      begin
        select D_STARTDATE
          into update_count
          from lcbase.t_zip_organization
         where C_ORGANIZATION_ID = DATAARR(2)
           and trunc(D_startdate) = trunc(sysdate);
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          update_count := NULL;
      end;
    
      IF Organization_Id IS NULL THEN
        INSERT INTO LCBASE.T_zip_ORGANIZATION
          (d_startdate,
           d_enddate,
           c_organization_id,
           v_organization_name,
           c_organization_parent_id,
           n_organization_level,
           n_organization_type,
           c_organization_owner,
           n_status,
           v_organization_abbname)
        VALUES
          (sysdate,
           to_date('9999-12-31', 'yyyy-mm-dd'),
           P_ID,
           DATAARR(2),
           DATAARR(3),
           DATAARR(4),
           DATAARR(5),
           DATAARR(6),
           DATAARR(7),
           DATAARR(8));
        Organization_Id := P_ID;
      ELSE
        --判断开始 if起始日期是当天，则不是当天首次修改 直接修改最新记录
        if trunc(update_count) = trunc(current_time) then
          UPDATE LCBASE.T_zip_ORGANIZATION
             SET v_organization_name      = DATAARR(2),
                 c_organization_parent_id = DATAARR(3),
                 n_organization_level     = DATAARR(4),
                 n_organization_type      = DATAARR(5),
                 c_organization_owner     = DATAARR(6)
                 --        ,n_status                              = DATAARR(7)
                ,
                 v_organization_abbname = DATAARR(8)
           WHERE c_organization_id = Organization_Id
             and D_ENDDATE > sysdate;
        else
          --更新原始数据有效期时间
          UPDATE lcbase.t_zip_organization o
             SET D_ENDDATE = current_time
           WHERE o.c_organization_id = Organization_Id
             and D_ENDDATE > sysdate;
        
          --新增开始
          insert into lcbase.t_zip_organization o
            (select sysdate,
                    to_date('9999-12-31', 'yyyy-mm-dd'),
                    o.c_organization_id,
                    o.v_organization_name,
                    o.c_organization_parent_id,
                    o.n_organization_level,
                    o.n_organization_type,
                    o.c_organization_owner,
                    o.n_status,
                    o.v_organization_abbname,
                    o.c_organization_bp,
                    o.n_order,
                    o.c_organization_po
               from lcbase.t_zip_organization o
              where C_ORGANIZATION_ID = DATAARR(2)
                and D_ENDDATE = current_time);
        
          --更新最新记录
          update lcbase.t_zip_organization
             SET v_organization_name      = DATAARR(2),
                 c_organization_parent_id = DATAARR(3),
                 n_organization_level     = DATAARR(4),
                 n_organization_type      = DATAARR(5),
                 c_organization_owner     = DATAARR(6)
                 --        ,n_status                              = DATAARR(7)
                ,
                 v_organization_abbname = DATAARR(8),
                 D_STARTDATE            = sysdate,
                 D_ENDDATE              = to_date('9999-12-31', 'yyyy-mm-dd')
           WHERE C_ORGANIZATION_ID = DATAARR(2)
             and D_ENDDATE > sysdate;
        
        end if;
      END IF;
      COMMIT;
      lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                         'lcbase.t_organization',
                                         P_OPTYPE,
                                         1);
      RETURN 0;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据' || ',' || DBMS_UTILITY.format_error_backtrace;
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字' || ',' || DBMS_UTILITY.format_error_backtrace;
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误' || ',' || DBMS_UTILITY.format_error_backtrace;
      WHEN OTHERS THEN
        ErrMsg := '新增/更新组织信息失败: ' || P_STEP || ',' || SQLCODE || ',' ||
                  SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
    END;
    ROLLBACK;
    lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                       'lcbase.t_organization',
                                       P_OPTYPE,
                                       0);
    return - 1;
  END;

    FUNCTION Delete_Organization(Organization_Id IN VARCHAR2,
                                 OperationUserId IN VARCHAR2,
                                 ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
        P_OPTYPE NUMBER(1) := 4;
    BEGIN
        BEGIN
            UPDATE LCBASE.T_ZIP_ORGANIZATION
               SET n_status = 1
             WHERE c_organization_id = Organization_Id
            and D_ENDDATE > sysdate;
            COMMIT;
        
            lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                                 't_organization',
                                                 P_OPTYPE,
                                                 1);
            RETURN 0;
        EXCEPTION
            WHEN ACCESS_INTO_NULL THEN
                ErrMsg := '数据不能为空';
            WHEN CASE_NOT_FOUND THEN
                ErrMsg := '没有找到数据';
            WHEN NO_DATA_FOUND THEN
                ErrMsg := '没有找到数据' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN INVALID_NUMBER THEN
                ErrMsg := '无效数字' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN VALUE_ERROR THEN
                ErrMsg := '数据错误' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
            WHEN OTHERS THEN
                ErrMsg := '删除组织信息失败: ' || SQLCODE || ',' ||
                          SQLERRM || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
        END;
        ROLLBACK;
        lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                             't_organization',
                                             P_OPTYPE,
                                             0);
        RETURN - 1;
    END;

    FUNCTION Get_OrganizationAlone(Organization_Id IN VARCHAR2,
                                   OperationUserId IN VARCHAR2,
                                   CUR_DATA        OUT SYS_REFCURSOR,
                                   ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT *
              FROM t_zip_organization
             WHERE c_organization_id = Organization_Id and d_enddate > sysdate;
        lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                             't_organization',
                                             1,
                                             1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                                 't_organization',
                                                 1,
                                                 0);
            RETURN - 1;
    END;

    FUNCTION Get_OrganizationUpward(Organization_Id IN VARCHAR2,
                                    OperationUserId IN VARCHAR2,
                                    CUR_DATA        OUT SYS_REFCURSOR,
                                    ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT *
              FROM (
		SELECT
			*
		FROM
			LCBASE.T_ZIP_ORGANIZATION
		WHERE
			D_ENDDATE > SYSDATE) t
             start with t.c_organization_id =
                        Organization_Id
            connect by prior t.c_organization_parent_id =
                        t.c_organization_id;
    
        lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                             't_organization',
                                             1,
                                             1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                                 't_organization',
                                                 1,
                                                 0);
            RETURN - 1;
    END;

    FUNCTION Get_OrganizationUpwardTest(Organization_Id IN VARCHAR2,
                                        OperationUserId IN VARCHAR2,
                                        CUR_DATA        OUT SYS_REFCURSOR,
                                        ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT *
              FROM (
		SELECT
			*
		FROM
			LCBASE.T_ZIP_ORGANIZATION
		WHERE
			D_ENDDATE > SYSDATE) t
             start with t.c_organization_id =
                        Organization_Id
            connect by prior t.c_organization_parent_id =
                        t.c_organization_id;
    
        lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                             't_organization',
                                             1,
                                             1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                                 't_organization',
                                                 1,
                                                 0);
            RAISE_APPLICATION_ERROR(50000,
                                    '查询数据失败: ');
            RETURN - 1;
    END;

    FUNCTION Get_OrganizationDownward(Organization_Id IN VARCHAR2,
                                      OperationUserId IN VARCHAR2,
                                      CUR_DATA        OUT SYS_REFCURSOR,
                                      ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
    BEGIN
        OPEN CUR_DATA FOR
            SELECT t.c_organization_id        as "organizationId",
                   t.v_organization_name      as "organizationName",
                   t.c_organization_parent_id as "organizationParentId",
                   t.n_organization_level     as "organizationLevel",
                   t.n_organization_type      as "organizationType",
                   t.c_organization_owner     as "organizationOwner",
                   t.n_status                 as "status",
                   t.v_organization_abbname   as "organizationAbbname",
                   t.c_organization_bp        as "organizationBp",
                   t.n_order                  as "order"
              FROM (
		SELECT
			*
		FROM
			LCBASE.T_ZIP_ORGANIZATION
		WHERE
			D_ENDDATE > SYSDATE) t
             where t.n_status = 0
             start with t.c_organization_id =
                        Organization_Id
            connect by t.c_organization_parent_id = prior
                       t.c_organization_id
                   and t.n_status = 0;
        lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                             't_organization',
                                             1,
                                             1);
        return 0;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                      SQLERRM || ',' ||
                      DBMS_UTILITY.format_error_backtrace;
            lcbase.pkg_common.InsertOperationLog(OperationUserId,
                                                 't_organization',
                                                 1,
                                                 0);
            RETURN - 1;
    END;

end PKG_ORGANIZATION;
/

