create PACKAGE BODY PKG_BASEDICT AS
	FUNCTION Get_WorkPlaceList(
					CUR_DATA OUT SYS_REFCURSOR,
					ErrMsg   OUT VARCHAR2) RETURN NUMBER IS
	BEGIN
	  OPEN CUR_DATA FOR
		select N_AD_CODE,V_CNAME from t_sys_ad_code t where substr(t.n_ad_code,5,2)='00';
	  return 0;
	EXCEPTION
	  WHEN OTHERS THEN
		ErrMsg := '查询工作地址列表失败: ' || SQLCODE || ',' || SQLERRM || ',' ||
				  DBMS_UTILITY.format_error_backtrace;
		RETURN - 1;
	END;

	FUNCTION Get_NationList(
					CUR_DATA OUT SYS_REFCURSOR,
					ErrMsg   OUT VARCHAR2) RETURN NUMBER IS
	BEGIN
	  OPEN CUR_DATA FOR
		select t.n_nation_id,t.v_nation_name from t_sys_nation t order by t.n_nation_id;
	  return 0;
	EXCEPTION
	  WHEN OTHERS THEN
		ErrMsg := '查询民族列表失败: ' || SQLCODE || ',' || SQLERRM || ',' ||
				  DBMS_UTILITY.format_error_backtrace;
		RETURN - 1;
	END;
END PKG_BASEDICT;

/

