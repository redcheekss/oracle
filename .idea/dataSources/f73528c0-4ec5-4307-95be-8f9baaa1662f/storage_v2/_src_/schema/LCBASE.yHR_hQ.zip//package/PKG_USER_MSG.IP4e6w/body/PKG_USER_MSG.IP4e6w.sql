create PACKAGE BODY PKG_USER_MSG AS

  FUNCTION Insert_UserMsgFeed(
						PUserMsgFeed    IN VARCHAR2,
						OperationUserId IN VARCHAR2,
						MsgFeedId 		out varchar2,
						ErrMsg			out VARCHAR2
						) return number is
  DATAARR  PKG_COMMON.ARR_LONGSTR;
  P_ID     CHAR(32);
  n_optype number(1);
  n_result number(1) := 0;
  time_start timestamp;
  time_end timestamp;
  n_duration number(10);
  errcode  number(6) := 0;
  P_CNT number(6);
begin
  time_start := systimestamp;
  
	begin
		DATAARR := PKG_COMMON.Split(PUserMsgFeed, '^');
		P_ID    := LOWER(SYS_GUID());
		n_optype := 2;

    P_CNT := my_tabcolscount('T_USER_MSG_FEED');
    if P_CNT <> DATAARR.count then
      ErrMsg := '传入数据项与实际需求不符:' || '数据项个数=' || DATAARR.count || ',实际需求个数=' || P_CNT;
      raise pkg_common.EXP_PARAM;
    end if;
    
--    dbms_lock.sleep(0.01);
		insert into T_USER_MSG_FEED
		(
		C_FEED_ID,
		C_MSG_ID,
		V_FEED_CONTENT,
		C_FEED_USER_ID,
		V_FEED_USER_NAME,
		D_FEED_TIME,
		C_PRE_FEED_ID,
		C_PRE_USER_ID,
		V_PRE_USER_NAME,
		N_SIGNATURE_TYPE
		)
    values
      (P_ID,
       DATAARR(2),
       DATAARR(3),
       DATAARR(4),
       DATAARR(5),
       to_date(DATAARR(6),'yyyy-mm-dd hh24:mi:ss'),
       DATAARR(7),
       DATAARR(8),
       DATAARR(9),
       DATAARR(10)
		);
    MsgFeedId := P_ID;
		n_result := 0;
    commit;
	EXCEPTION
      WHEN PKG_COMMON.EXP_PARAM THEN
        errcode := -20001;
        n_result := 1;
      WHEN OTHERS THEN
        ErrMsg := '新增用户消息评论信息异常: ' || SQLCODE || ',' ||
                  SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := 1;
        errcode := -20999;
		    ROLLBACK;
	end;
  time_end := systimestamp;
  n_duration := uf_timestamp_diff(time_end, time_start);
	PKG_COMMON.InsertOperationLog( OperationUserId,
                                 'T_USER_MSG_FEED',
                                 n_optype,
                                 n_result,
                                 n_duration);

	if n_result = 0 then
		return 0;
	end if;
	return errcode;
end;

  FUNCTION Update_UserMsgFeed(
						PUserMsgFeed    IN VARCHAR2,
            OperationUserId IN VARCHAR2,
            ErrMsg      out VARCHAR2
						) RETURN NUMBER IS
  DATAARR  PKG_COMMON.ARR_LONGSTR;
  P_ID     CHAR(32);
  n_optype number(1);
  n_result number(1) := 0;
  time_start timestamp;
  time_end timestamp;
  n_duration number(10);
  errcode  number(6) := 0;
  P_CNT number(6);
    
  BEGIN
    time_start := systimestamp;
    BEGIN
      DATAARR := PKG_COMMON.Split(PUserMsgFeed, '^');
      P_ID    := LOWER(SYS_GUID());
      n_optype := 3;

      P_CNT := my_tabcolscount('T_USER_MSG_FEED');
      if P_CNT <> DATAARR.count then
        ErrMsg := '传入数据项与实际需求不符:' || '数据项个数=' || DATAARR.count || ',实际需求个数=' || P_CNT;
        raise pkg_common.EXP_PARAM;
      end if;
      
      P_ID := LOWER(DATAARR(1));
      
      UPDATE T_USER_MSG_FEED
         SET 
          C_MSG_ID = DATAARR(2),
          V_FEED_CONTENT = DATAARR(3),
          C_FEED_USER_ID = DATAARR(4),
          V_FEED_USER_NAME = DATAARR(5),
          D_FEED_TIME = to_date(DATAARR(6),'yyyy-mm-dd hh24:mi:ss'),
          C_PRE_FEED_ID = DATAARR(7),
          C_PRE_USER_ID = DATAARR(8),
          V_PRE_USER_NAME = DATAARR(9),
          N_SIGNATURE_TYPE = DATAARR(10)         
       WHERE C_FEED_ID = P_ID;

      n_result := 0;
      COMMIT;
    EXCEPTION
      WHEN PKG_COMMON.EXP_PARAM THEN
        errcode := -20001;
      WHEN OTHERS THEN
        ErrMsg := '更新用户消息评论信息异常: ' || SQLCODE || ',' ||
                  SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        errcode := -20999;
        ROLLBACK;
    END;
    
    time_end := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    PKG_COMMON.InsertOperationLog( OperationUserId,
                                   'T_USER_MSG_FEED',
                                   n_optype,
                                   n_result,
                                   n_duration);

    if n_result = 0 then
      return 0;
    end if;
    return errcode;
  END;
  
  FUNCTION Update_UserMsgReaded(
            MsgId           IN VARCHAR2,
            OperationUserId IN VARCHAR2,
            ErrMsg          OUT VARCHAR2
            ) return number IS
  n_optype number(1);
  n_result number(1) := 0;
  time_start timestamp;
  time_end timestamp;
  n_duration number(10);
  errcode  number(6) := 0;
  nReadFlag number(1);  
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      
      if MsgId is null then
        ErrMsg := 'MsgId不能为空.';
        raise pkg_common.EXP_PARAM;
      end if;
      
      select n_read_flag into nReadFlag from t_user_msg_info where C_MSG_ID = MsgId;
      if nReadFlag = 1 then
        ErrMsg := '该消息已读状态，无需重复操作.';
        raise PKG_COMMON.EXP_CHECK;
      elsif nReadFlag <> 0 then
        ErrMsg := '该消息已读状态非法Flag=[' || nReadFlag || ']';
        raise PKG_COMMON.EXP_CHECK;
      end if;
      
      UPDATE T_USER_MSG_INFO
         SET n_read_flag = 1,
         d_update_time = sysdate
       WHERE C_MSG_ID = MsgId;

      n_result := 0;
      COMMIT;
    EXCEPTION
      WHEN PKG_COMMON.EXP_PARAM THEN
        errcode := -20001;
      WHEN PKG_COMMON.EXP_CHECK THEN
        errcode := -20002;
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
        errcode := -20002;
        ROLLBACK;
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到指定消息ID[' || MsgId || ']的数据.';
        errcode := -20002;
        ROLLBACK;
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字' || ',' || DBMS_UTILITY.format_error_backtrace;
        errcode := SQLCODE;
        ROLLBACK;
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误' || ',' || DBMS_UTILITY.format_error_backtrace;
        errcode := SQLCODE;
        ROLLBACK;
      WHEN OTHERS THEN
        ErrMsg := '更新用户消息已读状态异常: ' || SQLCODE || ',' ||
                  SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        errcode := -20999;
        ROLLBACK;
    END;
    if errcode <> 0 then 
      n_result := 1;
    end if;
    time_end := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    PKG_COMMON.InsertOperationLog( OperationUserId,
                                   'T_USER_MSG_INFO',
                                   n_optype,
                                   n_result,
                                   n_duration);

    if n_result = 0 then
      return 0;
    end if;
    return errcode;
  END;  
  FUNCTION Update_UserMsgTop(
            PNewsInfo          IN VARCHAR2,
            OperationUserId IN VARCHAR2,
            ErrMsg          OUT VARCHAR2
            ) return number IS
  DATAARR  PKG_COMMON.ARR_LONGSTR;
  n_optype number(1);
  n_result number(1) := 0;
  time_start timestamp;
  time_end timestamp;
  n_duration number(10);
  errcode  number(6) := 0;
  nIsTopFlag number(1);
  nNewsType number(1);
  NewsId char(32);
  IsTopFlag number(1);
  P_CNT number(6);
  BEGIN
    time_start := systimestamp;
    BEGIN
      n_optype := 3;
      DATAARR := PKG_COMMON.Split(PNewsInfo, '^');
      
      P_CNT := my_tabcolscount('t_User_Publish_Info');
      if P_CNT <> DATAARR.count then
        ErrMsg := '传入数据项与实际需求不符:' || '数据项个数=' || DATAARR.count || ',实际需求个数=' || P_CNT;
        raise pkg_common.EXP_PARAM;
      end if;
      NewsId := DATAARR(1);
      IsTopFlag := DATAARR(11);
      if NewsId is null then
        ErrMsg := 'NewsId不能为空.';
        raise pkg_common.EXP_PARAM;
      end if;
      if OperationUserId is null then
        ErrMsg := 'OperationUserId不能为空.';
        raise pkg_common.EXP_PARAM;
      end if;
      if IsTopFlag not in (0,1) then
        ErrMsg := 'IsTopFlag只能为0或1.';
        raise pkg_common.EXP_PARAM;
      end if;
      
      select n_istop_flag,n_news_type into nIsTopFlag,nNewsType from t_user_publish_info where C_NEWS_ID = NewsId;
      if nNewsType <> 1 then
        Errmsg := '只有公告才能置顶.';
        raise PKG_COMMON.EXP_CHECK;
      end if;
      if nIsTopFlag = IsTopFlag then
        ErrMsg := '该公告置顶状态与计划变更一致，无需操作.';
        raise PKG_COMMON.EXP_CHECK;
      end if;
      
      UPDATE t_user_publish_info
         SET n_istop_flag = IsTopFlag
       WHERE C_NEWS_ID = NewsId;

      n_result := 0;
      COMMIT;
    EXCEPTION
      WHEN PKG_COMMON.EXP_PARAM THEN
        errcode := -20001;
      WHEN PKG_COMMON.EXP_CHECK THEN
        errcode := -20002;
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
        errcode := -20002;
        ROLLBACK;
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到指定消息ID[' || NewsId || ']的数据.';
        errcode := -20002;
        ROLLBACK;
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字' || ',' || DBMS_UTILITY.format_error_backtrace;
        errcode := SQLCODE;
        ROLLBACK;
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误' || ',' || DBMS_UTILITY.format_error_backtrace;
        errcode := SQLCODE;
        ROLLBACK;
      WHEN OTHERS THEN
        ErrMsg := '设置公告置顶状态异常: ' || SQLCODE || ',' ||
                  SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        errcode := -20999;
        ROLLBACK;
    END;
    if errcode <> 0 then 
      n_result := 1;
    end if;
    time_end := systimestamp;
    n_duration := uf_timestamp_diff(time_end, time_start);
    PKG_COMMON.InsertOperationLog( OperationUserId,
                                   upper('t_user_publish_info'),
                                   n_optype,
                                   n_result,
                                   n_duration);

    if n_result = 0 then
      return 0;
    end if;
    return errcode;
  END;    
END PKG_USER_MSG;

/

