create package body PKG_EMPLOYEE is
  FUNCTION Update_Employee(
                       PEmployeeInfo       	   IN VARCHAR2,
                       OperationUserId         IN VARCHAR2,
                       Employee_Id             IN OUT VARCHAR2,
                       ErrMsg                  OUT VARCHAR2
                       ) RETURN NUMBER IS
    DATAARR PKG_COMMON.ARR_LONGSTR;
    P_ID    CHAR(32);
    P_STEP  NUMBER(2):=0;
    P_CNT   NUMBER(3):=0;
    P_OPTYPE NUMBER(1) := 1;
  BEGIN
    BEGIN
      DATAARR := PKG_COMMON.Split(PEmployeeInfo, '^');
      P_ID    := LOWER(SYS_GUID());

      IF Employee_Id IS NULL THEN
         P_OPTYPE := 2;
      else
         P_OPTYPE := 3;
      end if;

      P_CNT := my_tabcolscount('t_employees_info');
      DBMS_OUTPUT.put_line('P_CNT=' || P_CNT);
      if P_CNT <> DATAARR.count then
        ErrMsg := '待导入数据项与数据表字段项不符:' || '数据项个数=' || DATAARR.count || ',数据表字段项个数=' || P_CNT;
        DBMS_OUTPUT.put_line(ErrMsg);
        lcbase.pkg_common.InsertOperationLog(OperationUserId,'t_organization',P_OPTYPE,0);
        return -1;
      end if;
      IF Employee_Id IS NULL THEN
        insert into T_EMPLOYEES_INFO(
          C_USER_ID,
          N_WORK_PLACE,
          N_POSSESSION,
          V_USER_TITLE,
          C_ID_CARD_NUMBER,
          D_HIRE_DATE,
          N_POLITICAL_APPERAR,
          V_NATION,
          N_MARRIAGE,
          V_ID_CARD_ADDRESS,
          N_HU_KOU_TYPE,
          V_PRESENT_ADDRESS,
          V_URGENCY_LINK_MAN,
          V_URGENCY_LINK_TEL,
          V_COLLEGE,
          V_MAJOR,
          N_LEARNING,
          D_ENTRANCE,
          D_GRADUATION,
          N_HOBBIES,
          V_GRADES,
          D_PROMOTION,
          N_EDUCATION,
          V_BANK_CARD_NUMBER,
          V_ACCUMULATION_FUND_TYPE,
          V_OPENING_BANK,
          V_REMARK,
          N_SOCIAL_SECURITY_TYPE,
          D_LEAVE,
          N_WORK_NUM,
          N_WORK_NUM_OLD,
          C_LABOR_REF,
          N_STATUS) values(P_ID,
          DATAARR(2),
          DATAARR(3),
          DATAARR(4),
          DATAARR(5),
          DATAARR(6),
          DATAARR(7),
          DATAARR(8),
          DATAARR(9),
          DATAARR(10),
          DATAARR(11),
          DATAARR(12),
          DATAARR(13),
          DATAARR(14),
          DATAARR(15),
          DATAARR(16),
          DATAARR(17),
          DATAARR(18),
          DATAARR(19),
          DATAARR(20),
          DATAARR(21),
          DATAARR(22),
          DATAARR(23),
          DATAARR(24),
          DATAARR(25),
          DATAARR(26),
          DATAARR(27),
          DATAARR(28),
          DATAARR(29),
          DATAARR(30),
          DATAARR(31),
          DATAARR(32),
          DATAARR(33)
          );
        Employee_Id := P_ID;
      ELSE
        UPDATE LCBASE.T_Employees_Info
        SET
            N_WORK_PLACE = DATAARR(2),
            N_POSSESSION = DATAARR(3),
            V_USER_TITLE = DATAARR(4),
            C_ID_CARD_NUMBER = DATAARR(5),
            D_HIRE_DATE = DATAARR(6),
            N_POLITICAL_APPERAR = DATAARR(7),
            V_NATION = DATAARR(8),
            N_MARRIAGE = DATAARR(9),
            V_ID_CARD_ADDRESS = DATAARR(10),
            N_HU_KOU_TYPE = DATAARR(11),
            V_PRESENT_ADDRESS = DATAARR(12),
            V_URGENCY_LINK_MAN = DATAARR(13),
            V_URGENCY_LINK_TEL = DATAARR(14),
            V_COLLEGE = DATAARR(15),
            V_MAJOR = DATAARR(16),
            N_LEARNING = DATAARR(17),
            D_ENTRANCE = DATAARR(18),
            D_GRADUATION = DATAARR(19),
            N_HOBBIES = DATAARR(20),
            V_GRADES = DATAARR(21),
            D_PROMOTION = DATAARR(22),
            N_EDUCATION = DATAARR(23),
            V_BANK_CARD_NUMBER = DATAARR(24),
            V_ACCUMULATION_FUND_TYPE = DATAARR(25),
            V_OPENING_BANK = DATAARR(26),
            V_REMARK = DATAARR(27),
            N_SOCIAL_SECURITY_TYPE = DATAARR(28),
            D_LEAVE = DATAARR(29),
            N_WORK_NUM = DATAARR(30),
            N_WORK_NUM_OLD = DATAARR(31),
            C_LABOR_REF = DATAARR(32)
--            N_STATUS = DATAARR(33)
        WHERE c_user_id = Employee_Id;
      END IF;
      COMMIT;

      lcbase.pkg_common.InsertOperationLog(OperationUserId,'t_employees_info',P_OPTYPE,1);
      RETURN 0;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据' || ',' || DBMS_UTILITY.format_error_backtrace;
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字' || ',' || DBMS_UTILITY.format_error_backtrace;
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误' || ',' || DBMS_UTILITY.format_error_backtrace;
      WHEN OTHERS THEN
        ErrMsg := '新增/更新员工信息失败: ' || P_STEP || ',' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;

    END;
    ROLLBACK;
    lcbase.pkg_common.InsertOperationLog(OperationUserId,'t_employees_info',P_OPTYPE,0);
    RETURN - 1;
  END;

  FUNCTION Delete_Employee(
                       Employee_Id             IN VARCHAR2,
                       OperationUserId         IN VARCHAR2,
                       Employee_Status         IN NUMBER,
                       ErrMsg                  OUT VARCHAR2
                       ) RETURN NUMBER IS
  BEGIN
    BEGIN
      if NOT (Employee_Status > 0 AND Employee_Status < 5) then
        ErrMsg := '员工待删除状态只能为(1注销2离职3开除4淘汰)之一';
        DBMS_OUTPUT.put_line(ErrMsg);
        lcbase.pkg_common.InsertOperationLog(OperationUserId,'t_employees_info',4,0);
        return -1;
      end if;

      UPDATE LCBASE.T_Employees_Info
      SET n_status = Employee_Status
      WHERE c_user_id = Employee_Id;

      COMMIT;

      lcbase.pkg_common.InsertOperationLog(OperationUserId,'t_employees_info',4,1);
      RETURN 0;
    EXCEPTION
      WHEN ACCESS_INTO_NULL THEN
        ErrMsg := '数据不能为空';
      WHEN CASE_NOT_FOUND THEN
        ErrMsg := '没有找到数据';
      WHEN NO_DATA_FOUND THEN
        ErrMsg := '没有找到数据' || ',' || DBMS_UTILITY.format_error_backtrace;
      WHEN INVALID_NUMBER THEN
        ErrMsg := '无效数字' || ',' || DBMS_UTILITY.format_error_backtrace;
      WHEN VALUE_ERROR THEN
        ErrMsg := '数据错误' || ',' || DBMS_UTILITY.format_error_backtrace;
      WHEN OTHERS THEN
        ErrMsg := '删除员工信息失败: ' || SQLCODE || ',' || SQLERRM || ',' ||
                  DBMS_UTILITY.format_error_backtrace;

    END;
    ROLLBACK;
    lcbase.pkg_common.InsertOperationLog(OperationUserId,'t_employees_info',4,0);
    RETURN - 1;
  END;

  FUNCTION Get_Employee(
                       Employee_Id         IN VARCHAR2,
                       OperationUserId         IN VARCHAR2,
                       CUR_DATA                OUT SYS_REFCURSOR,
                       ErrMsg                  OUT VARCHAR2
                       ) RETURN NUMBER IS
  BEGIN
    OPEN CUR_DATA FOR
      SELECT * FROM t_employees_info WHERE c_user_id = Employee_Id;
    lcbase.pkg_common.InsertOperationLog(OperationUserId,'t_employees_info',1,1);
    return 0;
  EXCEPTION
    WHEN OTHERS THEN
      ErrMsg := '查询数据失败: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      lcbase.pkg_common.InsertOperationLog(OperationUserId,'t_employees_info',1,0);
      RETURN - 1;
  END;
end PKG_EMPLOYEE;


/

