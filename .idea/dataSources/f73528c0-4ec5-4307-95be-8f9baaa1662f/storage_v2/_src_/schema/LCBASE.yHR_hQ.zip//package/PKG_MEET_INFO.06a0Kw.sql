create package        PKG_MEET_info
is
       --根据id 获取会议室信息
       procedure   meetingmanager_GetMeetBaseInfo(operationUserId in char,rooms_result out SYS_REFCURSOR);

       -- 根据用户id获取会议类型
       procedure meetingmanager_GetMeetTypeInfo(operationUserId in char,N_MEETING_TYPE out SYS_REFCURSOR);


       --根据用户id or 会议id获取用户参会人员
       procedure  meetingmanager_GetPeopleInfo(operationUserId in char,c_meting_id in char,V_USER_NAMES out SYS_REFCURSOR);

end PKG_MEET_info;
/

