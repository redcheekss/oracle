create package        PKG_BASEDICT AS
  FUNCTION Get_WorkPlaceList(
                    CUR_DATA OUT SYS_REFCURSOR,
                    ErrMsg   OUT VARCHAR2) RETURN NUMBER;
  FUNCTION Get_NationList(
                    CUR_DATA OUT SYS_REFCURSOR,
                    ErrMsg   OUT VARCHAR2) RETURN NUMBER;
end PKG_BASEDICT;

/

