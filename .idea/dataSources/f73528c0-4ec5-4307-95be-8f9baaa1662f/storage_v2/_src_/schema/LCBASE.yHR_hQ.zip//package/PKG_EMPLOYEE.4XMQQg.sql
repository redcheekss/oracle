create package PKG_EMPLOYEE is

  -- Author  : lihuawei
  -- Created : 2020/2/27 21:09:54
  -- Purpose :

  -- Public function and procedure declarations
  FUNCTION Update_Employee(
                       PEmployeeInfo       	   IN VARCHAR2,
                       OperationUserId         IN VARCHAR2,
                       Employee_Id             IN OUT VARCHAR2,
                       ErrMsg                  OUT VARCHAR2
                       ) RETURN NUMBER;
  FUNCTION Delete_Employee(
                       Employee_Id             IN VARCHAR2,
                       OperationUserId         IN VARCHAR2,
                       Employee_Status         IN NUMBER,
                       ErrMsg                  OUT VARCHAR2
                       ) RETURN NUMBER;
  FUNCTION Get_Employee(
                       Employee_Id             IN VARCHAR2,
                       OperationUserId         IN VARCHAR2,
                       CUR_DATA                OUT SYS_REFCURSOR,
                       ErrMsg                  OUT VARCHAR2
                       ) RETURN NUMBER;
end PKG_EMPLOYEE;

/

