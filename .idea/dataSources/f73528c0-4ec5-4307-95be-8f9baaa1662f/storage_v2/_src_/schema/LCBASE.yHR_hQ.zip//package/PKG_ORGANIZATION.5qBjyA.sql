create package PKG_ORGANIZATION is

    -- Author  : lihuawei
    -- Created : 2020/2/27 21:09:54
    -- Purpose :

    -- Public function and procedure declarations

    FUNCTION Insert_Organization(pOrganizations  IN TYP_ORGANIZATION_LIST,
                                 Organization_Id OUT VARCHAR2)
        RETURN NUMBER;

    FUNCTION Update_Organization(POrganizationInfo IN VARCHAR2,
                                 OperationUserId   IN VARCHAR2,
                                 Organization_Id   IN OUT VARCHAR2,
                                 ErrMsg            OUT VARCHAR2)
        RETURN NUMBER;
    FUNCTION Delete_Organization(Organization_Id IN VARCHAR2,
                                 OperationUserId IN VARCHAR2,
                                 ErrMsg          OUT VARCHAR2)
        RETURN NUMBER;
    FUNCTION Get_OrganizationAlone(Organization_Id IN VARCHAR2,
                                   OperationUserId IN VARCHAR2,
                                   CUR_DATA        OUT SYS_REFCURSOR,
                                   ErrMsg          OUT VARCHAR2)
        RETURN NUMBER;
    FUNCTION Get_OrganizationUpward(Organization_Id IN VARCHAR2,
                                    OperationUserId IN VARCHAR2,
                                    CUR_DATA        OUT SYS_REFCURSOR,
                                    ErrMsg          OUT VARCHAR2)
        RETURN NUMBER;
    FUNCTION Get_OrganizationDownward(Organization_Id IN VARCHAR2,
                                      OperationUserId IN VARCHAR2,
                                      CUR_DATA        OUT SYS_REFCURSOR,
                                      ErrMsg          OUT VARCHAR2)
        RETURN NUMBER;
end PKG_ORGANIZATION;
/

