create package PKG_MESSAGE is

 FUNCTION Get_UserMessageInfo(
                     UserId          IN VARCHAR2,
                    MessageType     IN number,
                    OperationUserId IN VARCHAR2,
                    PageSize    IN NUMBER,          --每页显示大小>0
                    PageCur     IN NUMBER,          --当前页码[1-总页数]
                    CUR_DATA    OUT SYS_REFCURSOR,  --oracle标准游标
                    OutRows     OUT number,         --输出总记录数
                    OutPageCount  OUT number        --输出总页数
          ) RETURN NUMBER;
          
end PKG_MESSAGE;
/

