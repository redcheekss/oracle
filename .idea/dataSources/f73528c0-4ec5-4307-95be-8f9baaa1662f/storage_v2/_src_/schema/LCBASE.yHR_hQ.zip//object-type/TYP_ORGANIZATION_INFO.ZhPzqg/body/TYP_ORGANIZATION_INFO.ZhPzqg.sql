create type body TYP_ORGANIZATION_INFO is
  
  
end;
/

