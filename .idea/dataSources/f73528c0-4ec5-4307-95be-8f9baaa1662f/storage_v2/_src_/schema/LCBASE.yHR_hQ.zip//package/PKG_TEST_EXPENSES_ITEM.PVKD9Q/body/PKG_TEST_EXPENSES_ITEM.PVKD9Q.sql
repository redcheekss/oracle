create package body PKG_TEST_Expenses_Item is

  --修改报销信息
  function Update_Expense_Info(DataInfo        in TYPE_EXPENSES_list,
                               OperationUserId in varchar2,
                               ErrMsg          out varchar2) return number is
     
    P_ID     char(32);
    P_STATUS number(1);
  begin
        P_ID := DataInfo(1).expensesId;
      
    select n_status
      into P_STATUS
      from lcbase.t_user_expenses_info
     where c_expenses_id = P_ID;
  
    if P_STATUS in (-1, 0, 5) then
    
      update lcbase.t_user_expenses_info
         set n_expenses_type            = DataInfo(1).expensesType,
             c_expenses_user_id         = DataInfo(1).expensesUserId,
             v_expenses_user_name       = DataInfo(1).expensesUserName,
             v_expenses_user_tel        = DataInfo(1).expensesUserTel,
             c_dept_id                  = DataInfo(1).deptId,
             v_dept_name                = DataInfo(1).deptName,
             c_top1_dept_id             = DataInfo(1).top1DeptId,
             c_top2_dept_id             = DataInfo(1).top2DeptId,
             c_top3_dept_id             = DataInfo(1).top3DeptId,
             c_top4_dept_id             = DataInfo(1).top4DeptId,
             v_dept_full_name           = DataInfo(1).deptFullName,
             c_position_id              = DataInfo(1).positionId,
             v_position_name            = DataInfo(1).positionName,
             c_lk_corp_id               = DataInfo(1).positionName,
             v_expenses_reason          = DataInfo(1).positionName,
             c_project_id               = DataInfo(1).positionName,
             v_project_name             = DataInfo(1).positionName,
             n_borrowed_fee             = DataInfo(1).positionName,
             n_total_fee                = DataInfo(1).positionName,
             n_payable_fee              = DataInfo(1).positionName,
             v_expenses_no              = DataInfo(1).positionName,
             v_bar_code                 = DataInfo(1).positionName,
             n_repay_flag               = DataInfo(1).positionName,
             n_repay_type               = DataInfo(1).positionName,
             n_repay_amount             = DataInfo(1).positionName,
             d_input_time               = to_date(DataInfo(1).positionName,
                                                  'yyyymmddhh24miss'),
             d_reject_time              = to_date(DataInfo(1).positionName,
                                                  'yyyymmddhh24miss'),
             c_reject_user_id           = DataInfo(1).positionName,
             v_reject_user_name         = DataInfo(1).positionName,
             v_reject_remark            = DataInfo(1).positionName,
             d_update_time              = sysdate,
             c_update_user_id           = DataInfo(1).positionName,
             n_status                   = DataInfo(1).positionName,
             n_approval_avoid_flag      = DataInfo(1).positionName,
             n_finance_status           = DataInfo(1).positionName,
             n_current_level            = DataInfo(1).positionName,
             n_paid_fee                 = DataInfo(1).positionName,
             c_pay_lk_corp_id           = DataInfo(1).positionName,
             n_ebank_pay_status         = DataInfo(1).positionName,
             v_payment_flow_no          = DataInfo(1).positionName,
             v_payment_flow_no_prefix   = DataInfo(1).positionName,
             v_bank_flow_no             = DataInfo(1).positionName,
             n_payment_fee              = DataInfo(1).positionName,
             v_payment_failed_reason    = DataInfo(1).positionName,
             v_payment_account_no       = DataInfo(1).positionName,
             c_payment_user_id          = DataInfo(1).positionName,
             d_payment_date             = DataInfo(1).positionName,
             v_payment_purpose          = DataInfo(1).positionName,
             n_record_flag              = DataInfo(1).positionName,
             d_record_time              = DataInfo(1).positionName,
             n_check_flag               = DataInfo(1).positionName,
             v_check_remark             = DataInfo(1).positionName,
             d_check_time               = DataInfo(1).positionName,
             c_check_user_id            = DataInfo(1).positionName,
             n_notice_payable_fee       = DataInfo(1).positionName,
             n_notice_status            = DataInfo(1).positionName,
             v_notice_remark            = DataInfo(1).positionName,
             n_disabled_flag            = DataInfo(1).positionName,
             c_last_invalid_userid      = DataInfo(1).positionName,
             d_last_invalid_date        = DataInfo(1).positionName,
             v_last_invalid_memo        = DataInfo(1).positionName,
             v_finance_reject_reson     = DataInfo(1).positionName,
             d_finance_reject_date      = DataInfo(1).positionName,
             c_finance_reject_user_id   = DataInfo(1).positionName,
             v_finance_reject_user_name = DataInfo(1).positionName,
             n_invalid_status           = DataInfo(1).positionName,
             v_ex_memo                  = DataInfo(1).positionName
       where c_expenses_id = P_ID;
    
      --清除明细表
      delete from lcbase.t_user_expenses_item where c_expenses_id = P_ID;
    
      commit;
    else
      RAISE_APPLICATION_ERROR(-20008, '已经审批中，不能修改', false);
    end if;
    return 0;
  exception
    when others then
      ErrMsg := 'Update_Expense_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE_APPLICATION_ERROR(-20008, errmsg, false);
  end;

end PKG_TEST_Expenses_Item;
/

