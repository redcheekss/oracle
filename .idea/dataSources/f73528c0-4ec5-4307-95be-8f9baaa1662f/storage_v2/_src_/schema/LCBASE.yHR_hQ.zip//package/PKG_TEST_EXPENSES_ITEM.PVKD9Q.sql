create package PKG_TEST_Expenses_Item is
  --修改
  function Update_Expense_Info(DataInfo        in TYPE_EXPENSES_list,
                               OperationUserId in varchar2,
                               ErrMsg          out varchar2) return number;

end PKG_TEST_Expenses_Item;
/

