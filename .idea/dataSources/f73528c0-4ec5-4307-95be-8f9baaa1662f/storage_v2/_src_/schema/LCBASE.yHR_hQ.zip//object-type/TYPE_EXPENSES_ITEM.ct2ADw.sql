create type        TYPE_EXPENSES_ITEM as object
(
-- Author  : ADMINISTRATOR
-- Created : 2020/4/1 16:50:10
-- Purpose : 

-- Attributes
  expensesItemId      char(32), --                    报销单明细id
  expensesItemType    varchar2(40), --y                  费用类别(0:城际交通费;1:住宿费;2:市内交通;3:出差市内交通;4:差旅补助;5:快递费;6:办公用品或固定资产;7:餐饮;8:其它;9:外出交通;10福利费11:会议费12:办公费;13:外出交通)
  expensesItemSubtype varchar2(40), --y                  费用类别二级(1过节费、2团建费、3体检费、4旅游基金、5内部会议、6外部会议、7电话费、8宽带、9邮箱费、10办公用品、11绿植费、12饮用水、13快递费、14低值易耗品、15商业保险费)
  expensesId          char(32), --y                  报销单id
  startDate           date, --y                  出发日期/起始日期
  endDate             date, --y                  截至日期
  startPlace          varchar2(50), --y                  出发地
  endPlace            varchar2(50), --y                  目的地
  toolKey             number(1), --y                  工具key(0:飞机1:火车2:汽车3:其它4:自驾)
  tool                varchar2(50), --y                  工具
  personNum           number(4), --y                  人数
  ticketsWayKey       number(1), --y                  订票方式key
  ticketsWay          varchar2(50), --y                  订票方式
  fee                 number(10, 2), --y                  金额
  billNum             number(4), --y                  票据张数
  logement            varchar2(50), --y                  住处
  unitPrice           number(10, 2), --y                  单价
  days                number(4), --y                  天数
  room                number(4), --y                  房间数/人数
  memo                varchar2(500), --y                  备注
  cause               varchar2(500), --y                  事由
  nIndex               number(4), --y                  明细索引
  disabledFlag        number(1) --y                  是否有效(0:是;1:否)

)
/

