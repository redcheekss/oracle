create type        type_expenses_item_list AS TABLE OF type_expenses_item
/

