create function my_tabcolscount(tableName varchar2) return number is
  P_CNT number(3) := 0;
begin
  SELECT count(*) into P_CNT  FROM user_tab_columns where table_name = upper(tableName);

  return P_CNT;
end my_tabcolscount;
/

