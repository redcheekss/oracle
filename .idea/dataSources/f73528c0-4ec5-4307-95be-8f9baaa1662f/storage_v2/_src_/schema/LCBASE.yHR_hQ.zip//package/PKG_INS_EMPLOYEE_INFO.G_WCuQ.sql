create package PKG_INS_employee_info as
    --新增成员
    function insert_employeeInfo(bp              IN integer,
                                 owner           IN integer,
                                 vp              IN integer,
                                 employeesInfo   IN VARCHAR2,
                                 userInfo        IN VARCHAR2,
                                 userPicList     IN lcoa.arr_longstr,
                                 OperationUserId IN VARCHAR2,
                                 ErrMsg          OUT VARCHAR2

                                 ) return number;
    --更新成员
    function update_employeeInfo(bp              IN integer,
                                 owner           IN integer,
                                 vp              IN integer,
                                 employeesInfo   IN VARCHAR2,
                                 userInfo        IN VARCHAR2,
                                 userPicList     IN lcoa.arr_longstr,
                                 OperationUserId IN VARCHAR2,
                                 --UserId          IN OUT VARCHAR2,
                                 ErrMsg OUT VARCHAR2

                                 ) return number;
    --设置成员部门
    function update_user_organization(userId          IN lcoa.ARR_LONGSTR,
                                      organizationId  IN VARCHAR2,
                                      OperationUserId IN VARCHAR2,
                                      ErrMsg          OUT VARCHAR2)
        return number;
    --操作记录
    function operation_user_recordinfo(DATAINFO IN lcoa.ARR_LONGSTR,
                                       ErrMsg   OUT VARCHAR2

                                       ) return number;

    function insert_Employee(PEmployeeInfo IN VARCHAR2,
                             v_userID      in varchar2,
                             ErrMsg        OUT VARCHAR2)
        RETURN NUMBER;

    --设置添加用户角色
    function set_user_role(v_userID  in char,
                           v_ROLE_ID in char,
                           ErrMsg    OUT VARCHAR2)
        return NUMBER;

end PKG_INS_employee_info;
/

