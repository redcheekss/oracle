create package body PKG_TEST is

  FUNCTION Insert_Expenses_Info(DataInfo        in TYPE_EXPENSES_INFO,
                                OperationUserId in varchar2,
                                DataId          out varchar2,
                                ErrMsg          out varchar2) return number is
    DATAARR          PKG_COMMON.ARR_LONGSTR;
    P_ID             char(32);
    deptFullName     varchar2(50);
    expensesUserName varchar2(20);
    --FirstApprovalUserId char(32);
  BEGIN
    P_ID    := LOWER(SYS_GUID());
    DATAARR := PKG_COMMON.Split('', '^');
  
    select v_organization_name
      into deptFullName
      from t_organization
     where c_organization_id = DataInfo.deptId;
    deptFullName := DataInfo.deptFullName;
    select v_user_name
      into expensesUserName
      from t_user
     where c_user_id = DataInfo.expensesUserId;
    expensesUserName := DataInfo.expensesUserName;
  
    /* insert into lcbase.t_User_Expenses_Info
      (c_expenses_id,
       n_expenses_type,
       c_expenses_user_id,
       v_expenses_user_name,
       v_expenses_user_tel,
       c_dept_id,
       v_dept_name,
       c_top1_dept_id,
       c_top2_dept_id,
       c_top3_dept_id,
       c_top4_dept_id,
       v_dept_full_name,
       c_position_id,
       v_position_name,
       c_lk_corp_id,
       v_expenses_reason,
       c_project_id,
       v_project_name,
       n_borrowed_fee,
       n_total_fee,
       n_payable_fee,
       v_expenses_no,
       v_bar_code,
       n_repay_flag,
       n_repay_type,
       n_repay_amount,
       d_input_time,
       d_reject_time,
       c_reject_user_id,
       v_reject_user_name,
       v_reject_remark,
       d_update_time,
       c_update_user_id,
       n_status,
       n_approval_avoid_flag,
       n_finance_status,
       n_current_level,
       n_paid_fee,
       c_pay_lk_corp_id,
       n_ebank_pay_status,
       v_payment_flow_no,
       v_payment_flow_no_prefix,
       v_bank_flow_no,
       n_payment_fee,
       v_payment_failed_reason,
       v_payment_account_no,
       c_payment_user_id,
       d_payment_date,
       v_payment_purpose,
       n_record_flag,
       d_record_time,
       n_check_flag,
       v_check_remark,
       d_check_time,
       c_check_user_id,
       n_notice_payable_fee,
       n_notice_status,
       v_notice_remark,
       n_disabled_flag,
       c_last_invalid_userid,
       d_last_invalid_date,
       v_last_invalid_memo,
       v_finance_reject_reson,
       d_finance_reject_date,
       c_finance_reject_user_id,
       v_finance_reject_user_name,
       n_invalid_status,
       v_ex_memo)
    values
      (P_ID,
       DataInfo.expensesType,
       OperationUserId,
       DataInfo.expensesUserName,
       DataInfo.expensesUserTel,
       DataInfo.deptId,
       DataInfo.deptName,
       DataInfo.top1DeptId,
       DataInfo.top2DeptId,
       DataInfo.top3DeptId,
       DataInfo.top4DeptId,
       DataInfo.deptFullName,
       DATAARR(13),
       DATAARR(14),
       DATAARR(15),
       DATAARR(16),
       DATAARR(17),
       DATAARR(18),
       DATAARR(19),
       DATAARR(20),
       DATAARR(21),
       lcbase.pkg_common.getflownumber('BX', 4),
       DATAARR(23),
       DATAARR(24),
       DATAARR(25),
       DATAARR(26),
       sysdate,
       DATAARR(28),
       DATAARR(29),
       DATAARR(30),
       DATAARR(31),
       sysdate,
       DATAARR(33),
       DATAARR(34),
       DATAARR(35),
       DATAARR(36),
       DATAARR(37),
       DATAARR(38),
       DATAARR(39),
       DATAARR(40),
       DATAARR(41),
       DATAARR(42),
       DATAARR(43),
       DATAARR(44),
       DATAARR(45),
       DATAARR(46),
       DATAARR(47),
       DATAARR(48),
       DATAARR(49),
       DATAARR(50),
       DATAARR(51),
       DATAARR(52),
       DATAARR(53),
       DATAARR(54),
       DATAARR(55),
       DATAARR(56),
       DATAARR(57),
       DATAARR(58),
       DATAARR(59),
       DATAARR(60),
       DATAARR(61),
       DATAARR(62),
       DATAARR(63),
       DATAARR(64),
       DATAARR(65),
       DATAARR(66),
       DATAARR(67),
       DATAARR(68));
    DataId := P_ID;*/
  
    insert into t_user_expenses_info
      (c_expenses_id,
       n_expenses_type,
       c_expenses_user_id,
       v_expenses_user_name,
       v_expenses_user_tel,
       c_dept_id,
       v_dept_name,
       c_top1_dept_id,
       c_top2_dept_id,
       c_top3_dept_id,
       c_top4_dept_id,
       v_dept_full_name,
       c_position_id,
       v_position_name,
       c_lk_corp_id,
       v_expenses_reason,
       c_project_id,
       v_project_name,
       n_borrowed_fee,
       n_total_fee,
       n_payable_fee,
       v_expenses_no,
       v_bar_code,
       n_repay_flag,
       n_repay_type,
       n_repay_amount,
       d_input_time,
       d_reject_time,
       c_reject_user_id,
       v_reject_user_name,
       v_reject_remark,
       d_update_time,
       c_update_user_id,
       n_status,
       n_approval_avoid_flag,
       n_finance_status,
       n_current_level,
       n_paid_fee,
       c_pay_lk_corp_id,
       n_ebank_pay_status,
       v_payment_flow_no,
       v_payment_flow_no_prefix,
       v_bank_flow_no,
       n_payment_fee,
       v_payment_failed_reason,
       v_payment_account_no,
       c_payment_user_id,
       d_payment_date,
       v_payment_purpose,
       n_record_flag,
       d_record_time,
       n_check_flag,
       v_check_remark,
       d_check_time,
       c_check_user_id,
       n_notice_payable_fee,
       n_notice_status,
       v_notice_remark,
       n_disabled_flag,
       c_last_invalid_userid,
       d_last_invalid_date,
       v_last_invalid_memo,
       v_finance_reject_reson,
       d_finance_reject_date,
       c_finance_reject_user_id,
       v_finance_reject_user_name,
       n_invalid_status,
       v_ex_memo)
    values
      (P_ID,
       DataInfo.expensesType,
       DataInfo.expensesUserId,
       DataInfo.expensesUserName,
       DataInfo.expensesUserTel,
       DataInfo.deptId,
       DataInfo.deptName,
       DataInfo.top1DeptId,
       DataInfo.top2DeptId,
       DataInfo.top3DeptId,
       DataInfo.top4DeptId,
       DataInfo.deptFullName,
       DataInfo.positionId,
       DataInfo.positionName,
       DataInfo.lkCorpId,
       DataInfo.expensesReason,
       DataInfo.projectId,
       DataInfo.projectName,
       DataInfo.borrowedFee,
       DataInfo.totalFee,
       DataInfo.payableFee,
       DataInfo.expensesNo,
       DataInfo.barCode,
       DataInfo.repayFlag,
       DataInfo.repayType,
       DataInfo.repayAmount,
       sysdate,
       DataInfo.rejectTime,
       DataInfo.rejectUserId,
       DataInfo.rejectUserName,
       DataInfo.rejectRemark,
       sysdate,
       DataInfo.updateUserId,
       DataInfo.status,
       DataInfo.approvalAvoidFlag,
       DataInfo.financeStatus,
       DataInfo.currentLevel,
       DataInfo.paidFee,
       DataInfo.payLkCorpId,
       DataInfo.ebankPayStatus,
       DataInfo.paymentFlowNo,
       DataInfo.paymentFlowNoPrefix,
       DataInfo.bankFlowNo,
       DataInfo.payableFee,
       DataInfo.paymentFailedReason,
       DataInfo.paymentAccountNo,
       DataInfo.paymentUserId,
       DataInfo.paymentDate,
       DataInfo.paymentPurpose,
       DataInfo.recordFlag,
       DataInfo.recordTime,
       DataInfo.checkFlag,
       DataInfo.checkRemark,
       DataInfo.checkTime,
       DataInfo.checkUserId,
       DataInfo.noticePayableFee,
       DataInfo.noticeStatus,
       DataInfo.noticeRemark,
       DataInfo.disabledFlag,
       DataInfo.lastInvalidUserid,
       DataInfo.lastInvalidDate,
       DataInfo.lastInvalidMemo,
       DataInfo.financeRejectReson,
       DataInfo.financeRejectDate,
       DataInfo.financeRejectUserId,
       DataInfo.financeRejectUserName,
       DataInfo.invalidStatus,
       DataInfo.exMemo);
  
    -- Insert_Expenses_Item();
  
    --审批流，待办
    --PKG_USER_SCHEDULE.Insert_Approval_Flow(DataId, DATAARR(3), 4, FirstApprovalUserId);
    --PKG_USER_SCHEDULE.Insert_Approval_Next_Todo_Info(DataId, null);
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'Insert_Expenses_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE_APPLICATION_ERROR(-20008, errmsg, false);
  END;
  --插入报销单明细
  function Insert_Expenses_Item(DataInfo   in varchar2,
                                ExpensesId in varchar2,
                                DataId     out varchar2,
                                ErrMsg     out varchar2) return number is
    DATAARR PKG_COMMON.ARR_LONGSTR;
    P_ID    char(32);
  
  begin
    DATAARR := PKG_COMMON.Split(DataInfo, '^');
    P_ID    := LOWER(SYS_GUID());
    insert into lcbase.t_user_expenses_item
      (c_expenses_item_id,
       v_expenses_item_type,
       v_expenses_item_subtype,
       c_expenses_id,
       d_start_date,
       d_end_date,
       v_start_place,
       v_end_place,
       v_tool_key,
       v_tool,
       n_person_num,
       n_tickets_way_key,
       v_tickets_way,
       n_fee,
       n_bill_num,
       v_logement,
       n_unit_price,
       n_days,
       n_room,
       v_memo,
       v_cause,
       n_index,
       n_disabled_flag)
    values
      (P_ID,
       DATAARR(2),
       DATAARR(3),
       ExpensesId,
       to_date(DATAARR(5), 'yyyymmddhh24miss'),
       to_date(DATAARR(6), 'yyyymmddhh24miss'),
       DATAARR(7),
       DATAARR(8),
       DATAARR(9),
       DATAARR(10),
       DATAARR(11),
       DATAARR(12),
       DATAARR(13),
       DATAARR(14),
       DATAARR(15),
       DATAARR(16),
       DATAARR(17),
       DATAARR(18),
       DATAARR(19),
       DATAARR(20),
       DATAARR(21),
       DATAARR(22),
       DATAARR(23));
  
    DataId := P_ID;
    commit;
    return 0;
  exception
    when others then
      ErrMsg := 'Insert_Expenses_Item: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE_APPLICATION_ERROR(-20008, errmsg, false);
  end;

  --修改报销信息
  function Update_Expense_Info(DataInfo        in varchar2,
                               OperationUserId in varchar2,
                               ErrMsg          out varchar2) return number is
    DATAARR  PKG_COMMON.ARR_LONGSTR;
    P_ID     char(32);
    P_STATUS number(1);
  begin
    DATAARR := PKG_COMMON.Split(DataInfo, '^');
    P_ID    := DATAARR(1);
    select n_status
      into P_STATUS
      from lcbase.t_user_expenses_info
     where c_expenses_id = P_ID;
    if P_STATUS in (-1, 0, 5) then
      update lcbase.t_user_expenses_info
         set n_expenses_type            = DATAARR(2),
             c_expenses_user_id         = DATAARR(3),
             v_expenses_user_name       = DATAARR(4),
             v_expenses_user_tel        = DATAARR(5),
             c_dept_id                  = DATAARR(6),
             v_dept_name                = DATAARR(7),
             c_top1_dept_id             = DATAARR(8),
             c_top2_dept_id             = DATAARR(9),
             c_top3_dept_id             = DATAARR(10),
             c_top4_dept_id             = DATAARR(11),
             v_dept_full_name           = DATAARR(12),
             c_position_id              = DATAARR(13),
             v_position_name            = DATAARR(14),
             c_lk_corp_id               = DATAARR(15),
             v_expenses_reason          = DATAARR(16),
             c_project_id               = DATAARR(17),
             v_project_name             = DATAARR(18),
             n_borrowed_fee             = DATAARR(19),
             n_total_fee                = DATAARR(20),
             n_payable_fee              = DATAARR(21),
             v_expenses_no              = DATAARR(22),
             v_bar_code                 = DATAARR(23),
             n_repay_flag               = DATAARR(24),
             n_repay_type               = DATAARR(25),
             n_repay_amount             = DATAARR(26),
             d_input_time               = to_date(DATAARR(27),
                                                  'yyyymmddhh24miss'),
             d_reject_time              = to_date(DATAARR(28),
                                                  'yyyymmddhh24miss'),
             c_reject_user_id           = DATAARR(29),
             v_reject_user_name         = DATAARR(30),
             v_reject_remark            = DATAARR(31),
             d_update_time              = sysdate,
             c_update_user_id           = DATAARR(33),
             n_status                   = DATAARR(34),
             n_approval_avoid_flag      = DATAARR(35),
             n_finance_status           = DATAARR(36),
             n_current_level            = DATAARR(37),
             n_paid_fee                 = DATAARR(38),
             c_pay_lk_corp_id           = DATAARR(39),
             n_ebank_pay_status         = DATAARR(40),
             v_payment_flow_no          = DATAARR(41),
             v_payment_flow_no_prefix   = DATAARR(42),
             v_bank_flow_no             = DATAARR(43),
             n_payment_fee              = DATAARR(44),
             v_payment_failed_reason    = DATAARR(45),
             v_payment_account_no       = DATAARR(46),
             c_payment_user_id          = DATAARR(47),
             d_payment_date             = DATAARR(48),
             v_payment_purpose          = DATAARR(49),
             n_record_flag              = DATAARR(50),
             d_record_time              = DATAARR(51),
             n_check_flag               = DATAARR(52),
             v_check_remark             = DATAARR(53),
             d_check_time               = DATAARR(54),
             c_check_user_id            = DATAARR(55),
             n_notice_payable_fee       = DATAARR(56),
             n_notice_status            = DATAARR(57),
             v_notice_remark            = DATAARR(58),
             n_disabled_flag            = DATAARR(59),
             c_last_invalid_userid      = DATAARR(60),
             d_last_invalid_date        = DATAARR(61),
             v_last_invalid_memo        = DATAARR(62),
             v_finance_reject_reson     = DATAARR(63),
             d_finance_reject_date      = DATAARR(64),
             c_finance_reject_user_id   = DATAARR(65),
             v_finance_reject_user_name = DATAARR(66),
             n_invalid_status           = DATAARR(67),
             v_ex_memo                  = DATAARR(68)
       where c_expenses_id = P_ID;
    
      --清除明细表
      delete from lcbase.t_user_expenses_item where c_expenses_id = P_ID;
    
      commit;
    else
      RAISE_APPLICATION_ERROR(-20008, '已经审批中，不能修改', false);
    end if;
    return 0;
  exception
    when others then
      ErrMsg := 'Update_Expense_Info: ' || SQLCODE || ',' || SQLERRM || ',' ||
                DBMS_UTILITY.format_error_backtrace;
      rollback;
      RAISE_APPLICATION_ERROR(-20008, errmsg, false);
  end;

end PKG_TEST;
/

