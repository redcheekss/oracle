create package body        PKG_MEET_info
is
  --根据用户id获取会议室"
  procedure  meetingmanager_GetMeetBaseInfo(operationUserId in char,rooms_result out SYS_REFCURSOR)
  is
    begin
        open rooms_result for
            select
                 T.V_MROOM_NAME
            from
                  lcbase.T_SYS_MEETINGROOM_INFO T   --会议室基础信息表
            left join lcbase.T_USER_SCHEDULE_INFO S --用户日程信息表
                 on T.C_MROOM_NO = S.c_Mroom_No

            left join lcbase.t_User  U              --用户基础信息表
                 on S.C_SCH_USER_ID = U.c_User_Id
                 where U.C_USER_ID = operationUserId;

         --dbms_output.put_line('V_MROOM_NAME:'||V_MROOM_NAME);
         --close rooms_result;
       --异常处理
      exception
         when NO_DATA_FOUND THEN
               dbms_output.put_line('没有查询到任何数据');

     end meetingmanager_GetMeetBaseInfo;

     ---------------------------------------------------------------------------------
     --获取会议类型
   procedure meetingmanager_GetMeetTypeInfo(operationUserId in char,N_MEETING_TYPE out SYS_REFCURSOR)
   is
     begin
         open N_MEETING_TYPE for
              select
              case T.N_MEETING_TYPE
                    when 1 then '线上会议'
                    when 2 then '线下会议'
               end
         from
             lcbase.T_USER_SCHEDULE_INFO T
         left join lcbase.t_User  U
              on T.C_SCH_USER_ID = U.C_USER_ID
               where U.C_USER_ID=operationUserId;
     --异常处理
     exception
       when NO_DATA_FOUND THEN
             dbms_output.put_line('没有查询到任何数据');

    end meetingmanager_GetMeetTypeInfo;
    ---------------------------------------------------------------------------------

   -- 获取参会用户
   procedure  meetingmanager_GetPeopleInfo(operationUserId in char,c_meting_id in char,V_USER_NAMES out SYS_REFCURSOR)
   as
     begin
        open V_USER_NAMES for
          select
            T.V_USER_NAME   -- 参会用户
          from
           LCBASE.T_USER_MEETING_NUMBER TM
          left join  LCBASE.T_USER T
           on TM.C_USER_ID = T.c_User_Id
          where   T.c_User_Id =operationUserId and TM.C_MEETING_ID=c_meting_id;
      --异常处理
      exception
           when NO_DATA_FOUND THEN
               dbms_output.put_line('没有查询到任何数据');
    end meetingmanager_GetPeopleInfo;

end PKG_MEET_info;
/

