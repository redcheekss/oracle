create PACKAGE PKG_COMMON IS
  type ref_cursor is ref cursor;
  type total_record is record(
    totalrows number);

  TYPE ARR_UID is Table OF varchar2(32) INDEX BY pls_integer;
  TYPE ARR_LONGSTR is Table OF varchar2(4000) INDEX BY pls_integer;

  --以下自定义错误码
  EXP_PARAM EXCEPTION;
  PRAGMA EXCEPTION_INIT(EXP_PARAM, -20001);
  EXP_CHECK EXCEPTION;
  PRAGMA EXCEPTION_INIT(EXP_CHECK, -20002);
  --
  FUNCTION IsDateNumbers(CC CHAR) RETURN NUMBER;

  FUNCTION FormatNumber(N IN NUMBER, F IN VARCHAR2) RETURN VARCHAR2;

  FUNCTION SPLIT(P_STR IN VARCHAR2, P_DELIMITER IN VARCHAR2 := '^')
    RETURN ARR_LONGSTR;

  --插入用户操作
  --参数：用户ID   操作类型  操作表名  描述
  PROCEDURE InsertOperationLog(UserID    IN VARCHAR2,
                               TableName IN VARCHAR2,
                               nOpType   IN NUMBER,
                               nStatus   IN NUMBER,
                               nDuration IN NUMBER := 0);

  procedure InsertOperationLog2(UserId          in varchar2,
                                ActionName      in varchar2,
                                CallName        in varchar2,
                                SummeryInfo     in varchar2,
                                ActionStartTime in date,
                                ActionEndTime   in date,
                                ActionStatus    in number);

  function GetFlowNumber(prefix in varchar2, flowLength in number)
    return varchar2;

  /*
  函数功能：分页获取数据信息
  编写：李华伟
  时间：2020年三月二十一日
  */
  FUNCTION GetPagingInfo(vSql          IN VARCHAR2,
                         nPageSize     IN NUMBER, --每页显示大小>0
                         nPageCur      IN NUMBER, --当前页码[1-总页数]
                         CUR_DATA      OUT SYS_REFCURSOR, --oracle标准游标
                         nOutRows      OUT number, --输出总记录数
                         nOutPageCount OUT number --输出总页数
                         ) RETURN NUMBER;
END PKG_COMMON;
/

