create package body PKG_MESSAGE is

  FUNCTION Get_UserMessageInfo(
                    UserId          IN VARCHAR2,
                    MessageType     IN number,
                    OperationUserId IN VARCHAR2,
                    PageSize    IN NUMBER,          --每页显示大小>0
                    PageCur     IN NUMBER,          --当前页码[1-总页数]
                    CUR_DATA    OUT SYS_REFCURSOR,  --oracle标准游标
                    OutRows     OUT number,         --输出总记录数
                    OutPageCount  OUT number        --输出总页数
          ) RETURN NUMBER IS
          n_result number(1) := 0;
	v_sql varchar2(3000);
	errcode number(8);
	errmsg varchar2(2000);
	no_result  EXCEPTION;
  BEGIN
    BEGIN
    v_sql := 'select C_MSG_ID, N_MSG_TYPE, N_ISTOP_FLAG, D_ISTOP_TIME, V_MSG_TITLE, D_MSG_TIME, N_READ_FLAG, 
    C_MSG_USER_ID, C_MSG_SRC, V_MSG_CONTENT，V_MSG_SENDER from T_USER_MSG_INFO
      where N_ENABLE = 0 and C_MSG_USER_ID = ''' || UserId ||'''';
      if MessageType is not null and MessageType = 3  then 
         v_sql := v_sql||' and N_MSG_TYPE in (3,4,5,6)' ;
         end if;
       if MessageType is not null and MessageType <> 3  then
          v_sql := v_sql||' and N_MSG_TYPE =' ||  MessageType;          
       end if;
       n_result := pkg_common.GetPagingInfo(vSql => v_sql,nPageSize => PageSize, nPageCur =>PageCur,CUR_DATA => CUR_DATA, nOutRows => OutRows, nOutPageCount => OutPageCount);
       EXCEPTION
      WHEN no_result THEN
        dbms_output.put_line('自定义异常!');
        n_result := 1;
      WHEN OTHERS THEN
        errcode := SQLCODE;
        errmsg := SQLERRM || ',' || DBMS_UTILITY.format_error_backtrace;
        n_result := 1;
    end;
    PKG_COMMON.InsertOperationLog(OperationUserId, 'T_USER_TODO_INFO', 1, n_result);
    --正常返回
    if n_result = 0 then
  		return 0;
    end if;
    --异常返回
	  RAISE_APPLICATION_ERROR(-20009, errmsg, true);
   END;
end PKG_MESSAGE;
/

