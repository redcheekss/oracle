create type TYP_ORGANIZATION_INFO as object
(
  -- Author  : lihuawei
  -- Created : 2020/3/15 12:27:36
  -- Purpose : 部门信息
  
  -- Attributes
  c_organization_id        char(32),
  v_organization_name      VARCHAR2(30),
  c_organization_parent_id CHAR(32),
  n_organization_level     NUMBER(2),
  n_organization_type      NUMBER(1),
  c_organization_owner     CHAR(32),
  n_status                 NUMBER(1),
  v_organization_abbname   VARCHAR2(16)
)
/

