create package PKG_TEST is

    --新增
    FUNCTION Insert_Expenses_Info(DataInfo        in TYPE_EXPENSES_INFO,
                             OperationUserId in varchar2,
                             DataId          out varchar2,
                             ErrMsg          out varchar2) RETURN NUMBER;

  --插入报销明细
  function Insert_Expenses_Item(DataInfo        in varchar2,
                             ExpensesId in varchar2,
                             DataId          out varchar2,
                             ErrMsg          out varchar2)return number;
   --修改
   function Update_Expense_Info(DataInfo        in varchar2,
                               OperationUserId in varchar2,
                               ErrMsg          out varchar2) return number;
                               
    
end PKG_TEST;
/

