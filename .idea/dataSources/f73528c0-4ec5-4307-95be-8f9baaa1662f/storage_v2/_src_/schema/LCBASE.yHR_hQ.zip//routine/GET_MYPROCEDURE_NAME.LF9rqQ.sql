create FUNCTION get_myprocedure_name
RETURN VARCHAR2
IS
   v_prc_name  varchar(2000);
BEGIN
  v_prc_name := DBMS_UTILITY.FORMAT_CALL_STACK();
  v_prc_name := REGEXP_SUBSTR(v_prc_name, '\w*\.\w*', 1, 2);
  RETURN v_prc_name;
END get_myprocedure_name;
/

