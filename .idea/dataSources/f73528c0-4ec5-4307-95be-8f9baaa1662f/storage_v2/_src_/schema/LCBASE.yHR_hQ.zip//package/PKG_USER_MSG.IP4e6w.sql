create package PKG_USER_MSG AS
/*
	用户消息相关处理存储过程
	基本设计思想：
	针对每个用户生成一条消息，如果发布消息为全员，则为每个用户生成一条消息。
  针对消息回复，只能新增或更新消息回复，不能进行删除回复内容的操作。
*/
  FUNCTION Insert_UserMsgFeed(
						PUserMsgFeed    IN VARCHAR2,
						OperationUserId IN VARCHAR2,
						MsgFeedId 		out varchar2,
						ErrMsg			out VARCHAR2
						) return number;
  FUNCTION Update_UserMsgFeed(
						PUserMsgFeed    IN VARCHAR2,
            OperationUserId IN VARCHAR2,
            ErrMsg      out VARCHAR2
						) RETURN NUMBER;
  FUNCTION Update_UserMsgReaded(
            MsgId           IN VARCHAR2,
            OperationUserId IN VARCHAR2,
            ErrMsg          OUT VARCHAR2
            ) return number; 
  FUNCTION Update_UserMsgTop(
            PNewsInfo       IN VARCHAR2,
            OperationUserId IN VARCHAR2,
            ErrMsg          OUT VARCHAR2
            ) return number; 
end PKG_USER_MSG;

/

