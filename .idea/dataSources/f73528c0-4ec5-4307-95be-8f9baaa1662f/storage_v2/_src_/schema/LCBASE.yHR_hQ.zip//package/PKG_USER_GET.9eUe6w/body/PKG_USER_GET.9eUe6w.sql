create package body        pkg_user_get is

  --通用的批量查询列表：（当PageSize=0 && PageIndex=0时，表示不分页，取全部数据）
  function Get_Common_Data_List(SqlTxt            in varchar2,
                                PageSize          in number,
                                PageIndex         in number,
                                OperationUserId   in varchar2,
                                OperationFunction in varchar2,
                                CUR_DATA          out sys_refcursor,
                                PagesCount        out number,
                                RowsCount         out number,
                                ErrMsg            out varchar2) return number is
    n_result  number(1) := 0; --0表示成功 非0表示失败
    v_sql     varchar2(3000);
    n_start   number(4);
    n_end     number(4);
    call_time date;
  begin
    begin
      call_time := sysdate;
    end;
    begin
      if PageSize > 0 and PageIndex > 0 then
        n_start := PageSize * (PageIndex - 1) + 1;
        n_end   := PageSize * PageIndex;
        v_sql   := 'select t2.* from (select t1.*,rownum rn from (' ||
                   SqlTxt || ')t1 where rownum<=' || n_end ||
                   ') t2 where rn>=' || n_start;
      else
        v_sql := SqlTxt;
      end if;
    
      --打开游标，让游标指向结果集
      OPEN CUR_DATA FOR v_sql;
    
      --查询共有多少条记录
      v_sql := 'select count(*) from (' || SqlTxt || ')';
      execute immediate v_sql
        into RowsCount;
    
      --统计多少页记录
      if PageSize > 0 and PageIndex > 0 and RowsCount > 0 then
        if mod(RowsCount, PageSize) = 0 then
          PagesCount := RowsCount / PageSize;
        else
          PagesCount := RowsCount / PageSize + 1;
        end if;
      elsif RowsCount > 0 then
        PagesCount := 1;
      else
        PagesCount := 0;
      end if;
      n_result := 1;
    exception
      when others then
        ErrMsg   := 'Get_Common_Data_List: ' || SQLCODE || ',' || SQLERRM;
        n_result := 0;
    end;
  
    begin
      pkg_common.InsertOperationLog2(OperationUserId,
                                     '查询',
                                     OperationFunction,
                                     SqlTxt,
                                     call_time,
                                     sysdate,
                                     n_result);
    end;
  
    --正常返回
    if n_result = 1 then
      return 0;
    else
      RAISE_APPLICATION_ERROR(-20008, errmsg, false);
    end if;
  end;

  --新增请假申请信息
  function Get_Leave_Info(DataId          out varchar2,
                          OperationUserId in varchar2,
                          CUR_INFO        out sys_refcursor,
                          CUR_FLOW        out sys_refcursor,
                          CUR_FILE        out sys_refcursor,
                          ErrMsg          out varchar2) return number is
  begin
    open CUR_INFO for
      select * from lcbase.t_user_leave_info t where t.c_leave_id = DataId;
    open CUR_FLOW for
      select *
        from lcbase.t_user_approval_flow f
       where f.c_approval_id = DataId
       order by f.n_approval_level;
    open CUR_FILE for
      select *
        from lcbase.t_user_upload_info l
       where l.c_forign_id = DataId
       order by l.d_upload_time;
    return 0;
  exception
    when others then
      ErrMsg := 'Get_Leave_Info: ' || SQLCODE || ',' || SQLERRM;
      RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
  end;

  --新增外出申请信息
  function Get_Egress_Info(DataId          out varchar2,
                           OperationUserId in varchar2,
                           CUR_INFO        out sys_refcursor,
                           CUR_FLOW        out sys_refcursor,
                           CUR_FILE        out sys_refcursor,
                           ErrMsg          out varchar2) return number is
  begin
    open CUR_INFO for
      select *
        from lcbase.t_user_egress_info t
       where t.c_egress_id = DataId;
    open CUR_FLOW for
      select *
        from lcbase.t_user_approval_flow f
       where f.c_approval_id = DataId
       order by f.n_approval_level;
    open CUR_FILE for
      select *
        from lcbase.t_user_upload_info l
       where l.c_forign_id = DataId
       order by l.d_upload_time;
    return 0;
  exception
    when others then
      ErrMsg := 'Get_Egress_Info: ' || SQLCODE || ',' || SQLERRM;
      RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
  end;

  --新增发布公告信息
  function Get_News_Info(DataId          out varchar2,
                         OperationUserId in varchar2,
                         CUR_INFO        out sys_refcursor,
                         CUR_NUMB        out sys_refcursor,
                         CUR_FLOW        out sys_refcursor,
                         CUR_FILE        out sys_refcursor,
                         ErrMsg          out varchar2) return number is
  begin
    open CUR_INFO for
      select *
        from lcbase.t_user_publish_info t
       where t.c_news_id = DataId;
    open CUR_NUMB for
      select *
        from lcbase.t_user_publish_range r
       where r.c_news_id = DataId;
    open CUR_FLOW for
      select *
        from lcbase.t_user_approval_flow f
       where f.c_approval_id = DataId
       order by f.n_approval_level;
    open CUR_FILE for
      select *
        from lcbase.t_user_upload_info l
       where l.c_forign_id = DataId
       order by l.d_upload_time;
    return 0;
  exception
    when others then
      ErrMsg := 'Get_News_Info: ' || SQLCODE || ',' || SQLERRM;
      RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
  end;

  --新增报销信息
  function Get_Expense_Info(DataId          out varchar2,
                            OperationUserId in varchar2,
                            CUR_INFO        out sys_refcursor,
                            CUR_ITEM        out sys_refcursor,
                            CUR_FLOW        out sys_refcursor,
                            CUR_FILE        out sys_refcursor,
                            ErrMsg          out varchar2) return number is
  begin
    open CUR_INFO for
      select *
        from lcbase.t_user_expenses_info t
       where t.c_expenses_id = DataId;
    open CUR_ITEM for
      select *
        from lcbase.t_user_expenses_item i
       where i.c_expenses_id = DataId;
    open CUR_FLOW for
      select *
        from lcbase.t_user_approval_flow f
       where f.c_approval_id = DataId
       order by f.n_approval_level;
    open CUR_FILE for
      select *
        from lcbase.t_user_upload_info l
       where l.c_forign_id = DataId
       order by l.d_upload_time;
    return 0;
  exception
    when others then
      ErrMsg := 'Get_Expense_Info: ' || SQLCODE || ',' || SQLERRM;
      RAISE_APPLICATION_ERROR(-20008, ErrMsg, false);
  end;
end pkg_user_get;
/

