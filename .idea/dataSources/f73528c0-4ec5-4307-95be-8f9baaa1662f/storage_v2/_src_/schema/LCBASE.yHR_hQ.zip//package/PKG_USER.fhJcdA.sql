create package PKG_USER AS

    FUNCTION Update_User(PUserInfo         IN VARCHAR2,
                         OperationUserId   IN VARCHAR2,
                         UserId            IN OUT VARCHAR2,
                         V_ORGANIZATION_ID out char,
                         ErrMsg            OUT VARCHAR2)
        RETURN NUMBER;

    FUNCTION Delete_User(UserId          IN VARCHAR2,
                         OperationUserId IN VARCHAR2,
                         ErrMsg          OUT VARCHAR2)
        RETURN NUMBER;

    FUNCTION Get_User(UserId          IN VARCHAR2,
                      OperationUserId IN VARCHAR2,
                      --       PUserInfo       OUT VARCHAR2,
                      CUR_DATA OUT SYS_REFCURSOR,
                      ErrMsg   OUT VARCHAR2) RETURN NUMBER;

    FUNCTION Login_User(UserAccount  VARCHAR2,
                        UserPassword VARCHAR2,
                        LoginType    NUMBER,
                        CUR_DATA     OUT SYS_REFCURSOR,
                        ErrMsg       OUT VARCHAR2)
        RETURN NUMBER;
    -- 用户重名，返回工号
    function getUserWorkNo(UserId in varchar2) RETURN VARCHAR2;
end PKG_USER;
/

