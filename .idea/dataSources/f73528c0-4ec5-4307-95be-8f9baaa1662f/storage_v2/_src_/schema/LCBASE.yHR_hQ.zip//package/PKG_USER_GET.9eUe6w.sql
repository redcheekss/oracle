create package pkg_user_get as
  function Get_Common_Data_List(ArrSql            in ARR_LONGSTR,
                                PageSize          in number,
                                PageIndex         in number,
                                OperationUserId   in varchar2,
                                OperationFunction in varchar2,
                                CUR_DATA          out sys_refcursor,
                                PagesCount        out number,
                                RowsCount         out number,
                                ErrMsg            out varchar2) return number;
  function Get_Leave_Info(DataId          in varchar2,
                          OperationUserId in varchar2,
                          CUR_INFO        out sys_refcursor,
                          CUR_FLOW        out sys_refcursor,
                          CUR_FILE        out sys_refcursor,
                          ErrMsg          out varchar2) return number;
  function Get_Egress_Info(DataId          in varchar2,
                           OperationUserId in varchar2,
                           CUR_INFO        out sys_refcursor,
                           CUR_FLOW        out sys_refcursor,
                           CUR_FILE        out sys_refcursor,
                           ErrMsg          out varchar2) return number;
  function Get_News_Info(DataId          in varchar2,
                         OperationUserId in varchar2,
                         CUR_INFO        out sys_refcursor,
                         CUR_NUMB        out sys_refcursor,
                         CUR_FLOW        out sys_refcursor,
                         CUR_FILE        out sys_refcursor,
                         CUR_FEED        out sys_refcursor,
                         ErrMsg          out varchar2) return number;
  function Get_Expense_Info(DataId          in varchar2,
                            OperationUserId in varchar2,
                            CUR_INFO        out sys_refcursor,
                            CUR_ITEM        out sys_refcursor,
                            CUR_FLOW        out sys_refcursor,
                            CUR_FILE        out sys_refcursor,
                            ErrMsg          out varchar2) return number;
end pkg_user_get;

/

