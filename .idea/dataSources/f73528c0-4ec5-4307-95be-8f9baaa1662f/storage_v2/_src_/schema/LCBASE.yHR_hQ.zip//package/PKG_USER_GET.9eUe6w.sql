create package        pkg_user_get is

  -- Author  : ROCK
  -- Created : 2020/3/26 9:32:48
  -- Purpose : 

  --通用的批量查询列表：（当PageSize=0 && PageIndex=0时，表示不分页，取全部数据）
  function Get_Common_Data_List(SqlTxt            in varchar2,
                                PageSize          in number,
                                PageIndex         in number,
                                OperationUserId   in varchar2,
                                OperationFunction in varchar2,
                                CUR_DATA          out sys_refcursor,
                                PagesCount        out number,
                                RowsCount         out number,
                                ErrMsg            out varchar2) return number;

  --新增请假申请信息
  function Get_Leave_Info(DataId          out varchar2,
                          OperationUserId in varchar2,
                          CUR_INFO        out sys_refcursor,
                          CUR_FLOW        out sys_refcursor,
                          CUR_FILE        out sys_refcursor,
                          ErrMsg          out varchar2) return number;

  --新增外出申请信息
  function Get_Egress_Info(DataId          out varchar2,
                           OperationUserId in varchar2,
                           CUR_INFO        out sys_refcursor,
                           CUR_FLOW        out sys_refcursor,
                           CUR_FILE        out sys_refcursor,
                           ErrMsg          out varchar2) return number;

  --新增发布公告信息
  function Get_News_Info(DataId          out varchar2,
                         OperationUserId in varchar2,
                         CUR_INFO        out sys_refcursor,
                         CUR_NUMB        out sys_refcursor,
                         CUR_FLOW        out sys_refcursor,
                         CUR_FILE        out sys_refcursor,
                         ErrMsg          out varchar2) return number;

  --新增报销信息
  function Get_Expense_Info(DataId          out varchar2,
                            OperationUserId in varchar2,
                            CUR_INFO        out sys_refcursor,
                            CUR_ITEM        out sys_refcursor,
                            CUR_FLOW        out sys_refcursor,
                            CUR_FILE        out sys_refcursor,
                            ErrMsg          out varchar2) return number;

end pkg_user_get;
/

