create PACKAGE BODY PKG_USER AS

    FUNCTION Update_User(PUserInfo         IN VARCHAR2,
                         OperationUserId   IN VARCHAR2,
                         UserId            IN OUT VARCHAR2,
                         V_ORGANIZATION_ID out char,
                         ErrMsg            OUT VARCHAR2)
        RETURN NUMBER IS
        DATAARR  PKG_COMMON.ARR_LONGSTR;
        P_ID     CHAR(32);
        P_STEP   NUMBER(2);
        n_optype number(1);
        n_result number(1) := 0;
    BEGIN
        BEGIN
            P_STEP  := 0;
            DATAARR := PKG_COMMON.Split(PUserInfo, '^');
            P_ID    := DATAARR(1);
            IF P_ID IS NULL THEN
            
                P_ID := LOWER(SYS_GUID());
            
                INSERT INTO LCBASE.T_ZIP_USER
                    (C_USER_ID,
                     C_ORGANIZATION_ID,
                     V_USER_NAME,
                     N_USER_TYPE,
                     N_WORK_ID,
                     V_PET_NAME,
                     N_MOBILE_1,
                     N_MOBILE_2,
                     V_TEL_1,
                     V_TEL_2,
                     N_STATUS,
                     V_EMAIL,
                     C_PASSWORD,
                     V_WX_OPEN_ID,
                     V_WORK_WX_ACCOUNT,
                     N_SEX,
                     N_AUTHORITY,
                     N_WORK_WX_ACTIVATION,
                     V_HEADPIC_ALY)
                values
                    (P_ID,
                     DATAARR(2),
                     DATAARR(3),
                     DATAARR(4),
                     DATAARR(5),
                     DATAARR(6),
                     DATAARR(7),
                     DATAARR(8),
                     DATAARR(9),
                     DATAARR(10),
                     1, --DATAARR(11),
                     DATAARR(12),
                     lower(lcbase.md5('lecarlink2020')), --DATAARR(13),
                     DATAARR(14),
                     DATAARR(15),
                     DATAARR(16),
                     DATAARR(17),
                     DATAARR(18),
                     DATAARR(19)
                     
                     );
                --commit;
                UserId            := P_ID;
                V_ORGANIZATION_ID := DATAARR(2);
                ErrMsg            := '插入成功';
                RETURN 0;
            ELSE
            
                UPDATE lcbase.T_ZIP_USER
                   set C_ORGANIZATION_ID = DATAARR(2),
                       V_USER_NAME       = DATAARR(3),
                       N_USER_TYPE       = DATAARR(4),
                       N_WORK_ID         = DATAARR(5),
                       V_PET_NAME        = DATAARR(6),
                       N_MOBILE_1        = DATAARR(7),
                       N_MOBILE_2        = DATAARR(8),
                       V_TEL_1           = DATAARR(9),
                       V_TEL_2           = DATAARR(10),
                       N_STATUS          = DATAARR(11),
                       V_EMAIL           = DATAARR(12),
                       --C_PASSWORD           = lcbase.md5(DATAARR(13)),
                       V_WX_OPEN_ID         = DATAARR(14),
                       V_WORK_WX_ACCOUNT    = DATAARR(15),
                       N_SEX                = DATAARR(16),
                       N_AUTHORITY          = DATAARR(17),
                       N_WORK_WX_ACTIVATION = DATAARR(18),
                       V_HEADPIC_ALY        = DATAARR(19)
                 WHERE C_USER_ID = UserId;
            
            END IF;
            --commit;
            ErrMsg := '更新成功';
            RETURN 0;
        
        EXCEPTION
            WHEN ACCESS_INTO_NULL THEN
                ErrMsg := '数据不能为空';
                ROLLBACK;
            WHEN CASE_NOT_FOUND THEN
                ErrMsg := '没有找到数据';
                ROLLBACK;
            WHEN NO_DATA_FOUND THEN
                ErrMsg := '没有找到数据' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
                ROLLBACK;
            WHEN INVALID_NUMBER THEN
                ErrMsg := '无效数字' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
                ROLLBACK;
            WHEN VALUE_ERROR THEN
                ErrMsg := '数据错误' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
                ROLLBACK;
            WHEN OTHERS THEN
                ErrMsg := '新增/更新用户信息失败: ' || P_STEP || ',' ||
                          SQLCODE || ',' || SQLERRM || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
                ROLLBACK;
        END;
    
        return - 1;
    END;

    FUNCTION Delete_User(UserId          IN VARCHAR2,
                         OperationUserId IN VARCHAR2,
                         ErrMsg          OUT VARCHAR2)
        RETURN NUMBER IS
        n_optype number(1);
        n_result number(1) := 0;
    BEGIN
        BEGIN
            n_optype := 4;
            UPDATE T_ZIP_USER
               SET N_STATUS = 1
             WHERE C_USER_ID = UserId;
        
            COMMIT;
            n_result := 1;
            PKG_COMMON.InsertOperationLog(OperationUserId,
                                          'T_USER',
                                          n_optype,
                                          n_result);
            RETURN 0;
        EXCEPTION
            WHEN ACCESS_INTO_NULL THEN
                ErrMsg := '数据不能为空';
                ROLLBACK;
            WHEN CASE_NOT_FOUND THEN
                ErrMsg := '没有找到数据';
                ROLLBACK;
            WHEN NO_DATA_FOUND THEN
                ErrMsg := '没有找到数据' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
                ROLLBACK;
            WHEN INVALID_NUMBER THEN
                ErrMsg := '无效数字' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
                ROLLBACK;
            WHEN VALUE_ERROR THEN
                ErrMsg := '数据错误' || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
                ROLLBACK;
            WHEN OTHERS THEN
                ErrMsg := '删除用户信息失败: ' || SQLCODE || ',' ||
                          SQLERRM || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
                ROLLBACK;
        END;
        PKG_COMMON.InsertOperationLog(OperationUserId,
                                      'T_USER',
                                      n_optype,
                                      n_result);
        return - 1;
    END;

    FUNCTION Get_User(UserId          IN VARCHAR2,
                      OperationUserId IN VARCHAR2,
                      --       PUserInfo       OUT VARCHAR2,
                      CUR_DATA OUT SYS_REFCURSOR,
                      ErrMsg   OUT VARCHAR2) RETURN NUMBER IS
        n_result number(1) := 0;
    BEGIN
        BEGIN
            OPEN CUR_DATA FOR
                SELECT *
                  FROM T_ZIP_USER
                 WHERE C_USER_ID = UserId and d_enddate > sysdate;
            n_result := 1;
            return 0;
        EXCEPTION
            WHEN OTHERS THEN
                ErrMsg := '查询数据失败: ' || SQLCODE || ',' ||
                          SQLERRM || ',' ||
                          DBMS_UTILITY.format_error_backtrace;
        END;
        PKG_COMMON.InsertOperationLog(OperationUserId,
                                      'T_USER',
                                      1,
                                      n_result);
        RETURN - 1;
    END;

    FUNCTION Login_User(UserAccount  VARCHAR2,
                        UserPassword VARCHAR2,
                        LoginType    NUMBER,
                        CUR_DATA     OUT SYS_REFCURSOR,
                        ErrMsg       OUT VARCHAR2)
        RETURN NUMBER IS
        user_count   NUMBER;
        valid_count  NUMBER;
        ReturnNumber NUMBER;
    BEGIN
        select count(1),
               sum(case
                       when c_password = UserPassword then
                        1
                       else
                        0
                   end)
          INTO user_count, valid_count
          from t_zip_user t
         where t.n_mobile_1 = UserAccount;
        if user_count = 0 then
            ErrMsg       := '用户账户不存在';
            ReturnNumber := 30002;
        elsif valid_count = 0 then
            ErrMsg       := '密码错误';
            ReturnNumber := 30004;
        else
            open CUR_DATA for
                select *
                  from t_zip_user a
                  left join t_user_pic b
                    on a.c_user_id = b.c_user_id
                   and b.n_pic_type = 5
                 where n_mobile_1 = UserAccount
                   and c_password = UserPassword
                   and a.d_enddate > sysdate
                   ;
            ReturnNumber := 0;
        end if;
        return ReturnNumber;
    EXCEPTION
        WHEN OTHERS THEN
            ErrMsg := SQLCODE || ',' || SQLERRM;
            RETURN - 1; --其它错误
    END;

    -- 用户重名，返回工号
    function getUserWorkNo(UserId in varchar2) RETURN VARCHAR2 AS
        N_COUNT  NUMBER(4);
        cur_data varchar2(50);
    BEGIN
        select count(*)
          into n_count
          from lcbase.t_zip_user tt
         where tt.v_user_name =
               (select t.v_user_name
                  from lcbase.t_zip_user t
                 where t.c_user_id = UserId and t.d_enddate > sysdate) and tt.d_enddate > sysdate;
    
        if n_count > 1 then
            select t.v_user_name ||
                   decode(e.n_work_num,
                          null,
                          '',
                          '(' || e.n_work_num || ')')
              into cur_data
              from lcbase.t_zip_user t
              left join lcbase.t_employees_info e
                on e.c_user_id = t.c_user_id and t.d_enddate > sysdate
             where t.c_user_id = UserId;
        
        else
        
            select t.v_user_name
              into cur_data
              from lcbase.t_zip_user t
             where t.c_user_id = UserId and t.d_enddate > sysdate;
        
        end if;
        return cur_data;
    END;
END PKG_USER;
/

