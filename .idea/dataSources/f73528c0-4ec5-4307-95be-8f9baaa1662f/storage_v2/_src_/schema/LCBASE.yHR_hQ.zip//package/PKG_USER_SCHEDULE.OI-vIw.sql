create package        pkg_user_schedule is

  -- Author  : ROCK
  -- Created : 2020/3/17 16:53:06
  -- Purpose : 消息、待办、日程维护

  TYPE ARR_UID is Table OF varchar2(32) INDEX BY pls_integer;
  TYPE ARR_LONGSTR is Table OF varchar2(4000) INDEX BY pls_integer;

  --新增请假申请信息
  function Insert_Leave_Info(DataInfo        in varchar2,
                             OperationUserId in varchar2,
                             DataId          out varchar2,
                             ErrMsg          out varchar2) return number;

  --修改请假申请信息
  function Update_Leave_Info(DataInfo        in varchar2,
                             OperationUserId in varchar2,
                             ErrMsg          out varchar2) return number;

  --新增外出申请信息
  function Insert_Egress_Info(DataInfo        in varchar2,
                              OperationUserId in varchar2,
                              DataId          out varchar2,
                              ErrMsg          out varchar2) return number;

  --修改外出申请信息
  function Update_Egress_Info(DataInfo        in varchar2,
                              OperationUserId in varchar2,
                              ErrMsg          out varchar2) return number;

  --新增发布公告信息
  function Insert_News_Info(DataInfo        in varchar2,
                            OperationUserId in varchar2,
                            DataId          out varchar2,
                            ErrMsg          out varchar2) return number;

  --修改发布公告信息
  function Update_News_Info(DataInfo        in varchar2,
                            OperationUserId in varchar2,
                            ErrMsg          out varchar2) return number;

  --新增报销信息
  function Insert_Expense_Info(DataInfo        in varchar2,
                               OperationUserId in varchar2,
                               DataId          out varchar2,
                               ErrMsg          out varchar2) return number;

  --修改报销信息
  function Update_Expense_Info(DataInfo        in varchar2,
                               OperationUserId in varchar2,
                               ErrMsg          out varchar2) return number;

  --根据业务ID获得审批状态
  function Get_Approval_Status(APPROVAL_ID VARCHAR2,
                               CUR_DATA    OUT SYS_REFCURSOR,
                               ErrMsg      out varchar2) return number;

  --将业务ID对应的审批流插入数据库
  procedure Insert_Approval_Flow(ApprovalId          in varchar2,
                                 UserId              in varchar2,
                                 ApprovalType        in number,
                                 FirstApprovalUserId out varchar2);
  --下一个待办项
  procedure Insert_Approval_Next_Todo_Info(ApprovalId in varchar2,
                                           PreFlowId  in varchar2);

  --将业务ID对应的审批流从数据库删除
  function Remove_Approval_Flow(ApprovalId in varchar2,
                                ErrMsg     out varchar2) return number;

  procedure Send_New_Message(MsgType    in number,
                             MsgTitle   in varchar2,
                             MsgUserId  in varchar2,
                             MsgSrcId   in varchar2,
                             MsgContent in varchar2,
                             MsgSender  in varchar2);

  --业务审批通过
  function Approval_Target_Pass(ApprovalId     in varchar2,
                                ApprovalUserId in varchar2,
                                ApprovalRemark in varchar2,
                                ApprovalType   in number,
                                ErrMsg         out varchar2) return number;
  --业务审批拒绝
  function Approval_Target_Reject(ApprovalId     in varchar2,
                                  ApprovalUserId in varchar2,
                                  ApprovalRemark in varchar2,
                                  ApprovalType   in number,
                                  ErrMsg         out varchar2) return number;

  --业务审批撤销
  function Approval_Target_Cancel(ApprovalId     in varchar2,
                                  ApprovalUserId in varchar2,
                                  ApprovalRemark in varchar2,
                                  ApprovalType   in number,
                                  ErrMsg         out varchar2) return number;

  --新增日程设置信息
  function Insert_Schedule_Info(DataInfo        IN VARCHAR2,
                                OperationUserId IN VARCHAR2,
                                DataId          OUT VARCHAR2,
                                ErrMsg          OUT VARCHAR2) RETURN NUMBER;

  --修改日程设置信息
  function Update_Schedule_Info(DataInfo        IN VARCHAR2,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) RETURN NUMBER;

  --删除日程设置信息
  function Remove_Schedule_Info(ScheduleId      IN VARCHAR2,
                                OperationUserId IN VARCHAR2,
                                ErrMsg          OUT VARCHAR2) RETURN NUMBER;

end pkg_user_schedule;
/

